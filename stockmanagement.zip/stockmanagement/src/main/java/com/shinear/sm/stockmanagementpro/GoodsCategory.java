﻿package com.shinear.sm.stockmanagementpro;

import javax.ejb.*;
import java.util.*;

public interface GoodsCategory extends javax.ejb.EJBLocalObject {
  public Integer getCategoryId();
  public void setParentId(int parentId);
  public int getParentId();
  public void setCategoryName(String categoryName);
  public String getCategoryName();
  public void setCategoryDescription(String categoryDescription);
  public String getCategoryDescription();
}
﻿package com.shinear.sm.stockmanagementpro;

import javax.ejb.*;
import java.util.*;

public interface UserTable extends javax.ejb.EJBLocalObject {
  public String getUserName();
  public void setUserPassword(String userPassword);
  public String getUserPassword();
  public void setBaseInforFunction(int baseInforFunction);
  public int getBaseInforFunction();
  public void setStockFunction(int stockFunction);
  public int getStockFunction();
  public void setStockManageFunction(int stockManageFunction);
  public int getStockManageFunction();
  public void setSaleFunction(int saleFunction);
  public int getSaleFunction();
}
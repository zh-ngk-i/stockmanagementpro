﻿package com.shinear.sm.stockmanagementpro;

import javax.ejb.*;
import java.util.*;

public interface GoodsHome extends javax.ejb.EJBLocalHome {
  public Goods create(String goodsBarCode, int categoryId, String goodsName, String goodsNickName, String goodsAssistantName, String goodsPYName, String unit, String specification, String producer, int upperLimit, int lowerLimit, double salePrice, double discount) throws CreateException;
  public Collection findDiscountGoods() throws FinderException;
  public Collection findByGoodsCategory(int categoryId) throws FinderException;
  public Collection findByGoodsBarCode(String goodsBarCode) throws FinderException;
  public Collection findByGoodsName(String goodsName) throws FinderException;
  public Collection findByProducer(String producer) throws FinderException;
  public Goods findByPrimaryKey(String goodsBarCode) throws FinderException;
}
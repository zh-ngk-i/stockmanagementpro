﻿package com.shinear.sm.cactustest;

import org.apache.cactus.*;
import com.shinear.sm.stockmanagementpro.*;
import javax.naming.*;
import java.util.Collection;
import java.rmi.RemoteException;

public class TestAccountNameCactus1 extends ServletTestCase {
  private static final String ERROR_NULL_REMOTE = "接口未定义.";
  private static final int MAX_OUTPUT_LINE_LENGTH = 100;
  private boolean logging = false;
  private AccountNameHome accountNameHome = null;
  private AccountName accountName = null;

  public TestAccountNameCactus1(String name) {
    super(name);
  }

  public void initializeLocalHome() throws Exception {
    Context context = new InitialContext();
    accountNameHome = (AccountNameHome) context.lookup("AccountName");
  }

  public void setUp() throws Exception {
    super.setUp();
    initializeLocalHome();
  }

  public void tearDown() throws Exception {
    accountNameHome = null;
    accountName = null;
    super.tearDown();
  }
  //测试创建会计科目的方法
  public void testAccountNameCreate() throws Exception{
    //创建会计科目
    accountNameHome.create(new Integer(1), 0, "流动资产");
    //创建会计科目
    accountNameHome.create(new Integer(2), 0, "固定资产");
    //创建会计科目
    accountNameHome.create(new Integer(3), 1, "现金");
    //创建会计科目
    accountNameHome.create(new Integer(4), 1, "银行存款");
  }
  //测试修改会计科目的方法
  public void testAccountNameUpdate() throws Exception{
    accountName = accountNameHome.findByPrimaryKey(new Integer(1));
    //更新会计科目的值
    accountName.setParentId(0);
    accountName.setAccountName("流动资产(更新)");
  }
  //测试取得全部记录的方法
  public void testFindAll() throws Exception {
    Collection returnValue = accountNameHome.findAll();
    this.assertEquals("", 4, returnValue.size());
  }
  //测试根据父标识取得记录的方法
  public void testFindByParentId() throws Exception {
    Collection returnValue = accountNameHome.findByParentId(1);
    this.assertEquals("", 2, returnValue.size());
  }
  //测试删除会计科目的方法
  public void testAccountNameDelete() throws Exception{
    accountName = accountNameHome.findByPrimaryKey(new Integer(1));
    //删除会计科目
    accountName.remove();
    accountName = accountNameHome.findByPrimaryKey(new Integer(2));
    //删除会计科目
    accountName.remove();
    accountName = accountNameHome.findByPrimaryKey(new Integer(3));
    //删除会计科目
    accountName.remove();
    accountName = accountNameHome.findByPrimaryKey(new Integer(4));
    //删除会计科目
    accountName.remove();
  }
}
﻿package com.shinear.sm.servlet;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import com.shinear.sm.data.*;

public class UserLogView extends HttpServlet {
  private static final String CONTENT_TYPE = "text/html; charset=GBK";
  public void init() throws ServletException {
  }
  public void doPost(HttpServletRequest request, HttpServletResponse response) throws
      ServletException, IOException {
    //设置取得字符串的编码机制
    request.setCharacterEncoding("GBK");
    //设置字符输出的编码机制
    response.setContentType(CONTENT_TYPE);
    //取得html代码输出类
    PrintWriter out = response.getWriter();
    //通过HttpServlet类的getServletContext方法取得application的对象
    ServletContext application = getServletContext();
    //创建session对象
    HttpSession session = request.getSession();
    //声明页面转向类
    RequestDispatcher requestDispatcher = null;
    //创建数据类
    StockManagementData stockManagementData = new StockManagementData();
    //创建用户日志数组
    String[][] userLog = new String[0][5];
    //根据传入参数取得用户日志数组
    if(request.getParameter("selectedIndex") != null){
      int selectedIndex = Integer.parseInt(request.getParameter("selectedIndex"));
      String searchValue = request.getParameter("searchValue");
      if(selectedIndex == 0 | selectedIndex == 1 | selectedIndex == 2){
        if(searchValue.length() == 0){
          out.print("查询值为空，请<a href=\"javascript:history.back()\">重新输入</a>.");
          return;
        }
      }
      switch (selectedIndex) {
        case 0:
          //根据操作程序名字取得用户日志数组
          userLog = stockManagementData.getUserLogByProgramName(searchValue);
          break;
        case 1:
          //根据操作内容取得用户日志数组
          userLog = stockManagementData.getUserLogByOperationContent(searchValue);
          break;
        case 2:
          //根据用户名字取得用户日志数组
          userLog = stockManagementData.getUserLogByUserName(searchValue);
          break;
        case 3:
          /*根据操作时间取得用户日志数组*/
          //取得日期变量
          String startDateStr = request.getParameter("startDate");
          String endDateStr = request.getParameter("endDate");
          //创建日期变量
          int[] startDateInts = new int[3];
          int[] endDateInts = new int[3];
          Calendar startCalendar = Calendar.getInstance();
          Calendar endCalendar = Calendar.getInstance();
          java.sql.Timestamp startDate = null;
          java.sql.Timestamp endDate = null;
          /*检查开始日期字符串*/
          //创建日期类
          Calendar date = Calendar.getInstance();
          //创建默认的日期格式的DateFormat类
          java.text.DateFormat dateFormat1 = java.text.DateFormat.getDateInstance();
          try{
            date.setTime(dateFormat1.parse(startDateStr));
            startDateInts[0] = date.get(Calendar.YEAR);
            startDateInts[1] = date.get(Calendar.MONTH);
            startDateInts[2] = date.get(Calendar.DAY_OF_MONTH);
          }catch(Exception ex){
            startDateInts[0] = -1;
          }
          if(startDateInts[0] == -1){
            out.print("开始日期输入错误，正确的日期格式是yyyy-mm-dd（年-月-日），如2004-1-1"
                    + "请<a href=\"javascript:history.back()\">重新输入</a>.");
            return;
          }
          //取得开始日期
          startCalendar.set(startDateInts[0], startDateInts[1], startDateInts[2],
                            0, 0, 0);
          startDate = new java.sql.Timestamp(startCalendar.getTime().getTime());
          //如果结束日期字符为空,显示开始日期至当前日期的记录
          if(endDateStr.length() == 0){
            endDate = new java.sql.Timestamp(endCalendar.getTime().getTime());
          }else{
            //检查结束日期字符串
            try{
              date.setTime(dateFormat1.parse(endDateStr));
              endDateInts[0] = date.get(Calendar.YEAR);
              endDateInts[1] = date.get(Calendar.MONTH);
              endDateInts[2] = date.get(Calendar.DAY_OF_MONTH);
            }catch(Exception ex){
              endDateInts[0] = -1;
            }
            if(endDateInts[0] == -1){
              out.print("结束日期输入错误，正确的日期格式是yyyy-mm-dd（年-月-日），如2004-1-1"
                      + "请<a href=\"javascript:history.back()\">重新输入</a>.");
              return;
            }
            //取得结束日期
            endCalendar.set(endDateInts[0], endDateInts[1], endDateInts[2], 23, 59, 59);
            endDate = new java.sql.Timestamp(endCalendar.getTime().getTime());
          }
          //根据日期取得用户日志记录
          userLog = stockManagementData.getUserLogByOperationDate(startDate, endDate);
          break;
      }
    }
    //创建页面转向类
    requestDispatcher = application.getRequestDispatcher("/userlogview.jsp");
    //将数组放入request对象
    request.setAttribute("userLog", userLog);
    requestDispatcher.forward(request, response);
  }
  public void destroy() {
  }
}
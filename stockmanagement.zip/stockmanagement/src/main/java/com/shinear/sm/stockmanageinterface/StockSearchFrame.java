﻿package com.shinear.sm.stockmanageinterface;

import java.awt.*;
import java.awt.event.*;
import javax.swing.event.*;
import javax.swing.*;
import java.util.*;
import com.shinear.sm.data.*;
import com.shinear.sm.maininterface.*;
import com.shinear.sm.user.*;
import com.shinear.sm.method.*;

public class StockSearchFrame extends JFrame implements ActionListener {
  JPanel contentPane;
  //创建标签控件
  JLabel jLabel1 = new JLabel();
  JLabel jLabel2 = new JLabel();
  //创建按钮控件
  JButton jButton1 = new JButton();
  JButton jButton2 = new JButton();
  JButton jButton3 = new JButton();
  JButton jButton4 = new JButton();
  //创建编辑框控件
  JTextField jTextField1 = new JTextField();
  JTextField jTextField2 = new JTextField();
  //创建滚动框控件
  JScrollPane jScrollPane1 = new JScrollPane();
  JScrollPane jScrollPane2 = new JScrollPane();
  //创建列表框数据类和列表框控件
  DefaultListModel listData1 = new DefaultListModel();
  JList jList1 = new JList(listData1);
  //创建表格控件
  JTable jTable1 = new JTable();
  //创建表格模式类
  StockManagementTableModel smTableModel = new StockManagementTableModel();
  //创建标题数组
  String[] warehouseColNames = {"仓库", "进货价", "数量",  "金额", "有效期"};
  String[] goodsBarcodeColNames = {"商品条形码", "进货价", "数量",  "金额", "有效期"};
  //创建字体类
  Font dialog13 = new java.awt.Font("Dialog", 0, 13);
  //声明数据类
  StockManagementData stockManagementData = null;
  //声明用户类
  User user = null;
  //声明主窗口类
  StockManagementMainFrame stockManagementMainFrame = null;
  //创建仓库数组
  String[][] warehouses = new String[0][4];
  //创建商品数组
  String[][] goods = new String[0][13];
  //创建库存商品数组
  String[][] stockGoodsArray = new String[0][5];
  //创建帐套日期字符串
  String ledgerDate = "";
  //创建记录查询状态的变量，0表示根据仓库查询，1表示根据商品条形码查询
  int searchInt = 0;
  //创建方法类
  DataMethod dataMethod = new DataMethod();

  public StockSearchFrame(StockManagementMainFrame stockManagementMainFrame) {
    this.stockManagementMainFrame = stockManagementMainFrame;
    //取得主窗口的数据类
    stockManagementData = stockManagementMainFrame.getStockManagementData();
    //取得主窗口的用户类
    user = stockManagementMainFrame.getUser();
    //取得主窗口的账套日期
    ledgerDate = stockManagementMainFrame.getLedgerDate();
    //取得库存模块的用户权限
    int stockManageFunction = user.getStockManageFunction();
    //检查用户权限
    if ( (stockManageFunction & 64) != 64) {
      JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
      System.exit(0);
    }
    //检查账套日期
    if(ledgerDate.length() == 0){
      JOptionPane.showMessageDialog(null, user.getUserName() + "请选择账套.");
      return;
    }
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception  {
    contentPane = (JPanel) this.getContentPane();
    contentPane.setLayout(null);
    this.setSize(new Dimension(667, 352));
    this.setTitle("库存商品查询窗口");
    //设置标签的属性
    jLabel1.setText("数据表格");
    jLabel1.setBounds(new Rectangle(195, 24, 165, 16));
    jLabel2.setText("总金额");
    jLabel2.setBounds(new Rectangle(490, 24, 76, 16));
    //设置编辑框的属性
    jTextField1.setBounds(new Rectangle(28, 19, 80, 22));
    jTextField2.setEditable(false);
    jTextField2.setBounds(new Rectangle(550, 24, 80, 22));
    //设置按钮的属性
    jButton1.setText("查询");
    jButton1.setActionCommand("search");
    jButton1.setBounds(new Rectangle(115, 19, 63, 25));
    jButton2.setText("根据仓库查询");
    jButton2.setActionCommand("warehouse");
    jButton2.setBounds(new Rectangle(28, 257, 166, 25));
    jButton3.setText("根据商品条形码查询");
    jButton3.setActionCommand("goodsBarcode");
    jButton3.setBounds(new Rectangle(246, 257, 166, 25));
    jButton4.setText("退出");
    jButton4.setActionCommand("exit");
    jButton4.setBounds(new Rectangle(464, 257, 166, 25));
    //设置滚动框的属性
    jScrollPane1.setBounds(new Rectangle(28, 52, 152, 195));
    jScrollPane2.setBounds(new Rectangle(195, 52, 435, 195));
    jScrollPane1.getViewport().add(jList1, null);
    jScrollPane2.getViewport().add(jTable1, null);
    //为列表框加入选择接收器
    jList1.addListSelectionListener(new ListSelectionListener() {
      public void valueChanged(ListSelectionEvent e) {
        //当多种事件被激发的时候,不执行接收器后面的代码
        if (e.getValueIsAdjusting()) return;
        jList1_valueChanged(e);
      }
    });
    //为面板加入各个控件
    contentPane.add(jLabel1, null);
    contentPane.add(jLabel2, null);
    contentPane.add(jTextField1, null);
    contentPane.add(jTextField2, null);
    contentPane.add(jButton1, null);
    contentPane.add(jButton2, null);
    contentPane.add(jButton4, null);
    contentPane.add(jButton3, null);
    contentPane.add(jScrollPane2, null);
    contentPane.add(jScrollPane1, null);
    //设置窗口类的字体和为按钮加入动作接收器
    setupFontAndListener();
  }
  //设置窗口类的字体和为按钮加入动作接收器的方法
  public void setupFontAndListener(){
    Component[] components = contentPane.getComponents();
    //创建临时按钮控件
    JButton tmpBtn = new JButton();
    for(int i = 0; i < components.length; i++){
      components[i].setFont(dialog13);
      if(components[i].getClass().getName().equals("javax.swing.JButton")){
        tmpBtn = (JButton)components[i];
        tmpBtn.addActionListener(this);
      }
    }
  }
  //退出方法
  public void exit(){
    //隐藏窗口
    this.setVisible(false);
    //清空数组的内容
    warehouses = new String[0][4];
    goods = new String[0][13];
    stockGoodsArray = new String[0][4];
    //清空列表框的内容
    listData1.clear();
    //清空表格的内容
    this.showTableData(stockGoodsArray);
    //取得面板上的所有控件
    Component[] components = contentPane.getComponents();
    //创建临时编辑框控件
    JTextField tmpTextField = new JTextField();
    for(int i = 0; i < components.length; i++){
      if(components[i].getClass().getName().equals("javax.swing.JTextField")){
        tmpTextField = (JTextField)components[i];
        //清空编辑框的内容
        tmpTextField.setText("");
      }
    }

  }
  //设置用户的方法
  public void setUser(User user) {
    this.user = user;
  }
  //设置账套的方法
  public void setLedgerDate(String ledgerDate) {
    this.ledgerDate = ledgerDate;
  }
  protected void processWindowEvent(WindowEvent e) {
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      exit();
    }
  }
  //显示仓库的方法
  public void showWarehouse(){
    listData1.clear();
    //取得仓库的值
    warehouses = stockManagementData.getAllWarehouse();
    //为列表框加入数据
    for(int i = 0; i < warehouses.length; i++){
      listData1.addElement(warehouses[i][0]);
    }
  }
  //显示商品条形码的方法
  public void showGoodsBarcode(){
    listData1.clear();
    //取得商品数据全部条形码的值,该方法参考6.8节
    goods = stockManagementData.getGoodsByGoodsBarCode("");
    //为列表框加入数据
    for(int i = 0; i < goods.length; i++){
      listData1.addElement(goods[i][0]);
    }
  }
  //根据列表框数据显示记录的方法
  public void showStockGoodsArray(){
    //取得当前选择项的位置
    int selectedIndex = jList1.getSelectedIndex();
    //当列表框不处于选择状态，不显示数据
    if(selectedIndex == -1){
       return;
    }
    //取得查询值
    String searchValue = (String)listData1.getElementAt(selectedIndex);
    if(searchInt == 0){
      //根据仓库显示商品数量和金额
      stockGoodsArray = stockManagementData.getStockByWarehouse(ledgerDate, searchValue, 2);
    }else if(searchInt == 1){
     //根据商品条形码显示商品数量和金额
     stockGoodsArray = stockManagementData.getStockByGoodsBarcode(ledgerDate, searchValue, 2);
    }
    //显示表格数据
    this.showTableData(stockGoodsArray);
    //显示总金额
    this.recountGoodsAmount();
  }

  //显示表格内容的方法
  public void showTableData(Object[][] detail){
    //设置表格的标题
    if(searchInt == 0){
      smTableModel.setColumnNames(goodsBarcodeColNames);
    }else if(searchInt == 1){
      smTableModel.setColumnNames(warehouseColNames);
    }
    //设置表格的数据
    smTableModel.setData(detail);
    jTable1 = new JTable(smTableModel);
    //设置表格的字体
    jTable1.setFont(dialog13);
    //将数据表格加入数据滚动框
    jScrollPane2.getViewport().add(jTable1, null);
    //设置列的宽度
    jTable1.getColumnModel().getColumn(0).setPreferredWidth(30);
    jTable1.getColumnModel().getColumn(1).setPreferredWidth(20);
    jTable1.getColumnModel().getColumn(2).setPreferredWidth(20);
    jTable1.getColumnModel().getColumn(3).setPreferredWidth(20);
    jTable1.getColumnModel().getColumn(4).setPreferredWidth(50);
  }
  //计算金额方法
  public void recountGoodsAmount(){
    double amount = 0;
    double total = 0;
    for(int i = 0; i < stockGoodsArray.length; i++){
      //整理数据
      stockGoodsArray[i][1] = String.valueOf(dataMethod.round(Double.
          parseDouble(stockGoodsArray[i][1])));
      stockGoodsArray[i][3] = String.valueOf(dataMethod.round(Double.
          parseDouble(stockGoodsArray[i][3])));
      //取得单个记录金额
      amount = Double.parseDouble(stockGoodsArray[i][3]);
      total += amount;
    }
    jTextField2.setText(String.valueOf(dataMethod.round(total)));
  }
  //清空数据的方法
  public void clearStockGoodsArray(){
    stockGoodsArray = new String[0][5];
    this.showTableData(stockGoodsArray);
  }
  //列表1的选择事件
  void jList1_valueChanged(ListSelectionEvent e) {
    if(listData1.size() > 0){
      this.showStockGoodsArray();
    }else{
      this.clearStockGoodsArray();
    }
  }
  public void search(){
    String searchValue = jTextField1.getText().trim();
    if (searchValue.length() == 0) {
      JOptionPane.showMessageDialog(null, "请输入查询值");
      return;
    }
    jList1.setSelectedIndex(listData1.indexOf(searchValue));
  }
  //单击事件
  public void actionPerformed(ActionEvent e) {
    //取得按钮的动作字符串
    String actionCommand = e.getActionCommand().trim();
    if (actionCommand.equals("search")) {
      search();
    }else if(actionCommand.equals("warehouse")){
      //显示仓库名
      this.showWarehouse();
      searchInt = 0;
    }else if(actionCommand.equals("goodsBarcode")){
      //显示商品条形码
      this.showGoodsBarcode();
      searchInt = 1;
    }else if(actionCommand.equals("exit")){
      exit();
    }
  }
}
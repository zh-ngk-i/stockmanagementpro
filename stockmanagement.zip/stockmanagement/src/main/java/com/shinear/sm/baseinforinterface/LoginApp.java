﻿package com.shinear.sm.baseinforinterface;

import javax.swing.UIManager;
import java.awt.*;
import com.shinear.sm.maininterface.*;

public class LoginApp {

  public LoginApp() {
    //创建主窗口类，该类供测试使用
    StockManagementMainFrame stockManagementMainFrame = new StockManagementMainFrame();
    //通过构造方法传入主窗口类
    LoginFrame frame = new LoginFrame(stockManagementMainFrame);
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = frame.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }
    frame.setLocation( (screenSize.width - frameSize.width) / 2,
                      (screenSize.height - frameSize.height) / 2);
    frame.setVisible(true);
  }
  public static void main(String[] args) {
    try {
      UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
    }
    catch(Exception e) {
      e.printStackTrace();
    }
    new LoginApp();
  }
}
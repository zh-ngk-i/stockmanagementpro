﻿package com.shinear.sm.baseinforinterface;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.shinear.sm.data.StockManagementData;
import com.shinear.sm.user.User;
import com.shinear.sm.maininterface.*;
import com.shinear.sm.method.*;

public class LedgerManageFrame extends JFrame implements ActionListener {
  JPanel contentPane;
  //创建标签控件
  JLabel jLabel1 = new JLabel();
  JLabel jLabel2 = new JLabel();
  //创建滚动框
  JScrollPane jScrollPane1 = new JScrollPane();
  JScrollPane jScrollPane2 = new JScrollPane();
  //创建列表框数据类和列表框控件
  DefaultListModel listData1 = new DefaultListModel();
  DefaultListModel listData2 = new DefaultListModel();
  JList jList1 = new JList(listData1);
  JList jList2 = new JList(listData2);
  //创建按钮控件
  JButton jButton1 = new JButton();
  JButton jButton2 = new JButton();
  JButton jButton4 = new JButton();
  JButton jButton5 = new JButton();
  JButton jButton3 = new JButton();
  //创建字体类
  Font dialog13 = new java.awt.Font("Dialog", 0, 13);
  //声明数据类
  StockManagementData stockManagementData = null;
  //声明用户类
  User user = null;
  //声明主窗口类
  StockManagementMainFrame stockManagementMainFrame = null;
  //声明方法类
  DataMethod dataMethod = new DataMethod();

  public LedgerManageFrame(StockManagementMainFrame stockManagementMainFrame) {
    this.stockManagementMainFrame = stockManagementMainFrame;
    //取得主窗口的数据类
    stockManagementData = stockManagementMainFrame.getStockManagementData();
    //取得主窗口的用户类
    user = stockManagementMainFrame.getUser();
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception  {
    contentPane = (JPanel) this.getContentPane();
    contentPane.setLayout(null);
    this.setSize(new Dimension(574, 465));
    //设置标签控件
    jLabel1.setText("账套列表：");
    jLabel1.setBounds(new Rectangle(15, 27, 78, 16));
    jLabel2.setText("信息列表：");
    jLabel2.setBounds(new Rectangle(288, 27, 112, 16));
    //设置滚动框控件
    jScrollPane1.setBounds(new Rectangle(15, 57, 257, 300));
    jScrollPane2.setBounds(new Rectangle(288, 57, 257, 300));
    //设置按钮控件
    jButton1.setText("显示账套");
    jButton1.setActionCommand("show");
    jButton1.setBounds(new Rectangle(15, 387, 108, 25));
    jButton2.setText("打开账套");
    jButton2.setActionCommand("open");
    jButton2.setBounds(new Rectangle(128, 387, 108, 25));
    jButton3.setText("创建账套");
    jButton3.setActionCommand("create");
    jButton3.setBounds(new Rectangle(242, 387, 108, 25));
    jButton4.setText("删除账套");
    jButton4.setActionCommand("delete");
    jButton4.setBounds(new Rectangle(355, 387, 108, 25));
    jButton5.setText("退出");
    jButton5.setActionCommand("exit");
    jButton5.setBounds(new Rectangle(468, 387, 77, 25));
    //设置滚动框控件
    jScrollPane1.getViewport().add(jList1, null);
    jScrollPane2.getViewport().add(jList2, null);
    //为面板加入各个控件
    contentPane.add(jLabel1, null);
    contentPane.add(jLabel2, null);
    contentPane.add(jScrollPane1, null);
    contentPane.add(jScrollPane2, null);
    contentPane.add(jButton1, null);
    contentPane.add(jButton2, null);
    contentPane.add(jButton3, null);
    contentPane.add(jButton4, null);
    contentPane.add(jButton5, null);
    //设置窗口类的字体和为按钮加入动作接收器
    setupFontAndListener();
  }
  //设置窗口类的字体和为按钮加入动作接收器的方法
  public void setupFontAndListener(){
    Component[] components = contentPane.getComponents();
    //创建临时按钮控件
    JButton tmpBtn = new JButton();
    for(int i = 0; i < components.length; i++){
      components[i].setFont(dialog13);
      if(components[i].getClass().getName().equals("javax.swing.JButton")){
        tmpBtn = (JButton)components[i];
        tmpBtn.addActionListener(this);
      }
    }
  }
  protected void processWindowEvent(WindowEvent e) {
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      exit();
    }
  }
  //退出方法
  public void exit(){
    //隐藏窗口
    this.setVisible(false);
    //清空列表框的内容
    listData1.clear();
    listData2.clear();
  }
  //设置用户的方法
  public void setUser(User user) {
    this.user = user;
  }

  //显示列表框账套的方法
  public void showLedgerDate(){
    //清空列表框的数据
    listData1.clear();
    //取得账套名字
    String[] ledgerNames = stockManagementData.getLedgerNames();
    for(int i = 0; i < ledgerNames.length; i++){
      listData1.addElement(ledgerNames[i]);
    }
  }
  //单击事件
  public void actionPerformed(ActionEvent e) {
    //清空信息列表框的内容
    listData2.clear();
    //取得用户的权限参数
    int baseInforFunction = user.getBaseInforFunction();
    //取得按钮的动作字符串
    String actionCommand = e.getActionCommand().trim();
    if(actionCommand.equals("create") | actionCommand.equals("delete")){
      if((baseInforFunction & 4) != 4){
        listData2.addElement("该用户不具有创建和删除账套的权限.");
        return;
      }
    }
    //单击按钮的处理代码
    if (actionCommand.equals("show")) {
      showLedgerDate();
    }else if(actionCommand.equals("open")){
      if(jList1.getSelectedIndex() == -1){
        JOptionPane.showMessageDialog(null, "请选择账套.");
        return;
      }
      String ledgerDate = (String)listData1.get(jList1.getSelectedIndex());
      //设置主窗口的账套变量
      stockManagementMainFrame.setLedgerDate(ledgerDate);
      listData2.addElement("已成功打开" + ledgerDate + "账套.");
      //更改主窗口的标题
     stockManagementMainFrame.setTitle("进销存管理信息系统主窗口" + ":登陆用户("
                                       + user.getUserName() + "):帐套(" + ledgerDate + ")");
     //将用户操作写入日志数据表
     stockManagementData.createUserLog("账套管理窗口", "打开账套" + ledgerDate,
                                       user.getUserName());
    }else if(actionCommand.equals("create")){
      String ledgerDate = JOptionPane.showInputDialog(null,
          "您好，请输入账套日期,格式是yyyymm(200405).", "账套日期输入框",
          JOptionPane.INFORMATION_MESSAGE);
      if(ledgerDate == null){
        return;
      }
      //检查账套日期是否合法
      int result = dataMethod.checkLedgerDate(ledgerDate);
      if(result == 0){
        JOptionPane.showMessageDialog(null, "您输入的账套日期不合法，合法格式是yyyymm(200405).");
        return;
      }
      //根据账套日期创建账套
      result = stockManagementData.createLedger(ledgerDate);
      if(result == 1){
        listData2.addElement("已成功创建" + ledgerDate + "账套.");
        showLedgerDate();
      }else{
        listData2.addElement("创建" + ledgerDate + "账套不成功，请检查该账套的日期.");
      }
      //将用户操作写入日志数据表
      stockManagementData.createUserLog("账套管理窗口", "创建账套" + ledgerDate,
                                        user.getUserName());
    }else if(actionCommand.equals("delete")){
      if(jList1.getSelectedIndex() == -1){
        JOptionPane.showMessageDialog(null, "请选择账套.");
        return;
      }
      //取得账套日期
      String ledgerDate = (String)listData1.get(jList1.getSelectedIndex());
      //根据账套日期删除账套
      int result = stockManagementData.deleteLedger(ledgerDate);
      if(result == 1){
        listData2.addElement("已成功删除" + ledgerDate + "账套.");
        showLedgerDate();
      }else{
        listData2.addElement("删除" + ledgerDate + "账套不成功，该账套必须是最后一个账套.");
      }
      //将用户操作写入日志数据表
      stockManagementData.createUserLog("账套管理窗口", "删除账套" + ledgerDate,
                                        user.getUserName());
    }else if(actionCommand.equals("exit")){
      exit();
    }
  }
}
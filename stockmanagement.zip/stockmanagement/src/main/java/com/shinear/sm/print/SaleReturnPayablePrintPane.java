﻿package com.shinear.sm.print;

import javax.swing.*;
import java.awt.*;
import java.awt.print.*;
import java.util.*;

public class SaleReturnPayablePrintPane  extends JPanel{
  final static Color fg = Color.black;

  //创建字体
  Font font16 = new Font("宋体", Font.BOLD, 16);
  Font font11 = new Font("宋体", Font.PLAIN, 11);
  //创建往来账套数组
  static String[] currentAccountLedger = {"", "", "", "", "", "", "", "", "", "0", ""};
  //测试数组
  //static String[] currentAccountLedger = {"20040500001", "st20040500005", "0", "5632",
  //    "客户1", "jack", "jack", "2004-5-5 15:00:00.0", "2004-5-5 15:00:00.0", "0", "备注"};
  //页面左边的空白
  int pageLeftMargin = 88;
  //与左边的距离
  int x = 0;
  //与项部的距离
  int y = 0;
  //行宽
  int lineHeight = 14;
  //行间距
  int lineDistant = 14;
  //创建完成状态数组
  String[] onProcesses = {"进行", "撤消", "完成"};

  //重新绘画
  public void paintComponent(Graphics g) {
    super.paintComponent(g);
    Graphics2D g2 = (Graphics2D) g;
    //设置画笔颜色
    g2.setPaint(fg);
    drawPages(g2);
  }
  public SaleReturnPayablePrintPane() {
    this.setBackground(Color.white);
  }
  /** 打印页面的方法 */
  public void drawPages(Graphics2D g2){
    drawFirstPage(g2);
  }
  public void drawFirstPage(Graphics2D g2){
    //设置字体
    g2.setFont(font16);
    //显示应付票据
    g2.drawString("应付票据", 273, 80);
/*显示第1行的内容*/
    g2.setFont(font11);
    x = pageLeftMargin;
    //第一行与顶部的距离
    y = 114;
    //显示第1列内容
    g2.drawString("票据编号：", x, y);
    x = 148;
    //显示第2列内容
    g2.drawString(currentAccountLedger[0], x, y);
    x = 228;
    //显示第3列内容
    g2.drawString("相关联的票据标识：", x, y);
    x = 325;
    //显示第4列内容
    g2.drawString(currentAccountLedger[1], x, y);
/*显示第2行的内容*/
    x = pageLeftMargin;
    y += lineHeight + lineDistant;
    //显示第1列内容
    g2.drawString("客户名字：", x, y);
    x = 148;
    //显示第2列内容
    g2.drawString(currentAccountLedger[4], x, y);
    x = 228;
    //显示第3列内容
    g2.drawString("开票据用户：", x, y);
    x = 295;
    //显示第4列内容
    g2.drawString(currentAccountLedger[5], x, y);
    x = 379;
    //显示第5列内容
    g2.drawString("现金管理员：", x, y);
    x = 445;
    //显示第6列内容
    g2.drawString(currentAccountLedger[6], x, y);
/*显示第3行的内容*/
    x = pageLeftMargin;
    y += lineHeight + lineDistant;
    //显示第1列内容
    g2.drawString("金额：", x, y);
    x = 148;
    //显示第2列内容
    g2.drawString(currentAccountLedger[3], x, y);
/*显示第4行的内容*/
    x = pageLeftMargin;
    y += lineHeight + lineDistant;
    //显示第1列内容
    g2.drawString("开票据日期：", x, y);
    x = 148;
    //显示第2列内容
    g2.drawString(currentAccountLedger[7], x, y);
    x = 325;
    //显示第3列内容
    g2.drawString("收款日期：", x, y);
    x = 379;
    //显示第4列内容
    g2.drawString(currentAccountLedger[8], x, y);
/*显示第5行的内容*/
    x = pageLeftMargin;
    y += lineHeight + lineDistant;
    //显示第1列内容
    g2.drawString("完成状态：", x, y);
    x = 148;
    //显示第2列内容
    g2.drawString(onProcesses[Integer.parseInt(currentAccountLedger[9])] , x, y);
/*显示第6行的内容*/
    x = pageLeftMargin;
    y += lineHeight + lineDistant;
    //显示第1列内容
    g2.drawString("备注：", x, y);
/*显示第7行的内容*/
    x = pageLeftMargin + 22;
    y += lineHeight + lineDistant;
    //显示第1列内容
    g2.drawString(currentAccountLedger[10], x, y);
/*显示页尾的内容*/
    x = 279;
    y = 789;
    //显示页码
    g2.drawString("第 1 页", x, y);
  }
  public String[] getCurrentAccountLedger() {
    return currentAccountLedger;
  }
  public void setCurrentAccountLedger(String[] currentAccountLedger) {
    this.currentAccountLedger = currentAccountLedger;
  }
}
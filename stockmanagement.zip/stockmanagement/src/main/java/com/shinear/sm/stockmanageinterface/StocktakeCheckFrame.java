﻿package com.shinear.sm.stockmanageinterface;

import java.awt.*;
import java.awt.event.*;
import javax.swing.event.*;
import javax.swing.*;
import java.util.*;
import com.shinear.sm.data.*;
import com.shinear.sm.maininterface.*;
import com.shinear.sm.user.*;

public class StocktakeCheckFrame extends JFrame implements ActionListener {
  JPanel contentPane;
  //创建标签控件
  JLabel jLabel1 = new JLabel();
  JLabel jLabel2 = new JLabel();
  //创建按钮控件
  JButton jButton1 = new JButton();
  JButton jButton2 = new JButton();
  JButton jButton3 = new JButton();
  JButton jButton4 = new JButton();
  JButton jButton5 = new JButton();
  //创建滚动框控件
  JScrollPane jScrollPane1 = new JScrollPane();
  JScrollPane jScrollPane2 = new JScrollPane();
  //创建列表框数据类和列表框控件
  DefaultListModel listData1 = new DefaultListModel();
  JList jList1 = new JList(listData1);
  //创建表格控件
  JTable jTable1 = new JTable();
  //创建表格模式类
  StockManagementTableModel smTableModel = new StockManagementTableModel();
  //创建标题数组
  String[] colNames = {"商品条形码", "库存数", "盘点数",  "差异数"};
  //创建字体类
  Font dialog13 = new java.awt.Font("Dialog", 0, 13);
  //声明数据类
  StockManagementData stockManagementData = null;
  //声明用户类
  User user = null;
  //声明主窗口类
  StockManagementMainFrame stockManagementMainFrame = null;
  //创建仓库数组
  String[][] warehouses = new String[0][4];
  //创建盘点核查数组
  String[][] stocktakeArray = new String[0][4];
  //创建帐套日期字符串
  String ledgerDate = "";

  public StocktakeCheckFrame(StockManagementMainFrame stockManagementMainFrame) {
    this.stockManagementMainFrame = stockManagementMainFrame;
    //取得主窗口的数据类
    stockManagementData = stockManagementMainFrame.getStockManagementData();
    //取得主窗口的用户类
    user = stockManagementMainFrame.getUser();
    //取得主窗口的账套日期
    ledgerDate = stockManagementMainFrame.getLedgerDate();
    //取得库存模块的用户权限
    int stockManageFunction = user.getStockManageFunction();
    //检查用户权限
    if ( (stockManageFunction & 32) != 32) {
      JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
      System.exit(0);
    }
    //检查账套日期
    if(ledgerDate.length() == 0){
      JOptionPane.showMessageDialog(null, user.getUserName() + "请选择账套.");
      return;
    }
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception  {
    contentPane = (JPanel) this.getContentPane();
    contentPane.setLayout(null);
    this.setSize(new Dimension(667, 352));
    this.setTitle("库存盘点核查窗口");
    //设置标签的属性
    jLabel1.setText("仓库列表");
    jLabel1.setBounds(new Rectangle(28, 19, 134, 16));
    jLabel2.setText("盘点单核查表");
    jLabel2.setBounds(new Rectangle(195, 19, 165, 16));
    //设置按钮的属性
    jButton1.setText("显示仓库");
    jButton1.setActionCommand("showWarehouse");
    jButton1.setBounds(new Rectangle(28, 257, 103, 25));
    jButton2.setText("显示差异记录");
    jButton2.setActionCommand("showDifference");
    jButton2.setBounds(new Rectangle(140, 257, 120, 25));
    jButton3.setText("显示相同记录");
    jButton3.setActionCommand("showSame");
    jButton3.setBounds(new Rectangle(269, 257, 120, 25));
    jButton4.setText("显示全部记录");
    jButton4.setActionCommand("showAll");
    jButton4.setBounds(new Rectangle(398, 257, 120, 25));
    jButton5.setText("退出");
    jButton5.setActionCommand("exit");
    jButton5.setBounds(new Rectangle(527, 257, 103, 25));
    //设置滚动框的属性
    jScrollPane1.getViewport().add(jList1, null);
    jScrollPane1.setBounds(new Rectangle(28, 45, 152, 195));
    jScrollPane2.getViewport().add(jTable1, null);
    jScrollPane2.setBounds(new Rectangle(195, 45, 435, 195));
    //为列表框加入选择接收器
    jList1.addListSelectionListener(new ListSelectionListener() {
      public void valueChanged(ListSelectionEvent e) {
        //当多种事件被激发的时候,不执行接收器后面的代码
        if (e.getValueIsAdjusting()) return;
        jList1_valueChanged(e);
      }
    });
    //为面板加入各个控件
    contentPane.add(jLabel1, null);
    contentPane.add(jLabel2, null);
    contentPane.add(jScrollPane1, null);
    contentPane.add(jScrollPane2, null);
    contentPane.add(jButton1, null);
    contentPane.add(jButton2, null);
    contentPane.add(jButton3, null);
    contentPane.add(jButton4, null);
    contentPane.add(jButton5, null);
    //设置窗口类的字体和为按钮加入动作接收器
    setupFontAndListener();
  }
  //设置窗口类的字体和为按钮加入动作接收器的方法
  public void setupFontAndListener(){
    Component[] components = contentPane.getComponents();
    //创建临时按钮控件
    JButton tmpBtn = new JButton();
    for(int i = 0; i < components.length; i++){
      components[i].setFont(dialog13);
      if(components[i].getClass().getName().equals("javax.swing.JButton")){
        tmpBtn = (JButton)components[i];
        tmpBtn.addActionListener(this);
      }
    }
  }
  //退出方法
  public void exit(){
    //隐藏窗口
    this.setVisible(false);
    //清空数组的内容
    warehouses = new String[0][4];
    stocktakeArray = new String[0][4];
    //清空列表框的内容
    listData1.clear();
    //清空表格的内容
    this.showTableData(stocktakeArray);
  }
  //设置用户的方法
  public void setUser(User user) {
    this.user = user;
  }
  //设置账套的方法
  public void setLedgerDate(String ledgerDate) {
    this.ledgerDate = ledgerDate;
  }
  protected void processWindowEvent(WindowEvent e) {
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      exit();
    }
  }
  //显示仓库的方法
  public void showWarehouse(){
    listData1.clear();
    //取得仓库的值
    warehouses = stockManagementData.getAllWarehouse();
    //为仓库列表框加入仓库数据
    for(int i = 0; i < warehouses.length; i++){
      listData1.addElement(warehouses[i][0]);
    }
  }
  //显示盘点单核查表记录的方法
  public void showStocktakeArray(){
    //取得当前选择项的位置
    int selectedIndex = jList1.getSelectedIndex();
    //当列表框不处于选择状态，不显示数据
    if(selectedIndex == -1){
       return;
    }
    //取得仓库名
    String warehouse = (String)listData1.getElementAt(selectedIndex);
    //根据仓库取得库存数
    String[][] stockQuantities = stockManagementData.
        getStocktakeQuantityByWarehouse(ledgerDate, warehouse, 2);
    //创建库存商品条形码集合类
    Vector stockGoodsBarcode = new Vector();
    for(int i = 0; i < stockQuantities.length; i++){
      stockGoodsBarcode.addElement(stockQuantities[i][0]);
    }
    //根据仓库取得盘点数
    String[][] stocktakeQuantities = stockManagementData.
        getStocktakeQuantityByWarehouse(ledgerDate, warehouse, 4);
    //创建盘点商品条形码集合类
    Vector stocktakeGoodsBarcode = new Vector();
    for(int i = 0; i < stocktakeQuantities.length; i++){
      stocktakeGoodsBarcode.addElement(stocktakeQuantities[i][0]);
    }
    //创建商品条形码的集合类，过滤重复的商品条形码
    TreeSet goodsBarcodeSet = new TreeSet();
    for(int i = 0; i < stockQuantities.length; i++){
      goodsBarcodeSet.add(stockQuantities[i][0]);
    }
    for(int i = 0; i < stocktakeQuantities.length; i++){
      goodsBarcodeSet.add(stocktakeQuantities[i][0]);
    }
    //重新创建盘点核查数组
    stocktakeArray = new String[goodsBarcodeSet.size()][4];
    java.util.Iterator iterator = goodsBarcodeSet.iterator();
    //将数据放入盘点核查数组
    int i = 0;
    while(iterator.hasNext()){
      String goodsBarcode = (String)iterator.next();
      //取得库存数
      int stockQuantity = 0;
      if(stockGoodsBarcode.indexOf(goodsBarcode) != -1){
        stockQuantity = Integer.parseInt(stockQuantities[stockGoodsBarcode.indexOf(goodsBarcode)][1]);
      }
      //取得盘点数
      int stocktakeQuantity = 0;
      if(stocktakeGoodsBarcode.indexOf(goodsBarcode) != -1){
        stocktakeQuantity = Integer.parseInt(stocktakeQuantities[stocktakeGoodsBarcode.indexOf(goodsBarcode)][1]);
      }
      stocktakeArray[i][0] = goodsBarcode;   //商品条形码
      stocktakeArray[i][1] = String.valueOf(stockQuantity);       //库存数
      stocktakeArray[i][2] = String.valueOf(stocktakeQuantity);   //盘点数
      stocktakeArray[i][3] = String.valueOf(stocktakeQuantity - stockQuantity); //差异数
      i++;
    }
    this.showTableData(stocktakeArray);
  }
  //显示盘点差异记录的方法
  public void showDifferenceStocktakeArray(){
    String[][] tempStocktakeArray = new String[stocktakeArray.length][4];
    int line = 0;
    for(int i = 0; i < stocktakeArray.length; i++){
      int difference = Integer.parseInt(stocktakeArray[i][3]);
      if(difference != 0){
        tempStocktakeArray[line][0] = stocktakeArray[i][0];
        tempStocktakeArray[line][1] = stocktakeArray[i][1];
        tempStocktakeArray[line][2] = stocktakeArray[i][2];
        tempStocktakeArray[line][3] = stocktakeArray[i][3];
        line++;
      }
    }
    String[][] temp = new String[line][4];
    System.arraycopy(tempStocktakeArray, 0, temp, 0, line);
    //显示差异记录
    this.showTableData(temp);
  }
  //显示盘点相同记录的方法
  public void showSameStocktakeArray(){
    String[][] tempStocktakeArray = new String[stocktakeArray.length][4];
    int line = 0;
    for(int i = 0; i < stocktakeArray.length; i++){
      int difference = Integer.parseInt(stocktakeArray[i][3]);
      if(difference == 0){
        tempStocktakeArray[line][0] = stocktakeArray[i][0];
        tempStocktakeArray[line][1] = stocktakeArray[i][1];
        tempStocktakeArray[line][2] = stocktakeArray[i][2];
        tempStocktakeArray[line][3] = stocktakeArray[i][3];
        line++;
      }
    }
    String[][] temp = new String[line][4];
    System.arraycopy(tempStocktakeArray, 0, temp, 0, line);
    //显示相同记录
    this.showTableData(temp);
  }
  //显示盘点全部记录的方法
  public void showAllStocktakeArray(){
    this.showTableData(stocktakeArray);
  }
  //显示表格内容的方法
  public void showTableData(Object[][] detail){
    //设置表格的标题
    smTableModel.setColumnNames(colNames);
    //设置表格的数据
    smTableModel.setData(detail);
    jTable1 = new JTable(smTableModel);
    //设置表格的字体
    jTable1.setFont(dialog13);
    //将数据表格加入数据滚动框
    jScrollPane2.getViewport().add(jTable1, null);
    //设置列的宽度
    jTable1.getColumnModel().getColumn(0).setPreferredWidth(50);
    jTable1.getColumnModel().getColumn(1).setPreferredWidth(20);
    jTable1.getColumnModel().getColumn(2).setPreferredWidth(20);
    jTable1.getColumnModel().getColumn(3).setPreferredWidth(20);
  }
  //清空盘点单核查表数据的方法
  public void clearStocktakeArray(){
    stocktakeArray = new String[0][4];
    this.showTableData(stocktakeArray);
  }
  //列表1的选择事件
  void jList1_valueChanged(ListSelectionEvent e) {
    if(listData1.size() > 0){
      this.showStocktakeArray();
    }else{
      this.clearStocktakeArray();
    }
  }
  //单击事件
  public void actionPerformed(ActionEvent e) {
    //取得按钮的动作字符串
    String actionCommand = e.getActionCommand().trim();
    if (actionCommand.equals("showWarehouse")) {
      this.showWarehouse();
    }else if(actionCommand.equals("showDifference")){
      this.showDifferenceStocktakeArray();
    }else if(actionCommand.equals("showSame")){
      this.showSameStocktakeArray();
    }else if(actionCommand.equals("showAll")){
      this.showAllStocktakeArray();
    }else if(actionCommand.equals("exit")){
      exit();
    }
  }
}
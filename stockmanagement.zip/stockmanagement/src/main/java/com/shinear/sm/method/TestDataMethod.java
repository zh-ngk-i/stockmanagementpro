﻿package com.shinear.sm.method;

import junit.framework.*;

public class TestDataMethod extends TestCase {
  private DataMethod dataMethod = null;

  protected void setUp() throws Exception {
    super.setUp();
    dataMethod = new DataMethod();
  }

  protected void tearDown() throws Exception {
    dataMethod = null;
    super.tearDown();
  }

  //检查账套日期的方法
  public void testCheckLedgerDate() {
    String ledgerDate = "200313";
    int expectedReturn = 0;
    int actualReturn = dataMethod.checkLedgerDate(ledgerDate);
    assertEquals("return value", expectedReturn, actualReturn);
    ledgerDate = "200406";
    expectedReturn = 1;
    actualReturn = dataMethod.checkLedgerDate(ledgerDate);
    assertEquals("return value", expectedReturn, actualReturn);
  }
  //测试四舍五入的方法
  public void testRound()  throws Exception{
    double d = 15.67832;
    double result = dataMethod.round(d);
    this.assertEquals("return value", 15.68, result, 2);
  }
  //测试取得库存账套数据表的新序号的方法
  public void testGetStockLedgerNewOrder(){
    String orderId = "20040500001";
    String newOrderId = dataMethod.getStockLedgerNewOrder(orderId);
    this.assertEquals("", "20040500002", newOrderId);
  }
  //测试转换结束日期的方法
  public void testGetEndDate(){
    String dateStr = "2004-05-15 00:00:00.99";
    java.sql.Timestamp date = dataMethod.transferEndDate(dateStr);
    System.out.println(date);
  }
  //测试转换短日期的方法
  public void testGetShortDate(){
    String dateStr = "2004-5-3 12:15:23";
    java.sql.Date date = dataMethod.transferShortDate(dateStr);
    System.out.println(date);
  }
  //测试分离相关联的票据标识的方法
  public void testSplitLinkId(){
    String linkId = "st20040500001";
    linkId = dataMethod.splitLinkId(linkId);
    this.assertEquals("", "20040500001", linkId);
  }
  //测试将会计科目的@@标识转换为--标识
  public void testTransferAccountName(){
    String accountName = "存货@@1000001";
    accountName = dataMethod.transferAccountName(accountName);
    this.assertEquals("", "存货--1000001", accountName);
  }
}
﻿package com.shinear.sm.stockmanagementpro;

import javax.ejb.*;
import java.util.*;

public interface Warehouse extends javax.ejb.EJBLocalObject {
  public String getWarehouseName();
  public void setPyCode(String pyCode);
  public String getPyCode();
  public void setLocation(String location);
  public String getLocation();
  public void setDescription(String description);
  public String getDescription();
}
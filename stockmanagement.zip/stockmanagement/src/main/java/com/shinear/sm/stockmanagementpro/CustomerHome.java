﻿package com.shinear.sm.stockmanagementpro;

import javax.ejb.*;
import java.util.*;

public interface CustomerHome extends javax.ejb.EJBLocalHome {
  public Customer create(String customerName, String customerZone, String pyCode, String abbreviation, String companyPhone, String linkman, String mobilePhone, String fax, String fixedPhone, String address, String zipCode, String bankName, String bankAccount, String email, String homesite, double creditlimit, String remark) throws CreateException;
  public Collection findByCustomerName(String customerName) throws FinderException;
  public Collection findByCustomerZone(String customerZone) throws FinderException;
  public Collection findCreditCustomer() throws FinderException;
  public Customer findByPrimaryKey(String customerName) throws FinderException;
}
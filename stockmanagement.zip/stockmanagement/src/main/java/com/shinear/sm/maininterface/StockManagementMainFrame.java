﻿package com.shinear.sm.maininterface;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.shinear.sm.baseinforinterface.*;
import com.shinear.sm.data.*;
import com.shinear.sm.stockinterface.*;
import com.shinear.sm.stockmanageinterface.*;
import com.shinear.sm.user.User;
import com.shinear.sm.saleinterface.*;

public class StockManagementMainFrame extends JFrame implements ActionListener{
  JPanel contentPane;
  JMenuBar mainMenuBar = new JMenuBar();
  //创建系统设置菜单
  JMenu systemMenu = new JMenu();
  //创建基础信息菜单
  JMenu baseInforMenu = new JMenu();
  //创建进货菜单
  JMenu stockMenu = new JMenu();
  //创建库存菜单
  JMenu stockManageMenu = new JMenu();
  //创建销售菜单
  JMenu saleMenu = new JMenu();
  //创建系统设置菜单项
  JMenuItem exitMenuItem = new JMenuItem();
  //创建基础信息菜单项
  JMenuItem loginMenuItem = new JMenuItem();
  JMenuItem changeUserMenuItem = new JMenuItem();
  JMenuItem changePasswordMenuItem = new JMenuItem();
  JMenuItem viewAuthorityMenuItem = new JMenuItem();
  JMenuItem userManageMenuItem = new JMenuItem();
  JMenuItem dataBackupMenuItem = new JMenuItem();
  JMenuItem ledgerManageMenuItem = new JMenuItem();
  JMenuItem goodsManageMenuItem = new JMenuItem();
  JMenuItem goodsDiscountManageMenuItem = new JMenuItem();
  JMenuItem supplierManageMenuItem = new JMenuItem();
  JMenuItem customerManageMenuItem = new JMenuItem();
  JMenuItem customerCreditManageMenuItem = new JMenuItem();
  JMenuItem warehouseManageMenuItem = new JMenuItem();
  JMenuItem accountNameManageMenuItem = new JMenuItem();
  JMenuItem reportManageMenuItem = new JMenuItem();
  JMenuItem userLogViewMenuItem = new JMenuItem();
  //创建进货菜单项
  JMenuItem orderSubmitMenuItem = new JMenuItem();
  JMenuItem orderCommitMenuItem = new JMenuItem();
  JMenuItem orderCheckMenuItem = new JMenuItem();
  JMenuItem orderPayMenuItem = new JMenuItem();
  JMenuItem cashLedgerViewMenuItem = new JMenuItem();
  JMenuItem returnOrderSubmitMenuItem = new JMenuItem();
  JMenuItem returnOrderPayMenuItem = new JMenuItem();
  JMenuItem returnOrderCheckMenuItem = new JMenuItem();
  JMenuItem stockOrderSearchMenuItem = new JMenuItem();
  JMenuItem accountPayableSearchMenuItem = new JMenuItem();
  JMenuItem stockAccountEntryCheckMenuItem = new JMenuItem();
  JMenuItem stockAccountEntryCreateMenuItem = new JMenuItem();
  JMenuItem stockAccountEntrySearchMenuItem = new JMenuItem();
  //创建库存菜单项
  JMenuItem stockTransferSubmitMenuItem = new JMenuItem();
  JMenuItem stockTransferCheckMenuItem = new JMenuItem();
  JMenuItem goodsPriceManageMenuItem = new JMenuItem();
  JMenuItem goodsQuantitySplitMenuItem = new JMenuItem();
  JMenuItem goodsQuantityCombineMenuItem = new JMenuItem();
  JMenuItem stocktakeSubmitMenuItem = new JMenuItem();
  JMenuItem stocktakeCheckMenuItem = new JMenuItem();
  JMenuItem stocktakeLossManageMenuItem = new JMenuItem();
  JMenuItem stocktakeGainManageMenuItem = new JMenuItem();
  JMenuItem stockSearchMenuItem = new JMenuItem();
  JMenuItem stockLedgerSearchMenuItem = new JMenuItem();
  JMenuItem stockUsefulLifeSearchMenuItem = new JMenuItem();
  JMenuItem stockAlarmManageMenuItem = new JMenuItem();
  JMenuItem stockManageAccountEntryCheckMenuItem = new JMenuItem();
  JMenuItem stockManageAccountEntryCreateMenuItem = new JMenuItem();
  JMenuItem stockManageAccountEntrySearchMenuItem = new JMenuItem();
  //创建销售菜单项
  JMenuItem discountGoodsViewMenuItem = new JMenuItem();
  JMenuItem counterSaleMenuItem = new JMenuItem();
  JMenuItem creditSaleMenuItem = new JMenuItem();
  JMenuItem saleReceiveMenuItem = new JMenuItem();
  JMenuItem counterSaleReturnMenuItem = new JMenuItem();
  JMenuItem creditSaleReturnMenuItem = new JMenuItem();
  JMenuItem saleReturnPayableMenuItem = new JMenuItem();
  JMenuItem saleLedgerSearchMenuItem = new JMenuItem();
  JMenuItem saleReceiveSearchMenuItem = new JMenuItem();
  JMenuItem saleAccountEntryCheckMenuItem = new JMenuItem();
  JMenuItem saleAccountEntryCreateMenuItem = new JMenuItem();
  JMenuItem saleAccountEntrySearchMenuItem = new JMenuItem();

  //创建字体类
  Font dialog13 = new java.awt.Font("Dialog", 0, 13);
  //创建数据类
  StockManagementData stockManagementData = new StockManagementData();
  //声明用户类
  User user = null;
  //声明登陆窗口
  LoginFrame loginFrame = null;
  //声明修改密码窗口
  ChangePasswordFrame changePasswordFrame = null;
  //声明查看用户权限窗口
  ViewAuthorityFrame viewAuthorityFrame = null;
  //声明用户管理窗口
  UserManageFrame userManageFrame = null;
  //声明数据备份窗口
  DataBackupFrame dataBackupFrame = null;
  //声明账套管理窗口
  LedgerManageFrame ledgerManageFrame = null;
  //创建账套变量
  String ledgerDate = "";
  //声明商品数据管理窗口
  GoodsManageFrame goodsManageFrame = null;
  //声明商品折扣管理窗口
  GoodsDiscountManageFrame goodsDiscountManageFrame = null;
  //声明供应商数据管理窗口
  SupplierManageFrame supplierManageFrame = null;
  //声明客户数据管理窗口
  CustomerManageFrame customerManageFrame = null;
  //声明客户信用管理窗口
  CustomerCreditManageFrame customerCreditManageFrame = null;
  //声明仓库数据管理窗口
  WarehouseManageFrame warehouseManageFrame = null;
  //声明会计科目管理窗口
  AccountNameManageFrame accountNameManageFrame = null;
  //声明报表管理窗口
  ReportManageFrame reportManageFrame = null;
  //声明用户日志查看窗口
  UserLogViewFrame userLogViewFrame = null;
  //声明进货单填写窗口
  OrderSubmitFrame orderSubmitFrame = null;
  //声明进货单审核窗口
  OrderCommitFrame orderCommitFrame = null;
  //声明检查货物窗口
  OrderCheckFrame orderCheckFrame = null;
  //声明进货付款窗口
  OrderPayFrame orderPayFrame = null;
  //声明现金日记账查看窗口
  CashLedgerViewFrame cashLedgerViewFrame = null;
  //声明填写退货单窗口
  ReturnOrderSubmitFrame returnOrderSubmitFrame = null;
  //声明收取退款窗口
  ReturnOrderPayFrame returnOrderPayFrame = null;
  //声明退还货物窗口
  ReturnOrderCheckFrame returnOrderCheckFrame = null;
  //声明进货单查询窗口
  StockOrderSearchFrame stockOrderSearchFrame = null;
  //声明应付账款查询窗口
  AccountPayableSearchFrame accountPayableSearchFrame = null;
  //声明审核进货会计分录窗口
  StockAccountEntryCheckFrame stockAccountEntryCheckFrame = null;
  //声明编写进货会计分录窗口
  StockAccountEntryCreateFrame stockAccountEntryCreateFrame = null;
  //声明查询进货会计分录窗口
  StockAccountEntrySearchFrame stockAccountEntrySearchFrame = null;
  //声明商品调出窗口
  StockTransferSubmitFrame stockTransferSubmitFrame = null;
  //声明商品验收窗口
  StockTransferCheckFrame stockTransferCheckFrame = null;
  //声明商品调价窗口
  GoodsPriceManageFrame goodsPriceManageFrame = null;
  //声明商品数量分拆窗口
  GoodsQuantitySplitFrame goodsQuantitySplitFrame = null;
  //声明商品数量组合窗口
  GoodsQuantityCombineFrame goodsQuantityCombineFrame = null;
  //声明库存盘点计数窗口
  StocktakeSubmitFrame stocktakeSubmitFrame = null;
  //声明库存盘点核查窗口
  StocktakeCheckFrame stocktakeCheckFrame = null;
  //声明库存盘点损失单管理窗口
  StocktakeLossManageFrame stocktakeLossManageFrame = null;
  //声明库存盘点盈收单管理窗口
  StocktakeGainManageFrame stocktakeGainManageFrame = null;
  //声明库存商品查询窗口
  StockSearchFrame stockSearchFrame = null;
  //声明库存单据查询窗口
  StockLedgerSearchFrame stockLedgerSearchFrame = null;
  //声明商品有效期查询窗口
  StockUsefulLifeSearchFrame stockUsefulLifeSearchFrame = null;
  //声明库存警告管理窗口
  StockAlarmManageFrame stockAlarmManageFrame = null;
  //声明库存会计分录审核窗口
  StockManageAccountEntryCheckFrame stockManageAccountEntryCheckFrame = null;
  //声明库存会计分录编写窗口
  StockManageAccountEntryCreateFrame stockManageAccountEntryCreateFrame = null;
  //声明库存会计分录查询窗口
  StockManageAccountEntrySearchFrame stockManageAccountEntrySearchFrame = null;
  //声明特价商品查看窗口
  DiscountGoodsViewFrame discountGoodsViewFrame = null;
  //声明前台销售窗口
  CounterSaleFrame counterSaleFrame = null;
  //声明信用销售窗口
  CreditSaleFrame creditSaleFrame = null;
  //声明销售收款窗口
  SaleReceiveFrame saleReceiveFrame = null;
  //声明前台销售退货窗口
  CounterSaleReturnFrame counterSaleReturnFrame = null;
  //声明信用销售退货窗口
  CreditSaleReturnFrame creditSaleReturnFrame = null;
  //声明信用销售退款窗口
  SaleReturnPayableFrame saleReturnPayableFrame = null;
  //声明销售单查询窗口
  SaleLedgerSearchFrame saleLedgerSearchFrame = null;
  //声明应收账款查询窗口
  SaleReceiveSearchFrame saleReceiveSearchFrame = null;
  //声明销售会计分录审核窗口
  SaleAccountEntryCheckFrame saleAccountEntryCheckFrame = null;
  //声明销售会计分录编写窗口
  SaleAccountEntryCreateFrame saleAccountEntryCreateFrame = null;
  //声明销售会计分录查询窗口
  SaleAccountEntrySearchFrame saleAccountEntrySearchFrame = null;

  public StockManagementMainFrame() {
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception  {
    contentPane = (JPanel) this.getContentPane();
    contentPane.setLayout(null);
    this.setSize(new Dimension(529, 411));
    this.setTitle("进销存管理信息系统主窗口");
    //为面板加入菜单工具栏
    this.setJMenuBar(mainMenuBar);
    //设置菜单的标题和动作字符串
    systemMenu.setText("系统设置");
    baseInforMenu.setActionCommand("baseinfor");
    baseInforMenu.setText("基础信息");
    stockMenu.setText("进货");
    stockManageMenu.setText("库存");
    saleMenu.setText("销售");
    //设置系统设置的菜单项
    exitMenuItem.setActionCommand("exit");
    exitMenuItem.setText("退出");
    //设置基础信息模块的菜单项
    loginMenuItem.setActionCommand("login");
    loginMenuItem.setText("用户登陆");
    changeUserMenuItem.setActionCommand("changeUser");
    changeUserMenuItem.setText("切换用户");
    changePasswordMenuItem.setActionCommand("changePassword");
    changePasswordMenuItem.setText("修改密码");
    viewAuthorityMenuItem.setActionCommand("viewAuthority");
    viewAuthorityMenuItem.setText("查看用户权限");
    userManageMenuItem.setActionCommand("userManage");
    userManageMenuItem.setText("用户管理");
    dataBackupMenuItem.setActionCommand("dataBackup");
    dataBackupMenuItem.setText("数据备份");
    ledgerManageMenuItem.setActionCommand("ledgerManage");
    ledgerManageMenuItem.setText("账套管理");
    goodsManageMenuItem.setActionCommand("goodsManage");
    goodsManageMenuItem.setText("商品数据管理");
    goodsDiscountManageMenuItem.setActionCommand("goodsDiscountManage");
    goodsDiscountManageMenuItem.setText("商品折扣管理");
    supplierManageMenuItem.setActionCommand("supplierManage");
    supplierManageMenuItem.setText("供应商数据管理");
    customerManageMenuItem.setActionCommand("customerManage");
    customerManageMenuItem.setText("客户数据管理");
    customerCreditManageMenuItem.setActionCommand("customerCreditManage");
    customerCreditManageMenuItem.setText("客户信用管理");
    warehouseManageMenuItem.setActionCommand("warehouseManage");
    warehouseManageMenuItem.setText("仓库数据管理");
    accountNameManageMenuItem.setActionCommand("accountNameManage");
    accountNameManageMenuItem.setText("会计科目管理");
    reportManageMenuItem.setActionCommand("reportManage");
    reportManageMenuItem.setText("报表管理");
    userLogViewMenuItem.setActionCommand("userLogView");
    userLogViewMenuItem.setText("用户日志查看");
    //设置进货菜单项
    orderSubmitMenuItem.setActionCommand("orderSubmit");
    orderSubmitMenuItem.setText("填写进货单");
    orderCommitMenuItem.setActionCommand("orderCommit");
    orderCommitMenuItem.setText("审核进货单");
    orderCheckMenuItem.setActionCommand("orderCheck");
    orderCheckMenuItem.setText("检查货物");
    orderPayMenuItem.setActionCommand("orderPay");
    orderPayMenuItem.setText("进货付款");
    cashLedgerViewMenuItem.setActionCommand("cashLedgerView");
    cashLedgerViewMenuItem.setText("查看现金日记账");
    returnOrderSubmitMenuItem.setActionCommand("returnOrderSubmit");
    returnOrderSubmitMenuItem.setText("填写退货单");
    returnOrderPayMenuItem.setActionCommand("returnOrderPay");
    returnOrderPayMenuItem.setText("收取退款");
    returnOrderCheckMenuItem.setActionCommand("returnOrderCheck");
    returnOrderCheckMenuItem.setText("退还货物");
    stockOrderSearchMenuItem.setActionCommand("stockOrderSearch");
    stockOrderSearchMenuItem.setText("进货单查询");
    accountPayableSearchMenuItem.setActionCommand("accountPayableSearch");
    accountPayableSearchMenuItem.setText("应付账款查询");
    stockAccountEntryCheckMenuItem.setActionCommand("stockAccountEntryCheck");
    stockAccountEntryCheckMenuItem.setText("审核进货会计分录");
    stockAccountEntryCreateMenuItem.setActionCommand("stockAccountEntryCreate");
    stockAccountEntryCreateMenuItem.setText("编写进货会计分录");
    stockAccountEntrySearchMenuItem.setActionCommand("stockAccountEntrySearch");
    stockAccountEntrySearchMenuItem.setText("查询进货会计分录");
    //设置库存菜单项
    stockTransferSubmitMenuItem.setActionCommand("stockTransferSubmit");
    stockTransferSubmitMenuItem.setText("商品调出");
    stockTransferCheckMenuItem.setActionCommand("stockTransferCheck");
    stockTransferCheckMenuItem.setText("商品验收");
    goodsPriceManageMenuItem.setActionCommand("goodsPriceManage");
    goodsPriceManageMenuItem.setText("商品调价");
    goodsQuantitySplitMenuItem.setActionCommand("goodsQuantitySplit");
    goodsQuantitySplitMenuItem.setText("商品数量分拆");
    goodsQuantityCombineMenuItem.setActionCommand("goodsQuantityCombine");
    goodsQuantityCombineMenuItem.setText("商品数量组合");
    stocktakeSubmitMenuItem.setActionCommand("stocktakeSubmit");
    stocktakeSubmitMenuItem.setText("库存盘点计数");
    stocktakeCheckMenuItem.setActionCommand("stocktakeCheck");
    stocktakeCheckMenuItem.setText("库存盘点核查");
    stocktakeLossManageMenuItem.setActionCommand("stocktakeLossManage");
    stocktakeLossManageMenuItem.setText("库存盘点损失单管理");
    stocktakeGainManageMenuItem.setActionCommand("stocktakeGainManage");
    stocktakeGainManageMenuItem.setText("库存盘点盈收单管理");
    stockSearchMenuItem.setActionCommand("stockSearch");
    stockSearchMenuItem.setText("库存商品查询");
    stockLedgerSearchMenuItem.setActionCommand("stockLedgerSearch");
    stockLedgerSearchMenuItem.setText("库存单据查询");
    stockUsefulLifeSearchMenuItem.setActionCommand("stockUsefulLifeSearch");
    stockUsefulLifeSearchMenuItem.setText("商品有效期查询");
    stockAlarmManageMenuItem.setActionCommand("stockAlarmManage");
    stockAlarmManageMenuItem.setText("库存警告管理");
    stockManageAccountEntryCheckMenuItem.setActionCommand("stockManageAccountEntryCheck");
    stockManageAccountEntryCheckMenuItem.setText("审核库存会计分录");
    stockManageAccountEntryCreateMenuItem.setActionCommand("stockManageAccountEntryCreate");
    stockManageAccountEntryCreateMenuItem.setText("编写库存会计分录");
    stockManageAccountEntrySearchMenuItem.setActionCommand("stockManageAccountEntrySearch");
    stockManageAccountEntrySearchMenuItem.setText("查询库存会计分录");
    //设置销售菜单项
    discountGoodsViewMenuItem.setActionCommand("discountGoodsView");
    discountGoodsViewMenuItem.setText("特价商品查看");
    counterSaleMenuItem.setActionCommand("counterSale");
    counterSaleMenuItem.setText("前台销售");
    creditSaleMenuItem.setActionCommand("creditSale");
    creditSaleMenuItem.setText("信用销售");
    saleReceiveMenuItem.setActionCommand("saleReceive");
    saleReceiveMenuItem.setText("销售收款");
    counterSaleReturnMenuItem.setActionCommand("counterSaleReturn");
    counterSaleReturnMenuItem.setText("前台销售退货");
    creditSaleReturnMenuItem.setActionCommand("creditSaleReturn");
    creditSaleReturnMenuItem.setText("信用销售退货");
    saleReturnPayableMenuItem.setActionCommand("saleReturnPayable");
    saleReturnPayableMenuItem.setText("信用销售退款");
    saleLedgerSearchMenuItem.setActionCommand("saleLedgerSearch");
    saleLedgerSearchMenuItem.setText("销售单查询");
    saleReceiveSearchMenuItem.setActionCommand("saleReceiveSearch");
    saleReceiveSearchMenuItem.setText("应收账款查询");
    saleAccountEntryCheckMenuItem.setActionCommand("saleAccountEntryCheck");
    saleAccountEntryCheckMenuItem.setText("审核销售会计分录");
    saleAccountEntryCreateMenuItem.setActionCommand("saleAccountEntryCreate");
    saleAccountEntryCreateMenuItem.setText("编写销售会计分录");
    saleAccountEntrySearchMenuItem.setActionCommand("saleAccountEntrySearch");
    saleAccountEntrySearchMenuItem.setText("查询销售会计分录");

    //为系统设置菜单加入菜单项
    systemMenu.add(exitMenuItem);
    //为基础信息菜单加入菜单项
    baseInforMenu.add(loginMenuItem);
    baseInforMenu.add(changeUserMenuItem);
    baseInforMenu.add(changePasswordMenuItem);
    baseInforMenu.add(viewAuthorityMenuItem);
    baseInforMenu.add(userManageMenuItem);
    baseInforMenu.addSeparator();
    baseInforMenu.add(dataBackupMenuItem);
    baseInforMenu.add(ledgerManageMenuItem);
    baseInforMenu.add(goodsManageMenuItem);
    baseInforMenu.add(goodsDiscountManageMenuItem);
    baseInforMenu.add(supplierManageMenuItem);
    baseInforMenu.add(customerManageMenuItem);
    baseInforMenu.add(customerCreditManageMenuItem);
    baseInforMenu.add(warehouseManageMenuItem);
    baseInforMenu.add(accountNameManageMenuItem);
    baseInforMenu.add(reportManageMenuItem);
    baseInforMenu.add(userLogViewMenuItem);
    //为进货菜单加入菜单项
    stockMenu.add(orderSubmitMenuItem);
    stockMenu.add(orderCommitMenuItem);
    stockMenu.add(orderCheckMenuItem);
    stockMenu.addSeparator();
    stockMenu.add(orderPayMenuItem);
    stockMenu.add(cashLedgerViewMenuItem);
    stockMenu.addSeparator();
    stockMenu.add(returnOrderSubmitMenuItem);
    stockMenu.add(returnOrderPayMenuItem);
    stockMenu.add(returnOrderCheckMenuItem);
    stockMenu.addSeparator();
    stockMenu.add(stockOrderSearchMenuItem);
    stockMenu.add(accountPayableSearchMenuItem);
    stockMenu.addSeparator();
    stockMenu.add(stockAccountEntryCheckMenuItem);
    stockMenu.add(stockAccountEntryCreateMenuItem);
    stockMenu.add(stockAccountEntrySearchMenuItem);
    //为库存菜单加入菜单项
    stockManageMenu.add(stockTransferSubmitMenuItem);
    stockManageMenu.add(stockTransferCheckMenuItem);
    stockManageMenu.addSeparator();
    stockManageMenu.add(goodsPriceManageMenuItem);
    stockManageMenu.addSeparator();
    stockManageMenu.add(goodsQuantitySplitMenuItem);
    stockManageMenu.add(goodsQuantityCombineMenuItem);
    stockManageMenu.addSeparator();
    stockManageMenu.add(stocktakeSubmitMenuItem);
    stockManageMenu.add(stocktakeCheckMenuItem);
    stockManageMenu.add(stocktakeLossManageMenuItem);
    stockManageMenu.add(stocktakeGainManageMenuItem);
    stockManageMenu.addSeparator();
    stockManageMenu.add(stockSearchMenuItem);
    stockManageMenu.add(stockLedgerSearchMenuItem);
    stockManageMenu.add(stockUsefulLifeSearchMenuItem);
    stockManageMenu.addSeparator();
    stockManageMenu.add(stockAlarmManageMenuItem);
    stockManageMenu.addSeparator();
    stockManageMenu.add(stockManageAccountEntryCheckMenuItem);
    stockManageMenu.add(stockManageAccountEntryCreateMenuItem);
    stockManageMenu.add(stockManageAccountEntrySearchMenuItem);
    //为销售菜单加入菜单项
    saleMenu.add(discountGoodsViewMenuItem);
    saleMenu.addSeparator();
    saleMenu.add(counterSaleMenuItem);
    saleMenu.add(creditSaleMenuItem);
    saleMenu.add(saleReceiveMenuItem);
    saleMenu.addSeparator();
    saleMenu.add(counterSaleReturnMenuItem);
    saleMenu.add(creditSaleReturnMenuItem);
    saleMenu.add(saleReturnPayableMenuItem);
    saleMenu.addSeparator();
    saleMenu.add(saleLedgerSearchMenuItem);
    saleMenu.add(saleReceiveSearchMenuItem);
    saleMenu.addSeparator();
    saleMenu.add(saleAccountEntryCheckMenuItem);
    saleMenu.add(saleAccountEntryCreateMenuItem);
    saleMenu.add(saleAccountEntrySearchMenuItem);

    //为菜单工具栏加入菜单
    mainMenuBar.add(systemMenu);
    mainMenuBar.add(baseInforMenu);
    mainMenuBar.add(stockMenu);
    mainMenuBar.add(stockManageMenu);
    mainMenuBar.add(saleMenu);
    //为菜单项加入单击事件接收器和设置菜单的字体
    setupMenuItem();
  }
  public void setupMenuItem(){
    //设置菜单工具栏的菜单控件的字体
    Component[] components = mainMenuBar.getComponents();
    for(int i = 0; i < components.length; i++){
      ((JMenu)components[i]).setFont(dialog13);
    }
    //设置基础信息菜单的菜单项的事件接收器和字体
    components = baseInforMenu.getMenuComponents();
    for(int i = 0; i < components.length; i++){
      if(components[i].getClass().getName().equals("javax.swing.JPopupMenu$Separator")){
        continue;
      }
      JMenuItem tempMenuItem = (JMenuItem)components[i];
      tempMenuItem.setFont(dialog13);
      tempMenuItem.addActionListener(this);
    }
    //设置系统设置菜单的菜单项的事件接收器和字体
    components = systemMenu.getMenuComponents();
    for(int i = 0; i < components.length; i++){
      if(components[i].getClass().getName().equals("javax.swing.JPopupMenu$Separator")){
        continue;
      }
      JMenuItem tempMenuItem = (JMenuItem)components[i];
      tempMenuItem.setFont(dialog13);
      tempMenuItem.addActionListener(this);
    }
    //设置进货菜单的菜单项的事件接收器和字体
    components = stockMenu.getMenuComponents();
    for(int i = 0; i < components.length; i++){
      if(components[i].getClass().getName().equals("javax.swing.JPopupMenu$Separator")){
        continue;
      }
      JMenuItem tempMenuItem = (JMenuItem)components[i];
      tempMenuItem.setFont(dialog13);
      tempMenuItem.addActionListener(this);
    }
    //设置库存菜单的菜单项的事件接收器和字体
    components = stockManageMenu.getMenuComponents();
    for(int i = 0; i < components.length; i++){
      if(components[i].getClass().getName().equals("javax.swing.JPopupMenu$Separator")){
        continue;
      }
      JMenuItem tempMenuItem = (JMenuItem)components[i];
      tempMenuItem.setFont(dialog13);
      tempMenuItem.addActionListener(this);
    }
    //设置销售菜单的菜单项的事件接收器和字体
    components = saleMenu.getMenuComponents();
    for(int i = 0; i < components.length; i++){
      if(components[i].getClass().getName().equals("javax.swing.JPopupMenu$Separator")){
        continue;
      }
      JMenuItem tempMenuItem = (JMenuItem)components[i];
      tempMenuItem.setFont(dialog13);
      tempMenuItem.addActionListener(this);
    }
  }
  protected void processWindowEvent(WindowEvent e) {
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      this.exit();
    }
  }
  //退出程序
  public void exit(){
    if(user != null){
      //将用户离开信息写入日志数据表
      stockManagementData.createUserLog("主窗口", "退出", user.getUserName());
    }
    //清空系统占用内存
    System.exit(0);
  }
  //单击事件处理代码
  public void actionPerformed(ActionEvent e) {
    //取得动作字符串
    String actionCommand = e.getActionCommand().trim();
    //单击的处理代码
    if (actionCommand.equals("login")) {
      if(loginFrame == null){
        loginFrame = new LoginFrame(this);
        //使窗口居中对齐
        setCenterPosition(loginFrame);
        loginFrame.setVisible(true);
      }else{
        loginFrame.setVisible(true);
      }
      //设置窗口标题
      loginFrame.setTitle("进、销、存管理信息系统的登陆窗口");
    }
    else if (actionCommand.equals("changeUser")) {
      if(user == null){
        JOptionPane.showMessageDialog(null, "先登陆系统，再切换用户.");
        return;
      }else{
        loginFrame.setVisible(true);
      }
      //设置窗口标题
      loginFrame.setTitle("切换用户窗口");
    }
    else if (actionCommand.equals("changePassword")) {
      if(user == null){
        JOptionPane.showMessageDialog(null, "先登陆系统，再修改密码.");
        return;
      }else{
        if(changePasswordFrame == null){
          changePasswordFrame = new ChangePasswordFrame(this);
          //使窗口居中对齐
          setCenterPosition(changePasswordFrame);
          changePasswordFrame.setVisible(true);
        }else{
          //重新传入用户类
          changePasswordFrame.setUser(user);
          changePasswordFrame.setVisible(true);
        }
      }
    }
    else if (actionCommand.equals("viewAuthority")) {
      if(user == null){
        JOptionPane.showMessageDialog(null, "先登陆系统，再查看用户权限.");
        return;
      }else{
        if(viewAuthorityFrame == null){
          viewAuthorityFrame = new ViewAuthorityFrame(this);
          //使窗口居中对齐
          setCenterPosition(viewAuthorityFrame);
          viewAuthorityFrame.setVisible(true);
        }else{
          //重新传入用户类
          viewAuthorityFrame.setUser(user);
          //重新设置权限标签
          viewAuthorityFrame.setAuthorityJLabel();
          viewAuthorityFrame.setVisible(true);
        }
      }
      viewAuthorityFrame.setTitle("查看用户权限窗口"+ ":用户("
                                  + user.getUserName() + ")");
    }
    else if (actionCommand.equals("userManage")) {
      if(user == null){
        JOptionPane.showMessageDialog(null, "先登陆系统，再打开用户管理窗口.");
        return;
      }else{
        //取得基础信息模块的用户权限
        int baseInforFunction = user.getBaseInforFunction();
        if((baseInforFunction & 1) != 1){
          JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
          return;
        }
        if(userManageFrame == null){
          userManageFrame = new UserManageFrame(this);
          //使窗口居中对齐
          setCenterPosition(userManageFrame);
          userManageFrame.setVisible(true);
        }else{
          //重新传入用户类
          userManageFrame.setUser(user);
          userManageFrame.setVisible(true);
        }
      }
      userManageFrame.setTitle("用户管理窗口"+ ":用户("
                                + user.getUserName() + ")");
    }
    else if (actionCommand.equals("dataBackup")) {
      if(user == null){
        JOptionPane.showMessageDialog(null, "先登陆系统，再打开数据备份窗口.");
        return;
      }else{
        //取得基础信息模块的用户权限
        int baseInforFunction = user.getBaseInforFunction();
        if((baseInforFunction & 2) != 2){
          JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
          return;
        }
        if(dataBackupFrame == null){
          dataBackupFrame = new DataBackupFrame(this);
          //使窗口居中对齐
          setCenterPosition(dataBackupFrame);
          dataBackupFrame.setVisible(true);
        }else{
          //重新传入用户类
          dataBackupFrame.setUser(user);
          dataBackupFrame.setVisible(true);
        }
      }
      dataBackupFrame.setTitle("数据备份窗口"+ ":用户("
                                + user.getUserName() + ")");
    }
    else if (actionCommand.equals("ledgerManage")) {
      if(user == null){
        JOptionPane.showMessageDialog(null, "先登陆系统，再打开账套管理窗口.");
        return;
      }else{
        if(ledgerManageFrame == null){
          ledgerManageFrame = new LedgerManageFrame(this);
          //使窗口居中对齐
          setCenterPosition(ledgerManageFrame);
          ledgerManageFrame.setVisible(true);
        }else{
          //重新传入用户类
          ledgerManageFrame.setUser(user);
          ledgerManageFrame.setVisible(true);
        }
      }
      ledgerManageFrame.setTitle("账套管理窗口"+ ":用户("
                                + user.getUserName() + ")");
    }
    else if (actionCommand.equals("goodsManage")) {
      if(user == null){
        JOptionPane.showMessageDialog(null, "先登陆系统，再打开商品数据管理窗口.");
        return;
      }else{
        //取得基础信息模块的用户权限
        int baseInforFunction = user.getBaseInforFunction();
        if((baseInforFunction & 8) != 8){
          JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
          return;
        }
        if(goodsManageFrame == null){
          goodsManageFrame = new GoodsManageFrame(this);
          //使窗口居中对齐
          setCenterPosition(goodsManageFrame);
          goodsManageFrame.setVisible(true);
        }else{
          //重新传入用户类
          goodsManageFrame.setUser(user);
          goodsManageFrame.setVisible(true);
          //显示商品类别数据
          goodsManageFrame.showAllCategories();
        }
      }
      goodsManageFrame.setTitle("商品数据管理窗口"+ ":用户("
                                + user.getUserName() + ")");
    }
    else if (actionCommand.equals("goodsDiscountManage")) {
      if(user == null){
        JOptionPane.showMessageDialog(null, "先登陆系统，再打开商品折扣管理窗口.");
        return;
      }else{
        //取得基础信息模块的用户权限
        int baseInforFunction = user.getBaseInforFunction();
        if((baseInforFunction & 16) != 16){
          JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
          return;
        }
        if(goodsDiscountManageFrame == null){
          goodsDiscountManageFrame = new GoodsDiscountManageFrame(this);
          //使窗口居中对齐
          setCenterPosition(goodsDiscountManageFrame);
          goodsDiscountManageFrame.setVisible(true);
        }else{
          //重新传入用户类
          goodsDiscountManageFrame.setUser(user);
          goodsDiscountManageFrame.setVisible(true);
          //显示商品类别数据
          goodsDiscountManageFrame.showAllCategories();
        }
      }
      goodsDiscountManageFrame.setTitle("商品折扣管理窗口"+ ":用户("
                                + user.getUserName() + ")");
    }
    else if (actionCommand.equals("supplierManage")) {
      if(user == null){
        JOptionPane.showMessageDialog(null, "先登陆系统，再打开供应商数据管理窗口.");
        return;
      }else{
        //取得基础信息模块的用户权限
        int baseInforFunction = user.getBaseInforFunction();
        if((baseInforFunction & 32) != 32){
          JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
          return;
        }
        if(supplierManageFrame == null){
          supplierManageFrame = new SupplierManageFrame(this);
          //使窗口居中对齐
          setCenterPosition(supplierManageFrame);
          supplierManageFrame.setVisible(true);
        }else{
          //重新传入用户类
          supplierManageFrame.setUser(user);
          supplierManageFrame.setVisible(true);
        }
      }
      supplierManageFrame.setTitle("供应商数据管理窗口"+ ":用户("
                                + user.getUserName() + ")");
    }
    else if (actionCommand.equals("customerManage")) {
      if(user == null){
        JOptionPane.showMessageDialog(null, "先登陆系统，再打开客户数据管理窗口.");
        return;
      }else{
        //取得基础信息模块的用户权限
        int baseInforFunction = user.getBaseInforFunction();
        if((baseInforFunction & 64) != 64){
          JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
          return;
        }
        if(customerManageFrame == null){
          customerManageFrame = new CustomerManageFrame(this);
          //使窗口居中对齐
          setCenterPosition(customerManageFrame);
          customerManageFrame.setVisible(true);
        }else{
          //重新传入用户类
          customerManageFrame.setUser(user);
          customerManageFrame.setVisible(true);
        }
      }
      customerManageFrame.setTitle("客户数据管理窗口"+ ":用户("
                                + user.getUserName() + ")");
    }
    else if (actionCommand.equals("customerCreditManage")) {
      if(user == null){
        JOptionPane.showMessageDialog(null, "先登陆系统，再打开客户信用管理窗口.");
        return;
      }else{
        //取得基础信息模块的用户权限
        int baseInforFunction = user.getBaseInforFunction();
        if((baseInforFunction & 128) != 128){
          JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
          return;
        }
        if(customerCreditManageFrame == null){
          customerCreditManageFrame = new CustomerCreditManageFrame(this);
          //使窗口居中对齐
          setCenterPosition(customerCreditManageFrame);
          customerCreditManageFrame.setVisible(true);
        }else{
          //重新传入用户类
          customerCreditManageFrame.setUser(user);
          customerCreditManageFrame.setVisible(true);
        }
      }
      customerCreditManageFrame.setTitle("客户信用管理窗口"+ ":用户("
                                + user.getUserName() + ")");
    }
    else if (actionCommand.equals("warehouseManage")) {
      if(user == null){
        JOptionPane.showMessageDialog(null, "先登陆系统，再打开仓库数据管理窗口.");
        return;
      }else{
        //取得基础信息模块的用户权限
        int baseInforFunction = user.getBaseInforFunction();
        if((baseInforFunction & 256) != 256){
          JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
          return;
        }
        if(warehouseManageFrame == null){
          warehouseManageFrame = new WarehouseManageFrame(this);
          //使窗口居中对齐
          setCenterPosition(warehouseManageFrame);
          warehouseManageFrame.setVisible(true);
        }else{
          //重新传入用户类
          warehouseManageFrame.setUser(user);
          warehouseManageFrame.setVisible(true);
          //显示全部仓库
          warehouseManageFrame.showAllWarehouse();
        }
      }
      warehouseManageFrame.setTitle("仓库数据管理窗口"+ ":用户("
                                + user.getUserName() + ")");
    }
    else if (actionCommand.equals("accountNameManage")) {
      if(user == null){
        JOptionPane.showMessageDialog(null, "先登陆系统，再打开会计科目管理窗口.");
        return;
      }else{
        //取得基础信息模块的用户权限
        int baseInforFunction = user.getBaseInforFunction();
        if((baseInforFunction & 512) != 512){
          JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
          return;
        }
        if(accountNameManageFrame == null){
          accountNameManageFrame = new AccountNameManageFrame(this);
          //使窗口居中对齐
          setCenterPosition(accountNameManageFrame);
          accountNameManageFrame.setVisible(true);
        }else{
          //重新传入用户类
          accountNameManageFrame.setUser(user);
          accountNameManageFrame.setVisible(true);
          //显示会计科目的结构树
          accountNameManageFrame.showAllAccountName();
        }
      }
      accountNameManageFrame.setTitle("会计科目管理窗口"+ ":用户("
                                + user.getUserName() + ")");
    }
    else if (actionCommand.equals("reportManage")) {
      if(user == null){
        JOptionPane.showMessageDialog(null, "先登陆系统，再打开报表管理窗口.");
        return;
      }else{
        //取得基础信息模块的用户权限
        int baseInforFunction = user.getBaseInforFunction();
        if((baseInforFunction & 1024) != 1024){
          JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
          return;
        }
        if(ledgerDate.length() == 0){
          JOptionPane.showMessageDialog(null, "请选择账套.");
          return;
        }
        if(reportManageFrame == null){
          reportManageFrame = new ReportManageFrame(this);
          //使窗口居中对齐
          setCenterPosition(reportManageFrame);
          reportManageFrame.setVisible(true);
        }else{
          //重新传入用户类和账套
          reportManageFrame.setUser(user);
          reportManageFrame.setLedgerDate(ledgerDate);
          reportManageFrame.setVisible(true);
        }
      }
      reportManageFrame.setTitle("报表管理窗口"+ ":用户("
                                + user.getUserName() + "):账套(" + ledgerDate + ")");
    }
    else if (actionCommand.equals("userLogView")) {
      if(user == null){
        JOptionPane.showMessageDialog(null, "先登陆系统，再打开用户日志查看窗口.");
        return;
      }else{
        //取得基础信息模块的用户权限
        int baseInforFunction = user.getBaseInforFunction();
        if((baseInforFunction & 2048) != 2048){
          JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
          return;
        }
        if(userLogViewFrame == null){
          userLogViewFrame = new UserLogViewFrame(this);
          //使窗口居中对齐
          setCenterPosition(userLogViewFrame);
          userLogViewFrame.setVisible(true);
        }else{
          //重新传入用户类
          userLogViewFrame.setUser(user);
          userLogViewFrame.setVisible(true);
        }
      }
      userLogViewFrame.setTitle("用户日志查看窗口"+ ":用户("
                                + user.getUserName() + ")");
    }
    else if (actionCommand.equals("exit")) {
      //退出程序
      this.exit();
    }
    else if (actionCommand.equals("orderSubmit")) {
      if(user == null){
        JOptionPane.showMessageDialog(null, "先登陆系统，再打开进货单填写窗口.");
        return;
      }else{
        //取得进货模块的用户权限
        int stockFunction = user.getStockFunction();
        if((stockFunction & 1) != 1){
          JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
          return;
        }
        if(ledgerDate.length() == 0){
          JOptionPane.showMessageDialog(null, "请选择账套.");
          return;
        }
        if(orderSubmitFrame == null){
          orderSubmitFrame = new OrderSubmitFrame(this);
          //使窗口居中对齐
          setCenterPosition(orderSubmitFrame);
          orderSubmitFrame.setVisible(true);
        }else{
          //重新传入用户类和账套
          orderSubmitFrame.setUser(user);
          orderSubmitFrame.setLedgerDate(ledgerDate);
          orderSubmitFrame.setVisible(true);
        }
      }
      orderSubmitFrame.setTitle("进货单填写窗口"+ ":用户("
                                + user.getUserName() + "):账套(" + ledgerDate + ")");
    }
    else if (actionCommand.equals("orderCommit")) {
      if(user == null){
        JOptionPane.showMessageDialog(null, "先登陆系统，再打开进货单审核窗口.");
        return;
      }else{
        //取得进货模块的用户权限
        int stockFunction = user.getStockFunction();
        if((stockFunction & 2) != 2){
          JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
          return;
        }
        if(ledgerDate.length() == 0){
          JOptionPane.showMessageDialog(null, "请选择账套.");
          return;
        }
        if(orderCommitFrame == null){
          orderCommitFrame = new OrderCommitFrame(this);
          //使窗口居中对齐
          setCenterPosition(orderCommitFrame);
          orderCommitFrame.setVisible(true);
        }else{
          //重新传入用户类和账套
          orderCommitFrame.setUser(user);
          orderCommitFrame.setLedgerDate(ledgerDate);
          orderCommitFrame.setVisible(true);
        }
      }
      orderCommitFrame.setTitle("进货单审核窗口"+ ":用户("
                                + user.getUserName() + "):账套(" + ledgerDate + ")");
    }
    else if (actionCommand.equals("orderCheck")) {
      if(user == null){
        JOptionPane.showMessageDialog(null, "先登陆系统，再打开检查货物窗口.");
        return;
      }else{
        //取得进货模块的用户权限
        int stockFunction = user.getStockFunction();
        if((stockFunction & 4) != 4){
          JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
          return;
        }
        if(ledgerDate.length() == 0){
          JOptionPane.showMessageDialog(null, "请选择账套.");
          return;
        }
        if(orderCheckFrame == null){
          orderCheckFrame = new OrderCheckFrame(this);
          //使窗口居中对齐
          setCenterPosition(orderCheckFrame);
          orderCheckFrame.setVisible(true);
        }else{
          //重新传入用户类和账套
          orderCheckFrame.setUser(user);
          orderCheckFrame.setLedgerDate(ledgerDate);
          orderCheckFrame.setVisible(true);
        }
      }
      orderCheckFrame.setTitle("检查货物窗口"+ ":用户("
                                + user.getUserName() + "):账套(" + ledgerDate + ")");
    }
    else if (actionCommand.equals("orderPay")) {
      if(user == null){
        JOptionPane.showMessageDialog(null, "先登陆系统，再打开进货付款窗口.");
        return;
      }else{
        //取得进货模块的用户权限
        int stockFunction = user.getStockFunction();
        if((stockFunction & 8) != 8){
          JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
          return;
        }
        if(ledgerDate.length() == 0){
          JOptionPane.showMessageDialog(null, "请选择账套.");
          return;
        }
        if(orderPayFrame == null){
          orderPayFrame = new OrderPayFrame(this);
          //使窗口居中对齐
          setCenterPosition(orderPayFrame);
          orderPayFrame.setVisible(true);
        }else{
          //重新传入用户类和账套
          orderPayFrame.setUser(user);
          orderPayFrame.setLedgerDate(ledgerDate);
          orderPayFrame.setVisible(true);
        }
      }
      orderPayFrame.setTitle("进货付款窗口"+ ":用户("
                             + user.getUserName() + "):账套(" + ledgerDate + ")");
    }
    else if (actionCommand.equals("cashLedgerView")) {
      if(user == null){
        JOptionPane.showMessageDialog(null, "先登陆系统，再打开现金日记账查看窗口.");
        return;
      }else{
        //取得进货模块的用户权限
        int stockFunction = user.getStockFunction();
        if((stockFunction & 16) != 16){
          JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
          return;
        }
        if(ledgerDate.length() == 0){
          JOptionPane.showMessageDialog(null, "请选择账套.");
          return;
        }
        if(cashLedgerViewFrame == null){
          cashLedgerViewFrame = new CashLedgerViewFrame(this);
          //使窗口居中对齐
          setCenterPosition(cashLedgerViewFrame);
          cashLedgerViewFrame.setVisible(true);
        }else{
          //重新传入用户类和账套
          cashLedgerViewFrame.setUser(user);
          cashLedgerViewFrame.setLedgerDate(ledgerDate);
          cashLedgerViewFrame.setVisible(true);
        }
      }
      cashLedgerViewFrame.setTitle("现金日记账查看窗口"+ ":用户("
                             + user.getUserName() + "):账套(" + ledgerDate + ")");
    }
    else if (actionCommand.equals("returnOrderSubmit")) {
      if(user == null){
        JOptionPane.showMessageDialog(null, "先登陆系统，再打开填写退货单窗口.");
        return;
      }else{
        //取得进货模块的用户权限
        int stockFunction = user.getStockFunction();
        if((stockFunction & 2) != 2){
          JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
          return;
        }
        if(ledgerDate.length() == 0){
          JOptionPane.showMessageDialog(null, "请选择账套.");
          return;
        }
        if(returnOrderSubmitFrame == null){
          returnOrderSubmitFrame = new ReturnOrderSubmitFrame(this);
          //使窗口居中对齐
          setCenterPosition(returnOrderSubmitFrame);
          returnOrderSubmitFrame.setVisible(true);
        }else{
          //重新传入用户类和账套
          returnOrderSubmitFrame.setUser(user);
          returnOrderSubmitFrame.setLedgerDate(ledgerDate);
          returnOrderSubmitFrame.setVisible(true);
        }
      }
      returnOrderSubmitFrame.setTitle("填写退货单窗口"+ ":用户("
                             + user.getUserName() + "):账套(" + ledgerDate + ")");
    }
    else if (actionCommand.equals("returnOrderPay")) {
      if(user == null){
        JOptionPane.showMessageDialog(null, "先登陆系统，再打开收取退款窗口.");
        return;
      }else{
        //取得进货模块的用户权限
        int stockFunction = user.getStockFunction();
        if((stockFunction & 8) != 8){
          JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
          return;
        }
        if(ledgerDate.length() == 0){
          JOptionPane.showMessageDialog(null, "请选择账套.");
          return;
        }
        if(returnOrderPayFrame == null){
          returnOrderPayFrame = new ReturnOrderPayFrame(this);
          //使窗口居中对齐
          setCenterPosition(returnOrderPayFrame);
          returnOrderPayFrame.setVisible(true);
        }else{
          //重新传入用户类和账套
          returnOrderPayFrame.setUser(user);
          returnOrderPayFrame.setLedgerDate(ledgerDate);
          returnOrderPayFrame.setVisible(true);
        }
      }
      returnOrderPayFrame.setTitle("收取退款窗口"+ ":用户("
                             + user.getUserName() + "):账套(" + ledgerDate + ")");
    }
    else if (actionCommand.equals("returnOrderCheck")) {
      if(user == null){
        JOptionPane.showMessageDialog(null, "先登陆系统，再打开退还货物窗口.");
        return;
      }else{
        //取得进货模块的用户权限
        int stockFunction = user.getStockFunction();
        if((stockFunction & 4) != 4){
          JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
          return;
        }
        if(ledgerDate.length() == 0){
          JOptionPane.showMessageDialog(null, "请选择账套.");
          return;
        }
        if(returnOrderCheckFrame == null){
          returnOrderCheckFrame = new ReturnOrderCheckFrame(this);
          //使窗口居中对齐
          setCenterPosition(returnOrderCheckFrame);
          returnOrderCheckFrame.setVisible(true);
        }else{
          //重新传入用户类和账套
          returnOrderCheckFrame.setUser(user);
          returnOrderCheckFrame.setLedgerDate(ledgerDate);
          returnOrderCheckFrame.setVisible(true);
        }
      }
      returnOrderCheckFrame.setTitle("退还货物窗口"+ ":用户("
                             + user.getUserName() + "):账套(" + ledgerDate + ")");
    }
    else if (actionCommand.equals("stockOrderSearch")) {
      if(user == null){
        JOptionPane.showMessageDialog(null, "先登陆系统，再打开进货单查询窗口.");
        return;
      }else{
        //取得进货模块的用户权限
        int stockFunction = user.getStockFunction();
        if((stockFunction & 32) != 32){
          JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
          return;
        }
        if(ledgerDate.length() == 0){
          JOptionPane.showMessageDialog(null, "请选择账套.");
          return;
        }
        if(stockOrderSearchFrame == null){
          stockOrderSearchFrame = new StockOrderSearchFrame(this);
          //使窗口居中对齐
          setCenterPosition(stockOrderSearchFrame);
          stockOrderSearchFrame.setVisible(true);
        }else{
          //重新传入用户类和账套
          stockOrderSearchFrame.setUser(user);
          stockOrderSearchFrame.setLedgerDate(ledgerDate);
          stockOrderSearchFrame.setVisible(true);
        }
      }
      stockOrderSearchFrame.setTitle("进货单查询窗口"+ ":用户("
                             + user.getUserName() + "):账套(" + ledgerDate + ")");
    }
    else if (actionCommand.equals("accountPayableSearch")) {
      if(user == null){
        JOptionPane.showMessageDialog(null, "先登陆系统，再打开应付账款查询窗口.");
        return;
      }else{
        //取得进货模块的用户权限
        int stockFunction = user.getStockFunction();
        if((stockFunction & 64) != 64){
          JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
          return;
        }
        if(ledgerDate.length() == 0){
          JOptionPane.showMessageDialog(null, "请选择账套.");
          return;
        }
        if(accountPayableSearchFrame == null){
          accountPayableSearchFrame = new AccountPayableSearchFrame(this);
          //使窗口居中对齐
          setCenterPosition(accountPayableSearchFrame);
          accountPayableSearchFrame.setVisible(true);
        }else{
          //重新传入用户类和账套
          accountPayableSearchFrame.setUser(user);
          accountPayableSearchFrame.setLedgerDate(ledgerDate);
          accountPayableSearchFrame.setVisible(true);
        }
      }
      accountPayableSearchFrame.setTitle("应付账款查询窗口"+ ":用户("
                             + user.getUserName() + "):账套(" + ledgerDate + ")");
    }
    else if (actionCommand.equals("stockAccountEntryCheck")) {
      if(user == null){
        JOptionPane.showMessageDialog(null, "先登陆系统，再打开审核进货会计分录窗口.");
        return;
      }else{
        //取得进货模块的用户权限
        int stockFunction = user.getStockFunction();
        if((stockFunction & 128) != 128){
          JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
          return;
        }
        if(ledgerDate.length() == 0){
          JOptionPane.showMessageDialog(null, "请选择账套.");
          return;
        }
        if(stockAccountEntryCheckFrame == null){
          stockAccountEntryCheckFrame = new StockAccountEntryCheckFrame(this);
          //使窗口居中对齐
          setCenterPosition(stockAccountEntryCheckFrame);
          stockAccountEntryCheckFrame.setVisible(true);
        }else{
          //重新传入用户类和账套
          stockAccountEntryCheckFrame.setUser(user);
          stockAccountEntryCheckFrame.setLedgerDate(ledgerDate);
          stockAccountEntryCheckFrame.setVisible(true);
        }
      }
      stockAccountEntryCheckFrame.setTitle("审核进货会计分录窗口"+ ":用户("
                             + user.getUserName() + "):账套(" + ledgerDate + ")");
    }
    else if (actionCommand.equals("stockAccountEntryCreate")) {
      if(user == null){
        JOptionPane.showMessageDialog(null, "先登陆系统，再打开编写进货会计分录窗口.");
        return;
      }else{
        //取得进货模块的用户权限
        int stockFunction = user.getStockFunction();
        if((stockFunction & 128) != 128){
          JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
          return;
        }
        if(ledgerDate.length() == 0){
          JOptionPane.showMessageDialog(null, "请选择账套.");
          return;
        }
        if(stockAccountEntryCreateFrame == null){
          stockAccountEntryCreateFrame = new StockAccountEntryCreateFrame(this);
          //使窗口居中对齐
          setCenterPosition(stockAccountEntryCreateFrame);
          stockAccountEntryCreateFrame.setVisible(true);
        }else{
          //重新传入用户类和账套
          stockAccountEntryCreateFrame.setUser(user);
          stockAccountEntryCreateFrame.setLedgerDate(ledgerDate);
          stockAccountEntryCreateFrame.setVisible(true);
        }
      }
      stockAccountEntryCreateFrame.setTitle("编写进货会计分录窗口"+ ":用户("
                             + user.getUserName() + "):账套(" + ledgerDate + ")");
    }
    else if (actionCommand.equals("stockAccountEntrySearch")) {
      if(user == null){
        JOptionPane.showMessageDialog(null, "先登陆系统，再打开查询进货会计分录窗口.");
        return;
      }else{
        //取得进货模块的用户权限
        int stockFunction = user.getStockFunction();
        if((stockFunction & 256) != 256){
          JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
          return;
        }
        if(ledgerDate.length() == 0){
          JOptionPane.showMessageDialog(null, "请选择账套.");
          return;
        }
        if(stockAccountEntrySearchFrame == null){
          stockAccountEntrySearchFrame = new StockAccountEntrySearchFrame(this);
          //使窗口居中对齐
          setCenterPosition(stockAccountEntrySearchFrame);
          stockAccountEntrySearchFrame.setVisible(true);
        }else{
          //重新传入用户类和账套
          stockAccountEntrySearchFrame.setUser(user);
          stockAccountEntrySearchFrame.setLedgerDate(ledgerDate);
          stockAccountEntrySearchFrame.setVisible(true);
        }
      }
      stockAccountEntrySearchFrame.setTitle("查询进货会计分录窗口"+ ":用户("
                             + user.getUserName() + "):账套(" + ledgerDate + ")");
    }
    else if (actionCommand.equals("stockTransferSubmit")) {
      if(user == null){
        JOptionPane.showMessageDialog(null, "先登陆系统，再打开商品调出窗口.");
        return;
      }else{
        //取得库存模块的用户权限
        int stockManageFunction = user.getStockManageFunction();
        if((stockManageFunction & 1) != 1){
          JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
          return;
        }
        if(ledgerDate.length() == 0){
          JOptionPane.showMessageDialog(null, "请选择账套.");
          return;
        }
        if(stockTransferSubmitFrame == null){
          stockTransferSubmitFrame = new StockTransferSubmitFrame(this);
          //使窗口居中对齐
          setCenterPosition(stockTransferSubmitFrame);
          stockTransferSubmitFrame.setVisible(true);
        }else{
          //重新传入用户类和账套
          stockTransferSubmitFrame.setUser(user);
          stockTransferSubmitFrame.setLedgerDate(ledgerDate);
          stockTransferSubmitFrame.setVisible(true);
        }
      }
      stockTransferSubmitFrame.setTitle("商品调出窗口"+ ":用户("
                             + user.getUserName() + "):账套(" + ledgerDate + ")");
    }
    else if (actionCommand.equals("stockTransferCheck")) {
      if(user == null){
        JOptionPane.showMessageDialog(null, "先登陆系统，再打开商品验收窗口.");
        return;
      }else{
        //取得库存模块的用户权限
        int stockManageFunction = user.getStockManageFunction();
        if((stockManageFunction & 2) != 2){
          JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
          return;
        }
        if(ledgerDate.length() == 0){
          JOptionPane.showMessageDialog(null, "请选择账套.");
          return;
        }
        if(stockTransferCheckFrame == null){
          stockTransferCheckFrame = new StockTransferCheckFrame(this);
          //使窗口居中对齐
          setCenterPosition(stockTransferCheckFrame);
          stockTransferCheckFrame.setVisible(true);
        }else{
          //重新传入用户类和账套
          stockTransferCheckFrame.setUser(user);
          stockTransferCheckFrame.setLedgerDate(ledgerDate);
          stockTransferCheckFrame.setVisible(true);
        }
      }
      stockTransferCheckFrame.setTitle("商品验收窗口"+ ":用户("
                             + user.getUserName() + "):账套(" + ledgerDate + ")");
    }
    else if (actionCommand.equals("goodsPriceManage")) {
      if(user == null){
        JOptionPane.showMessageDialog(null, "先登陆系统，再打开商品调价窗口.");
        return;
      }else{
        //取得库存模块的用户权限
        int stockManageFunction = user.getStockManageFunction();
        if((stockManageFunction & 4) != 4){
          JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
          return;
        }
        if(ledgerDate.length() == 0){
          JOptionPane.showMessageDialog(null, "请选择账套.");
          return;
        }
        if(goodsPriceManageFrame == null){
          goodsPriceManageFrame = new GoodsPriceManageFrame(this);
          //使窗口居中对齐
          setCenterPosition(goodsPriceManageFrame);
          goodsPriceManageFrame.setVisible(true);
        }else{
          //重新传入用户类和账套
          goodsPriceManageFrame.setUser(user);
          goodsPriceManageFrame.setLedgerDate(ledgerDate);
          goodsPriceManageFrame.setVisible(true);
          //显示商品类别
          goodsPriceManageFrame.showAllCategories();
        }
      }
      goodsPriceManageFrame.setTitle("商品调价窗口"+ ":用户("
                             + user.getUserName() + "):账套(" + ledgerDate + ")");
    }
    else if (actionCommand.equals("goodsQuantitySplit")) {
      if(user == null){
        JOptionPane.showMessageDialog(null, "先登陆系统，再打开商品数量分拆窗口.");
        return;
      }else{
        //取得库存模块的用户权限
        int stockManageFunction = user.getStockManageFunction();
        if((stockManageFunction & 8) != 8){
          JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
          return;
        }
        if(ledgerDate.length() == 0){
          JOptionPane.showMessageDialog(null, "请选择账套.");
          return;
        }
        if(goodsQuantitySplitFrame == null){
          goodsQuantitySplitFrame = new GoodsQuantitySplitFrame(this);
          //使窗口居中对齐
          setCenterPosition(goodsQuantitySplitFrame);
          goodsQuantitySplitFrame.setVisible(true);
        }else{
          //重新传入用户类和账套
          goodsQuantitySplitFrame.setUser(user);
          goodsQuantitySplitFrame.setLedgerDate(ledgerDate);
          goodsQuantitySplitFrame.setVisible(true);
        }
      }
      goodsQuantitySplitFrame.setTitle("商品数量分拆窗口"+ ":用户("
                             + user.getUserName() + "):账套(" + ledgerDate + ")");
    }
    else if (actionCommand.equals("goodsQuantityCombine")) {
      if(user == null){
        JOptionPane.showMessageDialog(null, "先登陆系统，再打开商品数量组合窗口.");
        return;
      }else{
        //取得库存模块的用户权限
        int stockManageFunction = user.getStockManageFunction();
        if((stockManageFunction & 8) != 8){
          JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
          return;
        }
        if(ledgerDate.length() == 0){
          JOptionPane.showMessageDialog(null, "请选择账套.");
          return;
        }
        if(goodsQuantityCombineFrame == null){
          goodsQuantityCombineFrame = new GoodsQuantityCombineFrame(this);
          //使窗口居中对齐
          setCenterPosition(goodsQuantityCombineFrame);
          goodsQuantityCombineFrame.setVisible(true);
        }else{
          //重新传入用户类和账套
          goodsQuantityCombineFrame.setUser(user);
          goodsQuantityCombineFrame.setLedgerDate(ledgerDate);
          goodsQuantityCombineFrame.setVisible(true);
        }
      }
      goodsQuantityCombineFrame.setTitle("商品数量组合窗口"+ ":用户("
                             + user.getUserName() + "):账套(" + ledgerDate + ")");
    }
    else if (actionCommand.equals("stocktakeSubmit")) {
      if(user == null){
        JOptionPane.showMessageDialog(null, "先登陆系统，再打开库存盘点计数窗口.");
        return;
      }else{
        //取得库存模块的用户权限
        int stockManageFunction = user.getStockManageFunction();
        if((stockManageFunction & 16) != 16){
          JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
          return;
        }
        if(ledgerDate.length() == 0){
          JOptionPane.showMessageDialog(null, "请选择账套.");
          return;
        }
        if(stocktakeSubmitFrame == null){
          stocktakeSubmitFrame = new StocktakeSubmitFrame(this);
          //使窗口居中对齐
          setCenterPosition(stocktakeSubmitFrame);
          stocktakeSubmitFrame.setVisible(true);
        }else{
          //重新传入用户类和账套
          stocktakeSubmitFrame.setUser(user);
          stocktakeSubmitFrame.setLedgerDate(ledgerDate);
          stocktakeSubmitFrame.setVisible(true);
        }
      }
      stocktakeSubmitFrame.setTitle("库存盘点计数窗口"+ ":用户("
                             + user.getUserName() + "):账套(" + ledgerDate + ")");
    }
    else if (actionCommand.equals("stocktakeCheck")) {
      if(user == null){
        JOptionPane.showMessageDialog(null, "先登陆系统，再打开库存盘点核查窗口.");
        return;
      }else{
        //取得库存模块的用户权限
        int stockManageFunction = user.getStockManageFunction();
        if((stockManageFunction & 32) != 32){
          JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
          return;
        }
        if(ledgerDate.length() == 0){
          JOptionPane.showMessageDialog(null, "请选择账套.");
          return;
        }
        if(stocktakeCheckFrame == null){
          stocktakeCheckFrame = new StocktakeCheckFrame(this);
          //使窗口居中对齐
          setCenterPosition(stocktakeCheckFrame);
          stocktakeCheckFrame.setVisible(true);
        }else{
          //重新传入用户类和账套
          stocktakeCheckFrame.setUser(user);
          stocktakeCheckFrame.setLedgerDate(ledgerDate);
          stocktakeCheckFrame.setVisible(true);
        }
      }
      stocktakeCheckFrame.setTitle("库存盘点核查窗口"+ ":用户("
                             + user.getUserName() + "):账套(" + ledgerDate + ")");
    }
    else if (actionCommand.equals("stocktakeLossManage")) {
      if(user == null){
        JOptionPane.showMessageDialog(null, "先登陆系统，再打开库存盘点损失单管理窗口.");
        return;
      }else{
        //取得库存模块的用户权限
        int stockManageFunction = user.getStockManageFunction();
        if((stockManageFunction & 32) != 32){
          JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
          return;
        }
        if(ledgerDate.length() == 0){
          JOptionPane.showMessageDialog(null, "请选择账套.");
          return;
        }
        if(stocktakeLossManageFrame == null){
          stocktakeLossManageFrame = new StocktakeLossManageFrame(this);
          //使窗口居中对齐
          setCenterPosition(stocktakeLossManageFrame);
          stocktakeLossManageFrame.setVisible(true);
        }else{
          //重新传入用户类和账套
          stocktakeLossManageFrame.setUser(user);
          stocktakeLossManageFrame.setLedgerDate(ledgerDate);
          stocktakeLossManageFrame.setVisible(true);
        }
      }
      stocktakeLossManageFrame.setTitle("库存盘点损失单管理窗口"+ ":用户("
                             + user.getUserName() + "):账套(" + ledgerDate + ")");
    }
    else if (actionCommand.equals("stocktakeGainManage")) {
      if(user == null){
        JOptionPane.showMessageDialog(null, "先登陆系统，再打开库存盘点盈收单管理窗口.");
        return;
      }else{
        //取得库存模块的用户权限
        int stockManageFunction = user.getStockManageFunction();
        if((stockManageFunction & 32) != 32){
          JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
          return;
        }
        if(ledgerDate.length() == 0){
          JOptionPane.showMessageDialog(null, "请选择账套.");
          return;
        }
        if(stocktakeGainManageFrame == null){
          stocktakeGainManageFrame = new StocktakeGainManageFrame(this);
          //使窗口居中对齐
          setCenterPosition(stocktakeGainManageFrame);
          stocktakeGainManageFrame.setVisible(true);
        }else{
          //重新传入用户类和账套
          stocktakeGainManageFrame.setUser(user);
          stocktakeGainManageFrame.setLedgerDate(ledgerDate);
          stocktakeGainManageFrame.setVisible(true);
        }
      }
      stocktakeGainManageFrame.setTitle("库存盘点盈收单管理窗口"+ ":用户("
                             + user.getUserName() + "):账套(" + ledgerDate + ")");
    }
    else if (actionCommand.equals("stockSearch")) {
      if(user == null){
        JOptionPane.showMessageDialog(null, "先登陆系统，再打开库存商品查询窗口.");
        return;
      }else{
        //取得库存模块的用户权限
        int stockManageFunction = user.getStockManageFunction();
        if((stockManageFunction & 64) != 64){
          JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
          return;
        }
        if(ledgerDate.length() == 0){
          JOptionPane.showMessageDialog(null, "请选择账套.");
          return;
        }
        if(stockSearchFrame == null){
          stockSearchFrame = new StockSearchFrame(this);
          //使窗口居中对齐
          setCenterPosition(stockSearchFrame);
          stockSearchFrame.setVisible(true);
        }else{
          //重新传入用户类和账套
          stockSearchFrame.setUser(user);
          stockSearchFrame.setLedgerDate(ledgerDate);
          stockSearchFrame.setVisible(true);
        }
      }
      stockSearchFrame.setTitle("库存商品查询窗口"+ ":用户("
                             + user.getUserName() + "):账套(" + ledgerDate + ")");
    }
    else if (actionCommand.equals("stockLedgerSearch")) {
      if(user == null){
        JOptionPane.showMessageDialog(null, "先登陆系统，再打开库存单据查询窗口.");
        return;
      }else{
        //取得库存模块的用户权限
        int stockManageFunction = user.getStockManageFunction();
        if((stockManageFunction & 128) != 128){
          JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
          return;
        }
        if(ledgerDate.length() == 0){
          JOptionPane.showMessageDialog(null, "请选择账套.");
          return;
        }
        if(stockLedgerSearchFrame == null){
          stockLedgerSearchFrame = new StockLedgerSearchFrame(this);
          //使窗口居中对齐
          setCenterPosition(stockLedgerSearchFrame);
          stockLedgerSearchFrame.setVisible(true);
        }else{
          //重新传入用户类和账套
          stockLedgerSearchFrame.setUser(user);
          stockLedgerSearchFrame.setLedgerDate(ledgerDate);
          stockLedgerSearchFrame.setVisible(true);
        }
      }
      stockLedgerSearchFrame.setTitle("库存单据查询窗口"+ ":用户("
                             + user.getUserName() + "):账套(" + ledgerDate + ")");
    }
    else if (actionCommand.equals("stockUsefulLifeSearch")) {
      if(user == null){
        JOptionPane.showMessageDialog(null, "先登陆系统，再打开商品有效期查询窗口.");
        return;
      }else{
        //取得库存模块的用户权限
        int stockManageFunction = user.getStockManageFunction();
        if((stockManageFunction & 512) != 512){
          JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
          return;
        }
        if(ledgerDate.length() == 0){
          JOptionPane.showMessageDialog(null, "请选择账套.");
          return;
        }
        if(stockUsefulLifeSearchFrame == null){
          stockUsefulLifeSearchFrame = new StockUsefulLifeSearchFrame(this);
          //使窗口居中对齐
          setCenterPosition(stockUsefulLifeSearchFrame);
          stockUsefulLifeSearchFrame.setVisible(true);
        }else{
          //重新传入用户类和账套
          stockUsefulLifeSearchFrame.setUser(user);
          stockUsefulLifeSearchFrame.setLedgerDate(ledgerDate);
          stockUsefulLifeSearchFrame.setVisible(true);
        }
      }
      stockUsefulLifeSearchFrame.setTitle("商品有效期查询窗口"+ ":用户("
                             + user.getUserName() + "):账套(" + ledgerDate + ")");
    }
    else if (actionCommand.equals("stockAlarmManage")) {
      if(user == null){
        JOptionPane.showMessageDialog(null, "先登陆系统，再打开库存警告管理窗口.");
        return;
      }else{
        //取得库存模块的用户权限
        int stockManageFunction = user.getStockManageFunction();
        if((stockManageFunction & 256) != 256){
          JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
          return;
        }
        if(ledgerDate.length() == 0){
          JOptionPane.showMessageDialog(null, "请选择账套.");
          return;
        }
        if(stockAlarmManageFrame == null){
          stockAlarmManageFrame = new StockAlarmManageFrame(this);
          //使窗口居中对齐
          setCenterPosition(stockAlarmManageFrame);
          stockAlarmManageFrame.setVisible(true);
        }else{
          //重新传入用户类和账套
          stockAlarmManageFrame.setUser(user);
          stockAlarmManageFrame.setLedgerDate(ledgerDate);
          stockAlarmManageFrame.setVisible(true);
        }
      }
      stockAlarmManageFrame.setTitle("库存警告管理窗口"+ ":用户("
                             + user.getUserName() + "):账套(" + ledgerDate + ")");
    }
    else if (actionCommand.equals("stockManageAccountEntryCheck")) {
      if(user == null){
        JOptionPane.showMessageDialog(null, "先登陆系统，再打开审核库存会计分录窗口.");
        return;
      }else{
        //取得库存模块的用户权限
        int stockManageFunction = user.getStockManageFunction();
        if((stockManageFunction & 1024) != 1024){
          JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
          return;
        }
        if(ledgerDate.length() == 0){
          JOptionPane.showMessageDialog(null, "请选择账套.");
          return;
        }
        if(stockManageAccountEntryCheckFrame == null){
          stockManageAccountEntryCheckFrame = new StockManageAccountEntryCheckFrame(this);
          //使窗口居中对齐
          setCenterPosition(stockManageAccountEntryCheckFrame);
          stockManageAccountEntryCheckFrame.setVisible(true);
        }else{
          //重新传入用户类和账套
          stockManageAccountEntryCheckFrame.setUser(user);
          stockManageAccountEntryCheckFrame.setLedgerDate(ledgerDate);
          stockManageAccountEntryCheckFrame.setVisible(true);
        }
      }
      stockManageAccountEntryCheckFrame.setTitle("审核库存会计分录窗口"+ ":用户("
                             + user.getUserName() + "):账套(" + ledgerDate + ")");
    }
    else if (actionCommand.equals("stockManageAccountEntryCreate")) {
      if(user == null){
        JOptionPane.showMessageDialog(null, "先登陆系统，再打开编写库存会计分录窗口.");
        return;
      }else{
        //取得库存模块的用户权限
        int stockManageFunction = user.getStockManageFunction();
        if((stockManageFunction & 1024) != 1024){
          JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
          return;
        }
        if(ledgerDate.length() == 0){
          JOptionPane.showMessageDialog(null, "请选择账套.");
          return;
        }
        if(stockManageAccountEntryCreateFrame == null){
          stockManageAccountEntryCreateFrame = new StockManageAccountEntryCreateFrame(this);
          //使窗口居中对齐
          setCenterPosition(stockManageAccountEntryCreateFrame);
          stockManageAccountEntryCreateFrame.setVisible(true);
        }else{
          //重新传入用户类和账套
          stockManageAccountEntryCreateFrame.setUser(user);
          stockManageAccountEntryCreateFrame.setLedgerDate(ledgerDate);
          stockManageAccountEntryCreateFrame.setVisible(true);
        }
      }
      stockManageAccountEntryCreateFrame.setTitle("编写库存会计分录窗口"+ ":用户("
                             + user.getUserName() + "):账套(" + ledgerDate + ")");
    }
    else if (actionCommand.equals("stockManageAccountEntrySearch")) {
      if(user == null){
        JOptionPane.showMessageDialog(null, "先登陆系统，再打开查询库存会计分录窗口.");
        return;
      }else{
        //取得库存模块的用户权限
        int stockManageFunction = user.getStockManageFunction();
        if((stockManageFunction & 2048) != 2048){
          JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
          return;
        }
        if(ledgerDate.length() == 0){
          JOptionPane.showMessageDialog(null, "请选择账套.");
          return;
        }
        if(stockManageAccountEntrySearchFrame == null){
          stockManageAccountEntrySearchFrame = new StockManageAccountEntrySearchFrame(this);
          //使窗口居中对齐
          setCenterPosition(stockManageAccountEntrySearchFrame);
          stockManageAccountEntrySearchFrame.setVisible(true);
        }else{
          //重新传入用户类和账套
          stockManageAccountEntrySearchFrame.setUser(user);
          stockManageAccountEntrySearchFrame.setLedgerDate(ledgerDate);
          stockManageAccountEntrySearchFrame.setVisible(true);
        }
      }
      stockManageAccountEntrySearchFrame.setTitle("查询库存会计分录窗口"+ ":用户("
                             + user.getUserName() + "):账套(" + ledgerDate + ")");
    }
    else if (actionCommand.equals("discountGoodsView")) {
      if(user == null){
        JOptionPane.showMessageDialog(null, "先登陆系统，再打开特价商品查看窗口.");
        return;
      }else{
        if(discountGoodsViewFrame == null){
          discountGoodsViewFrame = new DiscountGoodsViewFrame(this);
          //使窗口居中对齐
          setCenterPosition(discountGoodsViewFrame);
          discountGoodsViewFrame.setVisible(true);
        }else{
          //重新传入用户类
          discountGoodsViewFrame.setUser(user);
          discountGoodsViewFrame.setVisible(true);
        }
      }
      discountGoodsViewFrame.setTitle("特价商品查看窗口"+ ":用户("
                             + user.getUserName() + ")");
    }
    else if (actionCommand.equals("counterSale")) {
      if(user == null){
        JOptionPane.showMessageDialog(null, "先登陆系统，再打开前台销售窗口.");
        return;
      }else{
        //取得销售模块的用户权限
        int saleFunction = user.getSaleFunction();
        if((saleFunction & 1) != 1){
          JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
          return;
        }
        if(ledgerDate.length() == 0){
          JOptionPane.showMessageDialog(null, "请选择账套.");
          return;
        }
        //取得仓库名
        String warehouse = (String)JOptionPane.showInputDialog(null,"您好,请输入柜台的名字",
                                 "柜台输入框",JOptionPane.QUESTION_MESSAGE);
        if(stockManagementData.checkWarehouse(warehouse) == 0){
          JOptionPane.showMessageDialog(null, "柜台不存在.");
          return;
        }
        if(counterSaleFrame == null){
          counterSaleFrame = new CounterSaleFrame(this);
          //使窗口居中对齐
          setCenterPosition(counterSaleFrame);
          counterSaleFrame.setVisible(true);
        }else{
          //重新传入用户类和账套
          counterSaleFrame.setUser(user);
          counterSaleFrame.setLedgerDate(ledgerDate);
          counterSaleFrame.setVisible(true);
        }
        //设置柜台
        counterSaleFrame.setWarehouse(warehouse);
      }
      counterSaleFrame.setTitle("前台销售窗口"+ ":用户("
                             + user.getUserName() + "):账套(" + ledgerDate + ")");
    }
    else if (actionCommand.equals("creditSale")) {
      if(user == null){
        JOptionPane.showMessageDialog(null, "先登陆系统，再打开信用销售窗口.");
        return;
      }else{
        //取得销售模块的用户权限
        int saleFunction = user.getSaleFunction();
        if((saleFunction & 2) != 2){
          JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
          return;
        }
        if(ledgerDate.length() == 0){
          JOptionPane.showMessageDialog(null, "请选择账套.");
          return;
        }
        if(creditSaleFrame == null){
          creditSaleFrame = new CreditSaleFrame(this);
          //使窗口居中对齐
          setCenterPosition(creditSaleFrame);
          creditSaleFrame.setVisible(true);
        }else{
          //重新传入用户类和账套
          creditSaleFrame.setUser(user);
          creditSaleFrame.setLedgerDate(ledgerDate);
          creditSaleFrame.setVisible(true);
        }
      }
      creditSaleFrame.setTitle("信用销售窗口"+ ":用户("
                             + user.getUserName() + "):账套(" + ledgerDate + ")");
    }
    else if (actionCommand.equals("saleReceive")) {
      if(user == null){
        JOptionPane.showMessageDialog(null, "先登陆系统，再打开销售收款窗口.");
        return;
      }else{
        //取得销售模块的用户权限
        int saleFunction = user.getSaleFunction();
        if((saleFunction & 4) != 4){
          JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
          return;
        }
        if(ledgerDate.length() == 0){
          JOptionPane.showMessageDialog(null, "请选择账套.");
          return;
        }
        if(saleReceiveFrame == null){
          saleReceiveFrame = new SaleReceiveFrame(this);
          //使窗口居中对齐
          setCenterPosition(saleReceiveFrame);
          saleReceiveFrame.setVisible(true);
        }else{
          //重新传入用户类和账套
          saleReceiveFrame.setUser(user);
          saleReceiveFrame.setLedgerDate(ledgerDate);
          saleReceiveFrame.setVisible(true);
        }
      }
      saleReceiveFrame.setTitle("销售收款窗口"+ ":用户("
                             + user.getUserName() + "):账套(" + ledgerDate + ")");
    }
    else if (actionCommand.equals("counterSaleReturn")) {
      if(user == null){
        JOptionPane.showMessageDialog(null, "先登陆系统，再打开前台销售退货窗口.");
        return;
      }else{
        //取得销售模块的用户权限
        int saleFunction = user.getSaleFunction();
        if((saleFunction & 1) != 1){
          JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
          return;
        }
        if(ledgerDate.length() == 0){
          JOptionPane.showMessageDialog(null, "请选择账套.");
          return;
        }
        if(counterSaleReturnFrame == null){
          counterSaleReturnFrame = new CounterSaleReturnFrame(this);
          //使窗口居中对齐
          setCenterPosition(counterSaleReturnFrame);
          counterSaleReturnFrame.setVisible(true);
        }else{
          //重新传入用户类和账套
          counterSaleReturnFrame.setUser(user);
          counterSaleReturnFrame.setLedgerDate(ledgerDate);
          counterSaleReturnFrame.setVisible(true);
        }
      }
      counterSaleReturnFrame.setTitle("前台销售退货窗口"+ ":用户("
                             + user.getUserName() + "):账套(" + ledgerDate + ")");
    }
    else if (actionCommand.equals("creditSaleReturn")) {
      if(user == null){
        JOptionPane.showMessageDialog(null, "先登陆系统，再打开信用销售退货窗口.");
        return;
      }else{
        //取得销售模块的用户权限
        int saleFunction = user.getSaleFunction();
        if((saleFunction & 2) != 2){
          JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
          return;
        }
        if(ledgerDate.length() == 0){
          JOptionPane.showMessageDialog(null, "请选择账套.");
          return;
        }
        if(creditSaleReturnFrame == null){
          creditSaleReturnFrame = new CreditSaleReturnFrame(this);
          //使窗口居中对齐
          setCenterPosition(creditSaleReturnFrame);
          creditSaleReturnFrame.setVisible(true);
        }else{
          //重新传入用户类和账套
          creditSaleReturnFrame.setUser(user);
          creditSaleReturnFrame.setLedgerDate(ledgerDate);
          creditSaleReturnFrame.setVisible(true);
        }
      }
      creditSaleReturnFrame.setTitle("信用销售退货窗口"+ ":用户("
                             + user.getUserName() + "):账套(" + ledgerDate + ")");
    }
    else if (actionCommand.equals("saleReturnPayable")) {
      if(user == null){
        JOptionPane.showMessageDialog(null, "先登陆系统，再打开信用销售退款窗口.");
        return;
      }else{
        //取得销售模块的用户权限
        int saleFunction = user.getSaleFunction();
        if((saleFunction & 4) != 4){
          JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
          return;
        }
        if(ledgerDate.length() == 0){
          JOptionPane.showMessageDialog(null, "请选择账套.");
          return;
        }
        if(saleReturnPayableFrame == null){
          saleReturnPayableFrame = new SaleReturnPayableFrame(this);
          //使窗口居中对齐
          setCenterPosition(saleReturnPayableFrame);
          saleReturnPayableFrame.setVisible(true);
        }else{
          //重新传入用户类和账套
          saleReturnPayableFrame.setUser(user);
          saleReturnPayableFrame.setLedgerDate(ledgerDate);
          saleReturnPayableFrame.setVisible(true);
        }
      }
      saleReturnPayableFrame.setTitle("信用销售退款窗口"+ ":用户("
                             + user.getUserName() + "):账套(" + ledgerDate + ")");
    }
    else if (actionCommand.equals("saleLedgerSearch")) {
      if(user == null){
        JOptionPane.showMessageDialog(null, "先登陆系统，再打开销售单查询窗口.");
        return;
      }else{
        //取得销售模块的用户权限
        int saleFunction = user.getSaleFunction();
        if((saleFunction & 8) != 8){
          JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
          return;
        }
        if(ledgerDate.length() == 0){
          JOptionPane.showMessageDialog(null, "请选择账套.");
          return;
        }
        if(saleLedgerSearchFrame == null){
          saleLedgerSearchFrame = new SaleLedgerSearchFrame(this);
          //使窗口居中对齐
          setCenterPosition(saleLedgerSearchFrame);
          saleLedgerSearchFrame.setVisible(true);
        }else{
          //重新传入用户类和账套
          saleLedgerSearchFrame.setUser(user);
          saleLedgerSearchFrame.setLedgerDate(ledgerDate);
          saleLedgerSearchFrame.setVisible(true);
        }
      }
      saleLedgerSearchFrame.setTitle("销售单查询窗口"+ ":用户("
                             + user.getUserName() + "):账套(" + ledgerDate + ")");
    }
    else if (actionCommand.equals("saleReceiveSearch")) {
      if(user == null){
        JOptionPane.showMessageDialog(null, "先登陆系统，再打开应收账款查询窗口.");
        return;
      }else{
        //取得销售模块的用户权限
        int saleFunction = user.getSaleFunction();
        if((saleFunction & 16) != 16){
          JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
          return;
        }
        if(ledgerDate.length() == 0){
          JOptionPane.showMessageDialog(null, "请选择账套.");
          return;
        }
        if(saleReceiveSearchFrame == null){
          saleReceiveSearchFrame = new SaleReceiveSearchFrame(this);
          //使窗口居中对齐
          setCenterPosition(saleReceiveSearchFrame);
          saleReceiveSearchFrame.setVisible(true);
        }else{
          //重新传入用户类和账套
          saleReceiveSearchFrame.setUser(user);
          saleReceiveSearchFrame.setLedgerDate(ledgerDate);
          saleReceiveSearchFrame.setVisible(true);
        }
      }
      saleReceiveSearchFrame.setTitle("应收账款查询窗口"+ ":用户("
                             + user.getUserName() + "):账套(" + ledgerDate + ")");
    }
    else if (actionCommand.equals("saleAccountEntryCheck")) {
      if(user == null){
        JOptionPane.showMessageDialog(null, "先登陆系统，再打开审核销售会计分录窗口.");
        return;
      }else{
        //取得销售模块的用户权限
        int saleFunction = user.getSaleFunction();
        if((saleFunction & 32) != 32){
          JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
          return;
        }
        if(ledgerDate.length() == 0){
          JOptionPane.showMessageDialog(null, "请选择账套.");
          return;
        }
        if(saleAccountEntryCheckFrame == null){
          saleAccountEntryCheckFrame = new SaleAccountEntryCheckFrame(this);
          //使窗口居中对齐
          setCenterPosition(saleAccountEntryCheckFrame);
          saleAccountEntryCheckFrame.setVisible(true);
        }else{
          //重新传入用户类和账套
          saleAccountEntryCheckFrame.setUser(user);
          saleAccountEntryCheckFrame.setLedgerDate(ledgerDate);
          saleAccountEntryCheckFrame.setVisible(true);
        }
      }
      saleAccountEntryCheckFrame.setTitle("审核销售会计分录窗口"+ ":用户("
                             + user.getUserName() + "):账套(" + ledgerDate + ")");
    }
    else if (actionCommand.equals("saleAccountEntryCreate")) {
      if(user == null){
        JOptionPane.showMessageDialog(null, "先登陆系统，再打开编写销售会计分录窗口.");
        return;
      }else{
        //取得销售模块的用户权限
        int saleFunction = user.getSaleFunction();
        if((saleFunction & 32) != 32){
          JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
          return;
        }
        if(ledgerDate.length() == 0){
          JOptionPane.showMessageDialog(null, "请选择账套.");
          return;
        }
        if(saleAccountEntryCreateFrame == null){
          saleAccountEntryCreateFrame = new SaleAccountEntryCreateFrame(this);
          //使窗口居中对齐
          setCenterPosition(saleAccountEntryCreateFrame);
          saleAccountEntryCreateFrame.setVisible(true);
        }else{
          //重新传入用户类和账套
          saleAccountEntryCreateFrame.setUser(user);
          saleAccountEntryCreateFrame.setLedgerDate(ledgerDate);
          saleAccountEntryCreateFrame.setVisible(true);
        }
      }
      saleAccountEntryCreateFrame.setTitle("编写销售会计分录窗口"+ ":用户("
                             + user.getUserName() + "):账套(" + ledgerDate + ")");
    }
    else if (actionCommand.equals("saleAccountEntrySearch")) {
      if(user == null){
        JOptionPane.showMessageDialog(null, "先登陆系统，再打开查询销售会计分录窗口.");
        return;
      }else{
        //取得销售模块的用户权限
        int saleFunction = user.getSaleFunction();
        if((saleFunction & 64) != 64){
          JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
          return;
        }
        if(ledgerDate.length() == 0){
          JOptionPane.showMessageDialog(null, "请选择账套.");
          return;
        }
        if(saleAccountEntrySearchFrame == null){
          saleAccountEntrySearchFrame = new SaleAccountEntrySearchFrame(this);
          //使窗口居中对齐
          setCenterPosition(saleAccountEntrySearchFrame);
          saleAccountEntrySearchFrame.setVisible(true);
        }else{
          //重新传入用户类和账套
          saleAccountEntrySearchFrame.setUser(user);
          saleAccountEntrySearchFrame.setLedgerDate(ledgerDate);
          saleAccountEntrySearchFrame.setVisible(true);
        }
      }
      saleAccountEntrySearchFrame.setTitle("查询销售会计分录窗口"+ ":用户("
                             + user.getUserName() + "):账套(" + ledgerDate + ")");
    }
  }
  //使窗口居中的方法
  public void setCenterPosition(JFrame frame){
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = frame.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }
    frame.setLocation( (screenSize.width - frameSize.width) / 2,
                           (screenSize.height - frameSize.height) / 2);
  }
  //设置用户的方法
  public void setUser(User user) {
    this.user = user;
  }
  //取得用户的方法
  public User getUser() {
    return user;
  }
  //取得数据类的方法
  public StockManagementData getStockManagementData() {
    return stockManagementData;
  }
  //设置账套日期变量
  public void setLedgerDate(String ledgerDate) {
    this.ledgerDate = ledgerDate;
  }
  //取得账套日期变量
  public String getLedgerDate() {
    return this.ledgerDate;
  }
}
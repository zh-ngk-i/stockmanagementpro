﻿package com.shinear.sm.baseinforinterface;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.shinear.sm.data.StockManagementData;
import com.shinear.sm.user.User;
import com.shinear.sm.maininterface.*;

public class ChangePasswordFrame extends JFrame implements ActionListener {
  JPanel contentPane;
  JLabel jLabel1 = new JLabel();
  JLabel jLabel2 = new JLabel();
  JLabel jLabel3 = new JLabel();
  JPasswordField jPasswordField1 = new JPasswordField();
  JPasswordField jPasswordField2 = new JPasswordField();
  JPasswordField jPasswordField3 = new JPasswordField();
  JButton jButton1 = new JButton();
  JButton jButton2 = new JButton();
  //创建字体类
  Font dialog13 = new java.awt.Font("Dialog", 0, 13);
  //声明数据类
  StockManagementData stockManagementData = null;
  //声明用户类
  User user = null;
  //声明主窗口类
  StockManagementMainFrame stockManagementMainFrame = null;

  public ChangePasswordFrame(StockManagementMainFrame stockManagementMainFrame) {
    this.stockManagementMainFrame = stockManagementMainFrame;
    //取得主窗口的数据类
    stockManagementData = stockManagementMainFrame.getStockManagementData();
    //取得主窗口的用户类
    user = stockManagementMainFrame.getUser();
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception  {
    contentPane = (JPanel) this.getContentPane();
    //设置窗口面板布局，窗口大小和标题
    contentPane.setLayout(null);
    this.setSize(new Dimension(400, 300));
    this.setTitle("修改密码窗口");
    //设置标签控件的属性
    jLabel1.setText("旧密码：");
    jLabel1.setBounds(new Rectangle(71, 50, 61, 14));
    jLabel2.setText("新密码：");
    jLabel2.setBounds(new Rectangle(71, 95, 56, 16));
    jLabel3.setText("确认新密码：");
    jLabel3.setBounds(new Rectangle(71, 137, 99, 16));
    //设置密码编辑框控件的属性
    jPasswordField1.setBounds(new Rectangle(183, 46, 132, 22));
    jPasswordField2.setBounds(new Rectangle(183, 89, 132, 22));
    jPasswordField3.setBounds(new Rectangle(183, 131, 132, 22));
    //设置按钮的属性
    jButton1.setText("修改密码");
    jButton1.setActionCommand("changePassword");
    jButton1.setBounds(new Rectangle(71, 200, 101, 25));
    jButton1.addActionListener(this);
    jButton2.setText("退出");
    jButton2.setActionCommand("exit");
    jButton2.setBounds(new Rectangle(214, 200, 101, 25));
    jButton2.addActionListener(this);
    //为窗口面板加入各个控件
    contentPane.add(jLabel1, null);
    contentPane.add(jLabel2, null);
    contentPane.add(jLabel3, null);
    contentPane.add(jPasswordField1, null);
    contentPane.add(jPasswordField2, null);
    contentPane.add(jPasswordField3, null);
    contentPane.add(jButton1, null);
    contentPane.add(jButton2, null);
    //设置窗口类的字体
    setupFont();
  }
  //设置窗口类的字体
  public void setupFont(){
    Component[] components = contentPane.getComponents();
    for(int i = 0; i < components.length; i++){
      components[i].setFont(dialog13);
    }
  }
  protected void processWindowEvent(WindowEvent e) {
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      exit();
    }
  }
  //单击事件处理代码
  public void actionPerformed(ActionEvent e) {
    //取得按钮的动作字符串
    String actionCommand = e.getActionCommand().trim();
    //取得旧密码
    String oldUserPassword = new String(jPasswordField1.getPassword());
    //取得新密码
    String newUserPassword = new String(jPasswordField2.getPassword());
    //取得确认新密码
    String confirmUserPassword = new String(jPasswordField3.getPassword());
    if(actionCommand.equals("changePassword")){
      //检查旧密码是否正确
      if(!oldUserPassword.equals(user.getUserPassword())){
        JOptionPane.showMessageDialog(null, "旧密码输入错误.");
        return;
      }else{
        //检查新密码是否为空
        if(newUserPassword.trim().length() == 0){
          JOptionPane.showMessageDialog(null, "新密码不能为空.");
          return;
        }
        //检查新密码和确认新密码是否相同
        if(!newUserPassword.equals(confirmUserPassword)){
          JOptionPane.showMessageDialog(null, "新密码和确认新密码不相同.");
          return;
        }
        //设置用户类的密码
        user.setUserPassword(newUserPassword);
        //更改用户类的密码
        stockManagementData.updateUser(user);
        //将用户类传入主窗口
        stockManagementMainFrame.setUser(user);
      }
      JOptionPane.showMessageDialog(null, "成功修改密码.");
      exit();
    }
    if(actionCommand.equals("exit")){
      exit();
    }
  }
  //退出方法
  public void exit(){
    //将输入框的值设为空值
    jPasswordField1.setText("");
    jPasswordField2.setText("");
    jPasswordField3.setText("");
    //隐藏窗口
    this.setVisible(false);
  }
  //设置用户的方法
  public void setUser(User user) {
    this.user = user;
  }
}
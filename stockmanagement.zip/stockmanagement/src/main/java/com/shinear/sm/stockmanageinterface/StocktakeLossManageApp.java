﻿package com.shinear.sm.stockmanageinterface;

import javax.swing.UIManager;
import java.awt.*;
import javax.swing.*;
import com.shinear.sm.maininterface.*;
import com.shinear.sm.user.User;

public class StocktakeLossManageApp {

  public StocktakeLossManageApp() {
    //创建主窗口类，该类供测试使用
    StockManagementMainFrame stockManagementMainFrame = new StockManagementMainFrame();
    //创建用户类
    User user = new User("jack", "jack", 4095, 0, 32, 0);
    //取得库存模块的用户权限
    int stockManageFunction = user.getStockManageFunction();
    if((stockManageFunction & 32) != 32){
      JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
      System.exit(0);
    }
    //设置主窗口的用户类
    stockManagementMainFrame.setUser(user);
    //设置主窗口的账套
    stockManagementMainFrame.setLedgerDate("200405");
    StocktakeLossManageFrame frame = new StocktakeLossManageFrame(stockManagementMainFrame);
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = frame.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }
    frame.setLocation( (screenSize.width - frameSize.width) / 2,
                      (screenSize.height - frameSize.height) / 2);
    frame.setVisible(true);
  }
  public static void main(String[] args) {
    try {
      UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
    }
    catch(Exception e) {
      e.printStackTrace();
    }
    new StocktakeLossManageApp();
  }
}
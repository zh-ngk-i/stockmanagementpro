﻿package com.shinear.sm.stockmanagementpro;

import javax.ejb.*;
import java.util.*;

public interface UserTableHome extends javax.ejb.EJBLocalHome {
  public UserTable create(String userName, String userPassword, int baseInforFunction, int stockFunction, int stockManageFunction, int saleFunction) throws CreateException;
  public Collection findByUserName(String userName) throws FinderException;
  public UserTable findByPrimaryKey(String userName) throws FinderException;
}
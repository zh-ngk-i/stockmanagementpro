﻿package com.shinear.sm.print;

import javax.swing.*;
import java.awt.*;
import java.awt.print.*;
import java.util.*;

public class SaleOrderPrintPane  extends JPanel{
  final static Color fg = Color.black;

  //创建字体
  Font font16 = new Font("宋体", Font.BOLD, 16);
  Font font11 = new Font("宋体", Font.PLAIN, 11);
  //是否第1页变量
  static boolean isFirstPage = true;
  //创建销售单数组
  static String[] saleLedger = {"", "", "", "", "", "", "", "", "", "0", ""};
  //创建销售单明细账数组
  static String[][] saleSubLedger = new String[0][4];
/*测试数组
  //创建销售单数组
  static String[] saleLedger = {"20040500001", "0", "顾客", "jack", "", "",
      "收货地址1", "2004-5-6 16:32:00.0", "2004-5-6 16:32:00.0", "2", "备注"};
  //创建销售单明细账数组
  static String[][] saleSubLedger = {{"1234567891234567", "25.5", "25", "125623.85"},
      {"2234567891234567", "33.5", "25", "125623.85"},
      {"3234567891234567", "75.5", "25", "125623.85"},
      {"4234567891234567", "29.5", "25", "125623.85"},
      {"5234567891234567", "63.5", "25", "125623.85"},
  };
*/
  //创建页码变量
  static int printPage = 0;
  //页面左边的空白
  int pageLeftMargin = 88;
  //与左边的距离
  int x = 0;
  //与项部的距离
  int y = 0;
  //行宽
  int lineHeight = 14;
  //行间距
  int lineDistant = 14;
  //表格的行高
  int tableLineHeight = 17;
  //表格的总高度
  int tableHeight = 0;
  //创建完成状态数组
  String[] onProcesses = {"进行", "撤消", "完成"};

  //重新绘画
  public void paintComponent(Graphics g) {
    super.paintComponent(g);
    Graphics2D g2 = (Graphics2D) g;
    //设置画笔颜色
    g2.setPaint(fg);
    drawPages(g2);
  }
  public SaleOrderPrintPane() {
    this.setBackground(Color.white);
  }
  /** 打印页面的方法 */
  public void drawPages(Graphics2D g2){
    if(isFirstPage){
      drawFirstPage(g2);
    }else{
      drawOtherPages(g2);
    }
  }
  /** 打印第1页的方法 */
  public void drawFirstPage(Graphics2D g2){
    //取得表格的高度
    tableHeight = tableLineHeight * (saleSubLedger.length + 1);
    //设置字体
    g2.setFont(font16);
    //显示销售单
    g2.drawString("销售单", 273, 80);
/*显示第1行的内容*/
    g2.setFont(font11);
    x = pageLeftMargin;
    //第一行与顶部的距离
    y = 114;
    //显示第1列内容
    g2.drawString("单据编号：", x, y);
    x += 70;
    //显示第2列内容
    g2.drawString(saleLedger[0], x, y);
/*显示第2行的内容*/
    x = pageLeftMargin;
    y += lineHeight + lineDistant;
    //显示第1列内容
    g2.drawString("柜台销售员：", x, y);
    x += 70;
    //显示第2列内容
    g2.drawString(saleLedger[3], x, y);
/*显示第3行的内容*/
    x = pageLeftMargin;
    y += lineHeight + lineDistant;
    //显示第1列内容
    g2.drawString("客  户：", x, y);
    x += 70;
    //显示第2列内容
    g2.drawString(saleLedger[2], x, y);
/*显示第4行的内容*/
    x = pageLeftMargin;
    y += lineHeight + lineDistant;
    //显示第1列内容
    g2.drawString("送货地址：", x, y);
    x += 70;
    //显示第2列内容
    g2.drawString(saleLedger[6], x, y);
/*显示第5行的内容*/
    x = pageLeftMargin;
    y += lineHeight + lineDistant;
    //显示第1列内容
    g2.drawString("填写日期：", x, y);
    x += 70;
    //显示第2列内容
    g2.drawString(saleLedger[7], x, y);
/*显示第6行的内容*/
    x = pageLeftMargin;
    y += lineHeight + lineDistant;
    //显示第1列内容
    g2.drawString("完成状态：", x, y);
    x += 70;
    //显示第2列内容
    g2.drawString(onProcesses[Integer.parseInt(saleLedger[9])] , x, y);
/*显示第7行的内容*/
    x = pageLeftMargin;
    y += lineHeight + lineDistant;
    //显示第1列内容
    g2.drawString("备注：", x, y);
/*显示第8行的内容*/
    x = pageLeftMargin + 22;
    y += lineHeight + lineDistant;
    //显示第1列内容
    g2.drawString(saleLedger[10], x, y);
/*显示销售单明细账字符串*/
    x = pageLeftMargin;
    y += 48;
    //显示第1列内容
    g2.drawString("销售单明细账：", x, y);
/*显示表格的第一行的线*/
    x = pageLeftMargin;
    y += lineDistant;
    //画表格的横线
    g2.drawLine(x, y, x + 357, y);
    //画表格的第1条竖线
    g2.drawLine(x, y, x, y + tableHeight);
    //画表格的第2条竖线(商品条形码列)
    x += 123;
    g2.drawLine(x, y, x, y + tableHeight);
    //画表格的第3条竖线(销售价列)
    x += 83;
    g2.drawLine(x, y, x, y + tableHeight);
    //画表格的第4条竖线(数量列)
    x += 68;
    g2.drawLine(x, y, x, y + tableHeight);
    //画表格的第5条竖线(金额列)
    x += 83;
    g2.drawLine(x, y, x, y + tableHeight);
/*显示表格的标题*/
    x = pageLeftMargin;
    y += tableLineHeight;
    //画表格的横线
    g2.drawLine(x, y, x + 357, y);
    x += 35;
    //显示第1列内容
    g2.drawString("商品条形码", x, y - 4);
    x += 115;
    //显示第2列内容
    g2.drawString("销售价", x, y - 4);
    x += 80;
    //显示第3列内容
    g2.drawString("数量", x, y - 4);
    x += 75;
    //显示第4列内容
    g2.drawString("金额", x, y - 4);
/*显示表格的内容*/
    for(int i = 0; i < saleSubLedger.length; i++){
      x = pageLeftMargin;
      y += tableLineHeight;
      //画表格的横线
      g2.drawLine(x, y, x + 357, y);
      x += 5;
      //显示第1列内容
      g2.drawString(saleSubLedger[i][0], x, y - 4);
      x += 125;
      //显示第2列内容
      g2.drawString(saleSubLedger[i][1], x, y - 4);
      x += 80;
      //显示第3列内容
      g2.drawString(saleSubLedger[i][2], x, y - 4);
      x += 70;
      //显示第4列内容
      g2.drawString(saleSubLedger[i][3], x, y - 4);
    }
/*显示页尾的内容*/
    x = 279;
    y = 789;
    //显示页码
    g2.drawString("第 1 页", x, y);
  }
  /** 打印其它页面的方法 */
  public void drawOtherPages(Graphics2D g2){
    //设置字体
    g2.setFont(font11);
    //取得表格的高度
    tableHeight = tableLineHeight * (saleSubLedger.length + 1);
/*显示销售单明细账字符串*/
    x = pageLeftMargin;
    y = 75;
    //显示第1列内容
    g2.drawString("销售单明细账(接上页)：", x, y);
/*显示表格的第一行的线*/
    x = pageLeftMargin;
    y += lineDistant;
    //画表格的横线
    g2.drawLine(x, y, x + 357, y);
    //画表格的第1条竖线
    g2.drawLine(x, y, x, y + tableHeight);
    //画表格的第2条竖线(商品条形码列)
    x += 123;
    g2.drawLine(x, y, x, y + tableHeight);
    //画表格的第3条竖线(销售价列)
    x += 83;
    g2.drawLine(x, y, x, y + tableHeight);
    //画表格的第4条竖线(数量列)
    x += 68;
    g2.drawLine(x, y, x, y + tableHeight);
    //画表格的第5条竖线(金额列)
    x += 83;
    g2.drawLine(x, y, x, y + tableHeight);
    /*显示表格的标题*/
    x = pageLeftMargin;
    y += tableLineHeight;
    //画表格的横线
    g2.drawLine(x, y, x + 357, y);
    x += 35;
    //显示第1列内容
    g2.drawString("商品条形码", x, y - 4);
    x += 115;
    //显示第2列内容
    g2.drawString("销售价", x, y - 4);
    x += 80;
    //显示第3列内容
    g2.drawString("数量", x, y - 4);
    x += 75;
    //显示第4列内容
    g2.drawString("金额", x, y - 4);
/*显示表格的内容*/
    for (int i = 0; i < saleSubLedger.length; i++) {
      x = pageLeftMargin;
      y += tableLineHeight;
      //画表格的横线
      g2.drawLine(x, y, x + 357, y);
      x += 5;
      //显示第1列内容
      g2.drawString(saleSubLedger[i][0], x, y - 4);
      x += 125;
      //显示第2列内容
      g2.drawString(saleSubLedger[i][1], x, y - 4);
      x += 80;
      //显示第3列内容
      g2.drawString(saleSubLedger[i][2], x, y - 4);
      x += 70;
      //显示第4列内容
      g2.drawString(saleSubLedger[i][3], x, y - 4);
    }
/*显示页尾的内容*/
    x = 279;
    y = 789;
    g2.drawString("第 " + printPage + " 页", x, y);
  }
  public boolean isIsFirstPage() {
    return isFirstPage;
  }
  public void setIsFirstPage(boolean isFirstPage) {
    this.isFirstPage = isFirstPage;
  }
  public String[] getSaleLedger() {
    return saleLedger;
  }
  public void setSaleLedger(String[] saleLedger) {
    this.saleLedger = saleLedger;
  }
  public String[][] getSaleSubLedger() {
    return saleSubLedger;
  }
  public void setSaleSubLedger(String[][] saleSubLedger) {
    this.saleSubLedger = saleSubLedger;
  }
  public int getPrintPage() {
    return printPage;
  }
  public void setPrintPage(int pirntPage) {
    this.printPage = pirntPage;
  }
}
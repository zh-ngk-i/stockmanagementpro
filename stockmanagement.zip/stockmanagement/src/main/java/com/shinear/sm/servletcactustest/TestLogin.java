﻿package com.shinear.sm.servletcactustest;

import org.apache.cactus.*;
import com.shinear.sm.servlet.*;
import javax.servlet.*;
import java.io.*;
import javax.servlet.http.*;
import com.shinear.sm.user.*;

public class TestLogin extends ServletTestCase {
  private Login login = null;

  public TestLogin(String name) {
    super(name);
  }

  //在testPostMethod方法前运行，作用是创建Login Servlet
  protected void setUp() throws Exception {
    super.setUp();
    login = new Login();
    //初始化ServletContext对象
    login.init(config);
    request.setCharacterEncoding("GBK");
  }

  //在testPostMethod方法后运行，作用是清空Servlet
  protected void tearDown() throws Exception {
    login = null;
    super.tearDown();
  }

  //为testPostMethod方法传入参数的方法，正确用户名
  public void beginPostMethod(WebRequest theRequest) {
    //通过WebRequest类设置参数
    theRequest.addParameter("userName", "jack", WebRequest.POST_METHOD);
    theRequest.addParameter("userPassword", "jack", WebRequest.POST_METHOD);
    theRequest.addParameter("action", "登陆", WebRequest.POST_METHOD);
  }
  //测试doPost方法，正确用户名
  public void testPostMethod() throws ServletException, IOException {
    //测试是否正确设置参数
    assertEquals("jack", request.getParameter("userName"));
    assertEquals("jack", request.getParameter("userPassword"));
    //将request对象和response对象传入Servlet
    login.doPost(request, response);
    //测试用户类是否为空
    this.assertNotNull(session.getAttribute("user"));
  }
  //为testPostMethod1方法传入参数的方法，错误用户名
  public void beginPostMethod1(WebRequest theRequest) {
    theRequest.addParameter("userName", "jack1", WebRequest.POST_METHOD);
    theRequest.addParameter("userPassword", "Jdsfaack", WebRequest.POST_METHOD);
    theRequest.addParameter("action", "登陆", WebRequest.POST_METHOD);
  }
  //测试doPost方法，错误用户名
  public void testPostMethod1() throws ServletException, IOException {
    //将request对象和response对象传入Servlet
    login.doPost(request, response);
    //测试用户类是否为空
    this.assertNull(session.getAttribute("user"));
  }
}
﻿package com.shinear.sm.baseinforinterface;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.shinear.sm.data.StockManagementData;
import com.shinear.sm.user.User;
import com.shinear.sm.maininterface.*;

public class LoginFrame extends JFrame implements ActionListener {
  //声明窗口控件
  JPanel contentPane;
  JLabel nameLabel = new JLabel();
  JLabel passwordLabel = new JLabel();
  JTextField nameTextField = new JTextField();
  JPasswordField passwordField = new JPasswordField();
  JButton loginBtn = new JButton();
  JButton exitBtn = new JButton();
  //声明数据类
  StockManagementData stockManagementData = null;
  //声明用户类
  User user = null;
  //声明主窗口类
  StockManagementMainFrame stockManagementMainFrame = null;

  public LoginFrame(StockManagementMainFrame stockManagementMainFrame) {
    //取得主窗口对象
    this.stockManagementMainFrame = stockManagementMainFrame;
    //取得主窗口的数据对象
    stockManagementData = stockManagementMainFrame.getStockManagementData();
    try {jbInit();}
    catch(Exception e) {e.printStackTrace();}
  }

  private void jbInit() throws Exception  {
    //取得窗口面板
    contentPane = (JPanel) this.getContentPane();
    //定义窗口面板的布局
    contentPane.setLayout(null);
    //定义窗口的大小和标题
    this.setSize(new Dimension(400, 276));
    //定义标签的标题、字符大小和位置
    nameLabel.setText("用户名：");
    nameLabel.setFont(new java.awt.Font("Dialog", 0, 15));
    nameLabel.setBounds(new Rectangle(65, 67, 81, 16));
    passwordLabel.setText("密码：");
    passwordLabel.setFont(new java.awt.Font("Dialog", 0, 15));
    passwordLabel.setBounds(new Rectangle(65, 112, 79, 16));
    //定义编辑框的位置
    nameTextField.setBounds(new Rectangle(194, 67, 118, 22));
    passwordField.setBounds(new Rectangle(194, 112, 118, 22));
    //定义按钮的标题、动作字符串、字符大小、位置和加入动作接收器
    loginBtn.setText("登陆");
    loginBtn.setActionCommand("login");
    loginBtn.setFont(new java.awt.Font("Dialog", 0, 15));
    loginBtn.setBounds(new Rectangle(65, 180, 109, 25));
    loginBtn.addActionListener(this);
    exitBtn.setText("退出");
    exitBtn.setActionCommand("exit");
    exitBtn.setFont(new java.awt.Font("Dialog", 0, 15));
    exitBtn.setBounds(new Rectangle(203, 180, 109, 25));
    exitBtn.addActionListener(this);
    //为面板加入各个控件
    contentPane.add(nameLabel, null);
    contentPane.add(nameTextField, null);
    contentPane.add(passwordLabel, null);
    contentPane.add(passwordField, null);
    contentPane.add(exitBtn, null);
    contentPane.add(loginBtn, null);
  }
  protected void processWindowEvent(WindowEvent e) {
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      exit();
    }
  }
  //单击事件处理代码
  public void actionPerformed(ActionEvent e) {
    //取得按钮的动作字符串
    String actionCommand = e.getActionCommand().trim();
    //取得用户名
    String userName = nameTextField.getText();
    //取得密码
    String userPassword = new String(passwordField.getPassword());
    if(actionCommand.equals("login")){
      int[] result = stockManagementData.checkUser(userName, userPassword);
      if(result[0] == -1){
        JOptionPane.showMessageDialog(null, "用户名或者密码输入错误.");
        return;
      }else{
        //创建用户类
        user = new User(userName, userPassword, result[0], result[1], result[2],
                        result[3]);
        //将用户类传入主窗口
        stockManagementMainFrame.setUser(user);
        //更改主窗口的标题
        stockManagementMainFrame.setTitle("进销存管理信息系统主窗口" + ":登陆用户("
                                          + userName + ")");
        //将用户登陆信息写入日志数据表
        stockManagementData.createUserLog("登陆窗口", "登陆", userName);
      }
      exit();
    }
    if(actionCommand.equals("exit")){
      exit();
    }
  }
  //退出方法
  public void exit(){
    //将输入框的值设为空值
    nameTextField.setText("");
    passwordField.setText("");
    //隐藏登陆窗口
    this.setVisible(false);
  }
}
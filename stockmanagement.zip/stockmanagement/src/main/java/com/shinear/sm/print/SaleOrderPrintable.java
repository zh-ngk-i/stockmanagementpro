﻿package com.shinear.sm.print;

import java.awt.*;
import java.awt.print.*;

public class SaleOrderPrintable implements Printable {

  public SaleOrderPrintable() {
  }
  public int print(Graphics g, PageFormat pf, int pageIndex)
      throws PrinterException {
    //创建打印面板
    SaleOrderPrintPane saleOrderPrintPane = new SaleOrderPrintPane();
    //绘画打印面板的文字，并且输送至打印机
    saleOrderPrintPane.drawPages((Graphics2D) g );
    return Printable.PAGE_EXISTS;
  }
}

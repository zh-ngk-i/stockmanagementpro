﻿package com.shinear.sm.print;

import java.awt.*;
import java.awt.print.*;

public class StockReturnOrderPrintable implements Printable {

  public StockReturnOrderPrintable() {
  }
  public int print(Graphics g, PageFormat pf, int pageIndex)
      throws PrinterException {
    //创建打印面板
    StockReturnOrderPrintPane stockReturnOrderPrintPane = new StockReturnOrderPrintPane();
    //绘画打印面板的文字，并且输送至打印机
    stockReturnOrderPrintPane.drawPages((Graphics2D) g );
    return Printable.PAGE_EXISTS;
  }
}

﻿package com.shinear.sm.cactustest;

import org.apache.cactus.*;
import javax.naming.*;
import java.util.Collection;
import java.rmi.RemoteException;
import com.shinear.sm.stockmanagementpro.*;

public class TestGoodsCactus1 extends ServletTestCase {
  private static final String ERROR_NULL_REMOTE = "接口未定义.";
  private static final int MAX_OUTPUT_LINE_LENGTH = 100;
  private boolean logging = false;
  private GoodsHome goodsHome = null;
  private Goods goods = null;

  public TestGoodsCactus1(String name) {
    super(name);
  }

  public void initializeLocalHome() throws Exception {
    Context context = new InitialContext();
    goodsHome = (GoodsHome) context.lookup("Goods");
  }

  public void setUp() throws Exception {
    super.setUp();
    initializeLocalHome();
  }

  public void tearDown() throws Exception {
    goodsHome = null;
    goods = null;
    super.tearDown();
  }

  //测试商品创建方法
  public void testGoodsCreate() throws Exception {
    /*String goodsBarCode = "10000001";
    int categoryId = 1;
    String goodsName  = "类别1的商品1";
    String goodsNickName = "别名1";
    String goodsAssistantName = "助记码1";
    String goodsPYName = "LBDSP1";
    String unit = "件";
    String specification = "每箱10件";
    String producer = "生产厂商1";
    int upperLimit = 0;
    int lowerLimit = 0;
    double salePrice = 15;
    double discount = 1;
    //创建商品
    goodsHome.create(goodsBarCode, categoryId, goodsName, goodsNickName,
                     goodsAssistantName, goodsPYName, unit,
                     specification, producer, upperLimit, lowerLimit,
                     salePrice, discount);
    goodsBarCode = "10000002";
    categoryId = 1;
    goodsName  = "类别1的商品2";
    goodsNickName = "别名2";
    goodsAssistantName = "助记码2";
    goodsPYName = "LBDSP2";
    unit = "件";
    specification = "每箱10件";
    producer = "生产厂商2";
    upperLimit = 0;
    lowerLimit = 0;
    salePrice = 20;
    discount = 1;
    //创建商品
    goodsHome.create(goodsBarCode, categoryId, goodsName, goodsNickName,
                     goodsAssistantName, goodsPYName, unit,
                     specification, producer, upperLimit, lowerLimit,
                     salePrice, discount);*/
  }
  //测试根据类别取得商品的方法
  public void testFindByGoodsCategory() throws Exception {
    java.util.Collection col = goodsHome.findByGoodsCategory(1);
    this.assertEquals("return value", 2, col.size());
  }
  //测试根据条形码取得商品的方法
  public void testFindByGoodsBarCode() throws Exception {
    java.util.Collection col = goodsHome.findByGoodsBarCode("%1%");
    this.assertEquals("return value", 2, col.size());
  }
  //测试根据商品名字取得商品的方法
  public void testFindByGoodsName() throws Exception {
    java.util.Collection col = goodsHome.findByGoodsName("%商品%");
    this.assertEquals("return value", 2, col.size());
  }
  //测试根据生产厂商取得商品的方法
  public void testFindByProducer() throws Exception {
    java.util.Collection col = goodsHome.findByProducer("%生产厂商%");
    this.assertEquals("return value", 2, col.size());
  }
  //测试取得打折商品的方法
  public void testFindDiscountGoods() throws Exception {
    java.util.Collection col = goodsHome.findDiscountGoods();
    this.assertEquals("return value", 2, col.size());
  }
  //测试商品删除方法
  public void testGoodsDelete() throws Exception {
    /*String goodsBarCode = "10000001";
    goods = goodsHome.findByPrimaryKey(goodsBarCode);
    //删除商品
    goods.remove();
    goodsBarCode = "10000002";
    goods = goodsHome.findByPrimaryKey(goodsBarCode);
    //删除商品
    goods.remove();*/
  }
}
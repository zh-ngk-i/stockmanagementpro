﻿package com.shinear.sm.saleinterface;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import com.shinear.sm.data.*;
import com.shinear.sm.maininterface.*;
import com.shinear.sm.user.*;
import com.shinear.sm.method.*;

public class DiscountGoodsViewFrame extends JFrame implements ActionListener {
  JPanel contentPane;
  //创建列表框数据类和列表框控件
  DefaultListModel listData1 = new DefaultListModel();
  JList jList1 = new JList(listData1);
  //创建滚动框控件
  JScrollPane jScrollPane1 = new JScrollPane();
  //创建标签控件
  JLabel jLabel1 = new JLabel();
  JLabel jLabel2 = new JLabel();
  JLabel jLabel3 = new JLabel();
  JLabel jLabel4 = new JLabel();
  JLabel jLabel5 = new JLabel();
  //创建编辑框控件
  JTextField jTextField1 = new JTextField();
  JTextField jTextField2 = new JTextField();
  JTextField jTextField3 = new JTextField();
  JTextField jTextField4 = new JTextField();
  //创建按钮控件
  JButton jButton1 = new JButton();
  JButton jButton2 = new JButton();
  //创建字体类
  Font dialog13 = new java.awt.Font("Dialog", 0, 13);
  //声明数据类
  StockManagementData stockManagementData = null;
  //声明用户类
  User user = null;
  //声明主窗口类
  StockManagementMainFrame stockManagementMainFrame = null;
  //创建商品数组
  String[][] goods = new String[0][13];
  //创建方法类
  DataMethod dataMethod = new DataMethod();

  public DiscountGoodsViewFrame(StockManagementMainFrame stockManagementMainFrame) {
    this.stockManagementMainFrame = stockManagementMainFrame;
    //取得主窗口的数据类
    stockManagementData = stockManagementMainFrame.getStockManagementData();
    //取得主窗口的用户类
    user = stockManagementMainFrame.getUser();
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception  {
    contentPane = (JPanel) this.getContentPane();
    contentPane.setLayout(null);
    this.setSize(new Dimension(528, 339));
    this.setTitle("特价商品查看窗口");
    //设置标签控件属性
    jLabel1.setText("商品列表：");
    jLabel1.setBounds(new Rectangle(31, 18, 97, 16));
    jLabel2.setBounds(new Rectangle(208, 44, 82, 16));
    jLabel2.setText("商品条形码");
    jLabel3.setText("商品名称");
    jLabel3.setBounds(new Rectangle(208, 100, 72, 16));
    jLabel4.setText("商品折扣");
    jLabel4.setBounds(new Rectangle(208, 157, 78, 16));
    jLabel5.setText("商品售价");
    jLabel5.setBounds(new Rectangle(208, 213, 78, 16));
    //设置编辑框控件属性
    jTextField1.setEditable(false);
    jTextField1.setBounds(new Rectangle(291, 44, 196, 22));
    jTextField2.setEditable(false);
    jTextField2.setBounds(new Rectangle(291, 100, 196, 22));
    jTextField3.setEditable(false);
    jTextField3.setBounds(new Rectangle(291, 157, 58, 22));
    jTextField4.setEditable(false);
    jTextField4.setBounds(new Rectangle(291, 213, 58, 22));
    //设置按钮属性
    jButton1.setText("显示折扣商品");
    jButton1.setActionCommand("showDiscountGoods");
    jButton1.setBounds(new Rectangle(31, 247, 198, 25));
    jButton2.setText("退出");
    jButton2.setActionCommand("exit");
    jButton2.setBounds(new Rectangle(289, 247, 198, 25));
    //设置滚动框的属性
    jScrollPane1.setBounds(new Rectangle(31, 44, 153, 191));
    jScrollPane1.getViewport().add(jList1, null);
    //为列表框加入选择接收器
    jList1.addListSelectionListener(new ListSelectionListener() {
      public void valueChanged(ListSelectionEvent e) {
        jList1_valueChanged(e);
      }
    });
    contentPane.add(jLabel1, null);
    contentPane.add(jLabel2, null);
    contentPane.add(jLabel3, null);
    contentPane.add(jLabel4, null);
    contentPane.add(jLabel5, null);
    contentPane.add(jTextField1, null);
    contentPane.add(jTextField2, null);
    contentPane.add(jTextField3, null);
    contentPane.add(jTextField4, null);
    contentPane.add(jButton1, null);
    contentPane.add(jButton2, null);
    contentPane.add(jScrollPane1, null);
    //设置窗口类的字体和为按钮加入动作接收器
    setupFontAndListener();
  }
  //设置窗口类的字体和为按钮加入动作接收器的方法
  public void setupFontAndListener(){
    Component[] components = contentPane.getComponents();
    //创建临时按钮控件
    JButton tmpBtn = new JButton();
    for(int i = 0; i < components.length; i++){
      components[i].setFont(dialog13);
      if(components[i].getClass().getName().equals("javax.swing.JButton")){
        tmpBtn = (JButton)components[i];
        tmpBtn.addActionListener(this);
      }
    }
  }
  //显示查询商品的方法
  public void showSearchGoods(){
    listData1.clear();
    //为商品列表框加入商品条形码
    for(int i = 0; i < goods.length; i++){
      listData1.addElement(goods[i][0]);
    }
  }
  //显示单个商品的方法
  public void showGood(){
    //取得当前选择项的位置
    int selectedIndex = jList1.getSelectedIndex();
    //当列表框不处于选择状态，不显示商品数据
    if(selectedIndex == -1){
       return;
    }
    //显示商品条形码
    jTextField1.setText(goods[selectedIndex][0]);
    //显示商品名称
    jTextField2.setText(goods[selectedIndex][2]);
    //显示折扣
    jTextField3.setText(goods[selectedIndex][12]);
    //显示销售价
    jTextField4.setText(String.valueOf(dataMethod.round(Double.parseDouble(goods[selectedIndex][11]))));
  }
  //清空单个商品显示的方法
  public void clearGood(){
    jTextField1.setText("");
    jTextField2.setText("");
    jTextField3.setText("");
    jTextField4.setText("");
  }
  //退出方法
  public void exit(){
    //隐藏窗口
    this.setVisible(false);
    //清空数组的内容
    goods = new String[0][13];
    //清空列表框的内容
    listData1.clear();
    listData1.clear();
    //取得面板上的所有控件
    Component[] components = contentPane.getComponents();
    //创建临时编辑框控件
    JTextField tmpTextField = new JTextField();
    for(int i = 0; i < components.length; i++){
      if(components[i].getClass().getName().equals("javax.swing.JTextField")){
        tmpTextField = (JTextField)components[i];
        //清空编辑框的内容
        tmpTextField.setText("");
      }
    }
  }
  //设置用户的方法
  public void setUser(User user) {
    this.user = user;
  }
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      exit();
    }
  }
  //列表1的选择事件
  void jList1_valueChanged(ListSelectionEvent e) {
    if(listData1.size() > 0){
      this.showGood();
    }else{
      this.clearGood();
    }
  }
  //单击事件
  public void actionPerformed(ActionEvent e) {
    //取得按钮的动作字符串
    String actionCommand = e.getActionCommand().trim();
    //单击按钮的处理代码
    if(actionCommand.equals("showDiscountGoods")){
      //取得折扣商品
      goods = stockManagementData.getDiscountGoods();
      this.showSearchGoods();
    }else if(actionCommand.equals("search")){
    }else if(actionCommand.equals("exit")){
      exit();
    }
  }
}
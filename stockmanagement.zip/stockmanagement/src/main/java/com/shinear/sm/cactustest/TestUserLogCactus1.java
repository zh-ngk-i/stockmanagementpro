﻿package com.shinear.sm.cactustest;

import org.apache.cactus.*;
import com.shinear.sm.stockmanagementpro.*;
import javax.naming.*;
import java.sql.Timestamp;
import java.rmi.RemoteException;
import java.util.*;

public class TestUserLogCactus1 extends ServletTestCase {
  private static final String ERROR_NULL_REMOTE = "对象未定义.";
  private static final int MAX_OUTPUT_LINE_LENGTH = 100;
  private boolean logging = false;
  private UserLogHome userLogHome = null;
  private UserLog userLog = null;

  public TestUserLogCactus1(String name) {
    super(name);
  }
  //EJB初始化方法
  public void initializeLocalHome() throws Exception {
    Context context = new InitialContext();
    userLogHome = (UserLogHome) context.lookup("UserLog");
  }
  public void setUp() throws Exception {
    super.setUp();
    initializeLocalHome();
  }
  public void tearDown() throws Exception {
    userLogHome = null;
    userLog = null;
    super.tearDown();
  }
  //测试日志数据表记录的创建方法
  public void testCreateUserLog() throws Exception{
    Integer id = new Integer(1);
    String programName = "登陆窗口";
    String operationContent = "登陆";
    String userName = "jack";
    java.util.Calendar now = java.util.Calendar.getInstance();
    java.sql.Timestamp operationDate = new java.sql.Timestamp(now.getTime().getTime());
    userLogHome.create(id, programName, operationContent, userName, operationDate);
  }
  //测试取得全部日志记录的方法
  public void testUserLogFindAll() throws Exception{
    Collection col = userLogHome.findAll();
    this.assertEquals("", 187, col.size());
  }
  //测试根据操作程序名字取得日志记录的方法
  public void testUserLogFindByProgramName() throws Exception{
    Collection col = userLogHome.findByProgramName("%登陆窗口%");
    this.assertEquals("", 106, col.size());
  }
  //测试根据操作内容取得日志记录的方法
  public void testUserLogFindByOperationContent() throws Exception{
    Collection col = userLogHome.findByOperationContent("%删除%");
    this.assertEquals("", 2, col.size());
  }
  //测试根据用户名取得日志记录的方法
  public void testUserLogFindByUserName() throws Exception{
    Collection col = userLogHome.findByUserName("%ame%");
    this.assertEquals("", 23, col.size());
  }
  //测试根据日期范围取得日志记录的方法
  public void testUserLogFindByOperationDate() throws Exception{
    //创建日期类
    java.util.Calendar date = java.util.Calendar.getInstance();
    date.set(2004, 4, 4, 0, 0, 0);
    java.sql.Timestamp startDate = new java.sql.Timestamp(date.getTime().getTime());
    date.set(2004, 4, 8, 23, 59, 59);
    java.sql.Timestamp endDate = new java.sql.Timestamp(date.getTime().getTime());
    Collection col = userLogHome.findByOperationDate(startDate, endDate);
    this.assertEquals("", 69, col.size());
  }
  //测试日志数据表记录的删除方法
  public void testDeleteUserLog() throws Exception{
    Integer id = new Integer(1);
    userLog = userLogHome.findByPrimaryKey(id);
    userLog.remove();
  }
}
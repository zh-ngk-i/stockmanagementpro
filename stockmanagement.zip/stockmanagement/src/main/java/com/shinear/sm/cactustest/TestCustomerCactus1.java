﻿package com.shinear.sm.cactustest;

import org.apache.cactus.*;
import com.shinear.sm.stockmanagementpro.*;
import javax.naming.*;
import java.util.Collection;
import java.rmi.RemoteException;

public class TestCustomerCactus1 extends ServletTestCase {
  private static final String ERROR_NULL_REMOTE = "接口未定义.";
  private static final int MAX_OUTPUT_LINE_LENGTH = 100;
  private boolean logging = false;
  private CustomerHome customerHome = null;
  private Customer customer = null;

  public TestCustomerCactus1(String name) {
    super(name);
  }

  public void initializeLocalHome() throws Exception {
    Context context = new InitialContext();
    customerHome = (CustomerHome) context.lookup("Customer");
  }

  public void setUp() throws Exception {
    super.setUp();
    initializeLocalHome();
  }

  public void tearDown() throws Exception {
    customerHome = null;
    customer = null;
    super.tearDown();
  }

  //测试客户创建方法
  public void testCustomerCreate() throws Exception{
    //创建客户数组
    String[] customer = new String[]{"测试客户1", "南部", "拼音码1", "简称1", "021-556892",
        "张凡", "1350058956", "021-896523", "021-963258", "地址1", "511896",
        "中行", "银行帐号", "jack@hotmail.com", "www.jack.com", "10000","备注1"};
    //创建客户
    customerHome.create(customer[0], customer[1], customer[2], customer[3],
                        customer[4], customer[5], customer[6], customer[7],
                        customer[8], customer[9], customer[10], customer[11],
                        customer[12], customer[13], customer[14],
                        Double.parseDouble(customer[15]), customer[16]);
    customer = new String[]{"测试客户2", "北部", "拼音码2", "简称2", "021-556892",
        "张凡", "1350058956", "021-896523", "021-963258", "地址2", "511896",
        "中行", "银行帐号", "jack@hotmail.com", "www.jack.com", "10000", "备注2"};
    //创建客户
    customerHome.create(customer[0], customer[1], customer[2], customer[3],
                        customer[4], customer[5], customer[6], customer[7],
                        customer[8], customer[9], customer[10], customer[11],
                        customer[12], customer[13], customer[14],
                        Double.parseDouble(customer[15]), customer[16]);
    customer = new String[]{"测试客户3", "南部", "拼音码3", "简称3", "021-556892",
        "张凡", "1350058956", "021-896523", "021-963258", "地址3", "511896",
        "中行", "银行帐号", "jack@hotmail.com", "www.jack.com", "10000", "备注3"};
    //创建客户
    customerHome.create(customer[0], customer[1], customer[2], customer[3],
                        customer[4], customer[5], customer[6], customer[7],
                        customer[8], customer[9], customer[10], customer[11],
                        customer[12], customer[13], customer[14],
                        Double.parseDouble(customer[15]), customer[16]);
  }
  //测试客户更新方法
  public void testCustomerUpdate() throws Exception{
    String[] customer = new String[]{"测试客户1", "北部"};
    this.customer = customerHome.findByPrimaryKey(customer[0]);
    //更新客户的值
    this.customer.setCustomerZone(customer[1]);
  }
  //测试根据客户名字取得记录的方法
  public void testFindByCustomerName() throws Exception {
    Collection col = customerHome.findByCustomerName("%客户%");
    this.assertEquals("", 6, col.size());
  }
  //测试根据地区取得记录的方法
  public void testFindByCustomerZone() throws Exception {
    Collection col = customerHome.findByCustomerZone("%北部%");
    this.assertEquals("", 4, col.size());
  }
  //测试取得信用客户记录的方法
  public void testFindCreditCustomer() throws Exception {
    Collection col = customerHome.findCreditCustomer();
    this.assertEquals("", 6, col.size());
  }
  //测试客户删除方法
  public void testCustomerDelete() throws Exception{
    String[] customers = new String[]{"测试客户1", "测试客户2", "测试客户3"};
    customer = customerHome.findByPrimaryKey(customers[0]);
    //删除客户
    customer.remove();
    customer = customerHome.findByPrimaryKey(customers[1]);
    //删除客户
    customer.remove();
    customer = customerHome.findByPrimaryKey(customers[2]);
    //删除客户
    customer.remove();
  }
}
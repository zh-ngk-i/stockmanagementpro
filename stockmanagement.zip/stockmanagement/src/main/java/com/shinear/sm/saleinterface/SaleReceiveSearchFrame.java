﻿package com.shinear.sm.saleinterface;

import java.awt.*;
import java.awt.event.*;
import javax.swing.event.*;
import javax.swing.*;
import com.shinear.sm.data.*;
import com.shinear.sm.maininterface.*;
import com.shinear.sm.user.*;
import com.shinear.sm.method.*;
import java.util.Date;
import com.shinear.sm.print.*;

public class SaleReceiveSearchFrame extends JFrame implements ActionListener {
  JPanel contentPane;

  //创建标签控件
  JLabel jLabel1 = new JLabel();
  JLabel jLabel2 = new JLabel();
  JLabel jLabel3 = new JLabel();
  JLabel jLabel4 = new JLabel();
  JLabel jLabel5 = new JLabel();
  JLabel jLabel6 = new JLabel();
  JLabel jLabel7 = new JLabel();
  JLabel jLabel8 = new JLabel();
  JLabel jLabel9 = new JLabel();
  JLabel jLabel10 = new JLabel();
  JLabel jLabel11 = new JLabel();
  JLabel jLabel12 = new JLabel();
  JLabel jLabel13 = new JLabel();
  JLabel jLabel14 = new JLabel();
  JLabel jLabel15 = new JLabel();
  //创建编辑框控件
  JTextField jTextField1 = new JTextField();
  JTextField jTextField2 = new JTextField();
  JTextField jTextField3 = new JTextField();
  JTextField jTextField4 = new JTextField();
  JTextField jTextField5 = new JTextField();
  JTextField jTextField6 = new JTextField();
  JTextField jTextField7 = new JTextField();
  JTextField jTextField8 = new JTextField();
  JTextField jTextField9 = new JTextField();
  JTextField jTextField10 = new JTextField();
  JTextField jTextField11 = new JTextField();
  JTextField jTextField12 = new JTextField();
  //创建按钮控件
  JButton jButton1 = new JButton();
  //创建滚动框控件
  JScrollPane jScrollPane1 = new JScrollPane();
  JScrollPane jScrollPane2 = new JScrollPane();
  //创建列表框数据类和列表框控件
  DefaultListModel listData1 = new DefaultListModel();
  JList jList1 = new JList(listData1);
  //创建下拉列表框控件
  JComboBox jComboBox1 = new JComboBox();
  //创建文本框控件
  JTextArea jTextArea1 = new JTextArea();

  //创建字体类
  Font dialog13 = new java.awt.Font("Dialog", 0, 13);
  //声明数据类
  StockManagementData stockManagementData = null;
  //声明用户类
  User user = null;
  //声明主窗口类
  StockManagementMainFrame stockManagementMainFrame = null;
  //创建往来账套数组
  String[][] currentAccountLedger = new String[0][11];
  //创建方法类
  DataMethod dataMethod = new DataMethod();
  //创建完成状态数组
  String[] onProcesses = {"进行", "撤消", "完成"};
  //创建帐套日期字符串
  String ledgerDate = "";

  public SaleReceiveSearchFrame(StockManagementMainFrame stockManagementMainFrame) {
    this.stockManagementMainFrame = stockManagementMainFrame;
    //取得主窗口的数据类
    stockManagementData = stockManagementMainFrame.getStockManagementData();
    //取得主窗口的用户类
    user = stockManagementMainFrame.getUser();
    //取得主窗口的账套日期
    ledgerDate = stockManagementMainFrame.getLedgerDate();
    //取得销售模块的用户权限
    int saleFunction = user.getSaleFunction();
    if((saleFunction & 16) != 16){
      JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
      System.exit(0);
    }
    //检查账套日期
    if(ledgerDate.length() == 0){
      JOptionPane.showMessageDialog(null, user.getUserName() + "请选择账套.");
      return;
    }
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception  {
    contentPane = (JPanel) this.getContentPane();
    contentPane.setLayout(null);
    this.setSize(new Dimension(667, 379));
    this.setTitle("应收账款查询窗口");
    //设置标签的属性
    jLabel1.setText("收款单列表");
    jLabel1.setBounds(new Rectangle(28, 19, 85, 16));
    jLabel2.setText("查询条件");
    jLabel2.setBounds(new Rectangle(197, 45, 62, 16));
    jLabel3.setText("查询值");
    jLabel3.setBounds(new Rectangle(440, 45, 50, 16));
    jLabel4.setText("开始日期");
    jLabel4.setBounds(new Rectangle(197, 77, 67, 16));
    jLabel5.setText("结束日期");
    jLabel5.setBounds(new Rectangle(373, 77, 66, 16));
    jLabel6.setText("票据编号");
    jLabel6.setBounds(new Rectangle(197, 109, 66, 16));
    jLabel7.setText("相关联票据标识");
    jLabel7.setBounds(new Rectangle(393, 109, 95, 16));
    jLabel8.setText("金额");
    jLabel8.setBounds(new Rectangle(197, 141, 66, 16));
    jLabel9.setText("客户");
    jLabel9.setBounds(new Rectangle(197, 173, 66, 16));
    jLabel10.setText("开票据用户");
    jLabel10.setBounds(new Rectangle(337, 173, 69, 16));
    jLabel11.setText("现金管理员");
    jLabel11.setBounds(new Rectangle(486, 173, 66, 16));
    jLabel12.setText("开票据日期");
    jLabel12.setBounds(new Rectangle(197, 205, 66, 16));
    jLabel13.setText("收款日期");
    jLabel13.setBounds(new Rectangle(197, 237, 66, 16));
    jLabel14.setText("完成状态");
    jLabel14.setBounds(new Rectangle(197, 269, 66, 16));
    jLabel15.setText("备注");
    jLabel15.setBounds(new Rectangle(427, 205, 66, 16));
    //设置编辑框的属性
    jTextField1.setBounds(new Rectangle(492, 45, 133, 22));
    jTextField2.setBounds(new Rectangle(264, 77, 101, 22));
    jTextField3.setBounds(new Rectangle(439, 77, 101, 22));
    jTextField4.setEditable(false);
    jTextField4.setText("");
    jTextField4.setBounds(new Rectangle(264, 109, 123, 22));
    jTextField5.setEditable(false);
    jTextField5.setBounds(new Rectangle(487, 109, 138, 22));
    jTextField6.setEditable(false);
    jTextField6.setBounds(new Rectangle(264, 141, 65, 22));
    jTextField7.setEditable(false);
    jTextField7.setBounds(new Rectangle(264, 173, 65, 22));
    jTextField8.setEditable(false);
    jTextField8.setBounds(new Rectangle(414, 173, 65, 22));
    jTextField9.setEditable(false);
    jTextField9.setBounds(new Rectangle(560, 173, 65, 22));
    jTextField10.setEditable(false);
    jTextField10.setBounds(new Rectangle(264, 205, 147, 22));
    jTextField11.setEditable(false);
    jTextField11.setBounds(new Rectangle(264, 237, 147, 22));
    jTextField12.setEditable(false);
    jTextField12.setBounds(new Rectangle(264, 269, 147, 22));
    //设置按钮的属性
    jButton1.setText("查询");
    jButton1.setActionCommand("search");
    jButton1.setBounds(new Rectangle(546, 77, 79, 22));
    //设置滚动框的属性
    jScrollPane1.setBounds(new Rectangle(28, 45, 158, 240));
    jScrollPane2.setBounds(new Rectangle(426, 237, 199, 54));
    jScrollPane1.getViewport().add(jList1, null);
    jScrollPane2.getViewport().add(jTextArea1, null);
    //为列表框加入选择接收器
    jList1.addListSelectionListener(new ListSelectionListener() {
      public void valueChanged(ListSelectionEvent e) {
        //当多种事件被激发的时候,不执行接收器后面的代码
        if (e.getValueIsAdjusting()) return;
        jList1_valueChanged(e);
      }
    });
    //设置下拉列表框的属性
    jComboBox1.setBounds(new Rectangle(264, 45, 156, 22));
    jComboBox1.addItem("根据票据编号查询");
    jComboBox1.addItem("根据客户查询");
    jComboBox1.addItem("根据开票据用户查询");
    jComboBox1.addItem("根据现金管理员查询");
    jComboBox1.addItem("根据完成状态查询");
    jComboBox1.addItem("根据开票据日期查询");
    //为面板加入各个控件
    contentPane.add(jLabel1, null);
    contentPane.add(jLabel2, null);
    contentPane.add(jLabel3, null);
    contentPane.add(jLabel4, null);
    contentPane.add(jLabel5, null);
    contentPane.add(jLabel6, null);
    contentPane.add(jLabel7, null);
    contentPane.add(jLabel8, null);
    contentPane.add(jLabel9, null);
    contentPane.add(jLabel11, null);
    contentPane.add(jLabel12, null);
    contentPane.add(jLabel13, null);
    contentPane.add(jLabel14, null);
    contentPane.add(jLabel15, null);
    contentPane.add(jComboBox1, null);
    contentPane.add(jTextField1, null);
    contentPane.add(jTextField2, null);
    contentPane.add(jTextField3, null);
    contentPane.add(jTextField4, null);
    contentPane.add(jTextField5, null);
    contentPane.add(jTextField6, null);
    contentPane.add(jTextField7, null);
    contentPane.add(jTextField9, null);
    contentPane.add(jTextField10, null);
    contentPane.add(jTextField11, null);
    contentPane.add(jTextField12, null);
    contentPane.add(jScrollPane1, null);
    contentPane.add(jScrollPane2, null);
    contentPane.add(jButton1, null);
    contentPane.add(jTextField8, null);
    contentPane.add(jLabel10, null);
    //设置窗口类的字体和为按钮加入动作接收器
    setupFontAndListener();
  }
  //设置窗口类的字体和为按钮加入动作接收器的方法
  public void setupFontAndListener(){
    Component[] components = contentPane.getComponents();
    //创建临时按钮控件
    JButton tmpBtn = new JButton();
    for(int i = 0; i < components.length; i++){
      components[i].setFont(dialog13);
      if(components[i].getClass().getName().equals("javax.swing.JButton")){
        tmpBtn = (JButton)components[i];
        tmpBtn.addActionListener(this);
      }
    }
  }
  //退出方法
  public void exit(){
    //隐藏窗口
    this.setVisible(false);
    //清空数组的内容
    currentAccountLedger = new String[0][13];
    //清空列表框的内容
    listData1.clear();
    //清空文本框的内容
    jTextArea1.setText("");
    //取得面板上的所有控件
    Component[] components = contentPane.getComponents();
    //创建临时编辑框控件
    JTextField tmpTextField = new JTextField();
    for(int i = 0; i < components.length; i++){
      if(components[i].getClass().getName().equals("javax.swing.JTextField")){
        tmpTextField = (JTextField)components[i];
        //清空编辑框的内容
        tmpTextField.setText("");
      }
    }
  }
  //设置用户的方法
  public void setUser(User user) {
    this.user = user;
  }
  //设置账套的方法
  public void setLedgerDate(String ledgerDate) {
    this.ledgerDate = ledgerDate;
  }
  protected void processWindowEvent(WindowEvent e) {
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      exit();
    }
  }
  //显示查询应收票据的方法
  public void showSearchCurrentAccountLedger(){
    listData1.clear();
    //为应收票据列表框加入应收票据数据
    for(int i = 0; i < currentAccountLedger.length; i++){
      listData1.addElement(currentAccountLedger[i][0]);
    }
  }
  //显示单个应收票据的方法
  public void showCurrentAccountLedger(){
    //取得当前选择项的位置
    int selectedIndex = jList1.getSelectedIndex();
    //当列表框不处于选择状态，不显示商品数据
    if(selectedIndex == -1){
       return;
    }
    //显示应收票据的数据
    jTextField4.setText(currentAccountLedger[selectedIndex][0]);
    jTextField5.setText(currentAccountLedger[selectedIndex][1]);
    jTextField6.setText(currentAccountLedger[selectedIndex][3]);
    jTextField7.setText(currentAccountLedger[selectedIndex][4]);
    jTextField8.setText(currentAccountLedger[selectedIndex][5]);
    jTextField9.setText(currentAccountLedger[selectedIndex][6]);
    jTextField10.setText(currentAccountLedger[selectedIndex][7]);
    jTextField11.setText(currentAccountLedger[selectedIndex][8]);
    jTextField12.setText(onProcesses[Integer.parseInt(currentAccountLedger[selectedIndex][9])]);
    jTextArea1.setText(currentAccountLedger[selectedIndex][10]);
  }
  //清空单个应收票据显示的方法
  public void clearCurrentAccountLedger(){
    jTextField4.setText("");
    jTextField5.setText("");
    jTextField6.setText("");
    jTextField7.setText("");
    jTextField8.setText("");
    jTextField9.setText("");
    jTextField10.setText("");
    jTextField11.setText("");
    jTextField12.setText("");
    jTextArea1.setText("");
  }
  //列表1的选择事件
  void jList1_valueChanged(ListSelectionEvent e) {
    if(listData1.size() > 0){
      this.showCurrentAccountLedger();
    }else{
      this.clearCurrentAccountLedger();
    }
  }
  //查询方法
  public void search(){
    //取得查询选项
    int selectedIndex = jComboBox1.getSelectedIndex();
    //取得编辑框的变量
    String searchValue = jTextField1.getText().trim();
    String startDateStr = jTextField2.getText().trim();
    String endDateStr = jTextField3.getText().trim();
    if (selectedIndex == 0 | selectedIndex == 1 | selectedIndex == 2 |
        selectedIndex == 3 | selectedIndex == 4) {
      if (searchValue.length() == 0) {
        JOptionPane.showMessageDialog(null, "请输入查询值");
        return;
      }
      switch (selectedIndex) {
        case 0:
          //根据票据编号取得记录
          currentAccountLedger = stockManagementData.getCurrentAccountLedgerByStringField(
              ledgerDate, "currentAccountId", searchValue, 1);
          break;
        case 1:
          //根据客户取得记录
          currentAccountLedger = stockManagementData.getCurrentAccountLedgerByStringField(
              ledgerDate, "receiverName", searchValue, 1);
          break;
        case 2:
          //根据开票据用户取得记录
          currentAccountLedger = stockManagementData.getCurrentAccountLedgerByStringField(
              ledgerDate, "documentFiller", searchValue, 1);
          break;
        case 3:
          //根据现金管理员取得记录
          currentAccountLedger = stockManagementData.getCurrentAccountLedgerByStringField(
              ledgerDate, "cashUser", searchValue, 1);
          break;
        case 4:
          if(dataMethod.checkInt(searchValue) == 0){
            JOptionPane.showMessageDialog(null, "按完成状态查询时，输入值必须是整数，"
                                          + "0表示进行，1表示撤消，2表示完成.");
            return;
          }
          //根据完成状态取得记录
          currentAccountLedger = stockManagementData.getCurrentAccountLedgerByOnProcess(
              ledgerDate, 1, Integer.parseInt(searchValue));
          break;
      }
    }else{
      java.sql.Timestamp startDate = dataMethod.transferDate(startDateStr);
      java.sql.Timestamp endDate = dataMethod.transferEndDate(endDateStr);
      if(startDate == null | endDate == null){
        JOptionPane.showMessageDialog(null, "日期输入错误，正确的日期格式是"
                                      + "yyyy-mm-dd（年-月-日），如2004-1-1");
        return;
      }
      //根据日期取得记录
      currentAccountLedger = stockManagementData.getCurrentAccountLedgerByFillDate(ledgerDate,
          startDate, endDate, 1);
    }
    this.showSearchCurrentAccountLedger();
  }
  //单击事件
  public void actionPerformed(ActionEvent e) {
    //取得按钮的动作字符串
    String actionCommand = e.getActionCommand().trim();
    if (actionCommand.equals("search")) {
      //查询
      search();
    }
  }
}
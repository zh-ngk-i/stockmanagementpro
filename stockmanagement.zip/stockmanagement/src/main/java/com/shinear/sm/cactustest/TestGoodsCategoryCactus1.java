﻿package com.shinear.sm.cactustest;

import org.apache.cactus.*;
import javax.naming.*;
import java.util.Collection;
import java.rmi.RemoteException;
import com.shinear.sm.stockmanagementpro.*;

public class TestGoodsCategoryCactus1 extends ServletTestCase {
  private static final String ERROR_NULL_REMOTE = "接口未定义.";
  private static final int MAX_OUTPUT_LINE_LENGTH = 100;
  private boolean logging = false;
  private GoodsCategoryHome goodsCategoryHome = null;
  private GoodsCategory goodsCategory = null;

  public TestGoodsCategoryCactus1(String name) {
    super(name);
  }

  public void initializeLocalHome() throws Exception {
    Context context = new InitialContext();
    goodsCategoryHome = (GoodsCategoryHome) context.lookup("GoodsCategory");
  }

  public void setUp() throws Exception {
    super.setUp();
    initializeLocalHome();
  }

  public void tearDown() throws Exception {
    goodsCategoryHome = null;
    goodsCategory = null;
    super.tearDown();
  }

  //测试商品类别的创建方法
  public void testCreateGoodsCategory() throws Exception{
    Integer categoryId = new Integer(1);
    int parentId = 0;
    String categoryName = "商品类别1";
    String categoryDescription = "商品类别1的描述";
    goodsCategoryHome.create(categoryId, parentId, categoryName, categoryDescription);
    categoryId = new Integer(2);
    parentId = 0;
    categoryName = "商品类别2";
    categoryDescription = "商品类别2的描述";
    goodsCategoryHome.create(categoryId, parentId, categoryName, categoryDescription);
  }
  //测试商品类别的findAll方法
  public void testFindAll() throws Exception{
    String[] goodsCategories = new String[]{"商品类别1", "商品类别2"};
    int i = 0;
    //返回商类别的所有记录
    java.util.Collection col = goodsCategoryHome.findAll();
    if(col.size() > 0){
      java.util.Iterator iterator = col.iterator();
      while (iterator.hasNext()) {
        //取得远程接口
        goodsCategory = (GoodsCategory) javax.rmi.PortableRemoteObject.narrow(
            iterator.next(), GoodsCategory.class);
        this.assertEquals("return value", goodsCategories[i],
                          goodsCategory.getCategoryName());
        i++;
      }
    }
  }
  //测试商品类别的删除方法
  public void testDeleteGoodsCategory() throws Exception{
    Integer categoryId = new Integer(1);
    goodsCategory = goodsCategoryHome.findByPrimaryKey(categoryId);
    goodsCategory.remove();
    categoryId = new Integer(2);
    goodsCategory = goodsCategoryHome.findByPrimaryKey(categoryId);
    goodsCategory.remove();
  }
}
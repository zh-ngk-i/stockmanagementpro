﻿package com.shinear.sm.baseinforinterface;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.*;
import com.shinear.sm.data.*;
import com.shinear.sm.maininterface.*;
import com.shinear.sm.user.*;

public class ReportManageFrame extends JFrame implements ActionListener {
  JPanel contentPane;
  //创建标签控件
  JLabel jLabel1 = new JLabel();
  //创建下拉列表框控件
  JComboBox jComboBox1 = new JComboBox();
  //创建按钮
  JButton jButton1 = new JButton();
  JButton jButton2 = new JButton();
  //创建滚动框和表格
  JScrollPane tableScrollPane1 = new JScrollPane();
  JTable jdbTable1 = new JTable();
  //创建表格模式类
  StockManagementTableModel smTableModel = new StockManagementTableModel();
  //创建标题数组
  String[] colNames = {"会计科目", "借贷标识", "余额"};
  //创建字体类
  Font dialog13 = new java.awt.Font("Dialog", 0, 13);
  //声明数据类
  StockManagementData stockManagementData = null;
  //声明用户类
  User user = null;
  //声明主窗口类
  StockManagementMainFrame stockManagementMainFrame = null;
  //创建会计科目余额数组
  String[][] accountBalance = new String[0][3];
  //创建帐套日期字符串
  String ledgerDate = "";

  public ReportManageFrame(StockManagementMainFrame stockManagementMainFrame) {
    this.stockManagementMainFrame = stockManagementMainFrame;
    //取得主窗口的数据类
    stockManagementData = stockManagementMainFrame.getStockManagementData();
    //取得主窗口的用户类
    user = stockManagementMainFrame.getUser();
    //取得主窗口的账套日期
    ledgerDate = stockManagementMainFrame.getLedgerDate();
    //取得基础信息模块的用户权限
    int baseInforFunction = user.getBaseInforFunction();
    //检查用户权限
    if((baseInforFunction & 1024) != 1024){
      JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
      System.exit(0);
    }
    //检查账套日期
    if(ledgerDate.length() == 0){
      JOptionPane.showMessageDialog(null, "请选择账套.");
      return;
    }
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception  {
    contentPane = (JPanel) this.getContentPane();
    contentPane.setLayout(null);
    this.setSize(new Dimension(619, 505));
    this.setTitle("报表管理窗口");
    //设置标签控件属性
    jLabel1.setText("完成状态");
    jLabel1.setBounds(new Rectangle(23, 33, 70, 16));
    //设置下拉列表框属性
    jComboBox1.setBounds(new Rectangle(94, 33, 156, 22));
    jComboBox1.addItem("等待审核");
    jComboBox1.addItem("已经撤消");
    jComboBox1.addItem("完成审核");
    //设置滚动框的属性
    tableScrollPane1.setBounds(new Rectangle(23, 77, 570, 363));
    tableScrollPane1.getViewport().add(jdbTable1);
    //设置按钮的属性
    jButton1.setText("查询");
    jButton1.setActionCommand("search");
    jButton1.setBounds(new Rectangle(270, 33, 79, 22));
    jButton2.setText("退出");
    jButton2.setActionCommand("exit");
    jButton2.setBounds(new Rectangle(370, 33, 79, 22));
    //为面板加入控件
    contentPane.add(jLabel1, null);
    contentPane.add(jButton1, null);
    contentPane.add(jButton2, null);
    contentPane.add(tableScrollPane1);
    contentPane.add(jComboBox1, null);
    //设置窗口类的字体和为按钮加入动作接收器
    setupFontAndListener();
  }
  //设置窗口类的字体和为按钮加入动作接收器的方法
  public void setupFontAndListener(){
    Component[] components = contentPane.getComponents();
    //创建临时按钮控件
    JButton tmpBtn = new JButton();
    for(int i = 0; i < components.length; i++){
      components[i].setFont(dialog13);
      if(components[i].getClass().getName().equals("javax.swing.JButton")){
        tmpBtn = (JButton)components[i];
        tmpBtn.addActionListener(this);
      }
    }
  }
  //退出方法
  public void exit(){
    //隐藏窗口
    this.setVisible(false);
    //清空数组的内容
    accountBalance = new String[0][3];
    //清空表格的内容
    this.showTableData(accountBalance);
    //取得面板上的所有控件
    Component[] components = contentPane.getComponents();
    //创建临时编辑框控件
    JTextField tmpTextField = new JTextField();
    for(int i = 0; i < components.length; i++){
      if(components[i].getClass().getName().equals("javax.swing.JTextField")){
        tmpTextField = (JTextField)components[i];
        //清空编辑框的内容
        tmpTextField.setText("");
      }
    }
  }
  //设置账套的方法
  public void setLedgerDate(String ledgerDate) {
    this.ledgerDate = ledgerDate;
  }
  //设置用户的方法
  public void setUser(User user) {
    this.user = user;
  }
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      exit();
    }
  }
  //显示表格内容的方法
  public void showTableData(String[][] detail){
    //设置表格的标题
    smTableModel.setColumnNames(colNames);
    //设置表格的数据
    smTableModel.setData(detail);
    jdbTable1 = new JTable(smTableModel);
    //设置表格的字体
    jdbTable1.setFont(dialog13);
    //将数据表格加入数据滚动框
    tableScrollPane1.getViewport().add(jdbTable1, null);
  }
  //单击事件方法
  public void actionPerformed(ActionEvent e) {
    //取得按钮的动作字符串
    String actionCommand = e.getActionCommand().trim();
    //单击按钮的处理代码
    if (actionCommand.equals("search")) {
      //取得查询选项
      int selectedIndex = jComboBox1.getSelectedIndex();
      //0表示等待审核的会计科目余额，1表示撤消的会计科目余额，2表示完成审核的会计科目余额
      accountBalance = stockManagementData.getAccountBalance(ledgerDate, selectedIndex);
      this.showTableData(accountBalance);
    }else if (actionCommand.equals("exit")){
      exit();
    }
  }
}
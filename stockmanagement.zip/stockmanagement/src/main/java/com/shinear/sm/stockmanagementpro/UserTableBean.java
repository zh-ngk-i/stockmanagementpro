﻿package com.shinear.sm.stockmanagementpro;

import javax.ejb.*;

abstract public class UserTableBean implements EntityBean {
  EntityContext entityContext;
  public java.lang.String ejbCreate(java.lang.String userName,
                                    java.lang.String userPassword,
                                    int baseInforFunction, int stockFunction,
                                    int stockManageFunction, int saleFunction) throws
      CreateException {
    setUserName(userName);
    setUserPassword(userPassword);
    setBaseInforFunction(baseInforFunction);
    setStockFunction(stockFunction);
    setStockManageFunction(stockManageFunction);
    setSaleFunction(saleFunction);
    return null;
  }

  public void ejbPostCreate(java.lang.String userName,
                            java.lang.String userPassword,
                            int baseInforFunction, int stockFunction,
                            int stockManageFunction, int saleFunction) throws
      CreateException {
  }
  public void ejbRemove() throws RemoveException {
  }
  public abstract void setUserName(java.lang.String userName);
  public abstract void setUserPassword(java.lang.String userPassword);
  public abstract void setBaseInforFunction(int baseInforFunction);
  public abstract void setStockFunction(int stockFunction);
  public abstract void setStockManageFunction(int stockManageFunction);
  public abstract void setSaleFunction(int saleFunction);
  public abstract java.lang.String getUserName();
  public abstract java.lang.String getUserPassword();
  public abstract int getBaseInforFunction();
  public abstract int getStockFunction();
  public abstract int getStockManageFunction();
  public abstract int getSaleFunction();
  public void ejbLoad() {
  }
  public void ejbStore() {
  }
  public void ejbActivate() {
  }
  public void ejbPassivate() {
  }
  public void unsetEntityContext() {
    this.entityContext = null;
  }
  public void setEntityContext(EntityContext entityContext) {
    this.entityContext = entityContext;
  }
}
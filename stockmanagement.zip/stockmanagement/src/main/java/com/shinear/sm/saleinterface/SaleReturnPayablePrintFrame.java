﻿package com.shinear.sm.saleinterface;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.shinear.sm.print.*;
import java.awt.print.*;

public class SaleReturnPayablePrintFrame extends JFrame implements ActionListener {
  JPanel contentPane;
  //创建布局类
  BorderLayout borderLayout1 = new BorderLayout();
  FlowLayout flowLayout1 = new FlowLayout();
  //创建滚动框控件
  JScrollPane jScrollPane1 = new JScrollPane();
  //创建编辑框控件
  JTextField pageInfoTextField = new JTextField();
  //创建按钮面板
  JPanel btnPanel = new JPanel();
  //创建按钮
  JButton printPagesBtn = new JButton();
  JButton exitBtn = new JButton();
  //创建字体类
  Font dialog13 = new java.awt.Font("Dialog", 0, 13);
  //创建打印平面
  SaleReturnPayablePrintPane saleReturnPayablePrintPane = new SaleReturnPayablePrintPane();
  //创建打印类
  PrinterJob job = PrinterJob.getPrinterJob();
  //创建页面格式类
  PageFormat pageFormat = new PageFormat();
  //创建页面类
  Paper paper = new Paper();
  //创建应付票据数组
  String[] currentAccountLedger = {"", "", "", "", "", "", "", "", "", "0", ""};

  public SaleReturnPayablePrintFrame() {
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception  {
    contentPane = (JPanel) this.getContentPane();
    contentPane.setLayout(borderLayout1);
    this.setSize(new Dimension(630, 700));
    this.setTitle("应付票据打印窗口");
    //设置打印页面的的尺寸
    paper.setSize(600, 850);
    //设置打印范围
    paper.setImageableArea(0, 0, 600, 850);
    //加入pageFormat类中
    pageFormat.setPaper(paper);
    //设置打印面板的大小
    saleReturnPayablePrintPane.setPreferredSize(new Dimension(600, 850));
    //设置编辑框控件的属性
    pageInfoTextField.setEditable(false);
    pageInfoTextField.setText("共1页");
    pageInfoTextField.setPreferredSize(new Dimension(50, 22));
    //设置按钮面板的布局
    btnPanel.setLayout(flowLayout1);
    //设置按钮的属性
    printPagesBtn.setText("打印");
    printPagesBtn.setActionCommand("printOnePage");
    exitBtn.setText("退出");
    exitBtn.setActionCommand("exit");
    //设置滚动框的属性
    jScrollPane1.getViewport().add(saleReturnPayablePrintPane);
    //为按钮面板加入控件
    btnPanel.add(pageInfoTextField, null);
    btnPanel.add(printPagesBtn, null);
    btnPanel.add(exitBtn, null);
    //为窗口面板加入控件
    contentPane.add(btnPanel, BorderLayout.NORTH);
    contentPane.add(jScrollPane1, BorderLayout.CENTER);
    //设置窗口类的字体和为按钮加入动作接收器
    setupFontAndListener();
  }
  //设置窗口类的字体和为按钮加入动作接收器的方法
  public void setupFontAndListener(){
    Component[] components = btnPanel.getComponents();
    //创建临时按钮控件
    JButton tmpBtn = new JButton();
    for(int i = 0; i < components.length; i++){
      components[i].setFont(dialog13);
      if(components[i].getClass().getName().equals("javax.swing.JButton")){
        tmpBtn = (JButton)components[i];
        tmpBtn.addActionListener(this);
      }
    }
  }
  protected void processWindowEvent(WindowEvent e) {
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      exit();
    }
  }
  //退出方法
  public void exit(){
    //隐藏窗口
    this.setVisible(false);
  }
  //单击事件
  public void actionPerformed(ActionEvent e) {
    //取得按钮的动作字符串
    String actionCommand = e.getActionCommand().trim();
    //单击按钮的处理代码
    if(actionCommand.equals("printOnePage")){
      //打印选择页面的方法
      this.printOnePage();
    }else if(actionCommand.equals("exit")){
      exit();
    }
  }
  //显示当前页的方法
  public void showOnePage() {
    saleReturnPayablePrintPane.setCurrentAccountLedger(currentAccountLedger);
    //重新显示面板内容
    saleReturnPayablePrintPane.repaint();
  }
  //打印当前页的方法
  public void printOnePage() {
    //创建打印接口
    SaleReturnPayablePrintable saleReturnPayablePrintable = new SaleReturnPayablePrintable();
    //显示当前页的内容
    this.showOnePage();
    //创建打印任务
    Book book = new Book();
    book.append(saleReturnPayablePrintable, pageFormat);
    // 设置打印机的Book
    job.setPageable(book);
    //打开打印窗口，询问是否进行打印
    boolean doPrint = job.printDialog();
    if (doPrint) {
      try {
        //执行打印命令
        job.print();
      }
      catch (PrinterException ex) {
        ex.printStackTrace();
      }
    }
  }
  //设置应付票据数组的方法
  public void setCurrentAccountLedger(String[] currentAccountLedger) {
    this.currentAccountLedger = currentAccountLedger;
  }
}
﻿package com.shinear.sm.stockmanageinterface;

import java.awt.*;
import java.awt.event.*;
import javax.swing.event.*;
import javax.swing.*;
import com.shinear.sm.data.*;
import com.shinear.sm.maininterface.*;
import com.shinear.sm.user.*;
import com.shinear.sm.method.*;
import java.util.Date;

public class GoodsQuantityCombineFrame extends JFrame implements ActionListener {
  JPanel contentPane;
  //创建标签控件
  JLabel jLabel1 = new JLabel();
  JLabel jLabel2 = new JLabel();
  JLabel jLabel3 = new JLabel();
  JLabel jLabel4 = new JLabel();
  JLabel jLabel5 = new JLabel();
  JLabel jLabel6 = new JLabel();
  JLabel jLabel7 = new JLabel();
  JLabel jLabel8 = new JLabel();
  JLabel jLabel9 = new JLabel();
  JLabel jLabel10 = new JLabel();
  JLabel jLabel11 = new JLabel();
  JLabel jLabel12 = new JLabel();
  JLabel jLabel13 = new JLabel();
  JLabel jLabel14 = new JLabel();
  JLabel jLabel15 = new JLabel();
  JLabel jLabel16 = new JLabel();
  //创建编辑框控件
  JTextField jTextField1 = new JTextField();
  JTextField jTextField2 = new JTextField();
  JTextField jTextField3 = new JTextField();
  JTextField jTextField4 = new JTextField();
  JTextField jTextField5 = new JTextField();
  JTextField jTextField6 = new JTextField();
  JTextField jTextField7 = new JTextField();
  JTextField jTextField8 = new JTextField();
  JTextField jTextField9 = new JTextField();
  JTextField jTextField10 = new JTextField();
  JTextField jTextField11 = new JTextField();
  //创建按钮控件
  JButton jButton1 = new JButton();
  JButton jButton2 = new JButton();
  JButton jButton3 = new JButton();
  JButton jButton4 = new JButton();
  JButton jButton5 = new JButton();
  JButton jButton6 = new JButton();
  JButton jButton7 = new JButton();
  JButton jButton8 = new JButton();
  JButton jButton9 = new JButton();
  JButton jButton10 = new JButton();
  //创建滚动框控件
  JScrollPane jScrollPane1 = new JScrollPane();
  JScrollPane jScrollPane2 = new JScrollPane();
  JScrollPane jScrollPane3 = new JScrollPane();
  JScrollPane jScrollPane4 = new JScrollPane();
  //创建列表框数据类和列表框控件
  DefaultListModel listData1 = new DefaultListModel();
  JList jList1 = new JList(listData1);
  //创建表格控件
  JTable jTable1 = new JTable();
  JTable jTable2 = new JTable();
  //创建表格模式类
  StockSubLedgerTableModel sslTableModel = new StockSubLedgerTableModel();
  StockSubLedgerTableModel sslTableMode2 = new StockSubLedgerTableModel();
  //创建标题数组
  String[] colNames = {"明细编号", "单据编号", "商品条形码", "进货价", "数量", "金额", "有效期"};
  //创建下拉列表框控件
  JComboBox jComboBox1 = new JComboBox();
  //创建文本框控件
  JTextArea jTextArea1 = new JTextArea();

  //创建字体类
  Font dialog13 = new java.awt.Font("Dialog", 0, 13);
  //声明数据类
  StockManagementData stockManagementData = null;
  //声明用户类
  User user = null;
  //声明主窗口类
  StockManagementMainFrame stockManagementMainFrame = null;
  //创建库存账套数组
  String[][] stockLedgers = new String[0][13];
  //创建商品组合调出明细数组
  String[][] stockSubLedgersOut = new String[0][6];
  //创建商品组合调出明细表格数组
  Object[][] stockSubLedgerObjectsOut = new Object[0][7];
  //创建商品组合调入明细数组
  String[][] stockSubLedgersIn = new String[0][6];
  //创建商品组合调入明细表格数组
  Object[][] stockSubLedgerObjectsIn = new Object[0][7];
  //创建方法类
  DataMethod dataMethod = new DataMethod();
  //创建动作字符串
  String action = "";
  //创建完成状态数组
  String[] onProcesses = {"进行", "撤消", "完成"};
  //创建帐套日期字符串
  String ledgerDate = "";

  public GoodsQuantityCombineFrame(StockManagementMainFrame stockManagementMainFrame) {
    this.stockManagementMainFrame = stockManagementMainFrame;
    //取得主窗口的数据类
    stockManagementData = stockManagementMainFrame.getStockManagementData();
    //取得主窗口的用户类
    user = stockManagementMainFrame.getUser();
    //取得主窗口的账套日期
    ledgerDate = stockManagementMainFrame.getLedgerDate();
    //取得库存模块的用户权限
    int stockManageFunction = user.getStockManageFunction();
    //检查用户权限
    if ( (stockManageFunction & 8) != 8) {
      JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
      System.exit(0);
    }
    //检查账套日期
    if(ledgerDate.length() == 0){
      JOptionPane.showMessageDialog(null, user.getUserName() + "请选择账套.");
      return;
    }
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception  {
    contentPane = (JPanel) this.getContentPane();
    contentPane.setLayout(null);
    this.setSize(new Dimension(667, 669));
    this.setTitle("商品数量组合窗口");
    //设置标签的属性
    jLabel1.setText("商品组合单列表");
    jLabel1.setBounds(new Rectangle(28, 19, 134, 16));
    jLabel2.setText("查询条件");
    jLabel2.setBounds(new Rectangle(180, 45, 62, 16));
    jLabel3.setText("查询值");
    jLabel3.setBounds(new Rectangle(440, 45, 50, 16));
    jLabel4.setText("开始日期");
    jLabel4.setBounds(new Rectangle(180, 81, 67, 16));
    jLabel5.setText("结束日期");
    jLabel5.setBounds(new Rectangle(373, 81, 66, 16));
    jLabel6.setText("单据编号");
    jLabel6.setBounds(new Rectangle(180, 118, 66, 16));
    jLabel7.setText("关联标识");
    jLabel7.setBounds(new Rectangle(413, 120, 54, 16));
    jLabel8.setText("组合用户");
    jLabel8.setBounds(new Rectangle(180, 154, 66, 16));
    jLabel9.setText("组合前仓库");
    jLabel9.setBounds(new Rectangle(413, 154, 66, 16));
    jLabel10.setText("组合后仓库");
    jLabel10.setBounds(new Rectangle(180, 190, 66, 16));
    jLabel11.setText("组合日期");
    jLabel11.setRequestFocusEnabled(true);
    jLabel11.setBounds(new Rectangle(180, 227, 66, 16));
    jLabel12.setText("完成状态");
    jLabel12.setBounds(new Rectangle(180, 263, 66, 16));
    jLabel13.setText("备注");
    jLabel13.setBounds(new Rectangle(417, 190, 66, 16));
    jLabel14.setText("组合后的商品");
    jLabel14.setBounds(new Rectangle(29, 334, 165, 16));
    jLabel15.setText("组合前的商品列表");
    jLabel15.setBounds(new Rectangle(29, 438, 165, 16));
    jLabel16.setText("总价");
    jLabel16.setBounds(new Rectangle(477, 438, 63, 16));
    //设置编辑框的属性
    jTextField1.setBounds(new Rectangle(492, 45, 133, 22));
    jTextField2.setBounds(new Rectangle(261, 81, 101, 22));
    jTextField3.setBounds(new Rectangle(439, 81, 101, 22));
    jTextField4.setEditable(false);
    jTextField4.setBounds(new Rectangle(261, 118, 147, 22));
    jTextField5.setEditable(false);
    jTextField5.setBounds(new Rectangle(480, 120, 145, 22));
    jTextField6.setEditable(false);
    jTextField6.setBounds(new Rectangle(261, 154, 147, 22));
    jTextField7.setBounds(new Rectangle(480, 154, 145, 22));
    jTextField8.setBounds(new Rectangle(261, 190, 147, 22));
    jTextField9.setBounds(new Rectangle(261, 227, 147, 22));
    jTextField10.setEditable(false);
    jTextField10.setBounds(new Rectangle(261, 263, 147, 22));
    jTextField11.setEditable(false);
    jTextField11.setBounds(new Rectangle(534, 435, 91, 22));
    //设置按钮的属性
    jButton1.setText("查询");
    jButton1.setActionCommand("search");
    jButton1.setBounds(new Rectangle(546, 81, 79, 22));
    jButton2.setText("创建");
    jButton2.setActionCommand("createStockLedger");
    jButton2.setBounds(new Rectangle(28, 301, 85, 25));
    jButton3.setText("修改");
    jButton3.setActionCommand("updateStockLedger");
    jButton3.setBounds(new Rectangle(113, 301, 85, 25));
    jButton4.setText("撤消");
    jButton4.setActionCommand("cancelStockLedger");
    jButton4.setBounds(new Rectangle(199, 301, 85, 25));
    jButton5.setText("恢复");
    jButton5.setActionCommand("restoreStockLedger");
    jButton5.setBounds(new Rectangle(284, 301, 85, 25));
    jButton6.setText("确定");
    jButton6.setActionCommand("ok");
    jButton6.setBounds(new Rectangle(369, 301, 85, 25));
    jButton7.setText("取消");
    jButton7.setActionCommand("cancel");
    jButton7.setBounds(new Rectangle(455, 301, 85, 25));
    jButton8.setText("退出");
    jButton8.setActionCommand("exit");
    jButton8.setBounds(new Rectangle(540, 301, 85, 25));
    jButton9.setText("创建明细记录");
    jButton9.setActionCommand("createSub");
    jButton9.setBounds(new Rectangle(28, 582, 281, 25));
    jButton10.setText("删除明细记录");
    jButton10.setActionCommand("deleteSub");
    jButton10.setBounds(new Rectangle(344, 582, 281, 25));
    //设置滚动框的属性
    jScrollPane1.setBounds(new Rectangle(28, 45, 143, 240));
    jScrollPane2.setBounds(new Rectangle(418, 213, 207, 72));
    jScrollPane3.setBounds(new Rectangle(29, 463, 597, 108));
    jScrollPane4.setBounds(new Rectangle(29, 358, 597, 71));
    jScrollPane1.getViewport().add(jList1, null);
    jScrollPane2.getViewport().add(jTextArea1, null);
    jScrollPane3.getViewport().add(jTable1, null);
    jScrollPane4.getViewport().add(jTable2, null);
    //为列表框加入选择接收器
    jList1.addListSelectionListener(new ListSelectionListener() {
      public void valueChanged(ListSelectionEvent e) {
        //当多种事件被激发的时候,不执行接收器后面的代码
        if (e.getValueIsAdjusting()) return;
        jList1_valueChanged(e);
      }
    });
    //设置下拉列表框的属性
    jComboBox1.setBounds(new Rectangle(261, 45, 156, 22));
    jComboBox1.addItem("根据单据编号查询");
    jComboBox1.addItem("根据组合用户查询");
    jComboBox1.addItem("根据组合前仓库查询");
    jComboBox1.addItem("根据组合后仓库查询");
    jComboBox1.addItem("根据完成状态查询");
    jComboBox1.addItem("根据组合日期查询");
    //为面板加入各个控件
    contentPane.add(jLabel1, null);
    contentPane.add(jLabel2, null);
    contentPane.add(jLabel3, null);
    contentPane.add(jLabel4, null);
    contentPane.add(jLabel5, null);
    contentPane.add(jLabel6, null);
    contentPane.add(jLabel7, null);
    contentPane.add(jLabel8, null);
    contentPane.add(jLabel9, null);
    contentPane.add(jLabel10, null);
    contentPane.add(jLabel11, null);
    contentPane.add(jLabel12, null);
    contentPane.add(jLabel13, null);
    contentPane.add(jLabel14, null);
    contentPane.add(jLabel15, null);
    contentPane.add(jLabel16, null);
    contentPane.add(jScrollPane1, null);
    contentPane.add(jScrollPane2, null);
    contentPane.add(jScrollPane3, null);
    contentPane.add(jScrollPane4, null);
    contentPane.add(jButton1, null);
    contentPane.add(jButton2, null);
    contentPane.add(jButton3, null);
    contentPane.add(jButton4, null);
    contentPane.add(jButton5, null);
    contentPane.add(jButton6, null);
    contentPane.add(jButton7, null);
    contentPane.add(jButton8, null);
    contentPane.add(jButton9, null);
    contentPane.add(jButton10, null);
    contentPane.add(jTextField1, null);
    contentPane.add(jTextField2, null);
    contentPane.add(jTextField3, null);
    contentPane.add(jTextField4, null);
    contentPane.add(jTextField5, null);
    contentPane.add(jTextField6, null);
    contentPane.add(jTextField7, null);
    contentPane.add(jTextField8, null);
    contentPane.add(jTextField9, null);
    contentPane.add(jTextField10, null);
    contentPane.add(jTextField11, null);
    contentPane.add(jComboBox1, null);
    //设置窗口类的字体和为按钮加入动作接收器
    setupFontAndListener();
    //检查按钮状态
    this.checkBtn(false);
    this.checkSubBtn(false);
  }
  //设置窗口类的字体和为按钮加入动作接收器的方法
  public void setupFontAndListener(){
    Component[] components = contentPane.getComponents();
    //创建临时按钮控件
    JButton tmpBtn = new JButton();
    for(int i = 0; i < components.length; i++){
      components[i].setFont(dialog13);
      if(components[i].getClass().getName().equals("javax.swing.JButton")){
        tmpBtn = (JButton)components[i];
        tmpBtn.addActionListener(this);
      }
    }
  }
  //退出方法
  public void exit(){
    //隐藏窗口
    this.setVisible(false);
    //清空数组的内容
    stockLedgers = new String[0][13];
    stockSubLedgersOut = new String[0][6];
    stockSubLedgerObjectsOut = new Object[0][7];
    stockSubLedgersIn = new String[0][6];
    stockSubLedgerObjectsIn = new Object[0][7];
    //清空列表框的内容
    listData1.clear();
    //清空文本框的内容
    jTextArea1.setText("");
    //清空表格的内容
    this.showTableDataOut(stockSubLedgerObjectsOut);
    //取得面板上的所有控件
    Component[] components = contentPane.getComponents();
    //创建临时编辑框控件
    JTextField tmpTextField = new JTextField();
    for(int i = 0; i < components.length; i++){
      if(components[i].getClass().getName().equals("javax.swing.JTextField")){
        tmpTextField = (JTextField)components[i];
        //清空编辑框的内容
        tmpTextField.setText("");
      }
    }
  }
  //设置用户的方法
  public void setUser(User user) {
    this.user = user;
  }
  //设置账套的方法
  public void setLedgerDate(String ledgerDate) {
    this.ledgerDate = ledgerDate;
  }
  protected void processWindowEvent(WindowEvent e) {
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      exit();
    }
  }
  //显示查询商品组合单的方法
  public void showSearchStockLedger(){
    listData1.clear();
    //为商品组合单列表框加入商品组合单数据
    for(int i = 0; i < stockLedgers.length; i++){
      listData1.addElement(stockLedgers[i][0]);
    }
  }
  //显示单个商品组合单的方法
  public void showStockLedger(){
    //取得当前选择项的位置
    int selectedIndex = jList1.getSelectedIndex();
    //当列表框不处于选择状态，不显示数据
    if(selectedIndex == -1){
       return;
    }
    //显示商品组合单的数据
    jTextField4.setText(stockLedgers[selectedIndex][0]);   //票据编号
    jTextField5.setText(stockLedgers[selectedIndex][2]);   //关联标识
    jTextField6.setText(stockLedgers[selectedIndex][3]);   //组合用户
    jTextField7.setText(stockLedgers[selectedIndex][4]);   //组合前仓库
    jTextField8.setText(stockLedgers[selectedIndex][8]);   //组合后仓库
    jTextField9.setText(stockLedgers[selectedIndex][9]);   //组合日期
    jTextField10.setText(onProcesses[Integer.parseInt(stockLedgers[selectedIndex][11])]);
    jTextArea1.setText(stockLedgers[selectedIndex][12]);
    //显示调出商品明细数据
    this.showStockSubLedgerOut();
    //显示调入商品明细数据
    this.showStockSubLedgerIn();
  }
  //显示商品组合单的调出商品明细数据的方法
  public void showStockSubLedgerOut(){
    //取得当前选择项的位置
    int selectedIndex = jList1.getSelectedIndex();
    String orderId = stockLedgers[selectedIndex][2];
    stockSubLedgersOut = stockManagementData.getStockSubLedgerByOrderId(ledgerDate, orderId);
    //将数组数据转换为表格数据
    stockSubLedgerObjectsOut = new Object[stockSubLedgersOut.length][7];
    double total = 0;
    for(int i = 0; i < stockSubLedgersOut.length; i++){
      stockSubLedgerObjectsOut[i][0] = new Integer(stockSubLedgersOut[i][0]);
      stockSubLedgerObjectsOut[i][1] = stockSubLedgersOut[i][1];
      stockSubLedgerObjectsOut[i][2] = stockSubLedgersOut[i][2];
      double costPrice = dataMethod.round(Double.parseDouble(stockSubLedgersOut[i][3]));
      int quantity = Integer.parseInt(stockSubLedgersOut[i][4]);
      stockSubLedgerObjectsOut[i][3] = new Double(costPrice);
      stockSubLedgerObjectsOut[i][4] = new Integer(quantity);
      double amount = dataMethod.round(costPrice * quantity);
      stockSubLedgerObjectsOut[i][5] = new Double(amount);
      stockSubLedgerObjectsOut[i][6] = dataMethod.transferShortDate(stockSubLedgersOut[i][5]).toString();
      total += amount;
    }
    //显示总价
    jTextField11.setText(String.valueOf(dataMethod.round(total)));
    //显示表格的内容
    this.showTableDataOut(stockSubLedgerObjectsOut);
  }
  //显示商品组合单的调入商品明细数据的方法
  public void showStockSubLedgerIn(){
    //取得当前选择项的位置
    int selectedIndex = jList1.getSelectedIndex();
    String orderId = stockLedgers[selectedIndex][0];
    stockSubLedgersIn = stockManagementData.getStockSubLedgerByOrderId(ledgerDate, orderId);
    //将数组数据转换为表格数据
    stockSubLedgerObjectsIn = new Object[stockSubLedgersIn.length][7];
    for(int i = 0; i < stockSubLedgersIn.length; i++){
      stockSubLedgerObjectsIn[i][0] = new Integer(stockSubLedgersIn[i][0]);
      stockSubLedgerObjectsIn[i][1] = stockSubLedgersIn[i][1];
      stockSubLedgerObjectsIn[i][2] = stockSubLedgersIn[i][2];
      double costPrice = dataMethod.round(Double.parseDouble(stockSubLedgersIn[i][3]));
      int quantity = Integer.parseInt(stockSubLedgersIn[i][4]);
      stockSubLedgerObjectsIn[i][3] = new Double(costPrice);
      stockSubLedgerObjectsIn[i][4] = new Integer(quantity);
      double amount = dataMethod.round(costPrice * quantity);
      stockSubLedgerObjectsIn[i][5] = new Double(amount);
      stockSubLedgerObjectsIn[i][6] = dataMethod.transferShortDate(stockSubLedgersIn[i][5]).toString();
    }
    //显示表格的内容
    this.showTableDataIn(stockSubLedgerObjectsIn);
  }
  //转换表格数据的方法
  public void transferTableData(){
    stockSubLedgersOut = new String[stockSubLedgerObjectsOut.length][6];
    for(int i = 0; i < stockSubLedgerObjectsOut.length; i++){
      stockSubLedgersOut[i][0] = ((Integer)stockSubLedgerObjectsOut[i][0]).toString();
      stockSubLedgersOut[i][1] = (String)stockSubLedgerObjectsOut[i][1];
      stockSubLedgersOut[i][2] = (String)stockSubLedgerObjectsOut[i][2];
      stockSubLedgersOut[i][3] = ((Double)stockSubLedgerObjectsOut[i][3]).toString();
      stockSubLedgersOut[i][4] = ((Integer)stockSubLedgerObjectsOut[i][4]).toString();
      stockSubLedgersOut[i][5] = stockSubLedgerObjectsOut[i][6].toString();
    }
    stockSubLedgersIn = new String[stockSubLedgerObjectsIn.length][6];
    for(int i = 0; i < stockSubLedgerObjectsIn.length; i++){
      stockSubLedgersIn[i][0] = ((Integer)stockSubLedgerObjectsIn[i][0]).toString();
      stockSubLedgersIn[i][1] = (String)stockSubLedgerObjectsIn[i][1];
      stockSubLedgersIn[i][2] = (String)stockSubLedgerObjectsIn[i][2];
      stockSubLedgersIn[i][3] = ((Double)stockSubLedgerObjectsIn[i][3]).toString();
      stockSubLedgersIn[i][4] = ((Integer)stockSubLedgerObjectsIn[i][4]).toString();
      stockSubLedgersIn[i][5] = stockSubLedgerObjectsIn[i][6].toString();
    }
  }
  //显示组合调出商品的表格内容的方法
  public void showTableDataOut(Object[][] detail){
    //设置表格的标题
    sslTableModel.setColumnNames(colNames);
    //设置表格的数据
    sslTableModel.setData(detail);
    jTable1 = new JTable(sslTableModel);
    //设置表格的字体
    jTable1.setFont(dialog13);
    //将数据表格加入数据滚动框
    jScrollPane3.getViewport().add(jTable1, null);
    //设置列的宽度
    jTable1.getColumnModel().getColumn(0).setPreferredWidth(20);
    jTable1.getColumnModel().getColumn(1).setPreferredWidth(50);
    jTable1.getColumnModel().getColumn(2).setPreferredWidth(50);
    jTable1.getColumnModel().getColumn(3).setPreferredWidth(10);
    jTable1.getColumnModel().getColumn(4).setPreferredWidth(10);
    jTable1.getColumnModel().getColumn(5).setPreferredWidth(10);
    jTable1.getColumnModel().getColumn(6).setPreferredWidth(50);
    //取得表格的行
    ListSelectionModel rowSM = jTable1.getSelectionModel();
    //加入行选择接收器
    rowSM.addListSelectionListener(new ListSelectionListener() {
      public void valueChanged(ListSelectionEvent e) {
        //当多种事件被激发的时候,不执行接收器后面的代码
        if (e.getValueIsAdjusting()) return;
        jTable1_valueChanged(e);
      }
    });
  }
  //显示组合调入商品的表格内容的方法
  public void showTableDataIn(Object[][] detail){
    //设置表格的标题
    sslTableMode2.setColumnNames(colNames);
    //设置表格的数据
    sslTableMode2.setData(detail);
    jTable2 = new JTable(sslTableMode2);
    //设置表格的字体
    jTable2.setFont(dialog13);
    //将数据表格加入数据滚动框
    jScrollPane4.getViewport().add(jTable2, null);
    //设置列的宽度
    jTable2.getColumnModel().getColumn(0).setPreferredWidth(20);
    jTable2.getColumnModel().getColumn(1).setPreferredWidth(50);
    jTable2.getColumnModel().getColumn(2).setPreferredWidth(50);
    jTable2.getColumnModel().getColumn(3).setPreferredWidth(10);
    jTable2.getColumnModel().getColumn(4).setPreferredWidth(10);
    jTable2.getColumnModel().getColumn(5).setPreferredWidth(10);
    jTable2.getColumnModel().getColumn(6).setPreferredWidth(50);
    sslTableMode2.addTableModelListener(new TableModelListener(){
      public void tableChanged(TableModelEvent e) {
        jTable2_valueChanged(e);
      }
    });
  }
  //重新计算调出商品金额
  public void recountGoodsOutAmount(){
    double costPrice = 0;
    int quantity = 0;
    double amount = 0;
    double total = 0;
    for(int i = 0; i < stockSubLedgerObjectsOut.length; i++){
      costPrice = dataMethod.round(((Double)stockSubLedgerObjectsOut[i][3]).doubleValue());
      quantity = ((Integer)stockSubLedgerObjectsOut[i][4]).intValue();
      amount = dataMethod.round(costPrice * quantity);
      stockSubLedgerObjectsOut[i][5] = new Double(amount);
      total += amount;
    }
    jTextField11.setText(String.valueOf(dataMethod.round(total)));
  }
  //重新计算调入商品金额
  public void recountGoodsInAmount(){
    double costPrice = 0;
    int quantity = 0;
    double amount = 0;
    for(int i = 0; i < stockSubLedgerObjectsIn.length; i++){
      costPrice = dataMethod.round(((Double)stockSubLedgerObjectsIn[i][3]).doubleValue());
      quantity = ((Integer)stockSubLedgerObjectsIn[i][4]).intValue();
      amount = dataMethod.round(costPrice * quantity);
      stockSubLedgerObjectsIn[i][5] = new Double(amount);
    }
  }
  //检查组合商品与被组合商品的金额是否相等
  public int checkGoodsInAndOutAmount(){
    this.recountGoodsOutAmount();
    this.recountGoodsInAmount();
    double amountOut = - ((Double)stockSubLedgerObjectsIn[0][5]).doubleValue();
    double amountIn = Double.parseDouble(jTextField11.getText());
    if(amountOut != amountIn){
      JOptionPane.showMessageDialog(null, "组合前与组合后的商品的金额不相等.");
      return 0;
    }
    return 1;
  }
  //检查明细账日期的方法
  public int checkStockSubLedgerDate(){
    java.sql.Date date = null;
    for(int i = 0; i < stockSubLedgerObjectsOut.length; i++){
      date = dataMethod.transferShortDate((String)stockSubLedgerObjectsOut[i][6]);
      if(date == null){
        JOptionPane.showMessageDialog(null, "组合前的商品列表的第" + (i+1) + "行日期输入错误，正确的日期格式是"
                                      + "yyyy-mm-dd（年-月-日），如2004-1-1");
        return 0;
      }
    }
    for(int i = 0; i < stockSubLedgerObjectsIn.length; i++){
      date = dataMethod.transferShortDate((String)stockSubLedgerObjectsIn[i][6]);
      if(date == null){
        JOptionPane.showMessageDialog(null, "组合后的商品的第" + (i+1) + "行日期输入错误，正确的日期格式是"
                                      + "yyyy-mm-dd（年-月-日），如2004-1-1");
        return 0;
      }
    }
    return 1;
  }
  //检查明细账的商品条形码方法
  public int checkStockSubLedgerGoodsBarCode(){
    int result = 0;
    for(int i = 0; i < stockSubLedgerObjectsOut.length; i++){
      result = stockManagementData.checkGoodsBarCode((String)stockSubLedgerObjectsOut[i][2]);
      if(result == 0){
        JOptionPane.showMessageDialog(null, "组合前的商品列表的第" + (i + 1) + "行的商品条形码在商品数据库中"
                                      + "不存在，请打开商品数据管理窗口添加.");
        return 0;
      }
    }
    for(int i = 0; i < stockSubLedgerObjectsIn.length; i++){
      result = stockManagementData.checkGoodsBarCode((String)stockSubLedgerObjectsIn[i][2]);
      if(result == 0){
        JOptionPane.showMessageDialog(null, "组合后的商品的第" + (i + 1) + "行的商品条形码在商品数据库中"
                                      + "不存在，请打开商品数据管理窗口添加.");
        return 0;
      }
    }
    return 1;
  }
  //检查明细账数量的方法
  public int checkStockSubLedgerQuantity(){
    int quantity = 0;
    for(int i = 0; i < stockSubLedgerObjectsOut.length; i++){
      quantity = ((Integer)stockSubLedgerObjectsOut[i][4]).intValue();
      if(quantity >= 0){
        JOptionPane.showMessageDialog(null, "组合前的商品列表的第" + (i + 1) + "行的数量输入错误，该数量必须是负数.");
        return 0;
      }
    }
    for(int i = 0; i < stockSubLedgerObjectsIn.length; i++){
      quantity = ((Integer)stockSubLedgerObjectsIn[i][4]).intValue();
      if(quantity <= 0){
        JOptionPane.showMessageDialog(null, "组合后的商品的第" + (i + 1) + "行的数量输入错误，该数量必须是正数.");
        return 0;
      }
    }
    return 1;
  }
  //清空单个商品组合单显示的方法
  public void clearStockLedger(){
    jTextField4.setText("");
    jTextField5.setText("");
    jTextField6.setText("");
    jTextField7.setText("");
    jTextField8.setText("");
    jTextField9.setText("");
    jTextField10.setText("");
    jTextField11.setText("");
    jTextArea1.setText("");
    stockSubLedgersOut = new String[0][6];
    stockSubLedgerObjectsOut = new Object[0][7];
    stockSubLedgersIn = new String[0][6];
    stockSubLedgerObjectsIn = new Object[0][7];
    this.showTableDataOut(stockSubLedgerObjectsOut);
    this.showTableDataIn(stockSubLedgerObjectsIn);
  }
  //检查按钮的状态
  public void checkBtn(boolean isManipulated){
    if(isManipulated){
      jButton2.setEnabled(false);
      jButton3.setEnabled(false);
      jButton4.setEnabled(false);
      jButton5.setEnabled(false);
      jButton6.setEnabled(true);
      jButton7.setEnabled(true);
    }else{
      jButton2.setEnabled(true);
      jButton3.setEnabled(true);
      jButton4.setEnabled(true);
      jButton5.setEnabled(true);
      jButton6.setEnabled(false);
      jButton7.setEnabled(false);
    }
  }
  //检查明细账按钮的状态
  public void checkSubBtn(boolean isCreated){
    if(isCreated){
      jButton9.setEnabled(true);
      jButton10.setEnabled(true);
    }else{
      jButton9.setEnabled(false);
      jButton10.setEnabled(false);
    }
  }
  //列表1的选择事件
  void jList1_valueChanged(ListSelectionEvent e) {
    if(listData1.size() > 0){
      this.showStockLedger();
    }else{
      this.clearStockLedger();
    }
  }
  //表格行选择事件
  public void jTable1_valueChanged(ListSelectionEvent e) {
    //重新计算金额
    this.recountGoodsOutAmount();
  }
  //表格内容改变事件
  public void jTable2_valueChanged(TableModelEvent e) {
    //重新计算金额
    this.recountGoodsInAmount();
  }
  //为调入商品表格创建一个空行
  public void createNewLineForGoodsIn(){
    Object[][] tempObjs = new Object[1][7];
    tempObjs[0][0] = new Integer(0);
    tempObjs[0][1] = new String("");
    tempObjs[0][2] = new String("");
    tempObjs[0][3] = new Double(0);
    tempObjs[0][4] = new Integer(0);
    tempObjs[0][5] = new Double(0);
    tempObjs[0][6] = new String("");
    stockSubLedgerObjectsIn = tempObjs;
    this.showTableDataIn(stockSubLedgerObjectsIn);
  }
  //查询方法
  public void search(){
    //取得查询选项
    int selectedIndex = jComboBox1.getSelectedIndex();
    //取得编辑框的变量
    String searchValue = jTextField1.getText().trim();
    String startDateStr = jTextField2.getText().trim();
    String endDateStr = jTextField3.getText().trim();
    if (selectedIndex == 0 | selectedIndex == 1 | selectedIndex == 2 |
        selectedIndex == 3 | selectedIndex == 4) {
      if (searchValue.length() == 0) {
        JOptionPane.showMessageDialog(null, "请输入查询值");
        return;
      }
      switch (selectedIndex) {
        case 0:
          //根据商品组合单编号取得记录
          stockLedgers = stockManagementData.getStockLedgerByStringField(
              ledgerDate, "orderId", searchValue, 12);
          break;
        case 1:
          //根据商品组合用户取得记录
          stockLedgers = stockManagementData.getStockLedgerByStringField(
              ledgerDate, "submitUser", searchValue, 12);
          break;
        case 2:
          //根据组合前仓库名字取得记录,组合前仓库名字保存在组合单的commitUser字段
          stockLedgers = stockManagementData.getStockLedgerByStringField(
              ledgerDate, "commitUser", searchValue, 12);
          break;
        case 3:
          //根据组合后仓库名字取得记录,
          stockLedgers = stockManagementData.getStockLedgerByStringField(
              ledgerDate, "warehouse", searchValue, 12);
          break;
        case 4:
          if(dataMethod.checkInt(searchValue) == 0){
            JOptionPane.showMessageDialog(null, "按完成状态查询时，输入值必须是整数，"
                                          + "0表示进行，1表示撤消，2表示完成.");
            return;
          }
          //根据完成状态取得记录
          stockLedgers = stockManagementData.getStockLedgerByOnProcess(
              ledgerDate, 12, Integer.parseInt(searchValue));
          break;
      }
    }else{
      java.sql.Timestamp startDate = dataMethod.transferDate(startDateStr);
      java.sql.Timestamp endDate = dataMethod.transferEndDate(endDateStr);
      if(startDate == null | endDate == null){
        JOptionPane.showMessageDialog(null, "日期输入错误，正确的日期格式是"
                                      + "yyyy-mm-dd（年-月-日），如2004-1-1");
        return;
      }
      //根据日期取得记录
      stockLedgers = stockManagementData.getStockLedgerByOrderDate(ledgerDate,
          startDate, endDate, 12);
    }
    this.showSearchStockLedger();
  }
  //单击事件
  public void actionPerformed(ActionEvent e) {
    //取得按钮的动作字符串
    String actionCommand = e.getActionCommand().trim();
    //检查打开的账套是否当前账套
    if (actionCommand.equals("createStockLedger") |
        actionCommand.equals("updateStockLedger") |
        actionCommand.equals("cancelStockLedger") |
        actionCommand.equals("restoreStockLedger")) {
      int result = stockManagementData.isCurrentLedger(ledgerDate);
      if(result == 0){
        JOptionPane.showMessageDialog(null, ledgerDate + "是往期账套，不能进行添加、修改、撤消和恢复操作.");
        return;
      }
    }
    if (actionCommand.equals("search")) {
      //查询
      search();
    }else if(actionCommand.equals("createStockLedger")){
      action = "create";
      this.clearStockLedger();
      this.createNewLineForGoodsIn();
      this.checkBtn(true);
      this.checkSubBtn(true);
    }else if(actionCommand.equals("updateStockLedger")){
      action = "update";
      this.checkBtn(true);
    }else if(actionCommand.equals("cancelStockLedger")){
      action = "cancel";
      this.checkBtn(true);
    }else if(actionCommand.equals("restoreStockLedger")){
      action = "restore";
      this.checkBtn(true);
    }else if(actionCommand.equals("ok")){
      int selectedIndex = jList1.getSelectedIndex();
      //创建库存账套数据表的单个记录数组
      String[] stockLedger = new String[13];
      //取得商品组合单的值
      stockLedger[0] = "";                           //单据编号
      stockLedger[1] = "12";                         //12表示商品组合调入单
      stockLedger[2] = "";                           //关联标识
      stockLedger[3] = user.getUserName();           //组合用户
      stockLedger[4] = jTextField7.getText().trim(); //组合前仓库
      stockLedger[5] = "";
      stockLedger[6] = "";
      stockLedger[7] = "";
      stockLedger[8] = jTextField8.getText().trim();  //组合后仓库
      stockLedger[9] = jTextField9.getText().trim();  //组合日期
      stockLedger[10] = dataMethod.getCurrentDate().toString(); //填写组合单的系统日期
      stockLedger[11] = "2";                          //组合单一旦创建，便处于完成状态
      stockLedger[12] = jTextArea1.getText().trim();
      int result = 0;
      if(action.equals("update") | action.equals("create")){
        //检查组合前仓库名字
        result = stockManagementData.checkWarehouse(stockLedger[4]);
        if(result == 0){
          JOptionPane.showMessageDialog(null, stockLedger[4] + "在仓库数据库中"
                                        + "不存在，请打开仓库数据管理窗口添加.");
          return;
        }
        //检查组合后仓库名字
        result = stockManagementData.checkWarehouse(stockLedger[8]);
        if(result == 0){
          JOptionPane.showMessageDialog(null, stockLedger[8] + "在仓库数据库中"
                                        + "不存在，请打开仓库数据管理窗口添加.");
          return;
        }
        //检查组合日期
        if(dataMethod.transferDateTime(stockLedger[9]) == null){
          JOptionPane.showMessageDialog(null, "组合日期输入错误，正确的日期格式是"
                                      + "yyyy-mm-dd（年-月-日），如2004-1-1");
          return;
        }
        //检查商品组合单明细账的商品条形码、数量、日期
        result = this.checkStockSubLedgerGoodsBarCode();
        if(result == 0)  return;
        result = this.checkStockSubLedgerQuantity();
        if(result == 0)  return;
        result = this.checkStockSubLedgerDate();
        if(result == 0)  return;
        //检查组合前与组合后商品的进货金额是否相等
        result = this.checkGoodsInAndOutAmount();
        if(result == 0)  return;
        //转换表格数组
        this.transferTableData();
      }
      if(action.equals("create")){
        //检查明细账是否为空
        if(stockSubLedgerObjectsOut.length == 0){
          JOptionPane.showMessageDialog(null, "组合前的商品明细为空，不可以创建商品组合单.");
          return;
        }
        //添加商品组合单
        result = stockManagementData.createCombineOrder(ledgerDate,
            stockLedger, stockSubLedgersOut, stockSubLedgersIn);
        if(result == 1){
          JOptionPane.showMessageDialog(null, "商品组合单添加成功，请重新执行查询操作显示新的商品组合单.");
        }else{
          JOptionPane.showMessageDialog(null, "商品组合单添加失败，请检查输入值是否大于字段范围.");
        }
      }else if (action.equals("update")){
        //取得原来的单据编号
        stockLedger[0] = stockLedgers[selectedIndex][0].trim();
        //取得原来的关联标识
        stockLedger[2] = stockLedgers[selectedIndex][2].trim();
        //修改商品组合单
        result = stockManagementData.updateCombineOrder(ledgerDate,
            stockLedger, stockSubLedgersOut, stockSubLedgersIn);
        if(result == 1){
          JOptionPane.showMessageDialog(null, "商品组合单修改成功.");
          //更新数组的数据
          for (int i = 0; i < 13; i++) {
            stockLedgers[selectedIndex][i] = stockLedger[i];
          }
        }else{
          JOptionPane.showMessageDialog(null, "商品组合单修改失败，请检查输入值是否大于字段范围.");
        }
      }else if (action.equals("cancel")){
        //撤消商品组合单
        result = stockManagementData.cancelOrRestoreRearrangeOrder(ledgerDate,
            stockLedgers[selectedIndex][0], stockLedgers[selectedIndex][2],
            user.getUserName(), 1, stockLedger[12]);
        if(result == 1){
          JOptionPane.showMessageDialog(null, "商品组合单撤消成功.");
          //更新完成状态编辑框的值
          jTextField10.setText(onProcesses[1]);
          //更新数组的数据
          stockLedgers[selectedIndex][11] = "1";
          stockLedgers[selectedIndex][12] = stockLedger[12];
        }else{
          JOptionPane.showMessageDialog(null, "商品组合单撤消失败.");
        }
      }else if (action.equals("restore")){
        //恢复商品组合单
        result = stockManagementData.cancelOrRestoreRearrangeOrder(ledgerDate,
            stockLedgers[selectedIndex][0], stockLedgers[selectedIndex][2],
            user.getUserName(), 2, stockLedger[12]);
        if(result == 1){
          JOptionPane.showMessageDialog(null, "商品组合单恢复成功.");
          //更新完成状态编辑框的值
          jTextField10.setText(onProcesses[2]);
          //更新数组的数据
          stockLedgers[selectedIndex][11] = "2";
          stockLedgers[selectedIndex][12] = stockLedger[12];
        }else{
          JOptionPane.showMessageDialog(null, "商品组合单恢复失败.");
        }
      }
      this.checkSubBtn(false);
      this.checkBtn(false);
    }else if(actionCommand.equals("cancel")){
      this.jList1_valueChanged(null);
      this.checkBtn(false);
      this.checkSubBtn(false);
    }else if(actionCommand.equals("createSub")){
      //为商品明细表添加一个空行
      int objectsLength = stockSubLedgerObjectsOut.length;
      Object[][] tempObjs = new Object[objectsLength + 1][7];
      System.arraycopy(stockSubLedgerObjectsOut, 0, tempObjs, 0, objectsLength);
      tempObjs[objectsLength][0] = new Integer(0);
      tempObjs[objectsLength][1] = new String("");
      tempObjs[objectsLength][2] = new String("");
      tempObjs[objectsLength][3] = new Double(0);
      tempObjs[objectsLength][4] = new Integer(0);
      tempObjs[objectsLength][5] = new Double(0);
      tempObjs[objectsLength][6] = new String("");
      stockSubLedgerObjectsOut = tempObjs;
      this.showTableDataOut(stockSubLedgerObjectsOut);
    }else if(actionCommand.equals("deleteSub")){
      if(jTable1.getSelectedRowCount() == 0){
        JOptionPane.showMessageDialog(null, "请选择明细记录.");
        return;
      }
      //删除选择的记录
      int selectedIndex = jTable1.getSelectedRow();
      Object[][] tempObjs = new Object[stockSubLedgerObjectsOut.length - 1][7];
      int line = 0;
      for(int i = 0; i < stockSubLedgerObjectsOut.length; i++){
        if(i == selectedIndex){
          continue;
        }else{
          for(int j = 0; j < 7; j++){
            tempObjs[line][j] = stockSubLedgerObjectsOut[i][j];
          }
          line++;
        }
      }
      stockSubLedgerObjectsOut = tempObjs;
      this.showTableDataOut(stockSubLedgerObjectsOut);
    }else if(actionCommand.equals("exit")){
      exit();
    }
  }
}
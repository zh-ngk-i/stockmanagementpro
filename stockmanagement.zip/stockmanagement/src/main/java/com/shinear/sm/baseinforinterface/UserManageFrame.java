﻿package com.shinear.sm.baseinforinterface;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.shinear.sm.data.StockManagementData;
import com.shinear.sm.user.User;
import com.shinear.sm.maininterface.*;
import javax.swing.event.*;

public class UserManageFrame extends JFrame implements ActionListener {
  JPanel contentPane;
  //创建滚动框
  JScrollPane jScrollPane1 = new JScrollPane();
  //创建列表框数据类和列表框
  DefaultListModel listData=new DefaultListModel();
  JList jList1 = new JList(listData);
  //创建面板布局
  GridLayout baseInforGridLayout = new GridLayout();
  GridLayout stockGridLayout = new GridLayout();
  GridLayout stockManageGridLayout = new GridLayout();
  GridLayout saleGridLayout = new GridLayout();
  //创建复选框面板
  JPanel baseInforPanel = new JPanel();
  JPanel stockPanel = new JPanel();
  JPanel stockManagePanel = new JPanel();
  JPanel salePanel = new JPanel();
  //创建标签控件
  JLabel jLabel1 = new JLabel();
  JLabel jLabel2 = new JLabel();
  //创建编辑框控件
  JTextField jTextField1 = new JTextField();
  JTextField jTextField2 = new JTextField();
  JTextField jTextField3 = new JTextField();
  //创建按钮控件
  JButton jButton1 = new JButton();
  JButton jButton2 = new JButton();
  JButton jButton3 = new JButton();
  JButton jButton4 = new JButton();
  JButton jButton5 = new JButton();
  JButton jButton6 = new JButton();
  JButton jButton7 = new JButton();
  JButton jButton8 = new JButton();
  JButton jButton9 = new JButton();
  JButton jButton10 = new JButton();
  JButton jButton11 = new JButton();
  JButton jButton12 = new JButton();
  JButton jButton13 = new JButton();
  JButton jButton14 = new JButton();
  JButton jButton15 = new JButton();
  JButton jButton16 = new JButton();
  JButton jButton17 = new JButton();
  //创建基础信息模块的复选框和标题数组
  JCheckBox[] baseInforCheckBoxes = new JCheckBox[12];
  String[] baseInforTitles = {"用户管理用户", "数据备份用户", "账套管理用户",
      "商品数据管理用户", "商品折扣管理用户", "供应商数据管理用户", "客户数据管理用户",
      "客户信用管理用户", "仓库数据管理用户", "会计科目管理用户",
      "报表管理用户", "用户日志查看用户"};
  //创建进货模块的复选项和标题数组
  JCheckBox[] stockCheckBoxes = new JCheckBox[9];
  String[] stockTitles = {"请购用户", "订购用户", "验收用户",
      "现金管理用户", "现金日记账查看用户", "进货单查询用户", "应付账款查询用户",
      "进货会计分录管理用户", "进货会计分录查看用户"};
  //创建库存模块的复选项和标题数组
  JCheckBox[] stockManageCheckBoxes = new JCheckBox[12];
  String[] stockManageTitles = {"商品调出用户", "商品检收用户", "商品调价用户",
      "商品组合管理用户", "库存盘点计数用户", "库存盘点核查用户", "库存商品查询用户",
      "库存单据查询用户", "库存警告设置用户", "商品有效期查询用户", "库存会计分录管理用户",
      "库存会计分录查看用户"};
  //创建销售模块的复选项和标题数组
  JCheckBox[] saleCheckBoxes = new JCheckBox[7];
  String[] saleTitles = {"前台销售用户", "信用销售用户", "销售收款用户",
      "销售单查询用户", "应收帐款查询用户", "销售会计分录管理用户", "销售会计分录查看用户"};
  //创建字体类
  Font dialog13 = new java.awt.Font("Dialog", 0, 13);
  //声明数据类
  StockManagementData stockManagementData = null;
  //声明用户类
  User user = null;
  //声明选择用户类的数组
  User[] selectedUsers = new User[0];
  //声明主窗口类
  StockManagementMainFrame stockManagementMainFrame = null;
  //创建选择用户变量
  int baseInforFunction = 0;
  int stockFunction = 0;
  int stockManageFunction = 0;
  int saleFunction = 0;
  //创建记录按钮动作变量
  String action = "";

  public UserManageFrame(StockManagementMainFrame stockManagementMainFrame) {
    this.stockManagementMainFrame = stockManagementMainFrame;
    //取得主窗口的数据类
    stockManagementData = stockManagementMainFrame.getStockManagementData();
    //取得主窗口的用户类
    user = stockManagementMainFrame.getUser();
    //取得基础信息模块的用户权限
    int baseInforFunction = user.getBaseInforFunction();
    //检查用户是否具有用户管理权限
    if((baseInforFunction & 1) != 1){
      JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
      exit();
    }
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception  {
    contentPane = (JPanel) this.getContentPane();
    contentPane.setLayout(null);
    this.setSize(new Dimension(800, 712));
    //设置基础信息模块复选框面板的属性
    baseInforGridLayout.setRows(4);
    baseInforGridLayout.setColumns(3);
    baseInforPanel.setLayout(baseInforGridLayout);
    baseInforPanel.setBounds(new Rectangle(307, 90, 476, 145));
    baseInforPanel.setBorder(BorderFactory.createEtchedBorder());
    //设置进货模块复选框面板的属性
    stockGridLayout.setRows(3);
    stockGridLayout.setColumns(3);
    stockPanel.setLayout(stockGridLayout);
    stockPanel.setBounds(new Rectangle(307, 241, 476, 106));
    stockPanel.setBorder(BorderFactory.createEtchedBorder());
    //设置库存模块复选框面板的属性
    stockManageGridLayout.setRows(4);
    stockManageGridLayout.setColumns(3);
    stockManagePanel.setLayout(stockManageGridLayout);
    stockManagePanel.setBounds(new Rectangle(307, 353, 476, 145));
    stockManagePanel.setBorder(BorderFactory.createEtchedBorder());
    //设置销售模块复选框面板的属性
    saleGridLayout.setRows(3);
    saleGridLayout.setColumns(3);
    salePanel.setLayout(saleGridLayout);
    salePanel.setBounds(new Rectangle(307, 504, 476, 106));
    salePanel.setBorder(BorderFactory.createEtchedBorder());
    //设置编辑框的属性
    jTextField1.setBounds(new Rectangle(25, 20, 95, 22));
    jTextField2.setBounds(new Rectangle(374, 20, 139, 22));
    jTextField3.setBounds(new Rectangle(620, 20, 139, 22));
    //设置标签的属性
    jLabel1.setText("用户名：");
    jLabel1.setBounds(new Rectangle(283, 20, 67, 16));
    jLabel2.setText("密码：");
    jLabel2.setBounds(new Rectangle(538, 20, 58, 16));
    //设置按钮的属性
    jButton1.setText("查询");
    jButton1.setActionCommand("search");
    jButton1.setBounds(new Rectangle(133, 18, 66, 25));
    jButton2.setText("选择全部权限");
    jButton2.setActionCommand("selectAllCheckboxes");
    jButton2.setBounds(new Rectangle(374, 58, 122, 25));
    jButton3.setText("恢复全部权限");
    jButton3.setActionCommand("restoreAllCheckBoxes");
    jButton3.setBounds(new Rectangle(581, 58, 122, 25));
    jButton4.setText("选择权限");
    jButton4.setActionCommand("baseInforSelectCheckBoxes");
    jButton4.setBounds(new Rectangle(202, 91, 100, 25));
    jButton5.setText("恢复权限");
    jButton5.setActionCommand("baseInforRestoreCheckBoxes");
    jButton5.setBounds(new Rectangle(202, 129, 100, 25));
    jButton6.setText("选择权限");
    jButton6.setActionCommand("stockSelectCheckBoxes");
    jButton6.setBounds(new Rectangle(202, 241, 100, 25));
    jButton7.setText("恢复权限");
    jButton7.setActionCommand("stockRestoreCheckBoxes");
    jButton7.setBounds(new Rectangle(202, 279, 100, 25));
    jButton8.setText("选择权限");
    jButton8.setActionCommand("stockManageSelectCheckBoxes");
    jButton8.setBounds(new Rectangle(202, 353, 100, 25));
    jButton9.setText("恢复权限");
    jButton9.setActionCommand("stockManageRestoreCheckBoxes");
    jButton9.setBounds(new Rectangle(202, 391, 100, 25));
    jButton10.setText("选择权限");
    jButton10.setActionCommand("saleSelectCheckBoxes");
    jButton10.setBounds(new Rectangle(202, 504, 100, 25));
    jButton11.setText("恢复权限");
    jButton11.setActionCommand("saleRestoreCheckBoxes");
    jButton11.setBounds(new Rectangle(202, 542, 100, 25));
    jButton12.setText("添加用户");
    jButton12.setActionCommand("add");
    jButton12.setBounds(new Rectangle(24, 628, 108, 25));
    jButton13.setText("修改用户");
    jButton13.setActionCommand("update");
    jButton13.setBounds(new Rectangle(154, 628, 108, 25));
    jButton14.setText("删除用户");
    jButton14.setActionCommand("delete");
    jButton14.setBounds(new Rectangle(284, 628, 108, 25));
    jButton15.setText("确定");
    jButton15.setActionCommand("ok");
    jButton15.setBounds(new Rectangle(415, 628, 108, 25));
    jButton16.setText("取消");
    jButton16.setActionCommand("cancel");
    jButton16.setBounds(new Rectangle(545, 628, 108, 25));
    jButton17.setText("退出");
    jButton17.setActionCommand("exit");
    jButton17.setBounds(new Rectangle(675, 628, 108, 25));
    //设置滚动框的属性
    jScrollPane1.setBounds(new Rectangle(24, 58, 169, 553));
    jScrollPane1.getViewport().add(jList1, null);
    //为列表框加入选择接收器
    jList1.addListSelectionListener(new ListSelectionListener() {
      public void valueChanged(ListSelectionEvent e) {
        userNameList_valueChanged(e);
      }
    });
    //为面板加入控件
    contentPane.add(jTextField1, null);
    contentPane.add(jTextField2, null);
    contentPane.add(jTextField3, null);
    contentPane.add(jScrollPane1, null);
    contentPane.add(jLabel1, null);
    contentPane.add(jLabel2, null);
    contentPane.add(baseInforPanel, null);
    contentPane.add(stockPanel, null);
    contentPane.add(stockManagePanel, null);
    contentPane.add(salePanel, null);
    contentPane.add(jButton1, null);
    contentPane.add(jButton2, null);
    contentPane.add(jButton3, null);
    contentPane.add(jButton4, null);
    contentPane.add(jButton5, null);
    contentPane.add(jButton6, null);
    contentPane.add(jButton7, null);
    contentPane.add(jButton8, null);
    contentPane.add(jButton9, null);
    contentPane.add(jButton10, null);
    contentPane.add(jButton11, null);
    contentPane.add(jButton12, null);
    contentPane.add(jButton13, null);
    contentPane.add(jButton14, null);
    contentPane.add(jButton15, null);
    contentPane.add(jButton16, null);
    contentPane.add(jButton17, null);
    //设置窗口类的字体和为按钮加入动作接收器
    setupFontAndListener();
    //显示复选框
    showAuthorityCheckBox();
    //检查按钮状态
    checkBtn(false);
  }
  //设置窗口类的字体和为按钮加入动作接收器的方法
  public void setupFontAndListener(){
    Component[] components = contentPane.getComponents();
    //创建临时按钮控件
    JButton tmpBtn = new JButton();
    for(int i = 0; i < components.length; i++){
      components[i].setFont(dialog13);
      if(components[i].getClass().getName().equals("javax.swing.JButton")){
        tmpBtn = (JButton)components[i];
        tmpBtn.addActionListener(this);
      }
    }
  }
  //显示复选框的方法
  public void showAuthorityCheckBox(){
    //显示基础信息模块的复选框
    for(int i = 0; i < baseInforCheckBoxes.length; i++){
      baseInforCheckBoxes[i] = new JCheckBox();
      baseInforCheckBoxes[i].setText(baseInforTitles[i]);
      baseInforCheckBoxes[i].setFont(dialog13);
      baseInforPanel.add(baseInforCheckBoxes[i]);
    }
    //显示进货模块的复选框
    for(int i = 0; i < stockCheckBoxes.length; i++){
      stockCheckBoxes[i] = new JCheckBox();
      stockCheckBoxes[i].setText(stockTitles[i]);
      stockCheckBoxes[i].setFont(dialog13);
      stockPanel.add(stockCheckBoxes[i]);
    }
    //显示库存模块的复选框
    for(int i = 0; i < stockManageCheckBoxes.length; i++){
      stockManageCheckBoxes[i] = new JCheckBox();
      stockManageCheckBoxes[i].setText(stockManageTitles[i]);
      stockManageCheckBoxes[i].setFont(dialog13);
      stockManagePanel.add(stockManageCheckBoxes[i]);
    }
    //设置销售模块的复选框
    for(int i = 0; i < saleCheckBoxes.length; i++){
      saleCheckBoxes[i] = new JCheckBox();
      saleCheckBoxes[i].setText(saleTitles[i]);
      saleCheckBoxes[i].setFont(dialog13);
      salePanel.add(saleCheckBoxes[i]);
    }
  }
  //设置选择用户所有复选框的方法
  public void setAllAuthorityCheckBox(int selectIndex){
    //取得用户类的权限数字
    baseInforFunction = selectedUsers[selectIndex].getBaseInforFunction();
    stockFunction = selectedUsers[selectIndex].getStockFunction();
    stockManageFunction = selectedUsers[selectIndex].getStockManageFunction();
    saleFunction = selectedUsers[selectIndex].getSaleFunction();
    setBaseInforAuthorityCheckBox(baseInforFunction);
    setStockAuthorityCheckBox(stockFunction);
    setStockManageAuthorityCheckBox(stockManageFunction);
    setSaleAuthorityCheckBox(saleFunction);
  }
  //设置基础信息模块复选框的方法
  public void setBaseInforAuthorityCheckBox(int baseInforFunction){
    int power = 0;
    //设置基础信息模块的复选框
    for(int i = 0; i < baseInforCheckBoxes.length; i++){
      power = (int)Math.pow(2, i);
      if((baseInforFunction & power) == power){
        baseInforCheckBoxes[i].setSelected(true);
      }else{
        baseInforCheckBoxes[i].setSelected(false);
      }
    }
  }
  //设置进货模块复选框的方法
  public void setStockAuthorityCheckBox(int stockFunction){
    int power = 0;
    //设置进货模块的复选框
    for(int i = 0; i < stockCheckBoxes.length; i++){
      power = (int)Math.pow(2, i);
      if((stockFunction & power) == power){
        stockCheckBoxes[i].setSelected(true);
      }else{
        stockCheckBoxes[i].setSelected(false);
      }
    }
  }
  //设置库存模块复选框的方法
  public void setStockManageAuthorityCheckBox(int stockManageFunction){
    int power = 0;
    //设置库存模块的复选框
    for(int i = 0; i < stockManageCheckBoxes.length; i++){
      power = (int)Math.pow(2, i);
      if((stockManageFunction & power) == power){
        stockManageCheckBoxes[i].setSelected(true);
      }else{
        stockManageCheckBoxes[i].setSelected(false);
      }
    }
  }
  //设置销售模块复选框的方法
  public void setSaleAuthorityCheckBox(int saleFunction){
    int power = 0;
    //设置销售模块的复选框
    for(int i = 0; i < saleCheckBoxes.length; i++){
      power = (int)Math.pow(2, i);
      if((saleFunction & power) == power){
        saleCheckBoxes[i].setSelected(true);
      }else{
        saleCheckBoxes[i].setSelected(false);
      }
    }
  }
  protected void processWindowEvent(WindowEvent e) {
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      exit();
    }
  }
  //退出方法
  public void exit(){
    //隐藏窗口
    this.setVisible(false);
  }
  //设置用户的方法
  public void setUser(User user) {
    this.user = user;
  }
  //恢复所有复选框的方法
  public void restoreAllCheckBoxes(){
    setBaseInforAuthorityCheckBox(baseInforFunction);
    setStockAuthorityCheckBox(stockFunction);
    setStockManageAuthorityCheckBox(stockManageFunction);
    setSaleAuthorityCheckBox(saleFunction);
  }
  //选择所有复选框的方法
  public void selectAllCheckBoxes(){
    setBaseInforAuthorityCheckBox(4095);
    setStockAuthorityCheckBox(511);
    setStockManageAuthorityCheckBox(4095);
    setSaleAuthorityCheckBox(127);
  }
  //清空界面方法
  public void clearInterface(){
    //清空编辑框
    jTextField2.setText("");
    jTextField3.setText("");
    //清空权限变量
    baseInforFunction = 0;
    stockFunction = 0;
    stockManageFunction = 0;
    saleFunction = 0;
    //清空复选框
    restoreAllCheckBoxes();
  }
  public void searchUser(){
    //清空列表框和用户类数组
    listData.clear();
    selectedUsers = null;
    String userName = jTextField1.getText().trim();
    String[][] userNames = stockManagementData.getUserByUserName(userName);
    //创建用户类数组
    selectedUsers = new User[userNames.length];
    for(int i = 0; i < userNames.length; i++){
      //添加列表框的内容
      listData.addElement(userNames[i][0]);
      //创建用户
      selectedUsers[i] = new User(userNames[i][0], userNames[i][1],
                                  Integer.parseInt(userNames[i][2]),
                                  Integer.parseInt(userNames[i][3]),
                                  Integer.parseInt(userNames[i][4]),
                                  Integer.parseInt(userNames[i][5]));
    }
  }
  //动作接收器的方法
  public void actionPerformed(ActionEvent e) {
    //取得按钮的动作字符串
    String actionCommand = e.getActionCommand().trim();
    //单击查询按钮
    if (actionCommand.equals("search")) {
      searchUser();
    }
    else if (actionCommand.equals("selectAllCheckboxes")) {
      selectAllCheckBoxes();
    }
    else if (actionCommand.equals("restoreAllCheckBoxes")) {
      restoreAllCheckBoxes();
    }
    else if (actionCommand.equals("baseInforSelectCheckBoxes")) {
      setBaseInforAuthorityCheckBox(4095);
    }
    else if (actionCommand.equals("baseInforRestoreCheckBoxes")) {
      setBaseInforAuthorityCheckBox(baseInforFunction);
    }
    else if (actionCommand.equals("stockSelectCheckBoxes")) {
      setStockAuthorityCheckBox(511);
    }
    else if (actionCommand.equals("stockRestoreCheckBoxes")) {
      setStockAuthorityCheckBox(stockFunction);
    }
    else if (actionCommand.equals("stockManageSelectCheckBoxes")) {
      setStockManageAuthorityCheckBox(4095);
    }
    else if (actionCommand.equals("stockManageRestoreCheckBoxes")) {
      setStockManageAuthorityCheckBox(stockManageFunction);
    }
    else if (actionCommand.equals("saleSelectCheckBoxes")) {
      setSaleAuthorityCheckBox(127);
    }
    else if (actionCommand.equals("saleRestoreCheckBoxes")) {
      setSaleAuthorityCheckBox(saleFunction);
    }
    else if (actionCommand.equals("add")) {
      //清空界面
      clearInterface();
      //检查按钮状态
      checkBtn(true);
      action = "add";
    }
    else if (actionCommand.equals("update")) {
      if(jList1.getSelectedIndex() == -1){
        JOptionPane.showMessageDialog(null, "请选择用户.");
        return;
      }
      checkBtn(true);
      action = "update";
    }
    else if (actionCommand.equals("delete")) {
      if(jList1.getSelectedIndex() == -1){
        JOptionPane.showMessageDialog(null, "请选择用户.");
        return;
      }
      checkBtn(true);
      action = "delete";
    }
    else if (actionCommand.equals("ok")) {
      String userName = jTextField2.getText().trim();
      String userPassword = jTextField3.getText().trim();
      if((userName.length() == 0) | (userPassword.length() == 0)){
        JOptionPane.showMessageDialog(null, "用户名和密码不能为空.");
        return;
      }
      if (action.equals("update") | action.equals("delete")) {
        //取得列表框的用户类的名字
        String selectedUserName = (String) listData.getElementAt(jList1.
            getSelectedIndex());
        if (!selectedUserName.equals(userName)) {
          JOptionPane.showMessageDialog(null, "列表框的选择用户名和编辑框的用户名不相同，不能进行更新和删除操作.");
          return;
        }
      }
      //取得用户权限数字
      int tempBaseInforFunction = 0;
      int tempStockFunction = 0;
      int tempStockManageFunction = 0;
      int tempSaleFunction = 0;
      //取得基础信息模块的权限
      for(int i = 0; i < baseInforCheckBoxes.length; i++){
        if(baseInforCheckBoxes[i].isSelected()){
          tempBaseInforFunction += Math.pow(2, i);
        }
      }
      //取得进货模块的权限
      for(int i = 0; i < stockCheckBoxes.length; i++){
        if(stockCheckBoxes[i].isSelected()){
          tempStockFunction += Math.pow(2, i);
        }
      }
      //取得库存模块的权限
      for(int i = 0; i < stockManageCheckBoxes.length; i++){
        if(stockManageCheckBoxes[i].isSelected()){
          tempStockManageFunction += Math.pow(2, i);
        }
      }
      //取得销售模块的权限
      for(int i = 0; i < saleCheckBoxes.length; i++){
        if(saleCheckBoxes[i].isSelected()){
          tempSaleFunction += Math.pow(2, i);
        }
      }
      //创建用户类
      User tempUser = new User(userName, userPassword, tempBaseInforFunction,
                               tempStockFunction, tempStockManageFunction, tempSaleFunction);
      //执行添加操作
      if(action.equals("add")){
        int result = stockManagementData.createUser(tempUser);
        if(result == 1){
          //为列表框添加用户名
          listData.addElement(userName);
          //更新用户数组
          User[] tempUsers = new User[selectedUsers.length + 1];
          System.arraycopy(selectedUsers, 0, tempUsers, 0, selectedUsers.length);
          tempUsers[selectedUsers.length] = tempUser;
          selectedUsers = tempUsers;
          JOptionPane.showMessageDialog(null, "成功添加用户(" + userName + ").");
        }else{
          JOptionPane.showMessageDialog(null, "添加用户失败.");
        }
      }
      //执行更新操作
      else if(action.equals("update")){
        int result = stockManagementData.updateUser(tempUser);
        if(result == 1){
          JOptionPane.showMessageDialog(null, "成功更新用户(" + userName + ").");
          //更新用户列表的用户类
          selectedUsers[jList1.getSelectedIndex()] = tempUser;
        }else{
          JOptionPane.showMessageDialog(null, "更新用户失败.");
        }
      }
      //执行删除操作
      else if(action.equals("delete")){
        int result = stockManagementData.deleteUser(tempUser);
        if(result == 1){
          int selectedIndex = jList1.getSelectedIndex();
          //为列表框删除用户名
          listData.remove(selectedIndex);
          //更新用户数组
          User[] tempUsers = new User[selectedUsers.length - 1];
          int line = 0;
          for(int i = 0; i < selectedUsers.length; i++){
            if(i == selectedIndex){
              continue;
            }else{
              tempUsers[line] = selectedUsers[i];
              line++;
            }
          }
          selectedUsers = tempUsers;
          JOptionPane.showMessageDialog(null, "成功删除用户(" + userName + ").");
        }else{
          JOptionPane.showMessageDialog(null, "删除用户失败.");
        }
      }
      checkBtn(false);
    }
    else if (actionCommand.equals("cancel")) {
      checkBtn(false);
      //激活列表框的选择方法
      userNameList_valueChanged(null);
    }
    else if (actionCommand.equals("exit")) {
      exit();
    }
  }
  //检查按钮enabled状态的方法
  public void checkBtn(boolean manipulated){
    //增、删、改状态
    if(manipulated){
      jButton12.setEnabled(false);
      jButton13.setEnabled(false);
      jButton14.setEnabled(false);
      jButton15.setEnabled(true);
      jButton16.setEnabled(true);
    }else{
      jButton12.setEnabled(true);
      jButton13.setEnabled(true);
      jButton14.setEnabled(true);
      jButton15.setEnabled(false);
      jButton16.setEnabled(false);
    }
  }
  //列表内容改变方法
  void userNameList_valueChanged(ListSelectionEvent e) {
    //取得选择项的位置
    int selectIndex = jList1.getSelectedIndex();
    if(selectIndex > -1){
      //显示用户名和密码
      jTextField2.setText(selectedUsers[selectIndex].getUserName());
      jTextField3.setText(selectedUsers[selectIndex].getUserPassword());
      //根据用户重新设置所有复选框
      setAllAuthorityCheckBox(selectIndex);
    }else{
      //使所有控件回复到空状态
      clearInterface();
    }
 }
}
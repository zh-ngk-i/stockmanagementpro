﻿package com.shinear.sm.baseinforinterface;

import javax.swing.UIManager;
import java.awt.*;
import javax.swing.*;
import com.shinear.sm.maininterface.*;
import com.shinear.sm.user.User;

public class GoodsDiscountManageApp {

  public GoodsDiscountManageApp() {
    //创建主窗口类，该类供测试使用
    StockManagementMainFrame stockManagementMainFrame = new StockManagementMainFrame();
    //创建用户类
    User user = new User("jack", "jack", 4095, 0, 2088, 0);
    //取得基础信息模块的用户权限
    int baseInforFunction = user.getBaseInforFunction();
    if((baseInforFunction & 16) != 16){
      JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
      System.exit(0);
    }
    //设置主窗口的用户类
    stockManagementMainFrame.setUser(user);
    GoodsDiscountManageFrame frame = new GoodsDiscountManageFrame(stockManagementMainFrame);
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = frame.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }
    frame.setLocation( (screenSize.width - frameSize.width) / 2,
                      (screenSize.height - frameSize.height) / 2);
    frame.setVisible(true);
  }
  public static void main(String[] args) {
    try {
      UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
    }
    catch(Exception e) {
      e.printStackTrace();
    }
    new GoodsDiscountManageApp();
  }
}
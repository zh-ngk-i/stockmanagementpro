﻿package com.shinear.sm.baseinforinterface;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import com.shinear.sm.data.*;
import com.shinear.sm.maininterface.*;
import com.shinear.sm.user.*;
import com.shinear.sm.method.*;

public class GoodsManageFrame extends JFrame implements ActionListener {
  JPanel contentPane;
  //创建标签控件
  JLabel jLabel1 = new JLabel();
  JLabel jLabel2 = new JLabel();
  JLabel jLabel3 = new JLabel();
  JLabel jLabel4 = new JLabel();
  JLabel jLabel5 = new JLabel();
  JLabel jLabel6 = new JLabel();
  JLabel jLabel7 = new JLabel();
  JLabel jLabel8 = new JLabel();
  JLabel jLabel9 = new JLabel();
  JLabel jLabel10 = new JLabel();
  JLabel jLabel11 = new JLabel();
  JLabel jLabel12 = new JLabel();
  JLabel jLabel13 = new JLabel();
  JLabel jLabel14 = new JLabel();
  JLabel jLabel15 = new JLabel();
  JLabel jLabel16 = new JLabel();
  //创建编辑框控件
  JTextField jTextField1 = new JTextField();
  JTextField jTextField2 = new JTextField();
  JTextField jTextField3 = new JTextField();
  JTextField jTextField4 = new JTextField();
  JTextField jTextField5 = new JTextField();
  JTextField jTextField6 = new JTextField();
  JTextField jTextField7 = new JTextField();
  JTextField jTextField8 = new JTextField();
  JTextField jTextField9 = new JTextField();
  JTextField jTextField10 = new JTextField();
  JTextField jTextField11 = new JTextField();
  JTextField jTextField12 = new JTextField();
  JTextField jTextField13 = new JTextField();
  //创建按钮控件
  JButton jButton1 = new JButton();
  JButton jButton2 = new JButton();
  JButton jButton3 = new JButton();
  JButton jButton4 = new JButton();
  JButton jButton5 = new JButton();
  JButton jButton6 = new JButton();
  JButton jButton7 = new JButton();
  JButton jButton8 = new JButton();
  JButton jButton9 = new JButton();
  JButton jButton10 = new JButton();
  JButton jButton11 = new JButton();
  JButton jButton12 = new JButton();
  JButton jButton13 = new JButton();
  //创建滚动框控件
  JScrollPane jScrollPane1 = new JScrollPane();
  JScrollPane jScrollPane2 = new JScrollPane();
  JScrollPane jScrollPane3 = new JScrollPane();
  //创建列表框数据类和列表框控件
  DefaultListModel listData1 = new DefaultListModel();
  DefaultListModel listData2 = new DefaultListModel();
  JList jList1 = new JList(listData1);
  JList jList2 = new JList(listData2);
  //创建文本框控件
  JTextArea jTextArea1 = new JTextArea();
  //创建组合框控件
  JComboBox jComboBox1 = new JComboBox();
  //创建字体类
  Font dialog13 = new java.awt.Font("Dialog", 0, 13);
  //声明数据类
  StockManagementData stockManagementData = null;
  //声明用户类
  User user = null;
  //声明主窗口类
  StockManagementMainFrame stockManagementMainFrame = null;
  //创建商品类别数组
  String[][] categories = new String[0][4];
  //创建商品数组
  String[][] goods = new String[0][13];
  //创建动作字符串
  String action = "";
  //创建方法类
  DataMethod dataMethod = new DataMethod();

  public GoodsManageFrame(StockManagementMainFrame stockManagementMainFrame) {
    this.stockManagementMainFrame = stockManagementMainFrame;
    //取得主窗口的数据类
    stockManagementData = stockManagementMainFrame.getStockManagementData();
    //取得主窗口的用户类
    user = stockManagementMainFrame.getUser();
    //取得基础信息模块的用户权限
    int baseInforFunction = user.getBaseInforFunction();
    //检查用户权限
    if((baseInforFunction & 8) != 8){
      JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
      System.exit(0);
    }
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception  {
    contentPane = (JPanel) this.getContentPane();
    contentPane.setLayout(null);
    this.setSize(new Dimension(669, 585));
    this.setTitle("商品数据管理窗口");
    //设置标签控件
    jLabel1.setText("商品类别列表：");
    jLabel1.setBounds(new Rectangle(26, 17, 97, 16));
    jLabel2.setText("类别序号：");
    jLabel2.setBounds(new Rectangle(197, 47, 83, 16));
    jLabel3.setText("类别父索引：");
    jLabel3.setBounds(new Rectangle(197, 101, 88, 16));
    jLabel4.setText("商品类别名称：");
    jLabel4.setBounds(new Rectangle(197, 156, 109, 16));
    jLabel5.setText("商品类别描述：");
    jLabel5.setBounds(new Rectangle(403, 47, 112, 16));
    jLabel6.setText("商品列表：");
    jLabel6.setBounds(new Rectangle(26, 232, 97, 16));
    jLabel7.setText("查询条件：");
    jLabel7.setBounds(new Rectangle(196, 258, 97, 16));
    jLabel8.setText("商品条形码：");
    jLabel8.setBounds(new Rectangle(196, 308, 110, 16));
    jLabel9.setText("商品分类标识：");
    jLabel9.setBounds(new Rectangle(490, 308, 92, 16));
    jLabel10.setText("商品名称：");
    jLabel10.setBounds(new Rectangle(196, 357, 72, 16));
    jLabel11.setText("商品别名：");
    jLabel11.setBounds(new Rectangle(490, 357, 85, 16));
    jLabel12.setText("助记码：");
    jLabel12.setBounds(new Rectangle(196, 407, 76, 16));
    jLabel13.setText("拼音码：");
    jLabel13.setBounds(new Rectangle(356, 407, 76, 16));
    jLabel14.setText("计量单位：");
    jLabel14.setBounds(new Rectangle(490, 407, 76, 16));
    jLabel15.setText("规格：");
    jLabel15.setBounds(new Rectangle(196, 456, 76, 16));
    jLabel16.setText("生产厂商：");
    jLabel16.setBounds(new Rectangle(356, 456, 72, 16));
    //设置编辑框
    jTextField1.setBounds(new Rectangle(288, 47, 93, 22));
    //使类别序号不可编辑
    jTextField1.setEditable(false);
    jTextField2.setBounds(new Rectangle(288, 99, 93, 22));
    //使类别父索引不可编辑
    jTextField2.setEditable(false);
    jTextField3.setBounds(new Rectangle(288, 150, 190, 22));
    jTextField4.setBounds(new Rectangle(433, 258, 102, 22));
    jTextField5.setBounds(new Rectangle(281, 306, 179, 22));
    jTextField6.setBounds(new Rectangle(576, 306, 65, 22));
    jTextField7.setBounds(new Rectangle(281, 354, 179, 22));
    jTextField8.setBounds(new Rectangle(576, 354, 65, 22));
    jTextField9.setBounds(new Rectangle(281, 402, 65, 22));
    jTextField10.setBounds(new Rectangle(407, 402, 65, 22));
    jTextField11.setBounds(new Rectangle(576, 402, 65, 22));
    jTextField12.setBounds(new Rectangle(281, 450, 65, 22));
    jTextField13.setBounds(new Rectangle(462, 450, 179, 22));
    //设置按钮
    jButton1.setText("显示类别");
    jButton1.setActionCommand("showCategory");
    jButton1.setBounds(new Rectangle(26, 192, 98, 25));
    jButton2.setText("创建类别");
    jButton2.setActionCommand("createCategory");
    jButton2.setBounds(new Rectangle(135, 192, 98, 25));
    jButton3.setText("修改类别");
    jButton3.setActionCommand("updateCategory");
    jButton3.setBounds(new Rectangle(245, 192, 98, 25));
    jButton4.setText("删除类别");
    jButton4.setActionCommand("deleteCategory");
    jButton4.setBounds(new Rectangle(354, 192, 98, 25));
    jButton5.setText("确定");
    jButton5.setActionCommand("okCategory");
    jButton5.setEnabled(false);
    jButton5.setBounds(new Rectangle(464, 192, 83, 25));
    jButton6.setText("取消");
    jButton6.setActionCommand("cancelCategory");
    jButton6.setEnabled(false);
    jButton6.setBounds(new Rectangle(558, 192, 83, 25));
    jButton7.setText("查询");
    jButton7.setActionCommand("search");
    jButton7.setBounds(new Rectangle(543, 258, 98, 25));
    jButton8.setText("创建商品");
    jButton8.setActionCommand("createGoods");
    jButton8.setBounds(new Rectangle(26, 492, 98, 25));
    jButton9.setText("修改商品");
    jButton9.setActionCommand("updateGoods");
    jButton9.setBounds(new Rectangle(138, 492, 98, 25));
    jButton10.setText("删除商品");
    jButton10.setActionCommand("deleteGoods");
    jButton10.setBounds(new Rectangle(250, 492, 98, 25));
    jButton11.setText("确定");
    jButton11.setEnabled(false);
    jButton11.setActionCommand("okGoods");
    jButton11.setBounds(new Rectangle(361, 492, 83, 25));
    jButton12.setText("取消");
    jButton12.setEnabled(false);
    jButton12.setActionCommand("cancelGoods");
    jButton12.setBounds(new Rectangle(459, 492, 83, 25));
    jButton13.setText("退出");
    jButton13.setActionCommand("exit");
    jButton13.setBounds(new Rectangle(557, 492, 83, 25));
    //设置滚动框
    jScrollPane1.setBounds(new Rectangle(26, 47, 153, 125));
    jScrollPane2.setBounds(new Rectangle(488, 47, 153, 125));
    jScrollPane3.setBounds(new Rectangle(26, 258, 153, 214));
    jScrollPane1.getViewport().add(jList1, null);
    jScrollPane2.getViewport().add(jTextArea1, null);
    jScrollPane3.getViewport().add(jList2, null);
    //为列表框加入选择接收器
    jList1.addListSelectionListener(new ListSelectionListener() {
      public void valueChanged(ListSelectionEvent e) {
        jList1_valueChanged(e);
      }
    });
    jList2.addListSelectionListener(new ListSelectionListener() {
      public void valueChanged(ListSelectionEvent e) {
        jList2_valueChanged(e);
      }
    });
    //设置下拉列表框
    jComboBox1.setBounds(new Rectangle(281, 258, 141, 22));
    jComboBox1.addItem("按商品条形码查询");
    jComboBox1.addItem("按商品名称查询");
    jComboBox1.addItem("按生产厂商查询");
    //为面板加入各个控件
    contentPane.add(jComboBox1, null);
    contentPane.add(jScrollPane1, null);
    contentPane.add(jScrollPane2, null);
    contentPane.add(jScrollPane3, null);
    contentPane.add(jLabel1, null);
    contentPane.add(jLabel2, null);
    contentPane.add(jLabel3, null);
    contentPane.add(jLabel4, null);
    contentPane.add(jLabel5, null);
    contentPane.add(jLabel6, null);
    contentPane.add(jLabel7, null);
    contentPane.add(jLabel8, null);
    contentPane.add(jLabel9, null);
    contentPane.add(jLabel10, null);
    contentPane.add(jLabel11, null);
    contentPane.add(jLabel12, null);
    contentPane.add(jLabel13, null);
    contentPane.add(jLabel14, null);
    contentPane.add(jLabel15, null);
    contentPane.add(jLabel16, null);
    contentPane.add(jTextField1, null);
    contentPane.add(jTextField2, null);
    contentPane.add(jTextField3, null);
    contentPane.add(jTextField4, null);
    contentPane.add(jTextField5, null);
    contentPane.add(jTextField6, null);
    contentPane.add(jTextField7, null);
    contentPane.add(jTextField8, null);
    contentPane.add(jTextField9, null);
    contentPane.add(jTextField10, null);
    contentPane.add(jTextField11, null);
    contentPane.add(jTextField12, null);
    contentPane.add(jTextField13, null);
    contentPane.add(jButton1, null);
    contentPane.add(jButton2, null);
    contentPane.add(jButton3, null);
    contentPane.add(jButton4, null);
    contentPane.add(jButton5, null);
    contentPane.add(jButton6, null);
    contentPane.add(jButton7, null);
    contentPane.add(jButton8, null);
    contentPane.add(jButton9, null);
    contentPane.add(jButton10, null);
    contentPane.add(jButton11, null);
    contentPane.add(jButton12, null);
    contentPane.add(jButton13, null);
    //设置窗口类的字体和为按钮加入动作接收器
    setupFontAndListener();
    //显示全部商品类别的方法
    showAllCategories();
  }
  //设置窗口类的字体和为按钮加入动作接收器的方法
  public void setupFontAndListener(){
    Component[] components = contentPane.getComponents();
    //创建临时按钮控件
    JButton tmpBtn = new JButton();
    for(int i = 0; i < components.length; i++){
      components[i].setFont(dialog13);
      if(components[i].getClass().getName().equals("javax.swing.JButton")){
        tmpBtn = (JButton)components[i];
        tmpBtn.addActionListener(this);
      }
    }
  }
  //显示全部商品类别的方法
  public void showAllCategories(){
    listData1.clear();
    //取得商品类别数据
    categories = stockManagementData.getAllGoodsCategory();
    //为商品类别列表框加入商品类别数据
    for(int i = 0; i < categories.length; i++){
      listData1.addElement(categories[i][2]);
    }
  }
  //显示单个商品类别的方法
  public void showCategory(){
    //取得当前选择项的位置
    int selectedIndex = jList1.getSelectedIndex();
    //当列表框不处于选择状态，不显示商品类别数据
    if(selectedIndex == -1){
       return;
    }
    //显示商品类别序号
    jTextField1.setText(categories[selectedIndex][0]);
    //显示父索引
    jTextField2.setText(categories[selectedIndex][1]);
    //显示商品类别名称
    jTextField3.setText(categories[selectedIndex][2]);
    //显示商品类别描述
    jTextArea1.setText(categories[selectedIndex][3]);
    //取得商品数据
    goods = stockManagementData.getGoodsByGoodsCategory(Integer.parseInt(
        categories[selectedIndex][0]));
    this.showSearchGoods();
  }
  //清空单个商品类别显示的方法
  public void clearCategory(){
    jTextField1.setText("");
    jTextField2.setText("");
    jTextField3.setText("");
    jTextArea1.setText("");
  }
  //显示查询商品的方法
  public void showSearchGoods(){
    listData2.clear();
    //为商品列表框加入商品数据
    for(int i = 0; i < goods.length; i++){
      listData2.addElement(goods[i][0]);
    }
  }
  //显示单个商品的方法
  public void showGood(){
    //取得当前选择项的位置
    int selectedIndex = jList2.getSelectedIndex();
    //当列表框不处于选择状态，不显示商品数据
    if(selectedIndex == -1){
       return;
    }
    //显示商品条形码
    jTextField5.setText(goods[selectedIndex][0]);
    //显示商品分类标识
    jTextField6.setText(goods[selectedIndex][1]);
    //显示商品名称
    jTextField7.setText(goods[selectedIndex][2]);
    //显示商品别名
    jTextField8.setText(goods[selectedIndex][3]);
    //显示商品助记码
    jTextField9.setText(goods[selectedIndex][4]);
    //显示商品拼音码
    jTextField10.setText(goods[selectedIndex][5]);
    //显示计量单位
    jTextField11.setText(goods[selectedIndex][6]);
    //显示规格
    jTextField12.setText(goods[selectedIndex][7]);
    //显示生产厂商
    jTextField13.setText(goods[selectedIndex][8]);
  }
  //清空单个商品显示的方法
  public void clearGood(){
    jTextField5.setText("");
    jTextField6.setText("");
    jTextField7.setText("");
    jTextField8.setText("");
    jTextField9.setText("");
    jTextField10.setText("");
    jTextField11.setText("");
    jTextField12.setText("");
    jTextField13.setText("");
  }
  protected void processWindowEvent(WindowEvent e) {
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      exit();
    }
  }
  //退出方法
  public void exit(){
    //隐藏窗口
    this.setVisible(false);
    //清空数组的内容
    categories = new String[0][4];
    goods = new String[0][13];
    //清空列表框的内容
    listData1.clear();
    listData2.clear();
    //清空文本框的内容s
    jTextArea1.setText("");
    //取得面板上的所有控件
    Component[] components = contentPane.getComponents();
    //创建临时文本框控件
    JTextField tmpTextField = new JTextField();
    for(int i = 0; i < components.length; i++){
      if(components[i].getClass().getName().equals("javax.swing.JTextField")){
        tmpTextField = (JTextField)components[i];
        //清空编辑框的内容
        tmpTextField.setText("");
      }
    }
  }
  //设置用户的方法
  public void setUser(User user) {
    this.user = user;
  }
  //检查商品类别按钮的状态
  public void checkCategoryBtn(boolean isManipulated){
    if(isManipulated){
      jButton2.setEnabled(false);
      jButton3.setEnabled(false);
      jButton4.setEnabled(false);
      jButton5.setEnabled(true);
      jButton6.setEnabled(true);
    }else{
      jButton2.setEnabled(true);
      jButton3.setEnabled(true);
      jButton4.setEnabled(true);
      jButton5.setEnabled(false);
      jButton6.setEnabled(false);
    }
  }
  //检查商品按钮的状态
  public void checkGoodBtn(boolean isManipulated){
    if(isManipulated){
      jButton8.setEnabled(false);
      jButton9.setEnabled(false);
      jButton10.setEnabled(false);
      jButton11.setEnabled(true);
      jButton12.setEnabled(true);
    }else{
      jButton8.setEnabled(true);
      jButton9.setEnabled(true);
      jButton10.setEnabled(true);
      jButton11.setEnabled(false);
      jButton12.setEnabled(false);
    }
  }
  //事件单击方法
  public void actionPerformed(ActionEvent e) {
    //取得按钮的动作字符串
    String actionCommand = e.getActionCommand().trim();
    //进行商品类别的修改和删除时检查商品类别的选择状态
    if(actionCommand.equals("updateCategory") | actionCommand.equals("deleteCategory")){
      if(jList1.isSelectionEmpty()){
        JOptionPane.showMessageDialog(null, "请选择商品类别.");
        return;
      }
    }
    //进行商品的修改和删除时检查商品的选择状态
    if(actionCommand.equals("updateGoods") | actionCommand.equals("deleteGoods")){
      if(jList2.isSelectionEmpty()){
        JOptionPane.showMessageDialog(null, "请选择商品.");
        return;
      }
    }
    //单击按钮的处理代码
    if (actionCommand.equals("showCategory")) {
      this.showAllCategories();
    }else if(actionCommand.equals("createCategory")){
      this.checkCategoryBtn(true);
      this.clearCategory();
      jTextField2.setText("0");
      action = "createCategory";
    }else if(actionCommand.equals("updateCategory")){
      this.checkCategoryBtn(true);
      action = "updateCategory";
    }else if(actionCommand.equals("deleteCategory")){
      this.checkCategoryBtn(true);
      action = "deleteCategory";
    }else if(actionCommand.equals("okCategory")){
      //取得类别的值
      String categoryIdStr = jTextField1.getText();
      String parentIdStr = jTextField2.getText();
      int parentId = Integer.parseInt(parentIdStr);
      String categoryName = jTextField3.getText().trim();
      String categoryDescription = jTextArea1.getText().trim();
      if(action.equals("createCategory") || action.equals("updateCategory")){
        if(categoryName.length() == 0){
          JOptionPane.showMessageDialog(null, "商品类别名称不能为空.");
          return;
        }
      }
      if(action.equals("createCategory")){
        int result = stockManagementData.createGoodsCategory(parentId,
            categoryName, categoryDescription);
        if(result == 1){
          //重新取得类别数据
          this.showAllCategories();
        }else{
          JOptionPane.showMessageDialog(null, "创建类别(" + categoryName + ")失败.");
        }
      }else if(action.equals("updateCategory")){
        int categoryId = Integer.parseInt(categoryIdStr);
        int result = stockManagementData.updateGoodsCategory(categoryId, parentId,
            categoryName, categoryDescription);
        if(result == 1){
          //取得当前选择项的位置
          int selectedIndex = jList1.getSelectedIndex();
          //重新取得类别数据
          this.showAllCategories();
          jList1.setSelectedIndex(selectedIndex);
        }else{
          JOptionPane.showMessageDialog(null, "创建类别(" + categoryName + ")失败.");
        }
      }else if(action.equals("deleteCategory")){
        int categoryId = Integer.parseInt(categoryIdStr);
        int result = stockManagementData.deleteGoodsCategory(categoryId);
        if(result == 1){
          //重新取得类别数据
          this.showAllCategories();
        }else{
          JOptionPane.showMessageDialog(null, "删除类别(" + categoryName + ")失败，"
                                        + "请检查该类别是否有商品数据.");
        }
      }
      this.checkCategoryBtn(false);
    }else if(actionCommand.equals("cancelCategory")){
      this.jList1_valueChanged(null);
      this.checkCategoryBtn(false);
    }else if(actionCommand.equals("search")){
      //取得查询编辑框的内容
      String searchValue = jTextField4.getText().trim();
      //取得查询选项
      int selectedIndex = jComboBox1.getSelectedIndex();
      if(searchValue.length() == 0){
        JOptionPane.showMessageDialog(null, "请输入查询值");
        return;
      }
      switch (selectedIndex) {
        case 0:
          goods = stockManagementData.getGoodsByGoodsBarCode(searchValue);
          this.showSearchGoods();
          break;
        case 1:
          goods = stockManagementData.getGoodsByGoodsName(searchValue);
          this.showSearchGoods();
          break;
        case 2:
          goods = stockManagementData.getGoodsByProducer(searchValue);
          this.showSearchGoods();
          break;
      }
    }else if(actionCommand.equals("createGoods")){
      this.checkGoodBtn(true);
      this.clearGood();
      action = "createGoods";
    }else if(actionCommand.equals("updateGoods")){
      this.checkGoodBtn(true);
      action = "updateGoods";
    }else if(actionCommand.equals("deleteGoods")){
      this.checkGoodBtn(true);
      action = "deleteGoods";
    }else if(actionCommand.equals("okGoods")){
      //取得商品的值
      String goodsBarCode = jTextField5.getText().trim();
      String categoryIdStr = jTextField6.getText().trim();
      int categoryId = 0;
      String goodsName = jTextField7.getText().trim();
      String goodsNickName = jTextField8.getText().trim();
      String goodsAssistantName = jTextField9.getText().trim();
      String goodsPYName = jTextField10.getText().trim();
      String unit = jTextField11.getText().trim();
      String specification = jTextField12.getText().trim();
      String producer = jTextField13.getText().trim();
      if(action.equals("createGoods") || action.equals("updateGoods")){
        if (goodsBarCode.length() == 0 | goodsName.length() == 0 |
            categoryIdStr.length() == 0) {
          JOptionPane.showMessageDialog(null, "商品条形码、商品名称、商品分类标识不能为空.");
          return;
        }
        if(dataMethod.checkInt(categoryIdStr) == 0){
          JOptionPane.showMessageDialog(null, "商品分类标识必须是整数，请检查.");
          return;
        }else{
          categoryId = Integer.parseInt(categoryIdStr);
        }
        //检查商品类别标识与否存在
        boolean isExited = false;
        for(int i = 0; i < categories.length; i++){
          if(categoryId == Integer.parseInt(categories[i][0])){
            isExited = true;
            break;
          }
        }
        if(!isExited){
          JOptionPane.showMessageDialog(null, "该类别标识不存在，请检查相应的类别标识");
          return;
        }
      }
      if(action.equals("createGoods")){
        //创建商品
        int result = stockManagementData.createGoods(goodsBarCode, categoryId,
            goodsName, goodsNickName, goodsAssistantName, goodsPYName, unit,
            specification, producer, 0, 0, 0, 1);
        if(result == 1){
          //添加商品列表框的数据
          listData2.addElement(goodsBarCode);
          //更改商品数组的数据
          String[][] tempStrs = new String[goods.length + 1][13];
          System.arraycopy(goods, 0, tempStrs, 0, goods.length);
          tempStrs[goods.length][0] = goodsBarCode;
          tempStrs[goods.length][1] = categoryIdStr;
          tempStrs[goods.length][2] = goodsName;
          tempStrs[goods.length][3] = goodsNickName;
          tempStrs[goods.length][4] = goodsAssistantName;
          tempStrs[goods.length][5] = goodsPYName;
          tempStrs[goods.length][6] = unit;
          tempStrs[goods.length][7] = specification;
          tempStrs[goods.length][8] = producer;
          tempStrs[goods.length][9] = "0";
          tempStrs[goods.length][10] = "0";
          tempStrs[goods.length][11] = "0";
          tempStrs[goods.length][12] = "1";
          goods = tempStrs;
          //选择新添加的商品
          jList2.setSelectedIndex(goods.length -1);
        }else{
          JOptionPane.showMessageDialog(null, "创建商品(" + goodsName + ")失败.");
        }
      }else if(action.equals("updateGoods")){
        int selectedIndex = jList2.getSelectedIndex();
        //取得商品数组其余4个数据
        int upperLimit = Integer.parseInt(goods[selectedIndex][9]);
        int lowerLimit = Integer.parseInt(goods[selectedIndex][10]);
        double salePrice = Double.parseDouble(goods[selectedIndex][11]);
        double discount = Double.parseDouble(goods[selectedIndex][12]);
        //更新商品
        int result = stockManagementData.updateGoods(goodsBarCode, categoryId,
            goodsName, goodsNickName, goodsAssistantName, goodsPYName, unit,
            specification, producer, upperLimit, lowerLimit, salePrice, discount);
        if(result == 1){
          //更新商品数组
          goods[selectedIndex][1] = categoryIdStr;
          goods[selectedIndex][2] = goodsName;
          goods[selectedIndex][3] = goodsNickName;
          goods[selectedIndex][4] = goodsAssistantName;
          goods[selectedIndex][5] = goodsPYName;
          goods[selectedIndex][6] = unit;
          goods[selectedIndex][7] = specification;
          goods[selectedIndex][8] = producer;
        }else{
          JOptionPane.showMessageDialog(null, "更新商品(" + goodsName + ")失败.");
        }
      }else if(action.equals("deleteGoods")){
        //删除商品
        int result = stockManagementData.deleteGoods(goodsBarCode);
        if(result == 1){
          int selectedIndex = jList2.getSelectedIndex();
          //删除商品列表框的数据
          listData2.removeElementAt(selectedIndex);
          //更改商品数组的数据
          String[][] tempStrs = new String[goods.length -1][13];
          int line = 0;
          for(int i = 0; i < goods.length; i++){
            if(i == selectedIndex){
              continue;
            }else{
              for(int j = 0; j < 13; j++){
                tempStrs[line][j] = goods[i][j];
              }
              line++;
            }
          }
          goods = tempStrs;
          //清空商品编辑框的值
          this.clearGood();
        }else{
          JOptionPane.showMessageDialog(null, "删除类别(" + goodsName + ")失败，"
                                        + "请检查该类别是否有商品数据.");
        }
      }
      this.checkGoodBtn(false);
    }else if(actionCommand.equals("cancelGoods")){
      this.jList2_valueChanged(null);
      this.checkGoodBtn(false);
    }else if(actionCommand.equals("exit")){
      exit();
    }
  }
  //列表1的选择事件
  void jList1_valueChanged(ListSelectionEvent e) {
    if(listData1.size() > 0){
      this.showCategory();
    }else{
      this.clearCategory();
    }
  }
  //列表2的选择事件
  void jList2_valueChanged(ListSelectionEvent e) {
    if(listData2.size() > 0){
      this.showGood();
    }else{
      this.clearGood();
    }
  }
}
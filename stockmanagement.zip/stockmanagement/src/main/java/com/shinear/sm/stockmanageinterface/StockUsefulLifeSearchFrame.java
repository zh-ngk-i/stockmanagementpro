﻿package com.shinear.sm.stockmanageinterface;

import java.awt.*;
import java.awt.event.*;
import javax.swing.event.*;
import javax.swing.*;
import java.util.*;
import com.shinear.sm.data.*;
import com.shinear.sm.maininterface.*;
import com.shinear.sm.user.*;
import com.shinear.sm.method.*;

public class StockUsefulLifeSearchFrame extends JFrame implements ActionListener {
  JPanel contentPane;
  //创建标签控件
  JLabel jLabel1 = new JLabel();
  JLabel jLabel2 = new JLabel();
  //创建按钮控件
  JButton jButton1 = new JButton();
  //创建编辑框控件
  JTextField jTextField1 = new JTextField();
  JTextField jTextField2 = new JTextField();
  //创建滚动框控件
  JScrollPane jScrollPane1 = new JScrollPane();
  //创建列表框数据类和列表框控件
  DefaultListModel listData1 = new DefaultListModel();
  //创建表格控件
  JTable jTable1 = new JTable();
  //创建表格模式类
  StockManagementTableModel smTableModel = new StockManagementTableModel();
  //创建标题数组
  String[] colNames = {"商品条形码", "仓库", "进货价", "数量",  "金额", "有效期"};
  //创建字体类
  Font dialog13 = new java.awt.Font("Dialog", 0, 13);
  //声明数据类
  StockManagementData stockManagementData = null;
  //声明用户类
  User user = null;
  //声明主窗口类
  StockManagementMainFrame stockManagementMainFrame = null;
  //创建库存商品数组
  String[][] stockGoodsArray = new String[0][6];
  //创建帐套日期字符串
  String ledgerDate = "";
  //创建方法类
  DataMethod dataMethod = new DataMethod();

  public StockUsefulLifeSearchFrame(StockManagementMainFrame stockManagementMainFrame) {
    this.stockManagementMainFrame = stockManagementMainFrame;
    //取得主窗口的数据类
    stockManagementData = stockManagementMainFrame.getStockManagementData();
    //取得主窗口的用户类
    user = stockManagementMainFrame.getUser();
    //取得主窗口的账套日期
    ledgerDate = stockManagementMainFrame.getLedgerDate();
    //取得库存模块的用户权限
    int stockManageFunction = user.getStockManageFunction();
    //检查用户权限
    if ( (stockManageFunction & 512) != 512) {
      JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
      System.exit(0);
    }
    //检查账套日期
    if(ledgerDate.length() == 0){
      JOptionPane.showMessageDialog(null, user.getUserName() + "请选择账套.");
      return;
    }
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception  {
    contentPane = (JPanel) this.getContentPane();
    contentPane.setLayout(null);
    this.setSize(new Dimension(667, 375));
    this.setTitle("商品有效期查询窗口");
    //设置标签的属性
    jLabel1.setText("查询日期");
    jLabel1.setBounds(new Rectangle(27, 24, 78, 16));
    jLabel2.setText("总金额");
    jLabel2.setBounds(new Rectangle(490, 24, 76, 16));
    //设置编辑框的属性
    jTextField1.setBounds(new Rectangle(101, 24, 114, 22));
    jTextField2.setEditable(false);
    jTextField2.setBounds(new Rectangle(550, 24, 80, 22));
    //设置按钮的属性
    jButton1.setText("查询");
    jButton1.setActionCommand("search");
    jButton1.setBounds(new Rectangle(244, 24, 63, 25));
    //设置滚动框的属性
    jScrollPane1.setBounds(new Rectangle(27, 62, 603, 229));
    jScrollPane1.getViewport().add(jTable1, null);
    //为面板加入各个控件
    contentPane.add(jLabel1, null);
    contentPane.add(jLabel2, null);
    contentPane.add(jTextField1, null);
    contentPane.add(jTextField2, null);
    contentPane.add(jButton1, null);
    contentPane.add(jScrollPane1, null);
    //设置窗口类的字体和为按钮加入动作接收器
    setupFontAndListener();
  }
  //设置窗口类的字体和为按钮加入动作接收器的方法
  public void setupFontAndListener(){
    Component[] components = contentPane.getComponents();
    //创建临时按钮控件
    JButton tmpBtn = new JButton();
    for(int i = 0; i < components.length; i++){
      components[i].setFont(dialog13);
      if(components[i].getClass().getName().equals("javax.swing.JButton")){
        tmpBtn = (JButton)components[i];
        tmpBtn.addActionListener(this);
      }
    }
  }
  //退出方法
  public void exit(){
    //隐藏窗口
    this.setVisible(false);
    //清空数组的内容
    stockGoodsArray = new String[0][6];
    //清空列表框的内容
    listData1.clear();
    //清空表格的内容
    this.showTableData(stockGoodsArray);
    //清空编辑框的内容
    jTextField1.setText("");
    jTextField2.setText("");
  }
  //设置用户的方法
  public void setUser(User user) {
    this.user = user;
  }
  //设置账套的方法
  public void setLedgerDate(String ledgerDate) {
    this.ledgerDate = ledgerDate;
  }
  protected void processWindowEvent(WindowEvent e) {
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      exit();
    }
  }
  //显示表格内容的方法
  public void showTableData(Object[][] detail){
    //设置表格的标题
    smTableModel.setColumnNames(colNames);
    //设置表格的数据
    smTableModel.setData(detail);
    jTable1 = new JTable(smTableModel);
    //设置表格的字体
    jTable1.setFont(dialog13);
    //将数据表格加入数据滚动框
    jScrollPane1.getViewport().add(jTable1, null);
    //设置列的宽度
    jTable1.getColumnModel().getColumn(0).setPreferredWidth(30);
    jTable1.getColumnModel().getColumn(1).setPreferredWidth(20);
    jTable1.getColumnModel().getColumn(2).setPreferredWidth(20);
    jTable1.getColumnModel().getColumn(3).setPreferredWidth(20);
    jTable1.getColumnModel().getColumn(4).setPreferredWidth(20);
    jTable1.getColumnModel().getColumn(5).setPreferredWidth(50);
  }
  //计算金额方法
  public void recountGoodsAmount(){
    double amount = 0;
    double total = 0;
    for(int i = 0; i < stockGoodsArray.length; i++){
      //整理数据
      stockGoodsArray[i][2] = String.valueOf(dataMethod.round(Double.
          parseDouble(stockGoodsArray[i][2])));
      stockGoodsArray[i][4] = String.valueOf(dataMethod.round(Double.
          parseDouble(stockGoodsArray[i][4])));
      //取得单个记录金额
      amount = Double.parseDouble(stockGoodsArray[i][4]);
      total += amount;
    }
    jTextField2.setText(String.valueOf(dataMethod.round(total)));
  }
  public void search(){
    String searchValue = jTextField1.getText().trim();
    if (searchValue.length() == 0) {
      JOptionPane.showMessageDialog(null, "请输入查询值");
      return;
    }
    java.sql.Date date = dataMethod.transferShortDate(searchValue);
    if(date == null){
      JOptionPane.showMessageDialog(null, "日期输入错误，正确的日期格式是"
                                      + "yyyy-mm-dd（年-月-日），如2004-1-1");
      return;
    }
    //查询过期商品
    stockGoodsArray = stockManagementData.getStockByUsefulLife(ledgerDate, searchValue, 2);
    //显示表格数据
    this.showTableData(stockGoodsArray);
    //显示总金额
    this.recountGoodsAmount();
  }
  //单击事件
  public void actionPerformed(ActionEvent e) {
    //取得按钮的动作字符串
    String actionCommand = e.getActionCommand().trim();
    if (actionCommand.equals("search")) {
      search();
    }
  }
}
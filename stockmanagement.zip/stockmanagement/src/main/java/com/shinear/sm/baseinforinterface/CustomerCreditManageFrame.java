﻿package com.shinear.sm.baseinforinterface;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import com.shinear.sm.data.*;
import com.shinear.sm.maininterface.*;
import com.shinear.sm.user.*;
import com.shinear.sm.method.*;

public class CustomerCreditManageFrame extends JFrame implements ActionListener{
  JPanel contentPane;
  //创建滚动框
  JScrollPane jScrollPane1 = new JScrollPane();
  //创建列表框数据类和列表框控件
  DefaultListModel listData1 = new DefaultListModel();
  JList jList1 = new JList(listData1);
  //创建下拉列表框控件
  JComboBox jComboBox1 = new JComboBox();
  //创建标签控件
  JLabel jLabel1 = new JLabel();
  JLabel jLabel2 = new JLabel();
  JLabel jLabel3 = new JLabel();
  JLabel jLabel4 = new JLabel();
  JLabel jLabel5 = new JLabel();
  //创建编辑框控件
  JTextField jTextField1 = new JTextField();
  JTextField jTextField2 = new JTextField();
  JTextField jTextField3 = new JTextField();
  //创建按钮控件
  JButton jButton1 = new JButton();
  JButton jButton2 = new JButton();
  JButton jButton3 = new JButton();
  JButton jButton4 = new JButton();
  JButton jButton5 = new JButton();
  JButton jButton6 = new JButton();
  //创建字体类
  Font dialog13 = new java.awt.Font("Dialog", 0, 13);
  //声明数据类
  StockManagementData stockManagementData = null;
  //声明用户类
  User user = null;
  //声明主窗口类
  StockManagementMainFrame stockManagementMainFrame = null;
  //创建客户数组
  String[][] customer = new String[0][17];
  //创建方法类
  DataMethod dataMethod = new DataMethod();

  public CustomerCreditManageFrame(StockManagementMainFrame stockManagementMainFrame) {
    this.stockManagementMainFrame = stockManagementMainFrame;
    //取得主窗口的数据类
    stockManagementData = stockManagementMainFrame.getStockManagementData();
    //取得主窗口的用户类
    user = stockManagementMainFrame.getUser();
    //取得基础信息模块的用户权限
    int baseInforFunction = user.getBaseInforFunction();
    //检查用户权限
    if((baseInforFunction & 128) != 128){
      JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
      System.exit(0);
    }
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception  {
    contentPane = (JPanel) this.getContentPane();
    contentPane.setLayout(null);
    this.setSize(new Dimension(484, 340));
    this.setTitle("客户信用管理窗口");
    //设置标签控件属性
    jLabel1.setText("客户列表：");
    jLabel1.setBounds(new Rectangle(24, 21, 78, 16));
    jLabel2.setText("查询条件");
    jLabel2.setBounds(new Rectangle(202, 49, 67, 16));
    jLabel3.setText("查询值");
    jLabel3.setBounds(new Rectangle(205, 99, 47, 16));
    jLabel4.setText("客户名字");
    jLabel4.setBounds(new Rectangle(203, 150, 70, 16));
    jLabel5.setText("信用额度");
    jLabel5.setBounds(new Rectangle(202, 200, 65, 16));
    //设置编辑框控件属性
    jTextField1.setBounds(new Rectangle(278, 150, 174, 22));
    jTextField1.setEditable(false);
    jTextField2.setBounds(new Rectangle(278, 200, 63, 22));
    jTextField3.setBounds(new Rectangle(278, 99, 100, 22));
    //设置按钮控件属性
    jButton1.setText("查询");
    jButton1.setActionCommand("search");
    jButton1.setBounds(new Rectangle(384, 99, 68, 25));
    jButton2.setText("显示信用客户");
    jButton2.setActionCommand("showCreditCustomer");
    jButton2.setBounds(new Rectangle(24, 239, 116, 25));
    jButton3.setText("修改信用额度");
    jButton3.setActionCommand("updateCreditLimit");
    jButton3.setBounds(new Rectangle(142, 239, 117, 25));
    jButton4.setText("确定");
    jButton4.setActionCommand("ok");
    jButton4.setEnabled(false);
    jButton4.setBounds(new Rectangle(262, 239, 62, 25));
    jButton5.setText("取消");
    jButton5.setEnabled(false);
    jButton5.setActionCommand("cancel");
    jButton5.setBounds(new Rectangle(326, 239, 62, 25));
    jButton6.setText("退出");
    jButton6.setActionCommand("exit");
    jButton6.setBounds(new Rectangle(390, 239, 62, 25));
    //设置下拉列表框
    jComboBox1.setBounds(new Rectangle(278, 49, 174, 22));
    jComboBox1.addItem("按客户名字查询");
    jComboBox1.addItem("按地区查询");
    //设置滚动框控件属性
    jScrollPane1.setBounds(new Rectangle(24, 49, 166, 167));
    jScrollPane1.getViewport().add(jList1, null);
    //为列表框加入选择接收器
    jList1.addListSelectionListener(new ListSelectionListener() {
      public void valueChanged(ListSelectionEvent e) {
        jList1_valueChanged(e);
      }
    });
    //为面板加入控件
    contentPane.add(jLabel1, null);
    contentPane.add(jLabel2, null);
    contentPane.add(jLabel3, null);
    contentPane.add(jLabel4, null);
    contentPane.add(jLabel5, null);
    contentPane.add(jScrollPane1, null);
    contentPane.add(jComboBox1, null);
    contentPane.add(jTextField1, null);
    contentPane.add(jTextField2, null);
    contentPane.add(jTextField3, null);
    contentPane.add(jButton1, null);
    contentPane.add(jButton2, null);
    contentPane.add(jButton3, null);
    contentPane.add(jButton4, null);
    contentPane.add(jButton5, null);
    contentPane.add(jButton6, null);
    //设置窗口类的字体和为按钮加入动作接收器
    setupFontAndListener();
  }
  //设置窗口类的字体和为按钮加入动作接收器的方法
  public void setupFontAndListener(){
    Component[] components = contentPane.getComponents();
    //创建临时按钮控件
    JButton tmpBtn = new JButton();
    for(int i = 0; i < components.length; i++){
      components[i].setFont(dialog13);
      if(components[i].getClass().getName().equals("javax.swing.JButton")){
        tmpBtn = (JButton)components[i];
        tmpBtn.addActionListener(this);
      }
    }
  }
  //退出方法
  public void exit(){
    //隐藏窗口
    this.setVisible(false);
    //清空数组的内容
    customer = new String[0][17];
    //清空列表框的内容
    listData1.clear();
    //取得面板上的所有控件
    Component[] components = contentPane.getComponents();
    //创建临时编辑框控件
    JTextField tmpTextField = new JTextField();
    for(int i = 0; i < components.length; i++){
      components[i].setFont(dialog13);
      if(components[i].getClass().getName().equals("javax.swing.JTextField")){
        tmpTextField = (JTextField)components[i];
        //清空编辑框的内容
        tmpTextField.setText("");
      }
    }
  }
  //显示查询客户的方法
  public void showSearchCustomer(){
    listData1.clear();
    //为客户列表框加入客户数据
    for(int i = 0; i < customer.length; i++){
      listData1.addElement(customer[i][0]);
    }
  }
  //显示单个客户的方法
  public void showCustomer(){
    //取得当前选择项的位置
    int selectedIndex = jList1.getSelectedIndex();
    //当列表框不处于选择状态，不显示商品数据
    if(selectedIndex == -1){
       return;
    }
    //显示客户的数据
    jTextField1.setText(customer[selectedIndex][0]);
    jTextField2.setText(customer[selectedIndex][15]);
  }
  //清空单个客户显示的方法
  public void clearCustomer(){
    jTextField1.setText("");
    jTextField2.setText("");
  }
  //设置用户的方法
  public void setUser(User user) {
    this.user = user;
  }
  protected void processWindowEvent(WindowEvent e) {
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      exit();
    }
  }
  //检查按钮的状态
  public void checkBtn(boolean isManipulated){
    if(isManipulated){
      jButton3.setEnabled(false);
      jButton4.setEnabled(true);
      jButton5.setEnabled(true);
    }else{
      jButton3.setEnabled(true);
      jButton4.setEnabled(false);
      jButton5.setEnabled(false);
    }
  }
  //列表1的选择事件
  void jList1_valueChanged(ListSelectionEvent e) {
    if(listData1.size() > 0){
      this.showCustomer();
    }else{
      this.clearCustomer();
    }
  }
  //查询方法
  public void search(){
    //取得查询选项
    int selectedIndex = jComboBox1.getSelectedIndex();
    String searchValue = jTextField3.getText().trim();
    switch (selectedIndex) {
      case 0:
        //根据客户名字取得记录
        customer = stockManagementData.getCustomersByCustomerName(searchValue);
        break;
      case 1:
        //根据地区取得记录
        customer = stockManagementData.getCustomersByCustomerZone(searchValue);
        break;
    }
    this.showSearchCustomer();
  }
  //单击事件方法
  public void actionPerformed(ActionEvent e) {
    //取得按钮的动作字符串
    String actionCommand = e.getActionCommand().trim();
    //单击按钮的处理代码
    if (actionCommand.equals("search")) {
      String searchValue = jTextField3.getText().trim();
      if(searchValue.length() == 0){
        JOptionPane.showMessageDialog(null, "请输入查询值");
        return;
      }
      //查询
      search();
    }else if(actionCommand.equals("showCreditCustomer")){
      customer = stockManagementData.getCreditCustomer();
      this.showSearchCustomer();
    }else if(actionCommand.equals("updateCreditLimit")){
      if(jList1.isSelectionEmpty()){
        JOptionPane.showMessageDialog(null, "请选择客户.");
        return;
      }
      this.checkBtn(true);
    }else if(actionCommand.equals("ok")){
      //取得客户的名字和信用额度
      String customerName = jTextField1.getText().trim();
      String creditLimitStr = jTextField2.getText().trim();
      if(dataMethod.checkNumLargerThan0(creditLimitStr) == 0){
        JOptionPane.showMessageDialog(null, "客户的信用额度必须大于等于0.");
        return;
      }
      double creditlimit = Double.parseDouble(creditLimitStr);
      //更新客户信用额度
      int result = stockManagementData.setCreditCustomer(customerName, creditlimit);
      if (result == 1) {
        //更新数组的客户信用额度
        int selectedIndex = jList1.getSelectedIndex();
        customer[selectedIndex][15] = creditLimitStr;
      } else {
        JOptionPane.showMessageDialog(null, "客户信用额度更新失败.");
      }
      this.checkBtn(false);
    }else if(actionCommand.equals("cancel")){
       this.jList1_valueChanged(null);
       this.checkBtn(false);
    }else if(actionCommand.equals("exit")){
      exit();
    }
  }
}
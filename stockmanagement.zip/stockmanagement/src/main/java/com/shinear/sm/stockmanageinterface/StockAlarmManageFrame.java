﻿package com.shinear.sm.stockmanageinterface;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import com.shinear.sm.data.*;
import com.shinear.sm.maininterface.*;
import com.shinear.sm.user.*;
import com.shinear.sm.method.*;
import java.util.*;

public class StockAlarmManageFrame extends JFrame implements ActionListener {
  JPanel contentPane;
  //创建列表框数据类和列表框控件
  DefaultListModel listData1 = new DefaultListModel();
  JList jList1 = new JList(listData1);
  //创建滚动框控件
  JScrollPane jScrollPane1 = new JScrollPane();
  //创建标签控件
  JLabel jLabel1 = new JLabel();
  JLabel jLabel2 = new JLabel();
  JLabel jLabel3 = new JLabel();
  JLabel jLabel4 = new JLabel();
  JLabel jLabel5 = new JLabel();
  JLabel jLabel6 = new JLabel();
  //创建编辑框控件
  JTextField jTextField1 = new JTextField();
  JTextField jTextField2 = new JTextField();
  JTextField jTextField3 = new JTextField();
  JTextField jTextField4 = new JTextField();
  JTextField jTextField5 = new JTextField();
  JTextField jTextField6 = new JTextField();
  JTextField jTextField7 = new JTextField();
  //创建按钮控件
  JButton jButton1 = new JButton();
  JButton jButton2 = new JButton();
  JButton jButton3 = new JButton();
  JButton jButton4 = new JButton();
  JButton jButton5 = new JButton();
  JButton jButton6 = new JButton();
  JButton jButton7 = new JButton();
  //创建字体类
  Font dialog13 = new java.awt.Font("Dialog", 0, 13);
  //声明数据类
  StockManagementData stockManagementData = null;
  //声明用户类
  User user = null;
  //声明主窗口类
  StockManagementMainFrame stockManagementMainFrame = null;
  //创建商品数组
  String[][] goods = new String[0][13];
  //创建库存数量数组
  String[][] stockQuantity = new String[0][2];
  //创建库存数量数组的商品条形码集合
  Vector stockQuantityVector = new Vector();
  //创建方法类
  DataMethod dataMethod = new DataMethod();
  //创建帐套日期字符串
  String ledgerDate = "";

  public StockAlarmManageFrame(StockManagementMainFrame stockManagementMainFrame) {
    this.stockManagementMainFrame = stockManagementMainFrame;
    //取得主窗口的数据类
    stockManagementData = stockManagementMainFrame.getStockManagementData();
    //取得主窗口的用户类
    user = stockManagementMainFrame.getUser();
    //取得主窗口的账套日期
    ledgerDate = stockManagementMainFrame.getLedgerDate();
    //取得库存模块的用户权限
    int stockManageFunction = user.getStockManageFunction();
    //检查用户权限
    if((stockManageFunction & 256) != 256){
      JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
      System.exit(0);
    }
    //检查账套日期
    if(ledgerDate.length() == 0){
      JOptionPane.showMessageDialog(null, "请选择账套.");
      return;
    }
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception  {
    contentPane = (JPanel) this.getContentPane();
    contentPane.setLayout(null);
    this.setSize(new Dimension(643, 346));
    this.setTitle("库存警告管理窗口");
    //设置标签控件属性
    jLabel1.setText("商品条形码");
    jLabel1.setBounds(new Rectangle(227, 59, 84, 16));
    jLabel2.setText("商品名称");
    jLabel2.setBounds(new Rectangle(418, 59, 67, 16));
    jLabel3.setText("库存最大值");
    jLabel3.setBounds(new Rectangle(227, 133, 78, 16));
    jLabel4.setText("库存最小值");
    jLabel4.setBounds(new Rectangle(418, 133, 78, 16));
    jLabel5.setText("库存数量");
    jLabel5.setBounds(new Rectangle(227, 207, 78, 16));
    jLabel6.setText("库存状态");
    jLabel6.setBounds(new Rectangle(418, 207, 78, 16));
    //设置编辑框控件属性
    jTextField1.setBounds(new Rectangle(36, 30, 90, 22));
    jTextField2.setEditable(false);
    jTextField2.setBounds(new Rectangle(300, 59, 106, 22));
    jTextField3.setEditable(false);
    jTextField3.setBounds(new Rectangle(487, 59, 106, 22));
    jTextField4.setBounds(new Rectangle(300, 133, 106, 22));
    jTextField5.setBounds(new Rectangle(487, 133, 106, 22));
    jTextField6.setEditable(false);
    jTextField6.setBounds(new Rectangle(300, 207, 106, 22));
    jTextField7.setBounds(new Rectangle(487, 207, 106, 22));
    jTextField7.setEditable(false);
    //设置按钮属性
    jButton1.setText("查询");
    jButton1.setActionCommand("search");
    jButton1.setBounds(new Rectangle(134, 30, 77, 25));
    jButton2.setText("显示全部商品");
    jButton2.setActionCommand("showAllGoods");
    jButton2.setBounds(new Rectangle(36, 253, 130, 25));
    jButton3.setText("显示异常库存状态商品");
    jButton3.setActionCommand("showUnusalGoods");
    jButton3.setBounds(new Rectangle(168, 253, 173, 25));
    jButton4.setText("修改");
    jButton4.setActionCommand("update");
    jButton4.setBounds(new Rectangle(343, 253, 61, 25));
    jButton5.setText("确定");
    jButton5.setActionCommand("ok");
    jButton5.setEnabled(false);
    jButton5.setBounds(new Rectangle(406, 253, 61, 25));
    jButton6.setText("取消");
    jButton6.setActionCommand("cancel");
    jButton6.setEnabled(false);
    jButton6.setBounds(new Rectangle(469, 253, 61, 25));
    jButton7.setText("退出");
    jButton7.setActionCommand("exit");
    jButton7.setBounds(new Rectangle(532, 253, 61, 25));
    //设置滚动框的属性
    jScrollPane1.setBounds(new Rectangle(36, 59, 175, 170));
    jScrollPane1.getViewport().add(jList1, null);
    //为列表框加入选择接收器
    jList1.addListSelectionListener(new ListSelectionListener() {
      public void valueChanged(ListSelectionEvent e) {
        jList1_valueChanged(e);
      }
    });
    contentPane.add(jLabel1, null);
    contentPane.add(jLabel2, null);
    contentPane.add(jLabel3, null);
    contentPane.add(jLabel4, null);
    contentPane.add(jLabel5, null);
    contentPane.add(jLabel6, null);
    contentPane.add(jTextField1, null);
    contentPane.add(jTextField2, null);
    contentPane.add(jTextField3, null);
    contentPane.add(jTextField4, null);
    contentPane.add(jTextField5, null);
    contentPane.add(jTextField6, null);
    contentPane.add(jTextField7, null);
    contentPane.add(jButton1, null);
    contentPane.add(jButton2, null);
    contentPane.add(jButton3, null);
    contentPane.add(jButton4, null);
    contentPane.add(jButton5, null);
    contentPane.add(jButton6, null);
    contentPane.add(jButton7, null);
    contentPane.add(jScrollPane1, null);
    //设置窗口类的字体和为按钮加入动作接收器
    setupFontAndListener();
  }
  //设置窗口类的字体和为按钮加入动作接收器的方法
  public void setupFontAndListener(){
    Component[] components = contentPane.getComponents();
    //创建临时按钮控件
    JButton tmpBtn = new JButton();
    for(int i = 0; i < components.length; i++){
      components[i].setFont(dialog13);
      if(components[i].getClass().getName().equals("javax.swing.JButton")){
        tmpBtn = (JButton)components[i];
        tmpBtn.addActionListener(this);
      }
    }
  }
  //显示全部商品的方法
  public void showAllGoods(){
    //取得商品数据全部条形码的值,该方法参考6.8节
    goods = stockManagementData.getGoodsByGoodsBarCode("");
    stockQuantityVector.clear();
    //取得库存数量
    stockQuantity = stockManagementData.getStocktakeQuantityByWarehouse(ledgerDate, "", 2);
    //将商品条形码加入集合类内
    for(int i = 0; i < stockQuantity.length; i++){
      stockQuantityVector.add(stockQuantity[i][0]);
    }
  }
  //显示异常商品的方法
  public void showUnusalGoods(){
    if(listData1.isEmpty()){
      this.showAllGoods();
    }
    Vector vector = new Vector();
    for(int i = 0; i < goods.length; i++){
      int max = 0;
      int min = 0;
      int quantity = 0;
      String goodsBarcode = goods[i][0];
      max = Integer.parseInt(goods[i][9]);
      min = Integer.parseInt(goods[i][10]);
      //取得库存数
      int searchPos = stockQuantityVector.indexOf(goodsBarcode);
      if(searchPos != -1){
        quantity = Integer.parseInt(stockQuantity[searchPos][1]);
      }
      if(quantity > max | quantity < min){
        //增加异常库存商品
        vector.add(String.valueOf(i));
      }
    }
    //创建临时商品数组
    String[][] tempGoods = new String[vector.size()][13];
    int line = 0;
    //取得异常商品的值
    for(int i = 0; i < goods.length; i++){
      if(vector.indexOf(String.valueOf(i)) != -1){
        for(int j = 0; j < 13; j++){
          tempGoods[line][j] = goods[i][j];
        }
        line++;
      }
    }
    goods = tempGoods;
  }
  public void showListData(){
    //重新显示列表框的数据
    listData1.clear();
    //为列表框加入数据
    for(int i = 0; i < goods.length; i++){
      listData1.addElement(goods[i][0]);
    }
  }
  //显示单个商品的方法
  public void showGoods(){
    //取得当前选择项的位置
    int selectedIndex = jList1.getSelectedIndex();
    //当列表框不处于选择状态，不显示商品数据
    if(selectedIndex == -1){
       return;
    }
    //显示商品条形码
    jTextField2.setText(goods[selectedIndex][0]);
    //显示商品名称
    jTextField3.setText(goods[selectedIndex][2]);
    //显示库存最大数
    int max = Integer.parseInt(goods[selectedIndex][9]);
    jTextField4.setText(goods[selectedIndex][9]);
    //显示库存最小数
    int min = Integer.parseInt(goods[selectedIndex][10]);
    jTextField5.setText(goods[selectedIndex][10]);
    int quantity = 0;
    //显示库存数
    int searchPos = stockQuantityVector.indexOf(goods[selectedIndex][0]);
    if(searchPos != -1){
      jTextField6.setText(stockQuantity[searchPos][1]);
      quantity = Integer.parseInt(stockQuantity[searchPos][1]);
    }else{
      jTextField6.setText("0");
    }
    if(quantity > max | quantity < min){
      jTextField7.setText("异常");
    }else{
      jTextField7.setText("正常");
    }
  }
  //清空单个商品显示的方法
  public void clearGoods(){
    jTextField2.setText("");
    jTextField3.setText("");
    jTextField4.setText("");
    jTextField5.setText("");
    jTextField6.setText("");
    jTextField7.setText("");
  }
  //退出方法
  public void exit(){
    //隐藏窗口
    this.setVisible(false);
    //清空数组的内容
    goods = new String[0][13];
    stockQuantity = new String[0][2];
    //清空列表框的内容
    listData1.clear();
    //取得面板上的所有控件
    Component[] components = contentPane.getComponents();
    //创建临时文本框控件
    JTextField tmpTextField = new JTextField();
    for(int i = 0; i < components.length; i++){
      if(components[i].getClass().getName().equals("javax.swing.JTextField")){
        tmpTextField = (JTextField)components[i];
        //清空编辑框的内容
        tmpTextField.setText("");
      }
    }
  }
  //设置用户的方法
  public void setUser(User user) {
    this.user = user;
  }
  //设置账套的方法
  public void setLedgerDate(String ledgerDate) {
    this.ledgerDate = ledgerDate;
  }
  //检查商品按钮的状态
  public void checkGoodsBtn(boolean isManipulated){
    if(isManipulated){
      jButton4.setEnabled(false);
      jButton5.setEnabled(true);
      jButton6.setEnabled(true);
    }else{
      jButton4.setEnabled(true);
      jButton5.setEnabled(false);
      jButton6.setEnabled(false);
    }
  }
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      exit();
    }
  }
  //列表1的选择事件
  void jList1_valueChanged(ListSelectionEvent e) {
    if(listData1.size() > 0){
      this.showGoods();
    }else{
      this.clearGoods();
    }
  }
  public void search(){
    String searchValue = jTextField1.getText().trim();
    if (searchValue.length() == 0) {
      JOptionPane.showMessageDialog(null, "请输入查询值");
      return;
    }
    jList1.setSelectedIndex(listData1.indexOf(searchValue));
  }
  //单击事件
  public void actionPerformed(ActionEvent e) {
    //取得按钮的动作字符串
    String actionCommand = e.getActionCommand().trim();
    //单击按钮的处理代码
    if(actionCommand.equals("search")){
      search();
    }else if(actionCommand.equals("showAllGoods")){
      this.showAllGoods();
      this.showListData();
    }else if(actionCommand.equals("showUnusalGoods")){
      this.showUnusalGoods();
      this.showListData();
    }else if(actionCommand.equals("update")){
      //进行库存最大、最小值修改时检查商品的选择状态
      if (jList1.isSelectionEmpty()) {
        JOptionPane.showMessageDialog(null, "请选择商品.");
        return;
      }
      this.checkGoodsBtn(true);
    }else if(actionCommand.equals("ok")){
      //取得商品条形码、最大库存、最小库存
      String goodsBarCode = jTextField2.getText().trim();
      String maxStr = jTextField4.getText().trim();
      String minStr = jTextField5.getText().trim();
      int max = 0;
      int min = 0;
      if(dataMethod.checkInt(maxStr) == 0 | dataMethod.checkInt(minStr) == 0){
        JOptionPane.showMessageDialog(null, "库存的最大、最小数必须为整数.");
        return;
      }else{
        max = Integer.parseInt(maxStr);
        min = Integer.parseInt(minStr);
      }
      int selectedIndex = jList1.getSelectedIndex();
      //更新商品数组的最大、最小库存
      int result = stockManagementData.updateGoods(goods[selectedIndex][0],
          Integer.parseInt(goods[selectedIndex][1]), goods[selectedIndex][2],
          goods[selectedIndex][3], goods[selectedIndex][4], goods[selectedIndex][5],
          goods[selectedIndex][6], goods[selectedIndex][7], goods[selectedIndex][8],
          max, min,           //库存最大值、最小值
          Double.parseDouble(goods[selectedIndex][11]),
          Double.parseDouble(goods[selectedIndex][12]));
      if(result == 1){
        //更新商品数组
        goods[selectedIndex][9] = maxStr;
        goods[selectedIndex][10] = minStr;
        JOptionPane.showMessageDialog(null, "商品库存的最大值、最小值更改成功.");
      }else{
        JOptionPane.showMessageDialog(null, "商品库存的最大值、最小值更改失败.");
      }
      this.checkGoodsBtn(false);
    }else if(actionCommand.equals("cancel")){
      this.jList1_valueChanged(null);
      this.checkGoodsBtn(false);
    }else if(actionCommand.equals("exit")){
      exit();
    }
  }
}
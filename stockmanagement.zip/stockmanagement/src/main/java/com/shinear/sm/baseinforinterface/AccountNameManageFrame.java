﻿package com.shinear.sm.baseinforinterface;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.tree.*;
import javax.swing.event.*;
import com.shinear.sm.data.*;
import com.shinear.sm.maininterface.*;
import com.shinear.sm.user.*;
import com.shinear.sm.method.*;
import java.util.*;

public class AccountNameManageFrame extends JFrame  implements ActionListener{
  JPanel contentPane;
  //创建滚动框
  JScrollPane jScrollPane1 = new JScrollPane();
  //创建根节点、结构树数据类、结构树控件
  DefaultMutableTreeNode root = new DefaultMutableTreeNode("0、会计科目");;
  DefaultTreeModel treeModel = new DefaultTreeModel(root);
  JTree jTree1 = new JTree(treeModel);
  //创建标签控件
  JLabel jLabel1 = new JLabel();
  JLabel jLabel2 = new JLabel();
  JLabel jLabel3 = new JLabel();
  JLabel jLabel4 = new JLabel();
  JLabel jLabel5 = new JLabel();
  //创建编辑框控件
  JTextField jTextField1 = new JTextField();
  JTextField jTextField2 = new JTextField();
  JTextField jTextField3 = new JTextField();
  JTextField jTextField4 = new JTextField();
  //创建按钮控件
  JButton jButton1 = new JButton();
  JButton jButton2 = new JButton();
  JButton jButton3 = new JButton();
  JButton jButton4 = new JButton();
  JButton jButton5 = new JButton();
  JButton jButton6 = new JButton();
  JButton jButton7 = new JButton();
  JButton jButton8 = new JButton();
  //创建字体类
  Font dialog13 = new java.awt.Font("Dialog", 0, 13);
  //声明数据类
  StockManagementData stockManagementData = null;
  //声明用户类
  User user = null;
  //声明主窗口类
  StockManagementMainFrame stockManagementMainFrame = null;
  //创建会计科目数组
  String[][] accountName = new String[0][3];
  //创建会计科目的序号集合
  Vector accountNameVector = new Vector();
  //创建会计科目树结构集合
  Vector treeAccountNameVector = new Vector();
  //创建动作字符串
  String action = "";
  //创建方法类
  DataMethod dataMethod = new DataMethod();

  public AccountNameManageFrame(StockManagementMainFrame stockManagementMainFrame) {
    this.stockManagementMainFrame = stockManagementMainFrame;
    //取得主窗口的数据类
    stockManagementData = stockManagementMainFrame.getStockManagementData();
    //取得主窗口的用户类
    user = stockManagementMainFrame.getUser();
    //取得基础信息模块的用户权限
    int baseInforFunction = user.getBaseInforFunction();
    //检查用户权限
    if((baseInforFunction & 512) != 512){
      JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
      System.exit(0);
    }
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception  {
    contentPane = (JPanel) this.getContentPane();
    contentPane.setLayout(null);
    this.setSize(new Dimension(620, 421));
    this.setTitle("会计科目数据管理窗口");
    //设置标签控件属性
    jLabel1.setText("会计科目列表：");
    jLabel1.setBounds(new Rectangle(24, 21, 94, 16));
    jLabel2.setText("查询值");
    jLabel2.setBounds(new Rectangle(253, 49, 67, 16));
    jLabel3.setText("序号");
    jLabel3.setBounds(new Rectangle(253, 125, 70, 16));
    jLabel4.setText("父索引");
    jLabel4.setBounds(new Rectangle(253, 200, 70, 16));
    jLabel5.setText("会计科目名字");
    jLabel5.setBounds(new Rectangle(253, 276, 89, 16));
    //设置编辑框控件属性
    jTextField1.setBounds(new Rectangle(348, 49, 159, 22));
    jTextField2.setEditable(false);
    jTextField2.setBounds(new Rectangle(348, 125, 159, 22));
    jTextField3.setBounds(new Rectangle(348, 200, 159, 22));
    jTextField4.setBounds(new Rectangle(348, 276, 159, 22));
    //设置按钮控件属性
    jButton1.setText("查询");
    jButton1.setActionCommand("search");
    jButton1.setBounds(new Rectangle(517, 49, 68, 25));
    jButton2.setText("创建");
    jButton2.setActionCommand("create");
    jButton2.setBounds(new Rectangle(194, 324, 62, 25));
    jButton3.setText("修改");
    jButton3.setActionCommand("update");
    jButton3.setBounds(new Rectangle(260, 324, 62, 25));
    jButton4.setText("删除");
    jButton4.setActionCommand("delete");
    jButton4.setBounds(new Rectangle(326, 324, 62, 25));
    jButton5.setText("确定");
    jButton5.setActionCommand("ok");
    jButton5.setEnabled(false);
    jButton5.setBounds(new Rectangle(391, 324, 62, 25));
    jButton6.setText("取消");
    jButton6.setEnabled(false);
    jButton6.setActionCommand("cancel");
    jButton6.setBounds(new Rectangle(457, 324, 62, 25));
    jButton7.setText("退出");
    jButton7.setActionCommand("exit");
    jButton7.setBounds(new Rectangle(523, 324, 62, 25));
    jButton8.setText("显示会计科目");
    jButton8.setActionCommand("showAll");
    jButton8.setBounds(new Rectangle(23, 324, 167, 25));
    //设置滚动框控件属性
    jScrollPane1.setBounds(new Rectangle(23, 49, 189, 243));
    jScrollPane1.getViewport().add(jTree1, null);
    //为结构树加入选择接收器
    jTree1.addTreeSelectionListener(new TreeSelectionListener() {
      public void valueChanged(TreeSelectionEvent e) {
        jTree1_valueChanged(e);
      }
    });
    /*设置结构树的属性*/
    //定义树一次只能选择一个节点
    jTree1.getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);
    //定义树的线条
    jTree1.putClientProperty("JTree.lineStyle", "Angled");
    //显示总树根的手柄
    jTree1.setShowsRootHandles(true);
    //为面板加入控件
    contentPane.add(jLabel1, null);
    contentPane.add(jLabel2, null);
    contentPane.add(jLabel3, null);
    contentPane.add(jLabel4, null);
    contentPane.add(jLabel5, null);
    contentPane.add(jButton1, null);
    contentPane.add(jButton2, null);
    contentPane.add(jButton3, null);
    contentPane.add(jButton4, null);
    contentPane.add(jButton5, null);
    contentPane.add(jButton6, null);
    contentPane.add(jButton7, null);
    contentPane.add(jButton8, null);
    contentPane.add(jTextField1, null);
    contentPane.add(jTextField2, null);
    contentPane.add(jTextField3, null);
    contentPane.add(jTextField4, null);
    contentPane.add(jScrollPane1, null);
    //取得会计科目数组和显示结构树
    this.showAllAccountName();
    //设置窗口类的字体和为按钮加入动作接收器
    setupFontAndListener();
  }
  //设置窗口类的字体和为按钮加入动作接收器的方法
  public void setupFontAndListener(){
    Component[] components = contentPane.getComponents();
    //创建临时按钮控件
    JButton tmpBtn = new JButton();
    for(int i = 0; i < components.length; i++){
      components[i].setFont(dialog13);
      if(components[i].getClass().getName().equals("javax.swing.JButton")){
        tmpBtn = (JButton)components[i];
        tmpBtn.addActionListener(this);
      }
    }
  }
  //退出方法
  public void exit(){
    //隐藏窗口
    this.setVisible(false);
    //清空数组的内容
    accountName = new String[0][3];
    //清空集合内容
    accountNameVector.clear();
    treeAccountNameVector.clear();
    //取得面板上的所有控件
    Component[] components = contentPane.getComponents();
    //创建临时编辑框控件
    JTextField tmpTextField = new JTextField();
    for(int i = 0; i < components.length; i++){
      if(components[i].getClass().getName().equals("javax.swing.JTextField")){
        tmpTextField = (JTextField)components[i];
        //清空编辑框的内容
        tmpTextField.setText("");
      }
    }
  }
  //取得会计科目数组和显示结构树的方法
  public void showAllAccountName(){
    accountName = stockManagementData.getAllAccountName();
    //清空集合的内容
    accountNameVector.clear();
    treeAccountNameVector.clear();
    for(int i = 0; i < accountName.length; i++){
      accountNameVector.addElement(accountName[i][0]);
    }
    //清空结构树的内容
    root.removeAllChildren();
    //更新结构树的显示
    treeModel.reload();
    //显示结构树的内容
    this.showAccountNameTree(0, root);
    //展开结构树的节点
    this.expandEntireTree(root);
  }
  //展开节点的方法
  public void expandEntireTree(TreeNode node) {
    TreePath treePath = new TreePath( ( (DefaultMutableTreeNode) node).getPath());
    jTree1.expandPath(treePath);
    for (int i = 0; i < node.getChildCount(); i++) {
      expandEntireTree(node.getChildAt(i));
    }
  }
  //通过递归算法显示会计科目结构树的方法
  public void showAccountNameTree(int parentId, DefaultMutableTreeNode parentTreeNode){
    //根据父标识取得会计科目记录
    String[][] tempAccountName = stockManagementData.getAccountNameByParentid(parentId);
    //为会计科目结构树加入会计科目数据
    DefaultMutableTreeNode tempTreeNode = null;
    for(int i = 0; i < tempAccountName.length; i++){
      //创建一个树节点
      tempTreeNode = new DefaultMutableTreeNode(tempAccountName[i][0] + "、" +
                                                tempAccountName[i][2]);
      //为会计科目树结构集合添加记录
      treeAccountNameVector.addElement(tempAccountName[i][2]);
      //为父节点加入树节点
      parentTreeNode.add(tempTreeNode);
      //显示下一级会计科目
      this.showAccountNameTree(Integer.parseInt(tempAccountName[i][0]), tempTreeNode);
    }
  }
  //结构树的选择事件
  public void jTree1_valueChanged(TreeSelectionEvent e) {
    //取得选择的树节点对象
    if(!jTree1.isSelectionEmpty()){
      this.showAccountName();
    }else{
      this.clearAccountName();
    }
  }
  //显示单个会计科目的方法
  public void showAccountName(){
    //取得当前选择节点
    DefaultMutableTreeNode node = (DefaultMutableTreeNode)
        jTree1.getLastSelectedPathComponent();
    String tempStr = (String)node.getUserObject();
    String tempAccountId = tempStr.substring(0, tempStr.indexOf("、"));
    if(Integer.parseInt(tempAccountId) == 0){
      //当选择根节点时，清空编辑框的内容
      this.clearAccountName();
    }else{
      //显示会计科目的数据
      int selectedIndex = accountNameVector.indexOf(tempAccountId);
      jTextField2.setText(accountName[selectedIndex][0]);
      jTextField3.setText(accountName[selectedIndex][1]);
      jTextField4.setText(accountName[selectedIndex][2]);
    }
  }
  //清空单个会计科目显示的方法
  public void clearAccountName(){
    jTextField2.setText("");
    jTextField3.setText("");
    jTextField4.setText("");
  }
  //设置用户的方法
  public void setUser(User user) {
    this.user = user;
  }
  protected void processWindowEvent(WindowEvent e) {
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      exit();
    }
  }
  //检查按钮的状态
  public void checkBtn(boolean isManipulated){
    if(isManipulated){
      jButton2.setEnabled(false);
      jButton3.setEnabled(false);
      jButton4.setEnabled(false);
      jButton5.setEnabled(true);
      jButton6.setEnabled(true);
    }else{
      jButton2.setEnabled(true);
      jButton3.setEnabled(true);
      jButton4.setEnabled(true);
      jButton5.setEnabled(false);
      jButton6.setEnabled(false);
    }
  }
  //查询方法
  public void search(String searchValue){
    //展开结构树的所有树技
    this.expandEntireTree(root);
    String tempAccountName = "";
    //根据查询值选择树选项
    for(int i = 0; i < treeAccountNameVector.size(); i++){
      tempAccountName = (String)treeAccountNameVector.elementAt(i);
      if(tempAccountName.indexOf(searchValue) > -1){
        //1表示根节点的位置
        jTree1.setSelectionRow(i + 1);
        break;
      }
    }
  }
  //单击事件方法
  public void actionPerformed(ActionEvent e) {
    //取得按钮的动作字符串
    String actionCommand = e.getActionCommand().trim();
    if(actionCommand.equals("update") | actionCommand.equals("delete")){
      if(jTree1.isSelectionEmpty()){
        JOptionPane.showMessageDialog(null, "请选择会计科目.");
        return;
      }
    }
    //单击按钮的处理代码
    if (actionCommand.equals("search")) {
      String searchValue = jTextField1.getText().trim();
      if(searchValue.length() == 0){
        JOptionPane.showMessageDialog(null, "请输入查询值");
        return;
      }
      //根据查询值选择树节点
      this.search(searchValue);
    }else if(actionCommand.equals("showAll")){
      //重新取得会计科目数组和显示结构树
      this.showAllAccountName();
    }else if(actionCommand.equals("create")){
      action = "create";
      this.clearAccountName();
      this.checkBtn(true);
    }else if(actionCommand.equals("update")){
      action = "update";
      this.checkBtn(true);
    }else if(actionCommand.equals("delete")){
      action = "delete";
      this.checkBtn(true);
    }else if(actionCommand.equals("ok")){
      //取得会计科目的值
      String accountId = jTextField2.getText().trim();
      String parentIdStr = jTextField3.getText().trim();
      int parentId = 0;
      String accountName = jTextField4.getText().trim();
      if(action.equals("create") | action.equals("update")){
        if(parentIdStr.length() == 0 | accountName.length() == 0){
          JOptionPane.showMessageDialog(null, "父索引和会计科目名字不允许空值.");
          return;
        }
        //检查父索引是否整数
        if(dataMethod.checkInt(parentIdStr) == 0){
          JOptionPane.showMessageDialog(null, "父索引必须是整数.");
          return;
        }else{
          parentId = Integer.parseInt(parentIdStr);
        }
        //检查父索引是否存在
        if(accountNameVector.indexOf(parentIdStr) == -1){
          if(parentId != 0){
            JOptionPane.showMessageDialog(null, "父索引不存在，请检查会计科目的序号.");
            return;
          }
        }
      }
      if(action.equals("create")){
        //创建会计科目
        int result = stockManagementData.createAccountName(parentId, accountName);
        if(result == 1){
          //重新取得会计科目
          this.showAllAccountName();
          //选择新创建的会计科目
          this.search(accountName);
        }else{
          JOptionPane.showMessageDialog(null, "会计科目创建失败,请检查该会计科目"
                                        + "值是否超出字段长度.");
        }
      }else if (action.equals("update")){
        //更新会计科目
        int result = stockManagementData.updateAccountName(Integer.parseInt(
            accountId), parentId, accountName);
        if(result == 1){
          //重新取得会计科目
          this.showAllAccountName();
          //选择更新后的会计科目
          this.search(accountName);
        }else{
          JOptionPane.showMessageDialog(null, "会计科目更新失败.");
        }
      }else if (action.equals("delete")){
        if(accountId.length() == 0){
          JOptionPane.showMessageDialog(null, "请选择会计科目.");
          return;
        }
        //删除会计科目
        int result = stockManagementData.deleteAccountName(Integer.parseInt(accountId));
        if(result == 1){
          //重新取得会计科目
          this.showAllAccountName();
        }else{
          JOptionPane.showMessageDialog(null, "会计科目删除失败.");
        }
      }
      this.checkBtn(false);
    }else if(actionCommand.equals("cancel")){
       this.jTree1_valueChanged(null);
       this.checkBtn(false);
    }else if(actionCommand.equals("exit")){
      exit();
    }
  }
}
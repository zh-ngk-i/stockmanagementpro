﻿package com.shinear.sm.stockmanagementpro;

import javax.ejb.*;
import java.util.*;

public interface SupplierHome extends javax.ejb.EJBLocalHome {
  public Supplier create(String supplierName, String supplierZone, String pyCode, String abbreviation, String companyPhone, String linkman, String mobilePhone, String fax, String fixedPhone, String address, String zipCode, String bankName, String bankAccount, String email, String homesite, String remark) throws CreateException;
  public Collection findBySupplierName(String supplierName) throws FinderException;
  public Collection findBySupplierZone(String supplierZone) throws FinderException;
  public Supplier findByPrimaryKey(String supplierName) throws FinderException;
}
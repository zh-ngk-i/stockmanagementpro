﻿package com.shinear.sm.stockmanagementpro;

import javax.ejb.*;
import java.util.*;

public interface Goods extends javax.ejb.EJBLocalObject {
  public String getGoodsBarCode();
  public void setCategoryId(int categoryId);
  public int getCategoryId();
  public void setGoodsName(String goodsName);
  public String getGoodsName();
  public void setGoodsNickName(String goodsNickName);
  public String getGoodsNickName();
  public void setGoodsAssistantName(String goodsAssistantName);
  public String getGoodsAssistantName();
  public void setGoodsPYName(String goodsPYName);
  public String getGoodsPYName();
  public void setUnit(String unit);
  public String getUnit();
  public void setSpecification(String specification);
  public String getSpecification();
  public void setProducer(String producer);
  public String getProducer();
  public void setUpperLimit(int upperLimit);
  public int getUpperLimit();
  public void setLowerLimit(int lowerLimit);
  public int getLowerLimit();
  public void setSalePrice(double salePrice);
  public double getSalePrice();
  public void setDiscount(double discount);
  public double getDiscount();
}
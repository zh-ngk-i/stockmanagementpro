﻿package com.shinear.sm.baseinforinterface;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.shinear.sm.data.StockManagementData;
import com.shinear.sm.user.User;
import com.shinear.sm.maininterface.*;

public class ViewAuthorityFrame extends JFrame {
  JPanel contentPane;
  //创建标签面板的布局
  GridLayout baseInforGridLayout = new GridLayout();
  GridLayout stockGridLayout = new GridLayout();
  GridLayout stockManageGridLayout = new GridLayout();
  GridLayout saleGridLayout = new GridLayout();
  //创建标签控件
  JLabel jLabel1 = new JLabel();
  JLabel jLabel2 = new JLabel();
  JLabel jLabel3 = new JLabel();
  JLabel jLabel4 = new JLabel();
  //创建标签面板
  JPanel baseInforPanel = new JPanel();
  JPanel stockPanel = new JPanel();
  JPanel stockManagePanel = new JPanel();
  JPanel salePanel = new JPanel();
  //创建基础信息模块的标签和标题数组
  JLabel[] baseInforJLabels = new JLabel[12];
  String[] baseInforJLabelTitles = {"用户管理用户", "数据备份用户", "账套管理用户",
      "商品数据管理用户", "商品折扣管理用户", "供应商数据管理用户", "客户数据管理用户",
      "客户信用管理用户", "仓库数据管理用户", "会计科目管理用户",
      "报表管理用户", "用户日志查看用户"};
  //创建进货模块的标签和标题数组
  JLabel[] stockJLabels = new JLabel[9];
  String[] stockJLabelTitles = {"请购用户", "订购用户", "验收用户",
      "现金管理用户", "现金日记账查看用户", "进货单查询用户", "应付账款查询用户",
      "进货会计分录管理用户", "进货会计分录查看用户"};
  //创建库存模块的标签和标题数组
  JLabel[] stockManageJLabels = new JLabel[12];
  String[] stockManageJLabelTitles = {"商品调出用户", "商品检收用户", "商品调价用户",
      "商品组合管理用户", "库存盘点计数用户", "库存盘点核查用户", "库存商品查询用户",
      "库存单据查询用户", "库存警告设置用户", "商品有效期查询用户", "库存会计分录管理用户",
      "库存会计分录查看用户"};
  //创建销售模块的标签和标题数组
  JLabel[] saleJLabels = new JLabel[7];
  String[] saleJLabelTitles = {"前台销售用户", "信用销售用户", "销售收款用户",
      "销售单查询用户", "应收帐款查询用户", "销售会计分录管理用户", "销售会计分录查看用户"};

  //创建字体类
  Font dialog13 = new java.awt.Font("Dialog", 0, 13);
  //声明数据类
  StockManagementData stockManagementData = null;
  //声明用户类
  User user = null;
  //声明主窗口类
  StockManagementMainFrame stockManagementMainFrame = null;

  public ViewAuthorityFrame(StockManagementMainFrame stockManagementMainFrame) {
    this.stockManagementMainFrame = stockManagementMainFrame;
    //取得主窗口的数据类
    stockManagementData = stockManagementMainFrame.getStockManagementData();
    //取得主窗口的用户类
    user = stockManagementMainFrame.getUser();
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception  {
    contentPane = (JPanel) this.getContentPane();
    contentPane.setLayout(null);
    this.setSize(new Dimension(658, 620));
    //设置标签的属性
    jLabel1.setText("基础信息模块用户权限：");
    jLabel1.setBounds(new Rectangle(10, 30, 179, 16));
    jLabel2.setText("进货模块用户权限：");
    jLabel2.setBounds(new Rectangle(10, 193, 140, 16));
    jLabel3.setText("库存模块用户权限：");
    jLabel3.setBounds(new Rectangle(10, 314, 140, 16));
    jLabel4.setText("销售模块用户权限：");
    jLabel4.setBounds(new Rectangle(10, 475, 140, 16));
    //设置基础信息模块面板的布局的行数和列数
    baseInforGridLayout.setRows(4);     //行数
    baseInforGridLayout.setColumns(3);  //列数
    baseInforPanel.setLayout(baseInforGridLayout);
    baseInforPanel.setBounds(new Rectangle(152, 23, 476, 145));
    //设置面板的边框类型
    baseInforPanel.setBorder(BorderFactory.createEtchedBorder());
    //设置进货模块面板的布局的行数和列数
    stockGridLayout.setRows(3);     //行数
    stockGridLayout.setColumns(3);  //列数
    stockPanel.setLayout(stockGridLayout);
    stockPanel.setBounds(new Rectangle(152, 185, 476, 106));
    //设置面板的边框类型
    stockPanel.setBorder(BorderFactory.createEtchedBorder());
    //设置库存模块面板的布局的行数和列数
    stockManageGridLayout.setRows(4);     //行数
    stockManageGridLayout.setColumns(3);  //列数
    stockManagePanel.setLayout(stockManageGridLayout);
    stockManagePanel.setBounds(new Rectangle(152, 308, 476, 145));
    //设置面板的边框类型
    stockManagePanel.setBorder(BorderFactory.createEtchedBorder());
    //设置销售模块面板的布局的行数和列数
    saleGridLayout.setRows(3);     //行数
    saleGridLayout.setColumns(3);  //列数
    salePanel.setLayout(saleGridLayout);
    salePanel.setBounds(new Rectangle(152, 470, 476, 106));
    //设置面板的边框类型
    salePanel.setBorder(BorderFactory.createEtchedBorder());
    //为窗口面板加入各个控件
    contentPane.add(baseInforPanel, null);
    contentPane.add(stockPanel, null);
    contentPane.add(stockManagePanel, null);
    contentPane.add(salePanel, null);
    contentPane.add(jLabel1, null);
    contentPane.add(jLabel2, null);
    contentPane.add(jLabel3, null);
    contentPane.add(jLabel4, null);
    //根据用户权限显示标签
    showAuthorityJLabel();
    //设置窗口类的字体
    setupFont();
  }
  //设置窗口类的字体
  public void setupFont(){
    Component[] components = contentPane.getComponents();
    for(int i = 0; i < components.length; i++){
      components[i].setFont(dialog13);
    }
  }
  //显示标签的方法
  public void showAuthorityJLabel(){
    //显示基础信息模块的标签
    for(int i = 0; i < baseInforJLabels.length; i++){
      //创建标签
      baseInforJLabels[i] = new JLabel();
      //设置标签的标题
      baseInforJLabels[i].setText(baseInforJLabelTitles[i]);
      //设置标签的字体
      baseInforJLabels[i].setFont(dialog13);
      //为面板加入标签
      baseInforPanel.add(baseInforJLabels[i]);
    }
    //显示进货模块的标签
    for(int i = 0; i < stockJLabels.length; i++){
      //创建标签
      stockJLabels[i] = new JLabel();
      //设置标签的标题
      stockJLabels[i].setText(stockJLabelTitles[i]);
      //设置标签的字体
      stockJLabels[i].setFont(dialog13);
      //为面板加入标签
      stockPanel.add(stockJLabels[i]);
    }
    //显示库存模块的标签
    for(int i = 0; i < stockManageJLabels.length; i++){
      //创建标签
      stockManageJLabels[i] = new JLabel();
      //设置标签的标题
      stockManageJLabels[i].setText(stockManageJLabelTitles[i]);
      //设置标签的字体
      stockManageJLabels[i].setFont(dialog13);
      //为面板加入标签
      stockManagePanel.add(stockManageJLabels[i]);
    }
    //设置销售模块的标签
    for(int i = 0; i < saleJLabels.length; i++){
      //创建标签
      saleJLabels[i] = new JLabel();
      //设置标签的标题
      saleJLabels[i].setText(saleJLabelTitles[i]);
      //设置标签的字体
      saleJLabels[i].setFont(dialog13);
      //为面板加入标签
      salePanel.add(saleJLabels[i]);
    }
    setAuthorityJLabel();
  }
  //设置标签的方法
  public void setAuthorityJLabel(){
    //取得用户类的权限数字
    int baseInforFunction = user.getBaseInforFunction();
    int stockFunction = user.getStockFunction();
    int stockManageFunction = user.getStockManageFunction();
    int saleFunction = user.getSaleFunction();
    int power = 0;
    //设置基础信息模块的标签
    for(int i = 0; i < baseInforJLabels.length; i++){
      //将标签的enabled属性设为false
      baseInforJLabels[i].setEnabled(false);
      //求2的i次方
      power = (int)Math.pow(2, i);
      //根据用户权限将标签的enabled属性设为true
      if((baseInforFunction & power) == power){
        baseInforJLabels[i].setEnabled(true);
      }
    }
    //设置进货模块的标签
    for(int i = 0; i < stockJLabels.length; i++){
      //将标签的enabled属性设为false
      stockJLabels[i].setEnabled(false);
      //求2的i次方
      power = (int)Math.pow(2, i);
      //根据用户权限将标签的enabled属性设为true
      if((stockFunction & power) == power){
        stockJLabels[i].setEnabled(true);
      }
    }
    //设置库存模块的标签
    for(int i = 0; i < stockManageJLabels.length; i++){
      //将标签的enabled属性设为false
      stockManageJLabels[i].setEnabled(false);
      //求2的i次方
      power = (int)Math.pow(2, i);
      //根据用户权限将标签的enabled属性设为true
      if((stockManageFunction & power) == power){
        stockManageJLabels[i].setEnabled(true);
      }
    }
    //设置销售模块的标签
    for(int i = 0; i < saleJLabels.length; i++){
      //将标签的enabled属性设为false
      saleJLabels[i].setEnabled(false);
      //求2的i次方
      power = (int)Math.pow(2, i);
      //根据用户权限将标签的enabled属性设为true
      if((saleFunction & power) == power){
        saleJLabels[i].setEnabled(true);
      }
    }
  }
  protected void processWindowEvent(WindowEvent e) {
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      exit();
    }
  }
  //退出方法
  public void exit(){
    //隐藏窗口
    this.setVisible(false);
  }
  //设置用户的方法
  public void setUser(User user) {
    this.user = user;
  }
}
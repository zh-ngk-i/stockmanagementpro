﻿package com.shinear.sm.stockmanagementpro;

import javax.ejb.*;
import java.util.*;
import java.rmi.*;

public interface StockManagementDataHome extends javax.ejb.EJBHome {
  public StockManagementData create() throws CreateException, RemoteException;
}
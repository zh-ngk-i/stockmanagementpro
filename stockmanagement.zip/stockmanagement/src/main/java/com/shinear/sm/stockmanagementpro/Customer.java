﻿package com.shinear.sm.stockmanagementpro;

import javax.ejb.*;
import java.util.*;

public interface Customer extends javax.ejb.EJBLocalObject {
  public String getCustomerName();
  public void setCustomerZone(String customerZone);
  public String getCustomerZone();
  public void setPyCode(String pyCode);
  public String getPyCode();
  public void setAbbreviation(String abbreviation);
  public String getAbbreviation();
  public void setCompanyPhone(String companyPhone);
  public String getCompanyPhone();
  public void setLinkman(String linkman);
  public String getLinkman();
  public void setMobilePhone(String mobilePhone);
  public String getMobilePhone();
  public void setFax(String fax);
  public String getFax();
  public void setFixedPhone(String fixedPhone);
  public String getFixedPhone();
  public void setAddress(String address);
  public String getAddress();
  public void setZipCode(String zipCode);
  public String getZipCode();
  public void setBankName(String bankName);
  public String getBankName();
  public void setBankAccount(String bankAccount);
  public String getBankAccount();
  public void setEmail(String email);
  public String getEmail();
  public void setHomesite(String homesite);
  public String getHomesite();
  public void setCreditlimit(double creditlimit);
  public double getCreditlimit();
  public void setRemark(String remark);
  public String getRemark();
}
﻿package com.shinear.sm.stockmanagementpro;

import javax.ejb.*;

abstract public class WarehouseBean implements EntityBean {
  EntityContext entityContext;
  public java.lang.String ejbCreate(java.lang.String warehouseName,
                                    java.lang.String pyCode,
                                    java.lang.String location,
                                    java.lang.String description) throws
      CreateException {
    setWarehouseName(warehouseName);
    setPyCode(pyCode);
    setLocation(location);
    setDescription(description);
    return null;
  }

  public void ejbPostCreate(java.lang.String warehouseName,
                            java.lang.String pyCode, java.lang.String location,
                            java.lang.String description) throws
      CreateException {
  }
  public void ejbRemove() throws RemoveException {
  }
  public abstract void setWarehouseName(java.lang.String warehouseName);
  public abstract void setPyCode(java.lang.String pyCode);
  public abstract void setLocation(java.lang.String location);
  public abstract void setDescription(java.lang.String description);
  public abstract java.lang.String getWarehouseName();
  public abstract java.lang.String getPyCode();
  public abstract java.lang.String getLocation();
  public abstract java.lang.String getDescription();
  public void ejbLoad() {
  }
  public void ejbStore() {
  }
  public void ejbActivate() {
  }
  public void ejbPassivate() {
  }
  public void unsetEntityContext() {
    this.entityContext = null;
  }
  public void setEntityContext(EntityContext entityContext) {
    this.entityContext = entityContext;
  }
}
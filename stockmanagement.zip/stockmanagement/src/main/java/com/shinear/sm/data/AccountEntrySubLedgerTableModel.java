﻿package com.shinear.sm.data;

import javax.swing.table.*;

public class AccountEntrySubLedgerTableModel extends AbstractTableModel {
  //定义表格的数组
  private Object[][] data = null;
  //定义表格的标题
  private String[] columnNames = null;
  //定义列的编辑状态参数
  private int columnEditState = 0;

  //取得列总数的方法
  public int getColumnCount() {
    return columnNames.length;
  }
  //取得行总数的方法
  public int getRowCount() {
    return data.length;
  }
  //取得表格数值的方法
  public Object getValueAt(int row, int col) {
    return data[row][col];
  }
  //设置列的标题的方法
  public String getColumnName(int col) {
    return columnNames[col];
  }
  //通过getClass()方法设置默认的控件,如true与false的默认控件是复选框
  public Class getColumnClass(int c) {
    return getValueAt(0, c).getClass();
  }

  //定义可以编辑的单元,true表示可编辑,false表示不可编辑
  public boolean isCellEditable(int row, int col) {
    //如果columnEditState == 0，第1、2列不能编辑
    if(columnEditState == 0){
      if (col == 0 | col == 1) {
        return false;
      }
      return true;
    }else{
      return false;
    }
  }
  //将改变后的值保存在表格中
  public void setValueAt(Object value, int row, int col) {
    data[row][col] = value;
    fireTableCellUpdated(row, col);
  }
  //设置表格数据的方法
  public void setData(Object[][] data) {
    this.data = data;
  }
  //取得表格数据的方法
  public Object[][] getData() {
    return this.data;
  }
  //设置表格标题的方法
  public void setColumnNames(String[] columnNames) {
    this.columnNames = columnNames;
  }
  //设置表格列编辑参数的方法
  public void setColumnEditState(int columnEditState) {
    this.columnEditState = columnEditState;
  }
}
﻿package com.shinear.sm.stockmanagementpro;

import javax.ejb.*;
import java.util.*;
import java.sql.*;

public interface UserLogHome extends javax.ejb.EJBLocalHome {
  public UserLog create(Integer id, String programName, String operationContent, String userName, Timestamp operationDate) throws CreateException;
  public Collection findAll() throws FinderException;
  public Collection findByProgramName(String programName) throws FinderException;
  public Collection findByOperationContent(String operationContent) throws FinderException;
  public Collection findByUserName(String userName) throws FinderException;
  public Collection findByOperationDate(Timestamp startDate, Timestamp endDate) throws FinderException;
  public UserLog findByPrimaryKey(Integer id) throws FinderException;
}
﻿package com.shinear.sm.saleinterface;

import java.awt.*;
import java.awt.event.*;
import javax.swing.event.*;
import javax.swing.*;
import com.shinear.sm.data.*;
import com.shinear.sm.maininterface.*;
import com.shinear.sm.user.*;
import com.shinear.sm.method.*;
import java.util.Date;

public class CreditSaleFrame extends JFrame implements ActionListener {
  JPanel contentPane;
  //创建标签控件
  JLabel jLabel1 = new JLabel();
  JLabel jLabel2 = new JLabel();
  JLabel jLabel3 = new JLabel();
  JLabel jLabel4 = new JLabel();
  JLabel jLabel5 = new JLabel();
  JLabel jLabel6 = new JLabel();
  JLabel jLabel7 = new JLabel();
  JLabel jLabel8 = new JLabel();
  JLabel jLabel9 = new JLabel();
  JLabel jLabel10 = new JLabel();
  JLabel jLabel11 = new JLabel();
  JLabel jLabel12 = new JLabel();
  JLabel jLabel13 = new JLabel();
  JLabel jLabel14 = new JLabel();
  JLabel jLabel15 = new JLabel();
  JLabel jLabel16 = new JLabel();
  JLabel jLabel17 = new JLabel();
  //创建编辑框控件
  JTextField jTextField1 = new JTextField();
  JTextField jTextField2 = new JTextField();
  JTextField jTextField3 = new JTextField();
  JTextField jTextField4 = new JTextField();
  JTextField jTextField5 = new JTextField();
  JTextField jTextField6 = new JTextField();
  JTextField jTextField7 = new JTextField();
  JTextField jTextField8 = new JTextField();
  JTextField jTextField9 = new JTextField();
  JTextField jTextField10 = new JTextField();
  JTextField jTextField11 = new JTextField();
  JTextField jTextField12 = new JTextField();
  JTextField jTextField13 = new JTextField();
  //创建按钮控件
  JButton jButton1 = new JButton();
  JButton jButton2 = new JButton();
  JButton jButton3 = new JButton();
  JButton jButton4 = new JButton();
  JButton jButton5 = new JButton();
  JButton jButton6 = new JButton();
  JButton jButton7 = new JButton();
  JButton jButton8 = new JButton();
  JButton jButton9 = new JButton();
  JButton jButton10 = new JButton();
  JButton jButton11 = new JButton();
  JButton jButton12 = new JButton();
  JButton jButton13 = new JButton();
  //创建滚动框控件
  JScrollPane jScrollPane1 = new JScrollPane();
  JScrollPane jScrollPane2 = new JScrollPane();
  JScrollPane jScrollPane3 = new JScrollPane();
  //创建列表框数据类和列表框控件
  DefaultListModel listData1 = new DefaultListModel();
  JList jList1 = new JList(listData1);
  //创建表格控件
  JTable jTable1 = new JTable();
  //创建表格模式类
  SaleSubLedgerTableModel sslTableModel = new SaleSubLedgerTableModel();
  //创建标题数组
  String[] colNames = {
      "明细编号", "单据编号", "商品条形码", "销售价", "折扣", "实际售价", "数量", "金额"};
  //创建下拉列表框控件
  JComboBox jComboBox1 = new JComboBox();
  //创建文本框控件
  JTextArea jTextArea1 = new JTextArea();
  //创建字体类
  Font dialog13 = new java.awt.Font("Dialog", 0, 13);
  //声明数据类
  StockManagementData stockManagementData = null;
  //声明用户类
  User user = null;
  //声明主窗口类
  StockManagementMainFrame stockManagementMainFrame = null;
  //创建销售账套数组
  String[][] saleLedgers = new String[0][11];
  //创建销售账套明细数组
  String[][] saleSubLedgers = new String[0][5];
  //创建销售账套明细表格数组
  Object[][] saleSubLedgerObjects = new Object[0][8];
  //创建方法类
  DataMethod dataMethod = new DataMethod();
  //创建动作字符串
  String action = "";
  //创建完成状态数组
  String[] onProcesses = {"进行", "撤消", "完成"};
  //创建帐套日期字符串
  String ledgerDate = "";
  //创建柜台字符串
  String warehouse = "";
  //声明打印窗口
  SaleOrderPrintFrame saleOrderPrintFrame = null;
  //声明应收票据打印窗口
  AccountReceivablePrintFrame accountReceivablePrintFrame = null;

  public CreditSaleFrame(StockManagementMainFrame stockManagementMainFrame) {
    this.stockManagementMainFrame = stockManagementMainFrame;
    //取得主窗口的数据类
    stockManagementData = stockManagementMainFrame.getStockManagementData();
    //取得主窗口的用户类
    user = stockManagementMainFrame.getUser();
    //取得主窗口的账套日期
    ledgerDate = stockManagementMainFrame.getLedgerDate();
    //取得销售模块的用户权限
    int saleFunction = user.getSaleFunction();
    if((saleFunction & 2) != 2){
      JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
      System.exit(0);
    }
    //检查账套日期
    if(ledgerDate.length() == 0){
      JOptionPane.showMessageDialog(null, user.getUserName() + "请选择账套.");
      return;
    }
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception  {
    contentPane = (JPanel) this.getContentPane();
    contentPane.setLayout(null);
    this.setSize(new Dimension(667, 678));
    this.setTitle("信用销售窗口");
    //设置标签的属性
    jLabel1.setText("销售单列表");
    jLabel1.setBounds(new Rectangle(28, 19, 85, 16));
    jLabel2.setText("查询条件");
    jLabel2.setBounds(new Rectangle(193, 45, 62, 16));
    jLabel3.setText("查询值");
    jLabel3.setBounds(new Rectangle(440, 45, 50, 16));
    jLabel4.setText("开始日期");
    jLabel4.setBounds(new Rectangle(193, 77, 67, 16));
    jLabel5.setText("结束日期");
    jLabel5.setBounds(new Rectangle(373, 76, 66, 16));
    jLabel6.setText("单据编号");
    jLabel6.setBounds(new Rectangle(193, 108, 66, 16));
    jLabel7.setText("客户");
    jLabel7.setBounds(new Rectangle(419, 107, 54, 16));
    jLabel8.setText("送货地址");
    jLabel8.setBounds(new Rectangle(193, 140, 66, 16));
    jLabel9.setText("信用销售员");
    jLabel9.setBounds(new Rectangle(419, 138, 66, 16));
    jLabel10.setText("现金管理员");
    jLabel10.setBounds(new Rectangle(193, 171, 66, 16));
    jLabel11.setText("柜台名字");
    jLabel11.setBounds(new Rectangle(193, 203, 66, 16));
    jLabel12.setText("填写日期");
    jLabel12.setBounds(new Rectangle(193, 234, 66, 16));
    jLabel13.setText("完成日期");
    jLabel13.setBounds(new Rectangle(193, 266, 66, 16));
    jLabel14.setText("完成状态");
    jLabel14.setBounds(new Rectangle(193, 297, 66, 16));
    jLabel15.setText("备注");
    jLabel15.setBounds(new Rectangle(419, 170, 66, 16));
    jLabel16.setText("销售单明细列表");
    jLabel16.setBounds(new Rectangle(28, 413, 110, 16));
    jLabel17.setText("总价");
    jLabel17.setBounds(new Rectangle(477, 413, 63, 16));
    //设置编辑框的属性
    jTextField1.setBounds(new Rectangle(492, 45, 133, 22));
    jTextField2.setBounds(new Rectangle(267, 77, 101, 22));
    jTextField3.setBounds(new Rectangle(439, 76, 101, 22));
    jTextField4.setEditable(false);
    jTextField4.setBounds(new Rectangle(267, 108, 147, 22));
    jTextField5.setBounds(new Rectangle(494, 107, 131, 22));
    jTextField6.setBounds(new Rectangle(267, 140, 147, 22));
    jTextField8.setEditable(false);
    jTextField8.setBounds(new Rectangle(267, 171, 147, 22));
    jTextField7.setEditable(false);
    jTextField7.setBounds(new Rectangle(494, 138, 131, 22));
    jTextField9.setBounds(new Rectangle(267, 203, 147, 22));
    jTextField10.setEditable(false);
    jTextField10.setBounds(new Rectangle(267, 234, 147, 22));
    jTextField11.setEditable(false);
    jTextField11.setBounds(new Rectangle(267, 266, 147, 22));
    jTextField12.setEditable(false);
    jTextField12.setBounds(new Rectangle(267, 297, 147, 22));
    jTextField13.setEditable(false);
    jTextField13.setBounds(new Rectangle(534, 413, 91, 22));
    //设置按钮的属性
    jButton1.setText("查询");
    jButton1.setActionCommand("search");
    jButton1.setBounds(new Rectangle(546, 76, 79, 22));
    jButton2.setText("创建");
    jButton2.setActionCommand("createSaleLedger");
    jButton2.setBounds(new Rectangle(28, 332, 83, 25));
    jButton3.setText("修改");
    jButton3.setActionCommand("updateSaleLedger");
    jButton3.setBounds(new Rectangle(114, 332, 83, 25));
    jButton4.setText("撤消");
    jButton4.setActionCommand("cancelSaleLedger");
    jButton4.setBounds(new Rectangle(199, 332, 83, 25));
    jButton5.setText("恢复");
    jButton5.setActionCommand("restoreSaleLedger");
    jButton5.setBounds(new Rectangle(285, 332, 83, 25));
    jButton6.setText("确定");
    jButton6.setActionCommand("ok");
    jButton6.setBounds(new Rectangle(371, 332, 83, 25));
    jButton7.setText("取消");
    jButton7.setActionCommand("cancel");
    jButton7.setBounds(new Rectangle(456, 332, 83, 25));
    jButton8.setText("退出");
    jButton8.setActionCommand("exit");
    jButton8.setBounds(new Rectangle(542, 332, 83, 25));
    jButton9.setText("电子签名");
    jButton9.setActionCommand("sign");
    jButton9.setBounds(new Rectangle(28, 372, 183, 25));
    jButton10.setText("打印销售单");
    jButton10.setActionCommand("printSaleOrder");
    jButton10.setBounds(new Rectangle(235, 372, 183, 25));
    jButton11.setText("打印应收票据");
    jButton11.setActionCommand("printAccountReceivable");
    jButton11.setBounds(new Rectangle(442, 372, 183, 25));
    jButton12.setText("创建明细记录");
    jButton12.setActionCommand("createSub");
    jButton12.setBounds(new Rectangle(28, 581, 281, 25));
    jButton13.setText("删除明细记录");
    jButton13.setActionCommand("deleteSub");
    jButton13.setBounds(new Rectangle(344, 581, 281, 25));
    //设置滚动框的属性
    jScrollPane1.setBounds(new Rectangle(28, 44, 152, 275));
    jScrollPane2.setBounds(new Rectangle(426, 190, 199, 129));
    jScrollPane3.setBounds(new Rectangle(28, 443, 597, 124));
    jScrollPane1.getViewport().add(jList1, null);
    jScrollPane2.getViewport().add(jTextArea1, null);
    jScrollPane3.getViewport().add(jTable1, null);
    //为列表框加入选择接收器
    jList1.addListSelectionListener(new ListSelectionListener() {
      public void valueChanged(ListSelectionEvent e) {
        //当多种事件被激发的时候,不执行接收器后面的代码
        if (e.getValueIsAdjusting()) return;
        jList1_valueChanged(e);
      }
    });
    //设置下拉列表框的属性
    jComboBox1.setBounds(new Rectangle(267, 45, 156, 22));
    jComboBox1.addItem("根据单据编号查询");
    jComboBox1.addItem("根据客户查询");
    jComboBox1.addItem("根据信用销售员查询");
    jComboBox1.addItem("根据现金管理员查询");
    jComboBox1.addItem("根据送货地址查询");
    jComboBox1.addItem("根据完成状态查询");
    jComboBox1.addItem("根据填写日期查询");
    //为面板加入各个控件
    contentPane.add(jLabel1, null);
    contentPane.add(jLabel2, null);
    contentPane.add(jLabel3, null);
    contentPane.add(jLabel4, null);
    contentPane.add(jLabel5, null);
    contentPane.add(jLabel6, null);
    contentPane.add(jLabel7, null);
    contentPane.add(jLabel8, null);
    contentPane.add(jLabel9, null);
    contentPane.add(jLabel10, null);
    contentPane.add(jLabel11, null);
    contentPane.add(jLabel12, null);
    contentPane.add(jLabel13, null);
    contentPane.add(jLabel14, null);
    contentPane.add(jLabel15, null);
    contentPane.add(jLabel16, null);
    contentPane.add(jLabel17, null);
    contentPane.add(jComboBox1, null);
    contentPane.add(jTextField1, null);
    contentPane.add(jTextField2, null);
    contentPane.add(jTextField3, null);
    contentPane.add(jTextField4, null);
    contentPane.add(jTextField5, null);
    contentPane.add(jTextField6, null);
    contentPane.add(jTextField7, null);
    contentPane.add(jTextField8, null);
    contentPane.add(jTextField9, null);
    contentPane.add(jTextField10, null);
    contentPane.add(jTextField11, null);
    contentPane.add(jTextField12, null);
    contentPane.add(jTextField13, null);
    contentPane.add(jScrollPane1, null);
    contentPane.add(jScrollPane2, null);
    contentPane.add(jScrollPane3, null);
    contentPane.add(jButton1, null);
    contentPane.add(jButton2, null);
    contentPane.add(jButton3, null);
    contentPane.add(jButton4, null);
    contentPane.add(jButton5, null);
    contentPane.add(jButton6, null);
    contentPane.add(jButton7, null);
    contentPane.add(jButton8, null);
    contentPane.add(jButton9, null);
    contentPane.add(jButton10, null);
    contentPane.add(jButton11, null);
    contentPane.add(jButton12, null);
    contentPane.add(jButton13, null);
    //设置窗口类的字体和为按钮加入动作接收器
    setupFontAndListener();
    //检查按钮状态
    this.checkBtn(false);
    this.checkSubBtn(false);
  }
  //设置窗口类的字体和为按钮加入动作接收器的方法
  public void setupFontAndListener(){
    Component[] components = contentPane.getComponents();
    //创建临时按钮控件
    JButton tmpBtn = new JButton();
    for(int i = 0; i < components.length; i++){
      components[i].setFont(dialog13);
      if(components[i].getClass().getName().equals("javax.swing.JButton")){
        tmpBtn = (JButton)components[i];
        tmpBtn.addActionListener(this);
      }
    }
  }
  //退出方法
  public void exit(){
    //隐藏窗口
    this.setVisible(false);
    //清空数组的内容
    saleLedgers = new String[0][11];
    saleSubLedgers = new String[0][5];
    saleSubLedgerObjects = new Object[0][8];
    //清空列表框的内容
    listData1.clear();
    //清空文本框的内容
    jTextArea1.setText("");
    //清空表格的内容
    this.showTableData(saleSubLedgerObjects);
    //取得面板上的所有控件
    Component[] components = contentPane.getComponents();
    //创建临时编辑框控件
    JTextField tmpTextField = new JTextField();
    for(int i = 0; i < components.length; i++){
      if(components[i].getClass().getName().equals("javax.swing.JTextField")){
        tmpTextField = (JTextField)components[i];
        //清空编辑框的内容
        tmpTextField.setText("");
      }
    }
  }
  //设置用户的方法
  public void setUser(User user) {
    this.user = user;
  }
  //设置账套的方法
  public void setLedgerDate(String ledgerDate) {
    this.ledgerDate = ledgerDate;
  }
  protected void processWindowEvent(WindowEvent e) {
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      exit();
    }
  }
  //显示查询销售单的方法
  public void showSearchSaleLedger(){
    listData1.clear();
    //为销售单列表框加入销售单数据
    for(int i = 0; i < saleLedgers.length; i++){
      listData1.addElement(saleLedgers[i][0]);
    }
  }
  //显示单个销售单的方法
  public void showSaleLedger(){
    //取得当前选择项的位置
    int selectedIndex = jList1.getSelectedIndex();
    //当列表框不处于选择状态，不显示商品数据
    if(selectedIndex == -1){
       return;
    }
    //显示销售单的数据
    jTextField4.setText(saleLedgers[selectedIndex][0]);    //单据编号
    jTextField5.setText(saleLedgers[selectedIndex][2]);    //客户
    jTextField6.setText(saleLedgers[selectedIndex][6]);    //送货地址
    jTextField7.setText(saleLedgers[selectedIndex][4]);    //信用销售员
    jTextField8.setText(saleLedgers[selectedIndex][5]);    //现金管理员
    //信用销售单将柜台数据保存在counterUser字段内
    jTextField9.setText(saleLedgers[selectedIndex][3]);    //柜台
    jTextField10.setText(saleLedgers[selectedIndex][7]);   //填写日期
    jTextField11.setText(saleLedgers[selectedIndex][8]);   //完成日期
    jTextField12.setText(onProcesses[Integer.parseInt(saleLedgers[selectedIndex][9])]);
    jTextArea1.setText(saleLedgers[selectedIndex][10]);
    //显示销售单明细数据
    this.showSaleSubLedger();
  }
  //显示销售单明细数据的方法
  public void showSaleSubLedger(){
    //取得当前选择项的位置
    int selectedIndex = jList1.getSelectedIndex();
    String saleId = saleLedgers[selectedIndex][0];
    saleSubLedgers = stockManagementData.getSaleSubLedgerBySaleId(ledgerDate, saleId);
    //将数组数据转换为表格数据
    saleSubLedgerObjects = new Object[saleSubLedgers.length][8];
    double total = 0;
    for(int i = 0; i < saleSubLedgers.length; i++){
      saleSubLedgerObjects[i][0] = new Integer(saleSubLedgers[i][0]);
      saleSubLedgerObjects[i][1] = saleSubLedgers[i][1];
      saleSubLedgerObjects[i][2] = saleSubLedgers[i][2];    //商品条形码
      double actualSalePrice = dataMethod.round(Double.parseDouble(saleSubLedgers[i][3]));
      int quantity = Integer.parseInt(saleSubLedgers[i][4]);
      saleSubLedgerObjects[i][3] = new Double(0);
      saleSubLedgerObjects[i][4] = new Double(0);
      double amount = dataMethod.round(actualSalePrice * quantity);
      saleSubLedgerObjects[i][5] = new Double(actualSalePrice); //实际售价
      saleSubLedgerObjects[i][6] = new Integer(quantity);       //数量
      saleSubLedgerObjects[i][7] = new Double(amount);          //金额
      total += amount;
    }
    //显示总价
    jTextField13.setText(String.valueOf(dataMethod.round(total)));
    //显示表格的内容
    this.showTableData(saleSubLedgerObjects);
  }
  //转换表格数据的方法
  public void transferTableData(){
    saleSubLedgers = new String[saleSubLedgerObjects.length][5];
    for(int i = 0; i < saleSubLedgerObjects.length; i++){
      saleSubLedgers[i][0] = ((Integer)saleSubLedgerObjects[i][0]).toString();
      saleSubLedgers[i][1] = (String)saleSubLedgerObjects[i][1];
      saleSubLedgers[i][2] = (String)saleSubLedgerObjects[i][2];
      saleSubLedgers[i][3] = ((Double)saleSubLedgerObjects[i][5]).toString(); //实际售价
      saleSubLedgers[i][4] = ((Integer)saleSubLedgerObjects[i][6]).toString();//数量
    }
  }
  //显示表格内容的方法
  public void showTableData(Object[][] detail){
    //设置表格的标题
    sslTableModel.setColumnNames(colNames);
    //设置表格的数据
    sslTableModel.setData(detail);
    jTable1 = new JTable(sslTableModel);
    //设置表格的字体
    jTable1.setFont(dialog13);
    //将数据表格加入数据滚动框
    jScrollPane3.getViewport().add(jTable1, null);
    //设置列的宽度
    jTable1.getColumnModel().getColumn(0).setPreferredWidth(20);
    jTable1.getColumnModel().getColumn(1).setPreferredWidth(50);
    jTable1.getColumnModel().getColumn(2).setPreferredWidth(50);
    jTable1.getColumnModel().getColumn(3).setPreferredWidth(10);
    jTable1.getColumnModel().getColumn(4).setPreferredWidth(10);
    jTable1.getColumnModel().getColumn(5).setPreferredWidth(10);
    jTable1.getColumnModel().getColumn(6).setPreferredWidth(10);
    jTable1.getColumnModel().getColumn(7).setPreferredWidth(10);
    //为表格加入内容接收器
    sslTableModel.addTableModelListener(new TableModelListener(){
      public void tableChanged(TableModelEvent e) {
        jTable1_valueChanged(e);
      }
    });
  }
  //重新计算货物金额
  public void recountGoodsAmount(){
    double actualSalePrice = 0;
    int quantity = 0;
    double amount = 0;
    double total = 0;
    for(int i = 0; i < saleSubLedgerObjects.length; i++){
      actualSalePrice = dataMethod.round(((Double)saleSubLedgerObjects[i][5]).doubleValue());
      quantity = ((Integer)saleSubLedgerObjects[i][6]).intValue();
      amount = dataMethod.round(actualSalePrice * quantity);
      saleSubLedgerObjects[i][7] = new Double(amount);
      total += amount;
    }
    jTextField13.setText(String.valueOf(dataMethod.round(total)));
  }
  //检查明细账的商品条形码方法
  public int checkSaleSubLedgerGoodsBarCode(){
    int result = 0;
    for(int i = 0; i < saleSubLedgerObjects.length; i++){
      result = stockManagementData.checkGoodsBarCode((String)saleSubLedgerObjects[i][2]);
      if(result == 0){
        JOptionPane.showMessageDialog(null, "第" + (i + 1) + "行的商品条形码在商品数据库中"
                                      + "不存在，请打开商品数据管理窗口添加.");
        return 0;
      }
    }
    return 1;
  }
  //检查明细账的数量是否大于库存数
  public int checkStockQuantity(){
    int result = 0;
    for(int i = 0; i < saleSubLedgerObjects.length; i++){
      result = stockManagementData.checkGoodsSaleQuantity(ledgerDate,
          (String) saleSubLedgerObjects[i][2],
          ((Integer)saleSubLedgerObjects[i][6]).intValue(), warehouse);
      if (result == 0) {
        JOptionPane.showMessageDialog(null, "第" + (i + 1) + "行的商品的卖出数量大于库存数.");
        return 0;
      }
    }
    return 1;
  }
  //根据商品条形码取得销售价和折扣
  public void showGoodsPriceAndDiscount(){
    for(int i = 0; i < saleSubLedgerObjects.length; i++){
      String goodsBarcode = (String)saleSubLedgerObjects[i][2];
      double[] data = stockManagementData.getGoodsPriceAndDiscount(goodsBarcode);
      saleSubLedgerObjects[i][3] = new Double(data[0]);            //销售价
      saleSubLedgerObjects[i][4] = new Double(data[1]);            //折扣
      saleSubLedgerObjects[i][5] = new Double(data[0] * data[1]);  //实际售价
    }
  }
  //清空单个销售单显示的方法
  public void clearSaleLedger(){
    jTextField4.setText("");
    jTextField5.setText("");
    jTextField6.setText("");
    jTextField7.setText("");
    jTextField8.setText("");
    jTextField9.setText("");
    jTextField10.setText("");
    jTextField11.setText("");
    jTextField12.setText("");
    jTextField13.setText("");
    jTextArea1.setText("");
    saleSubLedgers = new String[0][5];
    saleSubLedgerObjects = new Object[0][8];
    this.showTableData(saleSubLedgerObjects);
  }
  //检查按钮的状态
  public void checkBtn(boolean isManipulated){
    if(isManipulated){
      jButton2.setEnabled(false);
      jButton3.setEnabled(false);
      jButton4.setEnabled(false);
      jButton5.setEnabled(false);
      jButton9.setEnabled(false);
      jButton6.setEnabled(true);
      jButton7.setEnabled(true);
    }else{
      jButton2.setEnabled(true);
      jButton3.setEnabled(true);
      jButton4.setEnabled(true);
      jButton5.setEnabled(true);
      jButton9.setEnabled(true);
      jButton6.setEnabled(false);
      jButton7.setEnabled(false);
    }
  }
  //检查明细账按钮的状态
  public void checkSubBtn(boolean isCreated){
    if(isCreated){
      jButton12.setEnabled(true);
      jButton13.setEnabled(true);
    }else{
      jButton12.setEnabled(false);
      jButton13.setEnabled(false);
    }
  }
  //列表1的选择事件
  void jList1_valueChanged(ListSelectionEvent e) {
    if(listData1.size() > 0){
      this.showSaleLedger();
    }else{
      this.clearSaleLedger();
    }
  }
  //表格内容改变事件
  public void jTable1_valueChanged(TableModelEvent e) {
    //重新计算金额
    this.recountGoodsAmount();
    //根据商品条形码取得销售价和折扣
    this.showGoodsPriceAndDiscount();
  }
  //查询方法
  public void search(){
    //取得查询选项
    int selectedIndex = jComboBox1.getSelectedIndex();
    //取得编辑框的变量
    String searchValue = jTextField1.getText().trim();
    String startDateStr = jTextField2.getText().trim();
    String endDateStr = jTextField3.getText().trim();
    if (selectedIndex == 0 | selectedIndex == 1 | selectedIndex == 2 |
        selectedIndex == 3 | selectedIndex == 4 | selectedIndex == 5) {
      if (searchValue.length() == 0) {
        JOptionPane.showMessageDialog(null, "请输入查询值");
        return;
      }
      switch (selectedIndex) {
        case 0:
          //根据销售单编号取得记录
          saleLedgers = stockManagementData.getSaleLedgerByStringField(
              ledgerDate, "saleId", searchValue, 1);
          break;
        case 1:
          //根据客户取得记录
          saleLedgers = stockManagementData.getSaleLedgerByStringField(
              ledgerDate, "customerName", searchValue, 1);
          break;
        case 2:
          //根据信用销售员取得记录
          saleLedgers = stockManagementData.getSaleLedgerByStringField(
              ledgerDate, "creditUser", searchValue, 1);
          break;
        case 3:
          //根据现金管理员取得记录
          saleLedgers = stockManagementData.getSaleLedgerByStringField(
              ledgerDate, "cashUser", searchValue, 1);
          break;
        case 4:
          //根据送货地址取得记录
          saleLedgers = stockManagementData.getSaleLedgerByStringField(
              ledgerDate, "address", searchValue, 1);
          break;
        case 5:
          if(dataMethod.checkInt(searchValue) == 0){
            JOptionPane.showMessageDialog(null, "按完成状态查询时，输入值必须是整数，"
                                          + "0表示进行，1表示撤消，2表示完成.");
            return;
          }
          //根据完成状态取得记录
          saleLedgers = stockManagementData.getSaleLedgerByOnProcess(
              ledgerDate, 1, Integer.parseInt(searchValue));
          break;
      }
    }else{
      java.sql.Timestamp startDate = dataMethod.transferDate(startDateStr);
      java.sql.Timestamp endDate = dataMethod.transferEndDate(endDateStr);
      if(startDate == null | endDate == null){
        JOptionPane.showMessageDialog(null, "日期输入错误，正确的日期格式是"
                                      + "yyyy-mm-dd（年-月-日），如2004-1-1");
        return;
      }
      //根据日期取得记录
      saleLedgers = stockManagementData.getSaleLedgerByOrderDate(ledgerDate,
          startDate, endDate, 1);
    }
    this.showSearchSaleLedger();
  }
  //单击事件
  public void actionPerformed(ActionEvent e) {
    //取得按钮的动作字符串
    String actionCommand = e.getActionCommand().trim();
    //检查打开的账套是否当前账套
    if (actionCommand.equals("createSaleLedger") |
        actionCommand.equals("updateSaleLedger") |
        actionCommand.equals("cancelSaleLedger") |
        actionCommand.equals("restoreSaleLedger") |
        actionCommand.equals("sign")) {
      int result = stockManagementData.isCurrentLedger(ledgerDate);
      if(result == 0){
        JOptionPane.showMessageDialog(null, ledgerDate + "是往期账套，不能进行添加、修改和撤消操作.");
        return;
      }
    }
    //检查销售单是否完成
    if (actionCommand.equals("updateSaleLedger") |
        actionCommand.equals("cancelSaleLedger") |
        actionCommand.equals("restoreSaleLedger")|
        actionCommand.equals("sign")) {
      if(jList1.isSelectionEmpty()){
        JOptionPane.showMessageDialog(null, "请选择销售单.");
        return;
      }
      int selectedIndex = jList1.getSelectedIndex();
      int onProcess = Integer.parseInt(saleLedgers[selectedIndex][9]);
      if(onProcess == 2){
        JOptionPane.showMessageDialog(null, saleLedgers[selectedIndex][0]
                                      + "销售单已经完成，不可以进行修改、撤消、恢复、电子签名操作.");
        return;
      }
    }
    //检查销售单是否撤消
    if (actionCommand.equals("sign")) {
      if(jList1.isSelectionEmpty()){
        JOptionPane.showMessageDialog(null, "请选择销售单.");
        return;
      }
      int selectedIndex = jList1.getSelectedIndex();
      int onProcess = Integer.parseInt(saleLedgers[selectedIndex][9]);
      if(onProcess == 1){
        JOptionPane.showMessageDialog(null, saleLedgers[selectedIndex][0]
                                      + "销售单已经撤消，不可以进行电子签名操作.");
        return;
      }
    }
    if (actionCommand.equals("search")) {
      //查询
      search();
    }else if(actionCommand.equals("createSaleLedger")){
      action = "create";
      this.clearSaleLedger();
      this.checkBtn(true);
      this.checkSubBtn(true);
    }else if(actionCommand.equals("updateSaleLedger")){
      action = "update";
      this.checkBtn(true);
    }else if(actionCommand.equals("cancelSaleLedger")){
      action = "cancel";
      this.checkBtn(true);
    }else if(actionCommand.equals("restoreSaleLedger")){
      action = "restore";
      this.checkBtn(true);
    }else if(actionCommand.equals("sign")){
      action = "sign";
      this.checkBtn(true);
    }else if(actionCommand.equals("ok")){
      //创建销售账套数据表的单个记录数组
      String[] saleLedger = new String[11];
      //取得销售单的值
      saleLedger[1] = "1";                                    //1表示信用销售单
      saleLedger[2] = jTextField5.getText().trim();
      saleLedger[3] = jTextField9.getText().trim();           //柜台
      saleLedger[4] = user.getUserName();                     //信用销售员
      saleLedger[5] = "";
      saleLedger[6] = jTextField6.getText().trim();           //送货地址
      saleLedger[7] = dataMethod.getCurrentDate().toString(); //填写日期
      saleLedger[8] = null;                                   //完成日期
      saleLedger[9] = "0";                                    //完成状态
      saleLedger[10] = jTextArea1.getText().trim();
      if (action.equals("update") | action.equals("cancel") |
          action.equals("restore") | action.equals("sign")) {
        int selectedIndex = jList1.getSelectedIndex();
        //取得原来的单据编号
        saleLedger[0] = saleLedgers[selectedIndex][0].trim();
      }
      int result = 0;
      if(action.equals("update") | action.equals("create")){
        //检查销售单的客户
        result = stockManagementData.checkCustomer(saleLedger[2]);
        if(result == 0){
          JOptionPane.showMessageDialog(null, saleLedger[2] + "在客户数据库中"
                                        + "不存在，请打开客户数据管理窗口添加.");
          return;
        }
        //检查销售单的柜台名字
        result = stockManagementData.checkWarehouse(saleLedger[3]);
        if(result == 0){
          JOptionPane.showMessageDialog(null, saleLedger[3] + "在仓库数据库中"
                                        + "不存在，请打开仓库数据管理窗口添加.");
          return;
        }
        //检查商品条形码
        result = this.checkSaleSubLedgerGoodsBarCode();
        if(result == 0) return;
        //检查销售单明细账的商品数量是否小于等于库存数
        result = this.checkStockQuantity();
        if(result == 0)  return;
        //重新计算卖出金额
        this.recountGoodsAmount();
        double amount = Double.parseDouble(jTextField13.getText());
        //检客户的信用限额
        result = stockManagementData.checkCustomerCreditLimit(saleLedger[2], amount);
        if(result == 0){
          JOptionPane.showMessageDialog(null, saleLedger[2] + "的信用额度不够.");
          return;
        }
        //转换表格数组
        this.transferTableData();
      }
      if(action.equals("create")){
        //检查明细账是否为空
        if(saleSubLedgerObjects.length == 0){
          JOptionPane.showMessageDialog(null, "明细账数据表为空，不可以创建销售单.");
          return;
        }
        //添加销售单
        result = stockManagementData.createSaleLedgerAndSub(ledgerDate,
            saleLedger, saleSubLedgers);
        if(result == 1){
          JOptionPane.showMessageDialog(null, "销售单添加成功，请重新执行查询操作显示新的销售单.");
        }else{
          JOptionPane.showMessageDialog(null, "销售单添加失败，请检查输入值是否大于字段范围.");
        }
      }else if (action.equals("update")){
        //修改销售单
        result = stockManagementData.updateSaleLedgerAndSub(ledgerDate,
            saleLedger, saleSubLedgers);
        if(result == 1){
          JOptionPane.showMessageDialog(null, "销售单修改成功.");
          //更新数组的数据
          int selectedIndex = jList1.getSelectedIndex();
          for(int i = 0; i < 11; i++){
            saleLedgers[selectedIndex][i] = saleLedger[i];
          }
        }else{
          JOptionPane.showMessageDialog(null, "销售单修改失败，请检查输入值是否大于字段范围.");
        }
      }else if (action.equals("cancel")){
        //撤消销售单
        result = stockManagementData.signSaleLedgerAndSub(ledgerDate, "creditUser", user.getUserName(),
            saleLedger[0], 1, saleLedger[10]);
        if(result == 1){
          JOptionPane.showMessageDialog(null, "销售单撤消成功.");
          //更新完成状态编辑框的值
          jTextField12.setText(onProcesses[1]);
          //更新数组的数据
          int selectedIndex = jList1.getSelectedIndex();
          saleLedgers[selectedIndex][9] = "1";
          saleLedgers[selectedIndex][10] = saleLedger[10];
        }else{
          JOptionPane.showMessageDialog(null, "销售单撤消失败.");
        }
      }else if (action.equals("restore")){
        //恢复销售单
        result = stockManagementData.signSaleLedgerAndSub(ledgerDate, "creditUser", user.getUserName(),
            saleLedger[0], 0, saleLedger[10]);
        if(result == 1){
          JOptionPane.showMessageDialog(null, "销售单恢复成功.");
          //更新完成状态编辑框的值
          jTextField12.setText(onProcesses[0]);
          //更新数组的数据
          int selectedIndex = jList1.getSelectedIndex();
          saleLedgers[selectedIndex][9] = "0";
          saleLedgers[selectedIndex][10] = saleLedger[10];
        }else{
          JOptionPane.showMessageDialog(null, "销售单恢复失败.");
        }
      }else if (action.equals("sign")){
        int selectedIndex = jList1.getSelectedIndex();
        //对销售单进行电子签名
        result = stockManagementData.creditUserSignSaleLedgerAndSub(ledgerDate,
            user.getUserName(), saleLedger[10], saleLedgers[selectedIndex][3],
            saleLedgers[selectedIndex][0], saleLedgers[selectedIndex][2]);
        if(result == 1){
          JOptionPane.showMessageDialog(null, "电子签名成功.");
          //更新完成状态编辑框的值
          jTextField12.setText(onProcesses[2]);
          //更新数组的数据
          saleLedgers[selectedIndex][9] = "2";
          saleLedgers[selectedIndex][10] = saleLedger[10];
        }else{
          JOptionPane.showMessageDialog(null, "电子签名失败.");
        }
      }
      this.checkSubBtn(false);
      this.checkBtn(false);
    }else if(actionCommand.equals("cancel")){
      this.jList1_valueChanged(null);
      this.checkBtn(false);
      this.checkSubBtn(false);
    }else if(actionCommand.equals("printSaleOrder")){
      int selectedIndex = jList1.getSelectedIndex();
      if(selectedIndex == -1){
        JOptionPane.showMessageDialog(null, "先选择销售单.");
        return;
      }
      //取得选择销售单的数据
      String[] saleLedger = new String[11];
      for(int i = 0; i < saleLedger.length; i++){
        if(saleLedgers[selectedIndex][i] == null){
          saleLedger[i] = "";
        }else{
          saleLedger[i] = saleLedgers[selectedIndex][i];
        }
      }
      //取得销售单的明细账数据
      String[][] saleSubLedgerForPrint = new String[saleSubLedgerObjects.length][4];
      for(int i = 0; i < saleSubLedgers.length; i++){
        saleSubLedgerForPrint[i][0] = (String)saleSubLedgerObjects[i][2];
        saleSubLedgerForPrint[i][1] = ((Double)saleSubLedgerObjects[i][5]).toString();
        saleSubLedgerForPrint[i][2] = ((Integer)saleSubLedgerObjects[i][6]).toString();
        saleSubLedgerForPrint[i][3] = ((Double)saleSubLedgerObjects[i][7]).toString();
      }
      //显示销售单打印窗口
      if(saleOrderPrintFrame == null){
        saleOrderPrintFrame = new SaleOrderPrintFrame();
        //使窗口居中对齐
        setCenterPosition(saleOrderPrintFrame);
        saleOrderPrintFrame.setVisible(true);
      }else{
        saleOrderPrintFrame.setVisible(true);
      }
      //为打印窗口传入数组参数
      saleOrderPrintFrame.setSaleLedger(saleLedger);
      saleOrderPrintFrame.setSaleSubLedger(saleSubLedgerForPrint);
      //显示总页码
      saleOrderPrintFrame.splitPage();
    }else if(actionCommand.equals("printAccountReceivable")){
      int selectedIndex = jList1.getSelectedIndex();
      if(selectedIndex == -1){
        JOptionPane.showMessageDialog(null, "先选择销售单.");
        return;
      }
      //取得销售单标识和完成状态
      String saleId = saleLedgers[selectedIndex][0];
      int onProcess = Integer.parseInt(saleLedgers[selectedIndex][9]);
      if(onProcess != 2){
        JOptionPane.showMessageDialog(null, "销售单未完成，不能打印应付票据.");
        return;
      }
      //根据销售单标识取得往来账数组
      String[] currentAccountLedger = stockManagementData.
          getCurrentAccountLedgerBylinkId(ledgerDate, "sa" + saleId);
      for(int i = 0; i < currentAccountLedger.length; i++){
        if(currentAccountLedger[i] == null){
          if(i == 9){
            currentAccountLedger[i] = "0";
          }else{
            currentAccountLedger[i] = "";
          }
        }
      }
      //显示应收票据打印窗口
      if(accountReceivablePrintFrame == null){
        accountReceivablePrintFrame = new AccountReceivablePrintFrame();
        //使窗口居中对齐
        setCenterPosition(accountReceivablePrintFrame);
        accountReceivablePrintFrame.setVisible(true);
      }else{
        accountReceivablePrintFrame.setVisible(true);
      }
      //为打印窗口传入数组参数
      accountReceivablePrintFrame.setCurrentAccountLedger(currentAccountLedger);
      //显示应收票据内容
      accountReceivablePrintFrame.showOnePage();
    }else if(actionCommand.equals("createSub")){
      //为销售账套明细表添加一个空行
      int objectsLength = saleSubLedgerObjects.length;
      Object[][] tempObjs = new Object[objectsLength + 1][8];
      System.arraycopy(saleSubLedgerObjects, 0, tempObjs, 0, objectsLength);
      tempObjs[objectsLength][0] = new Integer(0);
      tempObjs[objectsLength][1] = new String("");
      tempObjs[objectsLength][2] = new String("");
      tempObjs[objectsLength][3] = new Double(0);    //销售价
      tempObjs[objectsLength][4] = new Double(0);    //折扣
      tempObjs[objectsLength][5] = new Double(0);    //实际售价
      tempObjs[objectsLength][6] = new Integer(0);   //数量
      tempObjs[objectsLength][7] = new Double(0);    //金额
      saleSubLedgerObjects = tempObjs;
      this.showTableData(saleSubLedgerObjects);
    }else if(actionCommand.equals("deleteSub")){
      if(jTable1.getSelectedRowCount() == 0){
        JOptionPane.showMessageDialog(null, "请选择明细记录.");
        return;
      }
      //删除选择的记录
      int selectedIndex = jTable1.getSelectedRow();
      Object[][] tempObjs = new Object[saleSubLedgerObjects.length - 1][8];
      int line = 0;
      for(int i = 0; i < saleSubLedgerObjects.length; i++){
        if(i == selectedIndex){
          continue;
        }else{
          for(int j = 0; j < 8; j++){
            tempObjs[line][j] = saleSubLedgerObjects[i][j];
          }
          line++;
        }
      }
      saleSubLedgerObjects = tempObjs;
      this.showTableData(saleSubLedgerObjects);
    }else if(actionCommand.equals("exit")){
      exit();
    }
  }
  //使窗口居中的方法
  public void setCenterPosition(JFrame frame){
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = frame.getSize();
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }
    frame.setLocation( (screenSize.width - frameSize.width) / 2,
                           (screenSize.height - frameSize.height) / 2);
  }
}
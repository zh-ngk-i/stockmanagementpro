﻿package com.shinear.sm.stockmanageinterface;

import java.awt.*;
import java.awt.event.*;
import javax.swing.event.*;
import javax.swing.*;
import com.shinear.sm.data.*;
import com.shinear.sm.maininterface.*;
import com.shinear.sm.user.*;
import com.shinear.sm.method.*;
import java.util.Date;

public class StocktakeSubmitFrame extends JFrame implements ActionListener {
  JPanel contentPane;
  //创建标签控件
  JLabel jLabel1 = new JLabel();
  JLabel jLabel2 = new JLabel();
  JLabel jLabel3 = new JLabel();
  JLabel jLabel4 = new JLabel();
  JLabel jLabel5 = new JLabel();
  JLabel jLabel6 = new JLabel();
  JLabel jLabel7 = new JLabel();
  JLabel jLabel8 = new JLabel();
  JLabel jLabel9 = new JLabel();
  JLabel jLabel10 = new JLabel();
  JLabel jLabel11 = new JLabel();
  JLabel jLabel12 = new JLabel();
  //创建编辑框控件
  JTextField jTextField1 = new JTextField();
  JTextField jTextField2 = new JTextField();
  JTextField jTextField3 = new JTextField();
  JTextField jTextField4 = new JTextField();
  JTextField jTextField5 = new JTextField();
  JTextField jTextField6 = new JTextField();
  JTextField jTextField7 = new JTextField();
  JTextField jTextField8 = new JTextField();
  //创建按钮控件
  JButton jButton1 = new JButton();
  JButton jButton2 = new JButton();
  JButton jButton3 = new JButton();
  JButton jButton4 = new JButton();
  JButton jButton5 = new JButton();
  JButton jButton6 = new JButton();
  JButton jButton7 = new JButton();
  JButton jButton8 = new JButton();
  JButton jButton9 = new JButton();
  JButton jButton10 = new JButton();
  //创建滚动框控件
  JScrollPane jScrollPane1 = new JScrollPane();
  JScrollPane jScrollPane2 = new JScrollPane();
  JScrollPane jScrollPane3 = new JScrollPane();
  //创建列表框数据类和列表框控件
  DefaultListModel listData1 = new DefaultListModel();
  JList jList1 = new JList(listData1);
  //创建表格控件
  JTable jTable1 = new JTable();
  //创建表格模式类
  StockSubLedgerTableModel sslTableModel = new StockSubLedgerTableModel();
  //创建标题数组
  String[] colNames = {"明细编号", "单据编号", "商品条形码",  "盘点数量"};
  //创建下拉列表框控件
  JComboBox jComboBox1 = new JComboBox();
  //创建文本框控件
  JTextArea jTextArea1 = new JTextArea();
  //创建字体类
  Font dialog13 = new java.awt.Font("Dialog", 0, 13);
  //声明数据类
  StockManagementData stockManagementData = null;
  //声明用户类
  User user = null;
  //声明主窗口类
  StockManagementMainFrame stockManagementMainFrame = null;
  //创建库存账套数组
  String[][] stockLedgers = new String[0][13];
  //创建库存账套明细数组
  String[][] stockSubLedgers = new String[0][6];
  //创建库存账套明细表格数组
  Object[][] stockSubLedgerObjects = new Object[0][4];
  //创建方法类
  DataMethod dataMethod = new DataMethod();
  //创建动作字符串
  String action = "";
  //创建完成状态数组，3表示盘点单撤消，4表示盘点单完成
  String[] onProcesses = {"", "", "", "撤消", "完成"};
  //创建帐套日期字符串
  String ledgerDate = "";

  public StocktakeSubmitFrame(StockManagementMainFrame stockManagementMainFrame) {
    this.stockManagementMainFrame = stockManagementMainFrame;
    //取得主窗口的数据类
    stockManagementData = stockManagementMainFrame.getStockManagementData();
    //取得主窗口的用户类
    user = stockManagementMainFrame.getUser();
    //取得主窗口的账套日期
    ledgerDate = stockManagementMainFrame.getLedgerDate();
    //取得库存模块的用户权限
    int stockManageFunction = user.getStockManageFunction();
    //检查用户权限
    if ( (stockManageFunction & 16) != 16) {
      JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
      System.exit(0);
    }
    //检查账套日期
    if(ledgerDate.length() == 0){
      JOptionPane.showMessageDialog(null, user.getUserName() + "请选择账套.");
      return;
    }
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception  {
    contentPane = (JPanel) this.getContentPane();
    contentPane.setLayout(null);
    this.setSize(new Dimension(667, 632));
    this.setTitle("库存盘点计数窗口");
    //设置标签的属性
    jLabel1.setText("盘点单列表");
    jLabel1.setBounds(new Rectangle(28, 19, 134, 16));
    jLabel2.setText("查询条件");
    jLabel2.setBounds(new Rectangle(192, 45, 62, 16));
    jLabel3.setText("查询值");
    jLabel3.setBounds(new Rectangle(440, 45, 50, 16));
    jLabel4.setText("开始日期");
    jLabel4.setBounds(new Rectangle(192, 80, 67, 16));
    jLabel5.setText("结束日期");
    jLabel5.setBounds(new Rectangle(373, 80, 66, 16));
    jLabel6.setText("盘点单编号");
    jLabel6.setBounds(new Rectangle(192, 114, 66, 16));
    jLabel7.setText("盘点员");
    jLabel7.setBounds(new Rectangle(418, 114, 66, 16));
    jLabel8.setText("盘点仓库");
    jLabel8.setBounds(new Rectangle(192, 149, 66, 16));
    jLabel9.setText("盘点日期");
    jLabel9.setRequestFocusEnabled(true);
    jLabel9.setBounds(new Rectangle(192, 183, 66, 16));
    jLabel10.setText("完成状态");
    jLabel10.setBounds(new Rectangle(192, 218, 66, 16));
    jLabel11.setText("备注");
    jLabel11.setBounds(new Rectangle(418, 149, 66, 16));
    jLabel12.setText("盘点单明细列表");
    jLabel12.setBounds(new Rectangle(28, 294, 165, 16));
    //设置编辑框的属性
    jTextField1.setBounds(new Rectangle(492, 45, 133, 22));
    jTextField2.setBounds(new Rectangle(261, 80, 101, 22));
    jTextField3.setBounds(new Rectangle(439, 80, 101, 22));
    jTextField4.setEditable(false);
    jTextField4.setBounds(new Rectangle(261, 114, 147, 22));
    jTextField5.setEditable(false);
    jTextField5.setBounds(new Rectangle(478, 114, 147, 22));
    jTextField6.setBounds(new Rectangle(261, 149, 147, 22));
    jTextField7.setBounds(new Rectangle(261, 183, 147, 22));
    jTextField8.setEditable(false);
    jTextField8.setBounds(new Rectangle(261, 218, 147, 22));
    //设置按钮的属性
    jButton1.setText("查询");
    jButton1.setActionCommand("search");
    jButton1.setBounds(new Rectangle(546, 80, 79, 22));
    jButton2.setText("创建");
    jButton2.setActionCommand("createStockLedger");
    jButton2.setBounds(new Rectangle(28, 257, 85, 25));
    jButton3.setText("修改");
    jButton3.setActionCommand("updateStockLedger");
    jButton3.setBounds(new Rectangle(113, 257, 85, 25));
    jButton4.setText("撤消");
    jButton4.setActionCommand("cancelStockLedger");
    jButton4.setBounds(new Rectangle(199, 257, 85, 25));
    jButton5.setText("恢复");
    jButton5.setActionCommand("restoreStockLedger");
    jButton5.setBounds(new Rectangle(284, 257, 85, 25));
    jButton6.setText("确定");
    jButton6.setActionCommand("ok");
    jButton6.setBounds(new Rectangle(369, 257, 85, 25));
    jButton7.setText("取消");
    jButton7.setActionCommand("cancel");
    jButton7.setBounds(new Rectangle(455, 257, 85, 25));
    jButton8.setText("退出");
    jButton8.setActionCommand("exit");
    jButton8.setBounds(new Rectangle(540, 257, 85, 25));
    jButton9.setText("创建明细记录");
    jButton9.setActionCommand("createSub");
    jButton9.setBounds(new Rectangle(28, 550, 281, 25));
    jButton10.setText("删除明细记录");
    jButton10.setActionCommand("deleteSub");
    jButton10.setBounds(new Rectangle(344, 550, 281, 25));
    //设置滚动框的属性
    jScrollPane1.setBounds(new Rectangle(28, 45, 152, 195));
    jScrollPane2.setBounds(new Rectangle(418, 175, 207, 66));
    jScrollPane3.setBounds(new Rectangle(28, 315, 597, 221));
    jScrollPane1.getViewport().add(jList1, null);
    jScrollPane2.getViewport().add(jTextArea1, null);
    jScrollPane3.getViewport().add(jTable1, null);
    //为列表框加入选择接收器
    jList1.addListSelectionListener(new ListSelectionListener() {
      public void valueChanged(ListSelectionEvent e) {
        //当多种事件被激发的时候,不执行接收器后面的代码
        if (e.getValueIsAdjusting()) return;
        jList1_valueChanged(e);
      }
    });
    //设置下拉列表框的属性
    jComboBox1.setBounds(new Rectangle(261, 45, 156, 22));
    jComboBox1.addItem("根据单据编号查询");
    jComboBox1.addItem("根据盘点员查询");
    jComboBox1.addItem("根据盘点仓库名查询");
    jComboBox1.addItem("根据完成状态查询");
    jComboBox1.addItem("根据盘点日期查询");
    //为面板加入各个控件
    contentPane.add(jLabel1, null);
    contentPane.add(jLabel2, null);
    contentPane.add(jLabel3, null);
    contentPane.add(jLabel4, null);
    contentPane.add(jLabel5, null);
    contentPane.add(jLabel6, null);
    contentPane.add(jLabel7, null);
    contentPane.add(jLabel8, null);
    contentPane.add(jLabel9, null);
    contentPane.add(jLabel10, null);
    contentPane.add(jLabel11, null);
    contentPane.add(jLabel12, null);
    contentPane.add(jButton1, null);
    contentPane.add(jButton2, null);
    contentPane.add(jButton3, null);
    contentPane.add(jButton4, null);
    contentPane.add(jButton5, null);
    contentPane.add(jButton6, null);
    contentPane.add(jButton7, null);
    contentPane.add(jButton8, null);
    contentPane.add(jButton9, null);
    contentPane.add(jButton10, null);
    contentPane.add(jTextField1, null);
    contentPane.add(jTextField2, null);
    contentPane.add(jTextField3, null);
    contentPane.add(jTextField4, null);
    contentPane.add(jTextField5, null);
    contentPane.add(jTextField6, null);
    contentPane.add(jTextField7, null);
    contentPane.add(jTextField8, null);
    contentPane.add(jScrollPane1, null);
    contentPane.add(jScrollPane2, null);
    contentPane.add(jScrollPane3, null);
    contentPane.add(jComboBox1, null);
    //设置窗口类的字体和为按钮加入动作接收器
    setupFontAndListener();
    //检查按钮状态
    this.checkBtn(false);
    this.checkSubBtn(false);
  }
  //设置窗口类的字体和为按钮加入动作接收器的方法
  public void setupFontAndListener(){
    Component[] components = contentPane.getComponents();
    //创建临时按钮控件
    JButton tmpBtn = new JButton();
    for(int i = 0; i < components.length; i++){
      components[i].setFont(dialog13);
      if(components[i].getClass().getName().equals("javax.swing.JButton")){
        tmpBtn = (JButton)components[i];
        tmpBtn.addActionListener(this);
      }
    }
  }
  //退出方法
  public void exit(){
    //隐藏窗口
    this.setVisible(false);
    //清空数组的内容
    stockLedgers = new String[0][13];
    stockSubLedgers = new String[0][6];
    stockSubLedgerObjects = new Object[0][4];
    //清空列表框的内容
    listData1.clear();
    //清空文本框的内容
    jTextArea1.setText("");
    //清空表格的内容
    this.showTableData(stockSubLedgerObjects);
    //取得面板上的所有控件
    Component[] components = contentPane.getComponents();
    //创建临时编辑框控件
    JTextField tmpTextField = new JTextField();
    for(int i = 0; i < components.length; i++){
      if(components[i].getClass().getName().equals("javax.swing.JTextField")){
        tmpTextField = (JTextField)components[i];
        //清空编辑框的内容
        tmpTextField.setText("");
      }
    }
  }
  //设置用户的方法
  public void setUser(User user) {
    this.user = user;
  }
  //设置账套的方法
  public void setLedgerDate(String ledgerDate) {
    this.ledgerDate = ledgerDate;
  }
  protected void processWindowEvent(WindowEvent e) {
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      exit();
    }
  }
  //显示查询盘点单的方法
  public void showSearchStockLedger(){
    listData1.clear();
    //为盘点单列表框加入盘点单数据
    for(int i = 0; i < stockLedgers.length; i++){
      listData1.addElement(stockLedgers[i][0]);
    }
  }
  //显示单个盘点单的方法
  public void showStockLedger(){
    //取得当前选择项的位置
    int selectedIndex = jList1.getSelectedIndex();
    //当列表框不处于选择状态，不显示数据
    if(selectedIndex == -1){
       return;
    }
    //显示盘点单的数据
    jTextField4.setText(stockLedgers[selectedIndex][0]);   //票据编号
    jTextField5.setText(stockLedgers[selectedIndex][3]);   //盘点员
    jTextField6.setText(stockLedgers[selectedIndex][8]);   //盘点仓库
    jTextField7.setText(stockLedgers[selectedIndex][9]);   //盘点日期
    jTextField8.setText(onProcesses[Integer.parseInt(stockLedgers[selectedIndex][11])]);
    jTextArea1.setText(stockLedgers[selectedIndex][12]);
    //显示盘点单明细数据
    this.showStockSubLedger();
  }
  //显示盘点单明细数据的方法
  public void showStockSubLedger(){
    //取得当前选择项的位置
    int selectedIndex = jList1.getSelectedIndex();
    String orderId = stockLedgers[selectedIndex][0];
    stockSubLedgers = stockManagementData.getStockSubLedgerByOrderId(ledgerDate, orderId);
    //将数组数据转换为表格数据
    stockSubLedgerObjects = new Object[stockSubLedgers.length][4];
    for(int i = 0; i < stockSubLedgers.length; i++){
      stockSubLedgerObjects[i][0] = new Integer(stockSubLedgers[i][0]);
      stockSubLedgerObjects[i][1] = stockSubLedgers[i][1];
      stockSubLedgerObjects[i][2] = stockSubLedgers[i][2];
      int quantity = Integer.parseInt(stockSubLedgers[i][4]);
      stockSubLedgerObjects[i][3] = new Integer(quantity);
    }
    //显示表格的内容
    this.showTableData(stockSubLedgerObjects);
  }
  //转换表格数据的方法
  public void transferTableData(){
    stockSubLedgers = new String[stockSubLedgerObjects.length][6];
    for(int i = 0; i < stockSubLedgerObjects.length; i++){
      stockSubLedgers[i][0] = ((Integer)stockSubLedgerObjects[i][0]).toString();
      stockSubLedgers[i][1] = (String)stockSubLedgerObjects[i][1];
      stockSubLedgers[i][2] = (String)stockSubLedgerObjects[i][2];
      stockSubLedgers[i][3] = "0";
      stockSubLedgers[i][4] = ((Integer)stockSubLedgerObjects[i][3]).toString();
      //由于盘点单只记录商品条形码和数量，有效期写入系统当前日期
      stockSubLedgers[i][5] = dataMethod.getCurrentDate().toString();
    }
  }
  //显示表格内容的方法
  public void showTableData(Object[][] detail){
    //设置表格的标题
    sslTableModel.setColumnNames(colNames);
    //设置表格的数据
    sslTableModel.setData(detail);
    jTable1 = new JTable(sslTableModel);
    //设置表格的字体
    jTable1.setFont(dialog13);
    //将数据表格加入数据滚动框
    jScrollPane3.getViewport().add(jTable1, null);
    //设置列的宽度
    jTable1.getColumnModel().getColumn(0).setPreferredWidth(20);
    jTable1.getColumnModel().getColumn(1).setPreferredWidth(50);
    jTable1.getColumnModel().getColumn(2).setPreferredWidth(50);
    jTable1.getColumnModel().getColumn(3).setPreferredWidth(10);
  }
  //检查明细账的商品条形码方法
  public int checkStockSubLedgerGoodsBarCode(){
    int result = 0;
    for(int i = 0; i < stockSubLedgerObjects.length; i++){
      result = stockManagementData.checkGoodsBarCode((String)stockSubLedgerObjects[i][2]);
      if(result == 0){
        JOptionPane.showMessageDialog(null, "第" + (i + 1) + "行的商品条形码在商品数据库中"
                                      + "不存在，请打开商品数据管理窗口添加.");
        return 0;
      }
    }
    return 1;
  }
  //检查明细账数量是否为正的方法
  public int checkStockSubLedgerQuantity(){
    int quantity = 0;
    for(int i = 0; i < stockSubLedgerObjects.length; i++){
      quantity = ((Integer)stockSubLedgerObjects[i][3]).intValue();
      if(quantity < 0){
        JOptionPane.showMessageDialog(null, "第" + (i+1) + "行的盘点数量输入错误，盘点数量必须是正数.");
        return 0;
      }
    }
    return 1;
  }
  //清空单个盘点单显示的方法
  public void clearStockLedger(){
    jTextField4.setText("");
    jTextField5.setText("");
    jTextField6.setText("");
    jTextField7.setText("");
    jTextField8.setText("");
    jTextArea1.setText("");
    stockSubLedgers = new String[0][6];
    stockSubLedgerObjects = new Object[0][4];
    this.showTableData(stockSubLedgerObjects);
  }
  //检查按钮的状态
  public void checkBtn(boolean isManipulated){
    if(isManipulated){
      jButton2.setEnabled(false);
      jButton3.setEnabled(false);
      jButton4.setEnabled(false);
      jButton5.setEnabled(false);
      jButton6.setEnabled(true);
      jButton7.setEnabled(true);
    }else{
      jButton2.setEnabled(true);
      jButton3.setEnabled(true);
      jButton4.setEnabled(true);
      jButton5.setEnabled(true);
      jButton6.setEnabled(false);
      jButton7.setEnabled(false);
    }
  }
  //检查明细账按钮的状态
  public void checkSubBtn(boolean isCreated){
    if(isCreated){
      jButton9.setEnabled(true);
      jButton10.setEnabled(true);
    }else{
      jButton9.setEnabled(false);
      jButton10.setEnabled(false);
    }
  }
  //列表1的选择事件
  void jList1_valueChanged(ListSelectionEvent e) {
    if(listData1.size() > 0){
      this.showStockLedger();
    }else{
      this.clearStockLedger();
    }
  }
  //查询方法
  public void search(){
    //取得查询选项
    int selectedIndex = jComboBox1.getSelectedIndex();
    //取得编辑框的变量
    String searchValue = jTextField1.getText().trim();
    String startDateStr = jTextField2.getText().trim();
    String endDateStr = jTextField3.getText().trim();
    if (selectedIndex == 0 | selectedIndex == 1 | selectedIndex == 2 |
        selectedIndex == 3) {
      if (searchValue.length() == 0) {
        JOptionPane.showMessageDialog(null, "请输入查询值");
        return;
      }
      switch (selectedIndex) {
        case 0:
          //根据盘点单编号取得记录
          stockLedgers = stockManagementData.getStockLedgerByStringField(
              ledgerDate, "orderId", searchValue, 13);
          break;
        case 1:
          //根据商品盘点员取得记录
          stockLedgers = stockManagementData.getStockLedgerByStringField(
              ledgerDate, "submitUser", searchValue, 13);
          break;
        case 2:
          //根据盘点仓库名字取得记录
          stockLedgers = stockManagementData.getStockLedgerByStringField(
              ledgerDate, "warehouse", searchValue, 13);
          break;
        case 3:
          if(dataMethod.checkInt(searchValue) == 0){
            JOptionPane.showMessageDialog(null, "按完成状态查询时，输入值必须是整数，"
                                          + "3表示撤消，4表示完成.");
            return;
          }
          //根据完成状态取得记录
          stockLedgers = stockManagementData.getStockLedgerByOnProcess(
              ledgerDate, 13, Integer.parseInt(searchValue));
          break;
      }
    }else{
      java.sql.Timestamp startDate = dataMethod.transferDate(startDateStr);
      java.sql.Timestamp endDate = dataMethod.transferEndDate(endDateStr);
      if(startDate == null | endDate == null){
        JOptionPane.showMessageDialog(null, "日期输入错误，正确的日期格式是"
                                      + "yyyy-mm-dd（年-月-日），如2004-1-1");
        return;
      }
      //根据日期取得记录
      stockLedgers = stockManagementData.getStockLedgerByOrderDate(ledgerDate,
          startDate, endDate, 13);
    }
    this.showSearchStockLedger();
  }
  //单击事件
  public void actionPerformed(ActionEvent e) {
    //取得按钮的动作字符串
    String actionCommand = e.getActionCommand().trim();
    //检查打开的账套是否当前账套
    if (actionCommand.equals("createStockLedger") |
        actionCommand.equals("updateStockLedger") |
        actionCommand.equals("cancelStockLedger") |
        actionCommand.equals("restoreStockLedger")) {
      int result = stockManagementData.isCurrentLedger(ledgerDate);
      if(result == 0){
        JOptionPane.showMessageDialog(null, ledgerDate + "是往期账套，不能进行添加、修改和撤消操作.");
        return;
      }
    }
    if (actionCommand.equals("search")) {
      //查询
      search();
    }else if(actionCommand.equals("createStockLedger")){
      action = "create";
      this.clearStockLedger();
      this.checkBtn(true);
      this.checkSubBtn(true);
    }else if(actionCommand.equals("updateStockLedger")){
      action = "update";
      this.checkBtn(true);
    }else if(actionCommand.equals("cancelStockLedger")){
      action = "cancel";
      this.checkBtn(true);
    }else if(actionCommand.equals("restoreStockLedger")){
      action = "restore";
      this.checkBtn(true);
    }else if(actionCommand.equals("ok")){
      int selectedIndex = jList1.getSelectedIndex();
      //创建库存账套数据表的单个记录数组
      String[] stockLedger = new String[13];
      //取得盘点单的值
      stockLedger[0] = "";                           //单据编号
      stockLedger[1] = "13";                         //13表示盘点单
      stockLedger[2] = "";                           //关联标识
      stockLedger[3] = user.getUserName();           //盘点用户
      stockLedger[4] = "";
      stockLedger[5] = "";
      stockLedger[6] = "";
      stockLedger[7] = "";
      stockLedger[8] = jTextField6.getText().trim();  //盘点仓库
      stockLedger[9] = jTextField7.getText().trim();  //盘点日期
      stockLedger[10] = dataMethod.getCurrentDate().toString(); //系统日期
      //4表示盘点单完成,3表示盘点单撤消
      stockLedger[11] = "4";
      stockLedger[12] = jTextArea1.getText().trim();
      int result = 0;
      if(action.equals("update") | action.equals("create")){
        //检查盘点仓库名字
        result = stockManagementData.checkWarehouse(stockLedger[8]);
        if(result == 0){
          JOptionPane.showMessageDialog(null, stockLedger[8] + "在仓库数据库中"
                                        + "不存在，请打开仓库数据管理窗口添加.");
          return;
        }
        //检查商品盘点日期
        if(dataMethod.transferDateTime(stockLedger[9]) == null){
          JOptionPane.showMessageDialog(null, "盘点日期输入错误，正确的日期格式是"
                                      + "yyyy-mm-dd（年-月-日），如2004-1-1");
          return;
        }
        //检查盘点单明细账的商品条形码、盘点数量
        result = this.checkStockSubLedgerGoodsBarCode();
        if(result == 0)  return;
        result = this.checkStockSubLedgerQuantity();
        if(result == 0)  return;
        //转换表格数组
        this.transferTableData();
      }
      if(action.equals("create")){
        //检查明细账是否为空
        if(stockSubLedgerObjects.length == 0){
          JOptionPane.showMessageDialog(null, "明细账数据表为空，不可以创建盘点单.");
          return;
        }
        //添加盘点单
        result = stockManagementData.createStockLedgerAndSub(ledgerDate,
            stockLedger, stockSubLedgers);
        if(result == 1){
          JOptionPane.showMessageDialog(null, "盘点单添加成功，请重新执行查询操作显示新的盘点单.");
        }else{
          JOptionPane.showMessageDialog(null, "盘点单添加失败，请检查输入值是否大于字段范围.");
        }
      }else if (action.equals("update")){
        //取得原来的单据编号
        stockLedger[0] = stockLedgers[selectedIndex][0].trim();
        //修改盘点单
        result = stockManagementData.updateStockLedgerAndSub(ledgerDate,
            stockLedger, stockSubLedgers);
        if(result == 1){
          JOptionPane.showMessageDialog(null, "盘点单修改成功.");
          //更新数组的数据
          for (int i = 0; i < 13; i++) {
            stockLedgers[selectedIndex][i] = stockLedger[i];
          }
        }else{
          JOptionPane.showMessageDialog(null, "盘点单修改失败，请检查输入值是否大于字段范围.");
        }
      }else if (action.equals("cancel")){
        //撤消盘点单, 3表示撤消盘点单
        result = stockManagementData.signStockLedgerAndSubForFinish(ledgerDate,
            "submitUser", user.getUserName(), stockLedgers[selectedIndex][0], 3,
            stockLedger[12]);
        if(result == 1){
          JOptionPane.showMessageDialog(null, "盘点单撤消成功.");
          //更新完成状态编辑框的值
          jTextField8.setText(onProcesses[3]);
          //更新数组的数据
          stockLedgers[selectedIndex][11] = "3";
          stockLedgers[selectedIndex][12] = stockLedger[12];
        }else{
          JOptionPane.showMessageDialog(null, "盘点单撤消失败.");
        }
      }else if (action.equals("restore")){
        //恢复盘点单,4表示恢复盘点单
        result = stockManagementData.signStockLedgerAndSubForFinish(ledgerDate,
            "submitUser", user.getUserName(), stockLedgers[selectedIndex][0], 4,
            stockLedger[12]);
        if(result == 1){
          JOptionPane.showMessageDialog(null, "盘点单恢复成功.");
          //更新完成状态编辑框的值
          jTextField8.setText(onProcesses[4]);
          //更新数组的数据
          stockLedgers[selectedIndex][11] = "4";
          stockLedgers[selectedIndex][12] = stockLedger[12];
        }else{
          JOptionPane.showMessageDialog(null, "盘点单恢复失败.");
        }
      }
      this.checkSubBtn(false);
      this.checkBtn(false);
    }else if(actionCommand.equals("cancel")){
      this.jList1_valueChanged(null);
      this.checkBtn(false);
      this.checkSubBtn(false);
    }else if(actionCommand.equals("createSub")){
      //添加一个空行
      int objectsLength = stockSubLedgerObjects.length;
      Object[][] tempObjs = new Object[objectsLength + 1][4];
      System.arraycopy(stockSubLedgerObjects, 0, tempObjs, 0, objectsLength);
      tempObjs[objectsLength][0] = new Integer(0);
      tempObjs[objectsLength][1] = new String("");
      tempObjs[objectsLength][2] = new String("");
      tempObjs[objectsLength][3] = new Integer(0);
      stockSubLedgerObjects = tempObjs;
      this.showTableData(stockSubLedgerObjects);
    }else if(actionCommand.equals("deleteSub")){
      if(jTable1.getSelectedRowCount() == 0){
        JOptionPane.showMessageDialog(null, "请选择明细记录.");
        return;
      }
      //删除选择的记录
      int selectedIndex = jTable1.getSelectedRow();
      Object[][] tempObjs = new Object[stockSubLedgerObjects.length - 1][4];
      int line = 0;
      for(int i = 0; i < stockSubLedgerObjects.length; i++){
        if(i == selectedIndex){
          continue;
        }else{
          for(int j = 0; j < 4; j++){
            tempObjs[line][j] = stockSubLedgerObjects[i][j];
          }
          line++;
        }
      }
      stockSubLedgerObjects = tempObjs;
      this.showTableData(stockSubLedgerObjects);
    }else if(actionCommand.equals("exit")){
      exit();
    }
  }
}

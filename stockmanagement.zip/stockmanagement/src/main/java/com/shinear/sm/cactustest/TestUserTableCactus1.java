﻿package com.shinear.sm.cactustest;

import org.apache.cactus.*;
import com.shinear.sm.stockmanagementpro.*;
import javax.naming.*;
import java.util.Collection;
import java.rmi.RemoteException;

public class TestUserTableCactus1 extends ServletTestCase {
  private static final String ERROR_NULL_REMOTE = "对象未定义.";
  private static final int MAX_OUTPUT_LINE_LENGTH = 100;
  private boolean logging = false;
  private UserTableHome userTableHome = null;
  private UserTable userTable = null;

  public TestUserTableCactus1(String name) {
    super(name);
  }
  //初始化EJB创建接口
  public void initializeLocalHome() throws Exception {
    Context context = new InitialContext();
    userTableHome = (UserTableHome) context.lookup("UserTable");
  }
  public void setUp() throws Exception {
    super.setUp();
    initializeLocalHome();
  }
  public void tearDown() throws Exception {
    userTableHome = null;
    userTable = null;
    super.tearDown();
  }
  //测试记录创建方法
  public void testCreateUser() throws Exception{
    String userName = "test";
    String userPassword = "test";
    int baseInforFunction = 0;
    int stockFunction = 0;
    int stockManageFunction = 0;
    int saleFunction = 0;
    //创建一条新记录
    userTable = userTableHome.create(userName, userPassword, baseInforFunction,
                                     stockFunction, stockManageFunction,
                                     saleFunction);
  }
  //测试记录更新方法
  public void testUpdateUser() throws Exception{
    String userName = "test";
    String userPassword = "test1";
    int baseInforFunction = 1;
    int stockFunction = 1;
    int stockManageFunction = 1;
    int saleFunction = 1;
    //根据主键找到记录test
    userTable = userTableHome.findByPrimaryKey(userName);
    //更改记录
    userTable.setUserPassword(userPassword);
    userTable.setBaseInforFunction(baseInforFunction);
    userTable.setStockFunction(stockFunction);
    userTable.setStockManageFunction(stockManageFunction);
    userTable.setSaleFunction(saleFunction);
    //检查更新值
    this.assertEquals("return value", userPassword, userTable.getUserPassword());
    this.assertEquals("return value", baseInforFunction,
                      userTable.getBaseInforFunction());
    this.assertEquals("return value", stockFunction, userTable.getStockFunction());
    this.assertEquals("return value", stockManageFunction,
                      userTable.getStockManageFunction());
    this.assertEquals("return value", saleFunction, userTable.getSaleFunction());
  }
  //测根据据用户名返回记录的方法
  public void testFindByUserName() throws Exception{
    //查找用户名为jack的记录
    Collection col = userTableHome.findByUserName("%jack%");
    if(col.size() > 0){
      java.util.Iterator iterator = col.iterator();
      while (iterator.hasNext()) {
        //取得远程接口
        userTable = (UserTable) javax.rmi.PortableRemoteObject.narrow(
            iterator.next(), UserTable.class);
        this.assertEquals("return value", "jack", userTable.getUserName());
      }
    }
  }
  //测试记录删除方法
  public void testDeleteUser() throws Exception{
    String userName = "test";
    //根据主键找到记录test
    userTable = userTableHome.findByPrimaryKey(userName);
    //删除记录
    userTable.remove();
    //查找用户名为test的记录
    Collection col = userTableHome.findByUserName("test");
    this.assertEquals("return value", 0, col.size());
  }
}
﻿package com.shinear.sm.cactustest;

import org.apache.cactus.*;
import com.shinear.sm.stockmanagementpro.*;
import javax.naming.*;
import java.util.Collection;
import java.rmi.RemoteException;


public class TestWarehouseCactus1 extends ServletTestCase {
  private static final String ERROR_NULL_REMOTE = "接口未定义.";
  private static final int MAX_OUTPUT_LINE_LENGTH = 100;
  private boolean logging = false;
  private WarehouseHome warehouseHome = null;
  private Warehouse warehouse = null;

  public TestWarehouseCactus1(String name) {
    super(name);
  }

  public void initializeLocalHome() throws Exception {
    Context context = new InitialContext();
    warehouseHome = (WarehouseHome) context.lookup("Warehouse");
  }

  public void setUp() throws Exception {
    super.setUp();
    initializeLocalHome();
  }

  public void tearDown() throws Exception {
    warehouseHome = null;
    warehouse = null;
    super.tearDown();
  }
  //测试创建仓库的方法
  public void testWarehouseCreate() throws Exception{
    String[] warehouse = new String[]{"测试仓库1", "拼单码1", "第1厂区", "描述1"};
    //创建仓库
    warehouseHome.create(warehouse[0], warehouse[1], warehouse[2], warehouse[3]);
    warehouse = new String[]{"测试仓库2", "拼单码2", "第2厂区", "描述2"};
    //创建仓库
    warehouseHome.create(warehouse[0], warehouse[1], warehouse[2], warehouse[3]);
    warehouse = new String[]{"测试仓库3", "拼单码3", "第3厂区", "描述3"};
    //创建仓库
    warehouseHome.create(warehouse[0], warehouse[1], warehouse[2], warehouse[3]);
  }
  //测试修改仓库的方法
  public void testWarehouseUpdate() throws Exception{
    String[] warehouseArray = new String[]{"测试仓库1", "拼单码1(u)", "第1厂区(u)", "描述1(u)"};
    warehouse = warehouseHome.findByPrimaryKey(warehouseArray[0]);
    //更新测试仓库的值
    warehouse.setPyCode(warehouseArray[1]);
    warehouse.setLocation(warehouseArray[2]);
    warehouse.setDescription(warehouseArray[3]);
  }
  //测试取得全部记录的方法
  public void testFindAll() throws Exception {
    Collection returnValue = warehouseHome.findAll();
    this.assertEquals("", 3, returnValue.size());
  }
  //测试删除仓库的方法
  public void testWarehouseDelete() throws Exception{
    String[] warehouseArray = new String[]{"测试仓库1", "测试仓库2", "测试仓库3"};
    warehouse = warehouseHome.findByPrimaryKey(warehouseArray[0]);
    //删除仓库
    warehouse.remove();
    warehouse = warehouseHome.findByPrimaryKey(warehouseArray[1]);
    //删除仓库
    warehouse.remove();
    warehouse = warehouseHome.findByPrimaryKey(warehouseArray[2]);
    //删除仓库
    warehouse.remove();
  }
}
﻿package com.shinear.sm.servlet;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;
import com.shinear.sm.data.*;
import com.shinear.sm.user.*;

public class Login extends HttpServlet {
  private static final String CONTENT_TYPE = "text/html; charset=GBK";
  public void init() throws ServletException {
  }

  public void doPost(HttpServletRequest request, HttpServletResponse response) throws
      ServletException, IOException {
    //设置取得字符串的编码机制
    request.setCharacterEncoding("GBK");
    //设置字符输出的编码机制
    response.setContentType(CONTENT_TYPE);
    //取得html代码输出类
    PrintWriter out = response.getWriter();
    //通过HttpServlet类的getServletContext方法取得application的对象
    ServletContext application = getServletContext();
    //创建session对象
    HttpSession session = request.getSession();
    //声明页面转向类
    RequestDispatcher requestDispatcher = null;
    //取得按钮的字符
    String action = request.getParameter("action");
    //创建数据类
    StockManagementData stockManagementData = new StockManagementData();
    if(action.equals("登陆")){
      //取得用户名字和密码
      String userName = request.getParameter("userName");
      String userPassword = request.getParameter("userPassword");
      int[] result = stockManagementData.checkUser(userName, userPassword);
      if( result[0] == -1){
        //创建页面转向类
        requestDispatcher = application.getRequestDispatcher("/infor.jsp");
        request.setAttribute("infor", "用户的名字和密码不正确，请<a href=\"javascript:"
                             + "history.back()\">重新输入</a>.");
        requestDispatcher.forward(request, response);
      }else{
        //创建用户类
        User user = new User(userName, userPassword, result[0], result[1], result[2],
                        result[3]);
        //将用户放入session对象
        session.setAttribute("user", user);
        //创建页面转向类
        requestDispatcher = application.getRequestDispatcher("/infor.jsp");
        request.setAttribute("infor", "成功登陆，请返回主页进行相关信息浏览.");
        requestDispatcher.forward(request, response);
      }
    }
  }
  public void destroy() {
  }
}
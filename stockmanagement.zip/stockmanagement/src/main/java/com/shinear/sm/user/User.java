﻿package com.shinear.sm.user;

import java.io.Serializable;

public class User implements Serializable{
  private String userName;
  private String userPassword;
  private int baseInforFunction;
  private int stockFunction;
  private int stockManageFunction;
  private int saleFunction;

  //用户类的构造方法
  public User(String userName, String userPassword, int baseInforFunction,
              int stockFunction, int stockManageFunction, int saleFunction) {
    this.userName = userName;
    this.userPassword = userPassword;
    this.baseInforFunction = baseInforFunction;
    this.stockFunction = stockFunction;
    this.stockManageFunction = stockManageFunction;
    this.saleFunction = saleFunction;
  }
  //取得用户名字的方法
  public String getUserName() {
    return userName;
  }
  //取得用户密码的方法
  public String getUserPassword() {
    return userPassword;
  }
  //设置用户密码的方法
  public void setUserPassword(String userPassword) {
    this.userPassword = userPassword;
  }
  //取得基础信息模块的用户权限的方法
  public int getBaseInforFunction() {
    return baseInforFunction;
  }
  //设置基础信息模块的用户权限的方法
  public void setBaseInforFunction(int baseInforFunction) {
    this.baseInforFunction = baseInforFunction;
  }
  //取得进货模块的用户权限的方法
  public int getStockFunction() {
    return stockFunction;
  }
  //设置进货模块的用户权限的方法
  public void setStockFunction(int stockFunction) {
    this.stockFunction = stockFunction;
  }
  //取得库存模块的用户权限的方法
  public int getStockManageFunction() {
    return stockManageFunction;
  }
  //设置库存模块的用户权限的方法
  public void setStockManageFunction(int stockManageFunction) {
    this.stockManageFunction = stockManageFunction;
  }
  //取得销售模块的用户权限的方法
  public int getSaleFunction() {
    return saleFunction;
  }
  //设置销售模块的用户权限的方法
  public void setSaleFunction(int saleFunction) {
    this.saleFunction = saleFunction;
  }
}
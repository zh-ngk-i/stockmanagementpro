﻿package com.shinear.sm.stockmanagementpro;

import javax.ejb.*;

abstract public class GoodsCategoryBean implements EntityBean {
  EntityContext entityContext;
  public java.lang.Integer ejbCreate(java.lang.Integer categoryId, int parentId, java.lang.String categoryName, java.lang.String categoryDescription) throws CreateException {
    setCategoryId(categoryId);
    setParentId(parentId);
    setCategoryName(categoryName);
    setCategoryDescription(categoryDescription);
    return null;
  }

  public void ejbPostCreate(java.lang.Integer categoryId, int parentId, java.lang.String categoryName, java.lang.String categoryDescription) throws CreateException {
  }
  public void ejbRemove() throws RemoveException {
  }
  public abstract void setCategoryId(java.lang.Integer categoryId);
  public abstract void setParentId(int parentId);
  public abstract void setCategoryName(java.lang.String categoryName);
  public abstract void setCategoryDescription(java.lang.String categoryDescription);
  public abstract java.lang.Integer getCategoryId();
  public abstract int getParentId();
  public abstract java.lang.String getCategoryName();
  public abstract java.lang.String getCategoryDescription();
  public void ejbLoad() {
  }
  public void ejbStore() {
  }
  public void ejbActivate() {
  }
  public void ejbPassivate() {
  }
  public void unsetEntityContext() {
    this.entityContext = null;
  }
  public void setEntityContext(EntityContext entityContext) {
    this.entityContext = entityContext;
  }
}
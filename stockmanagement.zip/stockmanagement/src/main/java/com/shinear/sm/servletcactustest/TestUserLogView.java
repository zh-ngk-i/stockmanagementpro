﻿package com.shinear.sm.servletcactustest;

import org.apache.cactus.*;
import com.shinear.sm.servlet.*;
import javax.servlet.*;
import java.io.*;

public class TestUserLogView extends ServletTestCase {
  private UserLogView userLogView = null;

  public TestUserLogView(String name) {
    super(name);
  }

  protected void setUp() throws Exception {
    super.setUp();
    userLogView = new UserLogView();
    //初始化ServletContext对象
    userLogView.init(config);
    request.setCharacterEncoding("GBK");
  }

  protected void tearDown() throws Exception {
    userLogView = null;
    super.tearDown();
  }
  //为doPost方法传入参数，测试按程序名字查询返回的结果
  public void beginPostMethodByProgramName(WebRequest theRequest) {
    //通过WebRequest类设置参数
    theRequest.addParameter("selectedIndex", "0", WebRequest.POST_METHOD);
    theRequest.addParameter("searchValue", "登陆", WebRequest.POST_METHOD);
  }

  //测试按程序名字查询返回的结果
  public void testPostMethodByProgramName() throws ServletException, IOException {
    //将request对象和response对象传入Servlet
    userLogView.doPost(request, response);
    //取得用户数组
    String[][] userLog = (String[][])request.getAttribute("userLog");
    this.assertEquals("", 110, userLog.length);
  }
  //为doPost方法传入参数，测试按操作内容查询返回的结果
  public void beginPostMethodByOperationContent(WebRequest theRequest) {
    //通过WebRequest类设置参数
    theRequest.addParameter("selectedIndex", "1", WebRequest.POST_METHOD);
    theRequest.addParameter("searchValue", "删除", WebRequest.POST_METHOD);
  }
  //测试按操作内容查询返回的结果
  public void testPostMethodByOperationContent() throws ServletException, IOException {
    //将request对象和response对象传入Servlet
    userLogView.doPost(request, response);
    //取得用户数组
    String[][] userLog = (String[][])request.getAttribute("userLog");
    this.assertEquals("", 2, userLog.length);
  }
  //为doPost方法传入参数，测试按用户名字查询返回的结果
  public void beginPostMethodByUserName(WebRequest theRequest) {
    //通过WebRequest类设置参数
    theRequest.addParameter("selectedIndex", "2", WebRequest.POST_METHOD);
    theRequest.addParameter("searchValue", "ame", WebRequest.POST_METHOD);
  }
  //测试按用户名字查询返回的结果
  public void testPostMethodByUserName() throws ServletException, IOException {
    //将request对象和response对象传入Servlet
    userLogView.doPost(request, response);
    //取得用户数组
    String[][] userLog = (String[][])request.getAttribute("userLog");
    this.assertEquals("", 23, userLog.length);
  }
  //为doPost方法传入参数，测试按操作日期查询返回的结果
  public void beginPostMethodByOperationDate(WebRequest theRequest) {
    //通过WebRequest类设置参数
    theRequest.addParameter("selectedIndex", "3", WebRequest.POST_METHOD);
    theRequest.addParameter("searchValue", "", WebRequest.POST_METHOD);
    theRequest.addParameter("startDate", "2004-5-4", WebRequest.POST_METHOD);
    theRequest.addParameter("endDate", "2004-5-8", WebRequest.POST_METHOD);
  }

  //测试按操作日期查询返回的结果
  public void testPostMethodByOperationDate() throws ServletException, IOException {
    //将request对象和response对象传入Servlet
    userLogView.doPost(request, response);
    //取得用户数组
    String[][] userLog = (String[][])request.getAttribute("userLog");
    this.assertEquals("", 69, userLog.length);
  }
}
﻿package com.shinear.sm.stockmanagementpro;

import javax.ejb.*;

abstract public class AccountNameBean implements EntityBean {
  EntityContext entityContext;
  public java.lang.Integer ejbCreate(java.lang.Integer accountId, int parentId,
                                     java.lang.String accountName) throws
      CreateException {
    setAccountId(accountId);
    setParentId(parentId);
    setAccountName(accountName);
    return null;
  }
  public void ejbPostCreate(java.lang.Integer accountId, int parentId,
                            java.lang.String accountName) throws
      CreateException {
  }
  public void ejbRemove() throws RemoveException {
  }
  public abstract void setAccountId(java.lang.Integer accountId);
  public abstract void setParentId(int parentId);
  public abstract void setAccountName(java.lang.String accountName);
  public abstract java.lang.Integer getAccountId();
  public abstract int getParentId();
  public abstract java.lang.String getAccountName();
  public void ejbLoad() {
  }
  public void ejbStore() {
  }
  public void ejbActivate() {
  }
  public void ejbPassivate() {
  }
  public void unsetEntityContext() {
    this.entityContext = null;
  }
  public void setEntityContext(EntityContext entityContext) {
    this.entityContext = entityContext;
  }
}
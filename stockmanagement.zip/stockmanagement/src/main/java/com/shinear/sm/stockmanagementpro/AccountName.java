﻿package com.shinear.sm.stockmanagementpro;

import javax.ejb.*;
import java.util.*;

public interface AccountName extends javax.ejb.EJBLocalObject {
  public Integer getAccountId();
  public void setParentId(int parentId);
  public int getParentId();
  public void setAccountName(String accountName);
  public String getAccountName();
}
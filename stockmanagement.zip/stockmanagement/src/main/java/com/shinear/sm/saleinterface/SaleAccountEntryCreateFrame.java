﻿package com.shinear.sm.saleinterface;

import java.awt.*;
import java.awt.event.*;
import javax.swing.event.*;
import javax.swing.*;
import com.shinear.sm.data.*;
import com.shinear.sm.maininterface.*;
import com.shinear.sm.user.*;
import com.shinear.sm.method.*;
import java.util.Date;

public class SaleAccountEntryCreateFrame extends JFrame implements ActionListener {
  JPanel contentPane;
  //创建标签控件
  JLabel jLabel1 = new JLabel();
  JLabel jLabel2 = new JLabel();
  JLabel jLabel3 = new JLabel();
  JLabel jLabel4 = new JLabel();
  JLabel jLabel5 = new JLabel();
  JLabel jLabel6 = new JLabel();
  JLabel jLabel7 = new JLabel();
  JLabel jLabel8 = new JLabel();
  JLabel jLabel9 = new JLabel();
  JLabel jLabel10 = new JLabel();
  JLabel jLabel11 = new JLabel();
  JLabel jLabel12 = new JLabel();
  JLabel jLabel13 = new JLabel();
  JLabel jLabel14 = new JLabel();
  JLabel jLabel15 = new JLabel();
  //创建编辑框控件
  JTextField jTextField1 = new JTextField();
  JTextField jTextField2 = new JTextField();
  JTextField jTextField3 = new JTextField();
  JTextField jTextField4 = new JTextField();
  JTextField jTextField5 = new JTextField();
  JTextField jTextField6 = new JTextField();
  JTextField jTextField7 = new JTextField();
  JTextField jTextField8 = new JTextField();
  JTextField jTextField9 = new JTextField();
  JTextField jTextField10 = new JTextField();
  JTextField jTextField11 = new JTextField();
  //创建按钮控件
  JButton jButton1 = new JButton();
  JButton jButton2 = new JButton();
  JButton jButton3 = new JButton();
  JButton jButton4 = new JButton();
  JButton jButton5 = new JButton();
  JButton jButton6 = new JButton();
  JButton jButton7 = new JButton();
  JButton jButton8 = new JButton();
  JButton jButton9 = new JButton();
  JButton jButton10 = new JButton();
  //创建滚动框控件
  JScrollPane jScrollPane1 = new JScrollPane();
  JScrollPane jScrollPane2 = new JScrollPane();
  JScrollPane jScrollPane3 = new JScrollPane();
  //创建列表框数据类和列表框控件
  DefaultListModel listData1 = new DefaultListModel();
  JList jList1 = new JList(listData1);
  //创建表格控件
  JTable jTable1 = new JTable();
  //创建表格模式类
  AccountEntrySubLedgerTableModel aeslTableModel = new AccountEntrySubLedgerTableModel();
  //创建标题数组
  String[] colNames = {"序号", "联系字段", "借贷标识", "会计科目", "发生金额"};
  //创建下拉列表框控件
  JComboBox jComboBox1 = new JComboBox();
  JComboBox jComboBox2 = new JComboBox();
  //创建文本框控件
  JTextArea jTextArea1 = new JTextArea();
  //创建字体类
  Font dialog13 = new java.awt.Font("Dialog", 0, 13);
  //声明数据类
  StockManagementData stockManagementData = null;
  //声明用户类
  User user = null;
  //声明主窗口类
  StockManagementMainFrame stockManagementMainFrame = null;
  //创建会计分录数组
  String[][] accountEntryLedgers = new String[0][8];
  //创建会计分录明细数组
  String[][] accountEntrySubLedgers = new String[0][5];
  //创建会计分录明细表格数组
  Object[][] accountEntrySubLedgerObjects = new Object[0][5];
  //创建方法类
  DataMethod dataMethod = new DataMethod();
  //创建完成状态数组
  String[] onProcesses = {"进行", "撤消", "完成"};
  //创建借贷标识数组
  String[] debitCreditStrs = {"借", "贷"};
  //创建帐套日期字符串
  String ledgerDate = "";
  //创建动作字符串
  String action = "";

  public SaleAccountEntryCreateFrame(StockManagementMainFrame stockManagementMainFrame) {
    this.stockManagementMainFrame = stockManagementMainFrame;
    //取得主窗口的数据类
    stockManagementData = stockManagementMainFrame.getStockManagementData();
    //取得主窗口的用户类
    user = stockManagementMainFrame.getUser();
    //取得主窗口的账套日期
    ledgerDate = stockManagementMainFrame.getLedgerDate();
    //取得销售模块的用户权限
    int saleFunction = user.getSaleFunction();
    if((saleFunction & 32) != 32){
      JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
      System.exit(0);
    }
    //检查账套日期
    if(ledgerDate.length() == 0){
      JOptionPane.showMessageDialog(null, user.getUserName() + "请选择账套.");
      return;
    }
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception  {
    contentPane = (JPanel) this.getContentPane();
    contentPane.setLayout(null);
    this.setSize(new Dimension(667, 660));
    this.setTitle("编写销售会计分录窗口");
    //设置标签的属性
    jLabel1.setText("会计分录序号列表");
    jLabel1.setBounds(new Rectangle(28, 19, 126, 16));
    jLabel2.setText("查询条件");
    jLabel2.setBounds(new Rectangle(204, 45, 62, 16));
    jLabel3.setText("查询值");
    jLabel3.setBounds(new Rectangle(204, 75, 50, 16));
    jLabel4.setText("开始日期");
    jLabel4.setBounds(new Rectangle(204, 106, 67, 16));
    jLabel5.setText("结束日期");
    jLabel5.setBounds(new Rectangle(373, 106, 66, 16));
    jLabel6.setText("序号");
    jLabel6.setBounds(new Rectangle(204, 137, 66, 16));
    jLabel7.setText("关联票据标识");
    jLabel7.setBounds(new Rectangle(373, 137, 91, 16));
    jLabel8.setText("记账用户");
    jLabel8.setBounds(new Rectangle(204, 168, 66, 16));
    jLabel9.setText("审核用户");
    jLabel9.setBounds(new Rectangle(419, 170, 66, 16));
    jLabel10.setText("记账日期");
    jLabel10.setBounds(new Rectangle(204, 201, 66, 16));
    jLabel11.setText("审核日期");
    jLabel11.setBounds(new Rectangle(204, 232, 66, 16));
    jLabel12.setText("完成状态");
    jLabel12.setBounds(new Rectangle(204, 263, 66, 16));
    jLabel13.setText("备注");
    jLabel13.setBounds(new Rectangle(427, 199, 66, 16));
    jLabel14.setText("会计分录明细列表");
    jLabel14.setBounds(new Rectangle(28, 346, 133, 16));
    jLabel15.setText("借贷平衡");
    jLabel15.setBounds(new Rectangle(463, 346, 63, 16));
    //设置编辑框的属性
    jTextField1.setBounds(new Rectangle(267, 74, 169, 22));
    jTextField2.setBounds(new Rectangle(267, 106, 101, 22));
    jTextField3.setBounds(new Rectangle(439, 106, 101, 22));
    jTextField4.setEditable(false);
    jTextField4.setBounds(new Rectangle(267, 137, 101, 22));
    jTextField5.setBounds(new Rectangle(480, 137, 145, 22));
    jTextField6.setEditable(false);
    jTextField6.setBounds(new Rectangle(267, 168, 145, 22));
    jTextField7.setEditable(false);
    jTextField7.setBounds(new Rectangle(480, 170, 145, 22));
    jTextField8.setBounds(new Rectangle(267, 201, 147, 22));
    jTextField9.setEditable(false);
    jTextField9.setBounds(new Rectangle(267, 232, 147, 22));
    jTextField10.setEditable(false);
    jTextField10.setBounds(new Rectangle(267, 263, 147, 22));
    jTextField11.setEditable(false);
    jTextField11.setBounds(new Rectangle(534, 346, 91, 22));
    //设置按钮的属性
    jButton1.setText("查询");
    jButton1.setActionCommand("search");
    jButton1.setBounds(new Rectangle(546, 106, 79, 22));
    jButton2.setText("创建");
    jButton2.setActionCommand("create");
    jButton2.setBounds(new Rectangle(28, 305, 79, 25));
    jButton3.setText("修改");
    jButton3.setActionCommand("update");
    jButton3.setBounds(new Rectangle(114, 305, 79, 25));
    jButton4.setText("撤消");
    jButton4.setActionCommand("cancelAccountEntry");
    jButton4.setBounds(new Rectangle(201, 305, 79, 25));
    jButton5.setText("恢复");
    jButton5.setActionCommand("restore");
    jButton5.setBounds(new Rectangle(287, 305, 79, 25));
    jButton6.setText("确定");
    jButton6.setActionCommand("ok");
    jButton6.setBounds(new Rectangle(373, 305, 79, 25));
    jButton7.setText("取消");
    jButton7.setActionCommand("cancel");
    jButton7.setBounds(new Rectangle(460, 305, 79, 25));
    jButton8.setText("退出");
    jButton8.setActionCommand("exit");
    jButton8.setBounds(new Rectangle(546, 305, 79, 25));
    jButton9.setText("创建明细记录");
    jButton9.setActionCommand("createSub");
    jButton9.setBounds(new Rectangle(28, 559, 281, 25));
    jButton10.setText("删除明细记录");
    jButton10.setActionCommand("deleteSub");
    jButton10.setBounds(new Rectangle(344, 559, 281, 25));
    //设置滚动框的属性
    jScrollPane1.setBounds(new Rectangle(28, 45, 162, 240));
    jScrollPane2.setBounds(new Rectangle(426, 218, 199, 67));
    jScrollPane3.setBounds(new Rectangle(28, 379, 597, 157));
    jScrollPane1.getViewport().add(jList1, null);
    jScrollPane2.getViewport().add(jTextArea1, null);
    jScrollPane3.getViewport().add(jTable1, null);
    //为列表框加入选择接收器
    jList1.addListSelectionListener(new ListSelectionListener() {
      public void valueChanged(ListSelectionEvent e) {
        //当多种事件被激发的时候,不执行接收器后面的代码
        if (e.getValueIsAdjusting()) return;
        jList1_valueChanged(e);
      }
    });
    //设置下拉列表框的属性
    jComboBox1.setBounds(new Rectangle(267, 45, 169, 22));
    jComboBox1.addItem("销售收入");
    jComboBox1.addItem("销售成本");
    jComboBox1.addItem("应收账款");
    jComboBox1.addItem("应付账款");
    jComboBox1.addItem("存货");
    jComboBox1.addItem("现金");
    jComboBox1.addItem("所有科目");
    jComboBox2.setBounds(new Rectangle(456, 45, 169, 22));
    jComboBox2.addItem("根据关联标识查询");
    jComboBox2.addItem("根据记账用户查询");
    jComboBox2.addItem("根据审核用户查询");
    jComboBox2.addItem("根据完成状态查询");
    jComboBox2.addItem("根据记账日期查询");
    //为面板加入各个控件
    contentPane.add(jLabel1, null);
    contentPane.add(jLabel2, null);
    contentPane.add(jLabel3, null);
    contentPane.add(jLabel4, null);
    contentPane.add(jLabel5, null);
    contentPane.add(jLabel6, null);
    contentPane.add(jLabel7, null);
    contentPane.add(jLabel8, null);
    contentPane.add(jLabel9, null);
    contentPane.add(jLabel10, null);
    contentPane.add(jLabel13, null);
    contentPane.add(jLabel11, null);
    contentPane.add(jLabel12, null);
    contentPane.add(jLabel14, null);
    contentPane.add(jLabel15, null);
    contentPane.add(jTextField1, null);
    contentPane.add(jTextField2, null);
    contentPane.add(jTextField3, null);
    contentPane.add(jTextField4, null);
    contentPane.add(jTextField5, null);
    contentPane.add(jTextField6, null);
    contentPane.add(jTextField7, null);
    contentPane.add(jTextField8, null);
    contentPane.add(jTextField9, null);
    contentPane.add(jTextField10, null);
    contentPane.add(jTextField11, null);
    contentPane.add(jScrollPane1, null);
    contentPane.add(jScrollPane2, null);
    contentPane.add(jScrollPane3, null);
    contentPane.add(jButton1, null);
    contentPane.add(jButton2, null);
    contentPane.add(jButton3, null);
    contentPane.add(jButton4, null);
    contentPane.add(jButton5, null);
    contentPane.add(jButton6, null);
    contentPane.add(jButton7, null);
    contentPane.add(jButton8, null);
    contentPane.add(jButton9, null);
    contentPane.add(jButton10, null);
    contentPane.add(jComboBox1, null);
    contentPane.add(jComboBox2, null);
    //设置窗口类的字体和为按钮加入动作接收器
    setupFontAndListener();
    //检查按钮状态的方法
    this.checkBtn(false);
    this.checkSubBtn(false);
  }
  //设置窗口类的字体和为按钮加入动作接收器的方法
  public void setupFontAndListener(){
    Component[] components = contentPane.getComponents();
    //创建临时按钮控件
    JButton tmpBtn = new JButton();
    for(int i = 0; i < components.length; i++){
      components[i].setFont(dialog13);
      if(components[i].getClass().getName().equals("javax.swing.JButton")){
        tmpBtn = (JButton)components[i];
        tmpBtn.addActionListener(this);
      }
    }
  }
  //退出方法
  public void exit(){
    //隐藏窗口
    this.setVisible(false);
    //清空数组的内容
    accountEntryLedgers = new String[0][8];
    accountEntrySubLedgers = new String[0][5];
    accountEntrySubLedgerObjects = new Object[0][5];
    //清空列表框的内容
    listData1.clear();
    //清空文本框的内容
    jTextArea1.setText("");
    //清空表格的内容
    this.showTableData(accountEntrySubLedgerObjects);
    //取得面板上的所有控件
    Component[] components = contentPane.getComponents();
    //创建临时编辑框控件
    JTextField tmpTextField = new JTextField();
    for(int i = 0; i < components.length; i++){
      if(components[i].getClass().getName().equals("javax.swing.JTextField")){
        tmpTextField = (JTextField)components[i];
        //清空编辑框的内容
        tmpTextField.setText("");
      }
    }
  }
  //设置用户的方法
  public void setUser(User user) {
    this.user = user;
  }
  //设置账套的方法
  public void setLedgerDate(String ledgerDate) {
    this.ledgerDate = ledgerDate;
  }
  protected void processWindowEvent(WindowEvent e) {
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      exit();
    }
  }
  //显示查询会计分录的方法
  public void showSearchAccountEntryLedger(){
    listData1.clear();
    //为会计分录列表框加入会计分录数据
    for(int i = 0; i < accountEntryLedgers.length; i++){
      listData1.addElement(accountEntryLedgers[i][0]);
    }
  }
  //显示单个会计分录的方法
  public void showAccountEntryLedger(){
    //取得当前选择项的位置
    int selectedIndex = jList1.getSelectedIndex();
    //当列表框不处于选择状态，不显示数据
    if(selectedIndex == -1){
       return;
    }
    //显示会计分录的数据
    jTextField4.setText(accountEntryLedgers[selectedIndex][0]);
    jTextField5.setText(accountEntryLedgers[selectedIndex][1]);
    jTextField6.setText(accountEntryLedgers[selectedIndex][2]);
    jTextField7.setText(accountEntryLedgers[selectedIndex][3]);
    jTextField8.setText(accountEntryLedgers[selectedIndex][4]);
    jTextField9.setText(accountEntryLedgers[selectedIndex][5]);
    jTextField10.setText(onProcesses[Integer.parseInt(accountEntryLedgers[selectedIndex][6])]);
    jTextArea1.setText(accountEntryLedgers[selectedIndex][7]);
    //显示会计分录明细数据
    this.showAccountEntrySubLedger();
  }
  //显示会计分录明细数据的方法
  public void showAccountEntrySubLedger(){
    //取得当前选择项的位置
    int selectedIndex = jList1.getSelectedIndex();
    int serialId = Integer.parseInt(accountEntryLedgers[selectedIndex][0]);
    accountEntrySubLedgers = stockManagementData.getAccountEntrySubLedgerByLinkSerialId(ledgerDate, serialId);
    //将数组数据转换为表格数据
    accountEntrySubLedgerObjects = new Object[accountEntrySubLedgers.length][5];
    double total = 0;
    for(int i = 0; i < accountEntrySubLedgers.length; i++){
      accountEntrySubLedgerObjects[i][0] = new Integer(accountEntrySubLedgers[i][0]);
      accountEntrySubLedgerObjects[i][1] = new Integer(accountEntrySubLedgers[i][1]);
      int debitCredit = Integer.parseInt(accountEntrySubLedgers[i][2]);
      accountEntrySubLedgerObjects[i][2] = debitCreditStrs[debitCredit];
      accountEntrySubLedgerObjects[i][3] = dataMethod.transferAccountName(accountEntrySubLedgers[i][3]);
      double amount = dataMethod.round(Double.parseDouble(accountEntrySubLedgers[i][4]));
      accountEntrySubLedgerObjects[i][4] = new Double(amount);
      if(debitCredit == 0){
        total += amount;
      }else{
        total -= amount;
      }
    }
    //显示借贷平衡数字
    jTextField11.setText(String.valueOf(dataMethod.round(total)));
    //显示表格的内容
    this.showTableData(accountEntrySubLedgerObjects);
  }
  //显示表格内容的方法
  public void showTableData(Object[][] detail){
    //设置表格的标题
    aeslTableModel.setColumnNames(colNames);
    //设置表格的数据
    aeslTableModel.setData(detail);
    //设置表格的列编辑状态,第1、2列不能编辑
    aeslTableModel.setColumnEditState(0);
    jTable1 = new JTable(aeslTableModel);
    //设置表格的字体
    jTable1.setFont(dialog13);
    //将数据表格加入数据滚动框
    jScrollPane3.getViewport().add(jTable1, null);
    //为表格科目标识列加入下拉列表框
    javax.swing.table.TableColumn debitCreditColumn = jTable1.getColumnModel().getColumn(2);
    JComboBox comboBox = new JComboBox(new String[] {"借","贷"});
    debitCreditColumn.setCellEditor(new DefaultCellEditor(comboBox));
    //设置列的宽度
    jTable1.getColumnModel().getColumn(0).setPreferredWidth(20);
    jTable1.getColumnModel().getColumn(1).setPreferredWidth(20);
    jTable1.getColumnModel().getColumn(2).setPreferredWidth(20);
    jTable1.getColumnModel().getColumn(3).setPreferredWidth(120);
    jTable1.getColumnModel().getColumn(4).setPreferredWidth(20);
    //取得表格的行
    ListSelectionModel rowSM = jTable1.getSelectionModel();
    //加入行选择接收器
    rowSM.addListSelectionListener(new ListSelectionListener() {
      public void valueChanged(ListSelectionEvent e) {
        //当多种事件被激发的时候,不执行接收器后面的代码
        if (e.getValueIsAdjusting()) return;
        jTable1_valueChanged(e);
      }
    });
  }
  //转换表格数据的方法
  public void transferTableData(){
    accountEntrySubLedgers = new String[accountEntrySubLedgerObjects.length][6];
    for(int i = 0; i < accountEntrySubLedgerObjects.length; i++){
      accountEntrySubLedgers[i][0] = ((Integer)accountEntrySubLedgerObjects[i][0]).toString();
      accountEntrySubLedgers[i][1] = ((Integer)accountEntrySubLedgerObjects[i][1]).toString();
      if(((String)accountEntrySubLedgerObjects[i][2]).equals("借")){
        accountEntrySubLedgers[i][2] = "0";
      }else{
        accountEntrySubLedgers[i][2] = "1";
      }
      //将会计科目的--标识转换为@@标识
      accountEntrySubLedgers[i][3] = dataMethod.transferAccountNameBack( (
          String) accountEntrySubLedgerObjects[i][3]);
      accountEntrySubLedgers[i][4] = ((Double)accountEntrySubLedgerObjects[i][4]).toString();
    }
  }
  //重新计算借货平衡
  public void recountBalance(){
    int debitCredit = 0;
    double amount = 0;
    double total = 0;
    for(int i = 0; i < accountEntrySubLedgerObjects.length; i++){
      if(((String)accountEntrySubLedgerObjects[i][2]).equals("借")){
        debitCredit = 0;
      }else{
        debitCredit = 1;
      }
      amount = dataMethod.round(((Double)accountEntrySubLedgerObjects[i][4]).doubleValue());
      if(debitCredit == 0){
        total += amount;
      }else{
        total -= amount;
      }
    }
    jTextField11.setText(String.valueOf(dataMethod.round(total)));
  }
  //清空单个会计分录显示的方法
  public void clearAccountEntryLedger(){
    jTextField4.setText("");
    jTextField5.setText("");
    jTextField6.setText("");
    jTextField7.setText("");
    jTextField8.setText("");
    jTextField9.setText("");
    jTextField10.setText("");
    jTextField11.setText("");
    jTextArea1.setText("");
    accountEntrySubLedgers = new String[0][5];
    accountEntrySubLedgerObjects = new Object[0][5];
    this.showTableData(accountEntrySubLedgerObjects);
  }
  //列表1的选择事件
  void jList1_valueChanged(ListSelectionEvent e) {
    if(listData1.size() > 0){
      this.showAccountEntryLedger();
    }else{
      this.clearAccountEntryLedger();
    }
  }
  //表格行选择事件
  public void jTable1_valueChanged(ListSelectionEvent e) {
    //重新计算借贷平衡
    this.recountBalance();
  }
  //检查按钮的状态
  public void checkBtn(boolean isManipulated){
    if(isManipulated){
      jButton2.setEnabled(false);
      jButton3.setEnabled(false);
      jButton4.setEnabled(false);
      jButton5.setEnabled(false);
      jButton6.setEnabled(true);
      jButton7.setEnabled(true);
    }else{
      jButton2.setEnabled(true);
      jButton3.setEnabled(true);
      jButton4.setEnabled(true);
      jButton5.setEnabled(true);
      jButton6.setEnabled(false);
      jButton7.setEnabled(false);
    }
  }
  //检查明细账按钮的状态
  public void checkSubBtn(boolean isCreated){
    if(isCreated){
      jButton9.setEnabled(true);
      jButton10.setEnabled(true);
    }else{
      jButton9.setEnabled(false);
      jButton10.setEnabled(false);
    }
  }

  //查询方法
  public void search(){
    //取得查询选项
    int selectedIndex = jComboBox2.getSelectedIndex();
    //取得科目查询字符串
    String accountNameSearch = (String)jComboBox1.getSelectedItem();
    if(accountNameSearch.equals("所有科目")){
      accountNameSearch = "";
    }
    //取得编辑框的变量
    String searchValue = jTextField1.getText().trim();
    String startDateStr = jTextField2.getText().trim();
    String endDateStr = jTextField3.getText().trim();
    if (selectedIndex == 0 | selectedIndex == 1 | selectedIndex == 2 |
        selectedIndex == 3) {
      if (searchValue.length() == 0) {
        JOptionPane.showMessageDialog(null, "请输入查询值");
        return;
      }
      switch (selectedIndex) {
        case 0:
          //根据关联标识取得记录
          accountEntryLedgers = stockManagementData.getAccountEntryLedgerByStringField(
              ledgerDate, accountNameSearch, "linkId", searchValue);
          break;
        case 1:
          //根据记账用户取得记录
          accountEntryLedgers = stockManagementData.getAccountEntryLedgerByStringField(
              ledgerDate, accountNameSearch, "filler", searchValue);
          break;
        case 2:
          //根据审核用户取得记录
          accountEntryLedgers = stockManagementData.getAccountEntryLedgerByStringField(
              ledgerDate, accountNameSearch, "auditUser", searchValue);
          break;
        case 3:
          if(dataMethod.checkInt(searchValue) == 0){
            JOptionPane.showMessageDialog(null, "按完成状态查询时，输入值必须是整数，"
                                          + "0表示进行，1表示撤消，2表示完成.");
            return;
          }
          //根据完成状态取得记录
          accountEntryLedgers = stockManagementData.getAccountEntryLedgerByOnProcess(
              ledgerDate, accountNameSearch, Integer.parseInt(searchValue));
          break;
      }
    }else{
      java.sql.Timestamp startDate = dataMethod.transferDate(startDateStr);
      java.sql.Timestamp endDate = dataMethod.transferEndDate(endDateStr);
      if(startDate == null | endDate == null){
        JOptionPane.showMessageDialog(null, "日期输入错误，正确的日期格式是"
                                      + "yyyy-mm-dd（年-月-日），如2004-1-1");
        return;
      }
      //根据日期取得记录
      accountEntryLedgers = stockManagementData.getAccountEntryLedgerByFillDate(
          ledgerDate, startDate, endDate, accountNameSearch);
    }
    this.showSearchAccountEntryLedger();
  }
  //单击事件
  public void actionPerformed(ActionEvent e) {
    //取得按钮的动作字符串
    String actionCommand = e.getActionCommand().trim();
    int selectedIndex = 0;
    int serialId = 0;
    String userName = user.getUserName();
    String linkId = "";
    String remark = jTextArea1.getText().trim();
    if (actionCommand.equals("create") |
        actionCommand.equals("update") |
        actionCommand.equals("cancelAccountEntry") |
        actionCommand.equals("restore")
        ) {
      //检查打开的账套是否当前账套
      int result = stockManagementData.isCurrentLedger(ledgerDate);
      if(result == 0){
        JOptionPane.showMessageDialog(null, ledgerDate + "是往期账套，不能进行电子签名和撤消操作.");
        return;
      }
    }
    if (actionCommand.equals("update") |
        actionCommand.equals("cancelAccountEntry") |
        actionCommand.equals("restore")
        ) {
      if(jList1.isSelectionEmpty()){
        JOptionPane.showMessageDialog(null, "先选择会计分录序号.");
        return;
      }
      selectedIndex = jList1.getSelectedIndex();
      //检查会计分录是否上期转入
      linkId = accountEntryLedgers[selectedIndex][1].trim();
      if(linkId.equals("上期转入")){
        JOptionPane.showMessageDialog(null, "该会计分录是上期转入分录，不能进行修改、撤消和恢复操作.");
        return;
      }
      if(Integer.parseInt(accountEntryLedgers[selectedIndex][6]) == 2){
        JOptionPane.showMessageDialog(null, "会计分录已完成，不能进行修改、撤消和恢复操作.");
        return;
      }

    }
    if (actionCommand.equals("search")) {
      //查询
      search();
    }else if(actionCommand.equals("create")){
      action = "create";
      this.clearAccountEntryLedger();
      this.checkBtn(true);
      this.checkSubBtn(true);
    }else if(actionCommand.equals("update")){
      action = "update";
      this.checkBtn(true);
    }else if(actionCommand.equals("ok")){
      //创建会计分录数据表的单个记录数组
      String[] accountEntryLedger = new String[8];
      //取得会计分录的值
      accountEntryLedger[1] = jTextField5.getText().trim(); //相关票据标识
      accountEntryLedger[2] = user.getUserName();           //记账用户
      accountEntryLedger[3] = "";                           //审核用户
      accountEntryLedger[4] = jTextField8.getText().trim(); //记账日期
      accountEntryLedger[5] = null;                         //审核日期
      accountEntryLedger[6] = "0";                          //完成状态
      accountEntryLedger[7] = remark;                       //备注
      int result = 0;
      if(action.equals("create") | action.equals("update")){
        //检查明细账是否为空
        if(accountEntrySubLedgerObjects.length == 0){
          JOptionPane.showMessageDialog(null, "明细账数据表为空，不可以创建会计分录.");
          return;
        }
        //检查借货是否平衡
        this.recountBalance();
        double total = Double.parseDouble(jTextField11.getText().trim());
        if(total != 0){
          JOptionPane.showMessageDialog(null, "明细账借贷不平衡，不可以创建和更新会计分录.");
          return;
        }
        //检查记账日期是否正确
        if(dataMethod.transferDate(accountEntryLedger[4]) == null){
          JOptionPane.showMessageDialog(null, "记账日期输入错误，正确的日期格式是"
                                      + "yyyy-mm-dd（年-月-日），如2004-1-1");
          return;
        }
        //转换表格数据
        this.transferTableData();
      }
      if(action.equals("create")){
        //创建添加的会计分录数组
        String[] accountEntryLedgerForCreate = new String[7];
        System.arraycopy(accountEntryLedger, 1, accountEntryLedgerForCreate, 0, 7);
        //创建添加的会计分录的明细数组
        String[][] accountEntrySubLedgersForCreate = new String[accountEntrySubLedgers.length][3];
        for(int i = 0; i < accountEntrySubLedgers.length; i++){
          System.arraycopy(accountEntrySubLedgers[i], 2, accountEntrySubLedgersForCreate[i], 0, 3);
        }
        //添加会计分录
        result = stockManagementData.createAccountEntry(ledgerDate,
            accountEntryLedgerForCreate, accountEntrySubLedgersForCreate);
        if(result == 1){
          JOptionPane.showMessageDialog(null, "会计分录添加成功，请重新执行查询操作显示新的会计分录.");
        }else{
          JOptionPane.showMessageDialog(null, "会计分录添加失败，请检查输入值是否大于字段范围.");
        }
      }else if (action.equals("update")){
        selectedIndex = jList1.getSelectedIndex();
        //序号、记帐用户保持不变
        accountEntryLedger[0] = accountEntryLedgers[selectedIndex][0];
        accountEntryLedger[2] = accountEntryLedgers[selectedIndex][2];
        //更新会计分录,更新会计分录后将会计分录的完成状态设为进行
        result = stockManagementData.updateAccountEntry(ledgerDate,
            accountEntryLedger, accountEntrySubLedgers);
        if(result == 1){
          JOptionPane.showMessageDialog(null, "会计分录更新成功.");
          //更新会计分录数组
          accountEntryLedgers[selectedIndex][1] = accountEntryLedger[1]; //关联标识
          accountEntryLedgers[selectedIndex][3] = "";                    //审核用户
          accountEntryLedgers[selectedIndex][4] = accountEntryLedger[4]; //记账日期
          accountEntryLedgers[selectedIndex][5] = "";                    //审核日期
          accountEntryLedgers[selectedIndex][6] = "0";                   //完成状态
          accountEntryLedgers[selectedIndex][7] = remark;                //备注
          //更新编辑框的状态
          jTextField7.setText("");
          jTextField9.setText("");
          jTextField10.setText(onProcesses[0]);
        }else{
          JOptionPane.showMessageDialog(null, "会计分录更新失败.");
        }
      }
      this.checkSubBtn(false);
      this.checkBtn(false);
    }else if(actionCommand.equals("cancel")){
      this.jList1_valueChanged(null);
      this.checkBtn(false);
      this.checkSubBtn(false);
    }else if(actionCommand.equals("cancelAccountEntry")){
      selectedIndex = jList1.getSelectedIndex();
      serialId = Integer.parseInt(accountEntryLedgers[selectedIndex][0]);
      //撤消会计分录
      int result = stockManagementData.cancelOrRestoreAccountEntryLedger(
          ledgerDate, serialId, 1, remark);
      if(result == 1){
        JOptionPane.showMessageDialog(null, "会计分录撤消成功.");
        //更新数组的数据
        accountEntryLedgers[selectedIndex][6] = "1";
        accountEntryLedgers[selectedIndex][7] = remark;
        //更新编辑框的值
        jTextField10.setText(onProcesses[1]);
      }else{
        JOptionPane.showMessageDialog(null, "会计分录撤消失败.");
      }
    }else if(actionCommand.equals("restore")){
      selectedIndex = jList1.getSelectedIndex();
      serialId = Integer.parseInt(accountEntryLedgers[selectedIndex][0]);
      //恢复会计分录的完成状态
      int result = stockManagementData.cancelOrRestoreAccountEntryLedger(
          ledgerDate, serialId, 0, remark);
      if(result == 1){
        JOptionPane.showMessageDialog(null, "会计分录恢复成功.");
        //更新数组的数据
        accountEntryLedgers[selectedIndex][6] = "0";
        accountEntryLedgers[selectedIndex][7] = remark;
        //更新编辑框的值
        jTextField10.setText(onProcesses[0]);
      }else{
        JOptionPane.showMessageDialog(null, "会计分录恢复失败.");
      }
    }else if(actionCommand.equals("createSub")){
      //为会计分录明细表添加一个空行
      int objectsLength = accountEntrySubLedgerObjects.length;
      Object[][] tempObjs = new Object[objectsLength + 1][5];
      System.arraycopy(accountEntrySubLedgerObjects, 0, tempObjs, 0, objectsLength);
      tempObjs[objectsLength][0] = new Integer(0);
      tempObjs[objectsLength][1] = new Integer(0);
      tempObjs[objectsLength][2] = "借";
      tempObjs[objectsLength][3] = "";
      tempObjs[objectsLength][4] = new Double(0);
      accountEntrySubLedgerObjects = tempObjs;
      this.showTableData(accountEntrySubLedgerObjects);
    }else if(actionCommand.equals("deleteSub")){
      if(jTable1.getSelectedRowCount() == 0){
        JOptionPane.showMessageDialog(null, "请选择明细记录.");
        return;
      }
      //删除选择的记录
      int tableSelectedIndex = jTable1.getSelectedRow();
      Object[][] tempObjs = new Object[accountEntrySubLedgerObjects.length - 1][5];
      int line = 0;
      for(int i = 0; i < accountEntrySubLedgerObjects.length; i++){
        if(i == tableSelectedIndex){
          continue;
        }else{
          for(int j = 0; j < 5; j++){
            tempObjs[line][j] = accountEntrySubLedgerObjects[i][j];
          }
          line++;
        }
      }
      accountEntrySubLedgerObjects = tempObjs;
      this.showTableData(accountEntrySubLedgerObjects);
    }else if(actionCommand.equals("exit")){
      exit();
    }
  }
}
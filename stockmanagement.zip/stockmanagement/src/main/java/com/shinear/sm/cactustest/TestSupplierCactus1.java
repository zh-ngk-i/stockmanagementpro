﻿package com.shinear.sm.cactustest;

import org.apache.cactus.*;

import com.shinear.sm.stockmanagementpro.*;

import javax.naming.*;
import java.util.Collection;
import java.rmi.RemoteException;

public class TestSupplierCactus1 extends ServletTestCase {
  private static final String ERROR_NULL_REMOTE = "接口未定义.";
  private static final int MAX_OUTPUT_LINE_LENGTH = 100;
  private boolean logging = false;
  private SupplierHome supplierHome = null;
  private Supplier supplier = null;

  public TestSupplierCactus1(String name) {
    super(name);
  }

  public void initializeLocalHome() throws Exception {
    Context context = new InitialContext();
    supplierHome = (SupplierHome) context.lookup("Supplier");
  }

  public void setUp() throws Exception {
    super.setUp();
    initializeLocalHome();
  }

  public void tearDown() throws Exception {
    supplierHome = null;
    supplier = null;
    super.tearDown();
  }
  //测试供应商创建方法
  public void testSupplierCreate() throws Exception{
    //创建供应商数组
    String[] supplier = new String[]{"测试供应商1", "南部", "拼音码1", "简称1", "021-556892",
        "张凡", "1350058956", "021-896523", "021-963258", "地址1", "511896",
        "中行", "银行帐号", "jack@hotmail.com", "www.jack.com", "备注1"};
    //创建供应商
    supplierHome.create(supplier[0], supplier[1], supplier[2], supplier[3],
                        supplier[4], supplier[5], supplier[6], supplier[7],
                        supplier[8], supplier[9], supplier[10], supplier[11],
                        supplier[12], supplier[13], supplier[14], supplier[15]);
    supplier = new String[]{"测试供应商2", "北部", "拼音码2", "简称2", "021-556892",
        "张凡", "1350058956", "021-896523", "021-963258", "地址2", "511896",
        "中行", "银行帐号", "jack@hotmail.com", "www.jack.com", "备注2"};
    //创建供应商
    supplierHome.create(supplier[0], supplier[1], supplier[2], supplier[3],
                        supplier[4], supplier[5], supplier[6], supplier[7],
                        supplier[8], supplier[9], supplier[10], supplier[11],
                        supplier[12], supplier[13], supplier[14], supplier[15]);
    supplier = new String[]{"测试供应商3", "南部", "拼音码3", "简称3", "021-556892",
        "张凡", "1350058956", "021-896523", "021-963258", "地址3", "511896",
        "中行", "银行帐号", "jack@hotmail.com", "www.jack.com", "备注3"};
    //创建供应商
    supplierHome.create(supplier[0], supplier[1], supplier[2], supplier[3],
                        supplier[4], supplier[5], supplier[6], supplier[7],
                        supplier[8], supplier[9], supplier[10], supplier[11],
                        supplier[12], supplier[13], supplier[14], supplier[15]);
  }
  //测试供应商更新方法
  public void testSupplierUpdate() throws Exception{
    String[] supplier = new String[]{"测试供应商1", "北部", "拼音码1", "简称1", "021-556892",
        "张凡", "1350058956", "021-896523", "021-963258", "地址1", "511896",
        "中行", "银行帐号", "jack@hotmail.com", "www.jack.com", "备注1"};
    this.supplier = supplierHome.findByPrimaryKey(supplier[0]);
    //更新供应商的值
    this.supplier.setSupplierZone(supplier[1]);
  }
  //测试根据供应商名字取得记录的方法
  public void testFindBySupplierName() throws Exception {
    Collection col = supplierHome.findBySupplierName("%供应商%");
    this.assertEquals("", 3, col.size());
  }
  //测试根据地区取得记录的方法
  public void testFindBySupplierZone() throws Exception {
    Collection col = supplierHome.findBySupplierZone("%北部%");
    this.assertEquals("", 2, col.size());
  }
  //测试供应商删除方法
  public void testSupplierDelete() throws Exception{
    String[] suppliers = new String[]{"测试供应商1", "测试供应商2", "测试供应商3"};
    supplier = supplierHome.findByPrimaryKey(suppliers[0]);
    //删除供应商
    supplier.remove();
    supplier = supplierHome.findByPrimaryKey(suppliers[1]);
    //删除供应商
    supplier.remove();
    supplier = supplierHome.findByPrimaryKey(suppliers[2]);
    //删除供应商
    supplier.remove();
  }
}
﻿package com.shinear.sm.baseinforinterface;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import com.shinear.sm.data.*;
import com.shinear.sm.maininterface.*;
import com.shinear.sm.user.*;
import com.shinear.sm.method.*;

public class GoodsDiscountManageFrame extends JFrame implements ActionListener {
  JPanel contentPane;

  //创建列表框数据类和列表框控件
  DefaultListModel listData1 = new DefaultListModel();
  DefaultListModel listData2 = new DefaultListModel();
  JList jList1 = new JList(listData1);
  JList jList2 = new JList(listData2);
  //创建组合框控件
  JComboBox jComboBox1 = new JComboBox();
  //创建滚动框控件
  JScrollPane jScrollPane1 = new JScrollPane();
  JScrollPane jScrollPane2 = new JScrollPane();
  //创建标签控件
  JLabel jLabel1 = new JLabel();
  JLabel jLabel2 = new JLabel();
  JLabel jLabel3 = new JLabel();
  JLabel jLabel4 = new JLabel();
  JLabel jLabel5 = new JLabel();
  JLabel jLabel6 = new JLabel();
  JLabel jLabel7 = new JLabel();
  //创建编辑框控件
  JTextField jTextField1 = new JTextField();
  JTextField jTextField2 = new JTextField();
  JTextField jTextField3 = new JTextField();
  JTextField jTextField4 = new JTextField();
  //创建按钮控件
  JButton jButton1 = new JButton();
  JButton jButton2 = new JButton();
  JButton jButton3 = new JButton();
  JButton jButton4 = new JButton();
  JButton jButton5 = new JButton();
  JButton jButton6 = new JButton();
  JButton jButton7 = new JButton();
  //创建字体类
  Font dialog13 = new java.awt.Font("Dialog", 0, 13);
  //声明数据类
  StockManagementData stockManagementData = null;
  //声明用户类
  User user = null;
  //声明主窗口类
  StockManagementMainFrame stockManagementMainFrame = null;
  //创建商品类别数组
  String[][] categories = new String[0][4];
  //创建商品数组
  String[][] goods = new String[0][13];
  //创建方法类
  DataMethod dataMethod = new DataMethod();

  public GoodsDiscountManageFrame(StockManagementMainFrame stockManagementMainFrame) {
    this.stockManagementMainFrame = stockManagementMainFrame;
    //取得主窗口的数据类
    stockManagementData = stockManagementMainFrame.getStockManagementData();
    //取得主窗口的用户类
    user = stockManagementMainFrame.getUser();
    //取得基础信息模块的用户权限
    int baseInforFunction = user.getBaseInforFunction();
    //检查用户权限
    if((baseInforFunction & 16) != 16){
      JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
      System.exit(0);
    }
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception  {
    contentPane = (JPanel) this.getContentPane();
    contentPane.setLayout(null);
    this.setSize(new Dimension(643, 382));
    this.setTitle("商品折扣管理窗口");
    //设置标签控件属性
    jLabel1.setText("商品类别列表：");
    jLabel1.setBounds(new Rectangle(28, 19, 97, 16));
    jLabel2.setText("商品列表：");
    jLabel2.setBounds(new Rectangle(176, 19, 97, 16));
    jLabel3.setText("查询条件：");
    jLabel3.setBounds(new Rectangle(344, 45, 97, 16));
    jLabel4.setText("查询值：");
    jLabel4.setBounds(new Rectangle(344, 93, 97, 16));
    jLabel5.setBounds(new Rectangle(344, 141, 110, 16));
    jLabel5.setText("商品条形码：");
    jLabel6.setText("商品名称：");
    jLabel6.setBounds(new Rectangle(344, 190, 72, 16));
    jLabel7.setText("商品折扣：");
    jLabel7.setBounds(new Rectangle(344, 238, 78, 16));
    //设置编辑框控件属性
    jTextField1.setBounds(new Rectangle(427, 93, 102, 22));
    jTextField2.setEditable(false);
    jTextField2.setBounds(new Rectangle(427, 141, 196, 22));
    jTextField3.setEditable(false);
    jTextField3.setBounds(new Rectangle(427, 190, 196, 22));
    jTextField4.setBounds(new Rectangle(427, 238, 58, 22));
    //设置按钮属性
    jButton1.setText("显示类别");
    jButton1.setActionCommand("showCategory");
    jButton1.setBounds(new Rectangle(28, 249, 139, 25));
    jButton2.setText("修改折扣");
    jButton2.setActionCommand("updateDiscount");
    jButton2.setBounds(new Rectangle(344, 286, 95, 25));
    jButton3.setText("确定");
    jButton3.setActionCommand("ok");
    jButton3.setEnabled(false);
    jButton3.setBounds(new Rectangle(440, 286, 61, 25));
    jButton4.setText("取消");
    jButton4.setActionCommand("cancel");
    jButton4.setEnabled(false);
    jButton4.setBounds(new Rectangle(503, 286, 61, 25));
    jButton5.setText("退出");
    jButton5.setActionCommand("exit");
    jButton5.setBounds(new Rectangle(565, 286, 61, 25));
    jButton6.setText("查询");
    jButton6.setActionCommand("search");
    jButton6.setBounds(new Rectangle(546, 93, 77, 25));
    jButton7.setText("显示折扣商品");
    jButton7.setActionCommand("showDiscountGoods");
    jButton7.setBounds(new Rectangle(28, 286, 139, 25));
    //设置组合框属性
    jComboBox1.setBounds(new Rectangle(427, 45, 196, 22));
    jComboBox1.addItem("按商品条形码查询");
    jComboBox1.addItem("按商品名称查询");
    jComboBox1.addItem("按生产厂商查询");
    //设置滚动框的属性
    jScrollPane1.getViewport().add(jList1, null);
    jScrollPane2.getViewport().add(jList2, null);
    jScrollPane1.setBounds(new Rectangle(28, 45, 139, 193));
    jScrollPane2.setBounds(new Rectangle(176, 45, 153, 266));
    //为列表框加入选择接收器
    jList1.addListSelectionListener(new ListSelectionListener() {
      public void valueChanged(ListSelectionEvent e) {
        jList1_valueChanged(e);
      }
    });
    jList2.addListSelectionListener(new ListSelectionListener() {
      public void valueChanged(ListSelectionEvent e) {
        jList2_valueChanged(e);
      }
    });
    contentPane.add(jScrollPane1, null);
    contentPane.add(jScrollPane2, null);
    contentPane.add(jLabel1, null);
    contentPane.add(jLabel2, null);
    contentPane.add(jLabel3, null);
    contentPane.add(jLabel4, null);
    contentPane.add(jLabel5, null);
    contentPane.add(jLabel6, null);
    contentPane.add(jLabel7, null);
    contentPane.add(jButton1, null);
    contentPane.add(jButton2, null);
    contentPane.add(jButton3, null);
    contentPane.add(jButton4, null);
    contentPane.add(jButton5, null);
    contentPane.add(jButton6, null);
    contentPane.add(jButton7, null);
    contentPane.add(jComboBox1, null);
    contentPane.add(jTextField1, null);
    contentPane.add(jTextField2, null);
    contentPane.add(jTextField3, null);
    contentPane.add(jTextField4, null);
    //设置窗口类的字体和为按钮加入动作接收器
    setupFontAndListener();
    //显示全部商品类别的方法
    showAllCategories();
  }
  //设置窗口类的字体和为按钮加入动作接收器的方法
  public void setupFontAndListener(){
    Component[] components = contentPane.getComponents();
    //创建临时按钮控件
    JButton tmpBtn = new JButton();
    for(int i = 0; i < components.length; i++){
      components[i].setFont(dialog13);
      if(components[i].getClass().getName().equals("javax.swing.JButton")){
        tmpBtn = (JButton)components[i];
        tmpBtn.addActionListener(this);
      }
    }
  }
  //显示全部商品类别的方法
  public void showAllCategories(){
    listData1.clear();
    //取得商品类别数据
    categories = stockManagementData.getAllGoodsCategory();
    //为商品类别列表框加入商品类别数据
    for(int i = 0; i < categories.length; i++){
      listData1.addElement(categories[i][2]);
    }
  }
  //根据商品类别显示商品的方法
  public void showCategory(){
    //取得当前选择项的位置
    int selectedIndex = jList1.getSelectedIndex();
    //取得商品数据
    goods = stockManagementData.getGoodsByGoodsCategory(Integer.parseInt(
        categories[selectedIndex][0]));
    this.showSearchGoods();
  }
  //显示查询商品的方法
  public void showSearchGoods(){
    listData2.clear();
    //为商品列表框加入商品数据
    for(int i = 0; i < goods.length; i++){
      listData2.addElement(goods[i][2]);
    }
  }
  //显示单个商品的方法
  public void showGood(){
    //取得当前选择项的位置
    int selectedIndex = jList2.getSelectedIndex();
    //当列表框不处于选择状态，不显示商品数据
    if(selectedIndex == -1){
       return;
    }
    //显示商品条形码
    jTextField2.setText(goods[selectedIndex][0]);
    //显示商品名称
    jTextField3.setText(goods[selectedIndex][2]);
    //显示折扣
    jTextField4.setText(goods[selectedIndex][12]);
  }
  //清空单个商品显示的方法
  public void clearGood(){
    jTextField2.setText("");
    jTextField3.setText("");
    jTextField4.setText("");
  }
  //退出方法
  public void exit(){
    //隐藏窗口
    this.setVisible(false);
    //清空数组的内容
    categories = new String[0][4];
    goods = new String[0][13];
    //清空列表框的内容
    listData1.clear();
    listData2.clear();
    //取得面板上的所有控件
    Component[] components = contentPane.getComponents();
    //创建临时文本框控件
    JTextField tmpTextField = new JTextField();
    for(int i = 0; i < components.length; i++){
      if(components[i].getClass().getName().equals("javax.swing.JTextField")){
        tmpTextField = (JTextField)components[i];
        //清空编辑框的内容
        tmpTextField.setText("");
      }
    }
  }
  //设置用户的方法
  public void setUser(User user) {
    this.user = user;
  }
  //检查商品按钮的状态
  public void checkGoodsBtn(boolean isManipulated){
    if(isManipulated){
      jButton2.setEnabled(false);
      jButton3.setEnabled(true);
      jButton4.setEnabled(true);
    }else{
      jButton2.setEnabled(true);
      jButton3.setEnabled(false);
      jButton4.setEnabled(false);
    }
  }
  protected void processWindowEvent(WindowEvent e) {
    super.processWindowEvent(e);
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      exit();
    }
  }
  //列表1的选择事件
  void jList1_valueChanged(ListSelectionEvent e) {
    if(listData1.size() > 0){
      this.showCategory();
    }
  }
  //列表2的选择事件
  void jList2_valueChanged(ListSelectionEvent e) {
    if(listData2.size() > 0){
      this.showGood();
    }else{
      this.clearGood();
    }
  }
  //单击事件
  public void actionPerformed(ActionEvent e) {
    //取得按钮的动作字符串
    String actionCommand = e.getActionCommand().trim();
    //单击按钮的处理代码
    if (actionCommand.equals("showCategory")) {
      this.showAllCategories();
    }else if(actionCommand.equals("showDiscountGoods")){
      //取得折扣商品
      goods = stockManagementData.getDiscountGoods();
      this.showSearchGoods();
    }else if(actionCommand.equals("search")){
      //取得查询编辑框的内容
      String searchValue = jTextField1.getText().trim();
      //取得查询选项
      int selectedIndex = jComboBox1.getSelectedIndex();
      if(searchValue.length() == 0){
        JOptionPane.showMessageDialog(null, "请输入查询值");
        return;
      }
      switch (selectedIndex) {
        case 0:
          goods = stockManagementData.getGoodsByGoodsBarCode(searchValue);
          this.showSearchGoods();
          break;
        case 1:
          goods = stockManagementData.getGoodsByGoodsName(searchValue);
          this.showSearchGoods();
          break;
        case 2:
          goods = stockManagementData.getGoodsByProducer(searchValue);
          this.showSearchGoods();
          break;
      }
    }else if(actionCommand.equals("updateDiscount")){
      //进行商品折扣修改时检查商品的选择状态
      if (jList2.isSelectionEmpty()) {
        JOptionPane.showMessageDialog(null, "请选择商品.");
        return;
      }
      this.checkGoodsBtn(true);
    }else if(actionCommand.equals("ok")){
      //取得商品条形码和折扣
      String goodsBarCode = jTextField2.getText().trim();
      String discountStr = jTextField4.getText().trim();
      double discount = 0;
      if(dataMethod.checkNumIn0To1(discountStr) == 0){
        JOptionPane.showMessageDialog(null, "商品折扣的数值范围必须大于0小于等于1.");
        return;
      }else{
        discount = Double.parseDouble(discountStr);
      }
      int result = stockManagementData.setGoodsDiscount(goodsBarCode, discount);
      if(result == 1){
        //更新商品数组的折扣数据
        int selectedIndex = jList2.getSelectedIndex();
        goods[selectedIndex][12] = discountStr;
      }else{
        JOptionPane.showMessageDialog(null, "商品折扣更改失败.");
      }
      this.checkGoodsBtn(false);
    }else if(actionCommand.equals("cancel")){
      this.jList2_valueChanged(null);
      this.checkGoodsBtn(false);
    }else if(actionCommand.equals("exit")){
      exit();
    }
  }
}
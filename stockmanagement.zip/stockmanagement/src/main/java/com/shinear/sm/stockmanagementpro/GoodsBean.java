﻿package com.shinear.sm.stockmanagementpro;

import javax.ejb.*;

abstract public class GoodsBean implements EntityBean {
  EntityContext entityContext;
  public java.lang.String ejbCreate(java.lang.String goodsBarCode, int categoryId, java.lang.String goodsName, java.lang.String goodsNickName, java.lang.String goodsAssistantName, java.lang.String goodsPYName, java.lang.String unit, java.lang.String specification, java.lang.String producer, int upperLimit, int lowerLimit, double salePrice, double discount) throws CreateException {
    setGoodsBarCode(goodsBarCode);
    setCategoryId(categoryId);
    setGoodsName(goodsName);
    setGoodsNickName(goodsNickName);
    setGoodsAssistantName(goodsAssistantName);
    setGoodsPYName(goodsPYName);
    setUnit(unit);
    setSpecification(specification);
    setProducer(producer);
    setUpperLimit(upperLimit);
    setLowerLimit(lowerLimit);
    setSalePrice(salePrice);
    setDiscount(discount);
    return null;
  }

  public void ejbPostCreate(java.lang.String goodsBarCode, int categoryId, java.lang.String goodsName, java.lang.String goodsNickName, java.lang.String goodsAssistantName, java.lang.String goodsPYName, java.lang.String unit, java.lang.String specification, java.lang.String producer, int upperLimit, int lowerLimit, double salePrice, double discount) throws CreateException {
  }
  public void ejbRemove() throws RemoveException {
  }
  public abstract void setGoodsBarCode(java.lang.String goodsBarCode);
  public abstract void setCategoryId(int categoryId);
  public abstract void setGoodsName(java.lang.String goodsName);
  public abstract void setGoodsNickName(java.lang.String goodsNickName);
  public abstract void setGoodsAssistantName(java.lang.String goodsAssistantName);
  public abstract void setGoodsPYName(java.lang.String goodsPYName);
  public abstract void setUnit(java.lang.String unit);
  public abstract void setSpecification(java.lang.String specification);
  public abstract void setProducer(java.lang.String producer);
  public abstract void setUpperLimit(int upperLimit);
  public abstract void setLowerLimit(int lowerLimit);
  public abstract void setSalePrice(double salePrice);
  public abstract void setDiscount(double discount);
  public abstract java.lang.String getGoodsBarCode();
  public abstract int getCategoryId();
  public abstract java.lang.String getGoodsName();
  public abstract java.lang.String getGoodsNickName();
  public abstract java.lang.String getGoodsAssistantName();
  public abstract java.lang.String getGoodsPYName();
  public abstract java.lang.String getUnit();
  public abstract java.lang.String getSpecification();
  public abstract java.lang.String getProducer();
  public abstract int getUpperLimit();
  public abstract int getLowerLimit();
  public abstract double getSalePrice();
  public abstract double getDiscount();
  public void ejbLoad() {
  }
  public void ejbStore() {
  }
  public void ejbActivate() {
  }
  public void ejbPassivate() {
  }
  public void unsetEntityContext() {
    this.entityContext = null;
  }
  public void setEntityContext(EntityContext entityContext) {
    this.entityContext = entityContext;
  }
}
﻿package com.shinear.sm.stockmanagementpro;

import javax.ejb.*;

abstract public class SupplierBean implements EntityBean {
  EntityContext entityContext;
  public java.lang.String ejbCreate(java.lang.String supplierName, java.lang.String supplierZone, java.lang.String pyCode, java.lang.String abbreviation, java.lang.String companyPhone, java.lang.String linkman, java.lang.String mobilePhone, java.lang.String fax, java.lang.String fixedPhone, java.lang.String address, java.lang.String zipCode, java.lang.String bankName, java.lang.String bankAccount, java.lang.String email, java.lang.String homesite, java.lang.String remark) throws CreateException {
    setSupplierName(supplierName);
    setSupplierZone(supplierZone);
    setPyCode(pyCode);
    setAbbreviation(abbreviation);
    setCompanyPhone(companyPhone);
    setLinkman(linkman);
    setMobilePhone(mobilePhone);
    setFax(fax);
    setFixedPhone(fixedPhone);
    setAddress(address);
    setZipCode(zipCode);
    setBankName(bankName);
    setBankAccount(bankAccount);
    setEmail(email);
    setHomesite(homesite);
    setRemark(remark);
    return null;
  }

  public void ejbPostCreate(java.lang.String supplierName, java.lang.String supplierZone, java.lang.String pyCode, java.lang.String abbreviation, java.lang.String companyPhone, java.lang.String linkman, java.lang.String mobilePhone, java.lang.String fax, java.lang.String fixedPhone, java.lang.String address, java.lang.String zipCode, java.lang.String bankName, java.lang.String bankAccount, java.lang.String email, java.lang.String homesite, java.lang.String remark) throws CreateException {
  }
  public void ejbRemove() throws RemoveException {
  }
  public abstract void setSupplierName(java.lang.String supplierName);
  public abstract void setSupplierZone(java.lang.String supplierZone);
  public abstract void setPyCode(java.lang.String pyCode);
  public abstract void setAbbreviation(java.lang.String abbreviation);
  public abstract void setCompanyPhone(java.lang.String companyPhone);
  public abstract void setLinkman(java.lang.String linkman);
  public abstract void setMobilePhone(java.lang.String mobilePhone);
  public abstract void setFax(java.lang.String fax);
  public abstract void setFixedPhone(java.lang.String fixedPhone);
  public abstract void setAddress(java.lang.String address);
  public abstract void setZipCode(java.lang.String zipCode);
  public abstract void setBankName(java.lang.String bankName);
  public abstract void setBankAccount(java.lang.String bankAccount);
  public abstract void setEmail(java.lang.String email);
  public abstract void setHomesite(java.lang.String homesite);
  public abstract void setRemark(java.lang.String remark);
  public abstract java.lang.String getSupplierName();
  public abstract java.lang.String getSupplierZone();
  public abstract java.lang.String getPyCode();
  public abstract java.lang.String getAbbreviation();
  public abstract java.lang.String getCompanyPhone();
  public abstract java.lang.String getLinkman();
  public abstract java.lang.String getMobilePhone();
  public abstract java.lang.String getFax();
  public abstract java.lang.String getFixedPhone();
  public abstract java.lang.String getAddress();
  public abstract java.lang.String getZipCode();
  public abstract java.lang.String getBankName();
  public abstract java.lang.String getBankAccount();
  public abstract java.lang.String getEmail();
  public abstract java.lang.String getHomesite();
  public abstract java.lang.String getRemark();
  public void ejbLoad() {
  }
  public void ejbStore() {
  }
  public void ejbActivate() {
  }
  public void ejbPassivate() {
  }
  public void unsetEntityContext() {
    this.entityContext = null;
  }
  public void setEntityContext(EntityContext entityContext) {
    this.entityContext = entityContext;
  }
}
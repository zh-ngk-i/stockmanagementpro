﻿package com.shinear.sm.stockmanagementpro;

import javax.ejb.*;
import javax.naming.*;
import com.shinear.sm.user.*;
import java.util.*;
import javax.rmi.*;
import javax.sql.DataSource;
import java.sql.*;
import com.shinear.sm.method.*;

public class StockManagementDataBean implements SessionBean {
  SessionContext sessionContext;
  private UserTableHome userTableHome = null;
  private UserTable userTable = null;
  private UserLogHome userLogHome = null;
  private UserLog userLog = null;
  private GoodsCategoryHome goodsCategoryHome = null;
  private GoodsCategory goodsCategory = null;
  private GoodsHome goodsHome = null;
  private Goods goods = null;
  private SupplierHome supplierHome = null;
  private Supplier supplier = null;
  private CustomerHome customerHome = null;
  private Customer customer = null;
  private WarehouseHome warehouseHome = null;
  private Warehouse warehouse = null;
  private AccountNameHome accountNameHome = null;
  private AccountName accountName = null;
  //创建数据处理方法类
  private DataMethod dataMethod = new DataMethod();

  //创建EJB的创建接口
  public void ejbCreate() throws CreateException {
    try{
      Context context = new InitialContext();
      userTableHome = (UserTableHome)context.lookup("UserTable");
      userLogHome = (UserLogHome)context.lookup("UserLog");
      goodsCategoryHome = (GoodsCategoryHome)context.lookup("GoodsCategory");
      goodsHome = (GoodsHome)context.lookup("Goods");
      supplierHome = (SupplierHome)context.lookup("Supplier");
      customerHome = (CustomerHome)context.lookup("Customer");
      warehouseHome = (WarehouseHome)context.lookup("Warehouse");
      accountNameHome = (AccountNameHome)context.lookup("AccountName");
    }catch (Exception ex){
    }
  }
  public void ejbRemove() {
  }
  public void ejbActivate() {
  }
  public void ejbPassivate() {
  }
  public void setSessionContext(SessionContext sessionContext) {
    this.sessionContext = sessionContext;
  }
  //检查用户的方法
  public int[] checkUser(String userName, String userPassword){
    int[] functions = new int[4];
    try{
      //根据用户名字取得EJB的接口
      userTable = userTableHome.findByPrimaryKey(userName);
      //取得用户的名字和密码
      String name = userTable.getUserName();
      String password = userTable.getUserPassword();
      //检查用户名和密码
      if(name.equals(userName) && password.equals(userPassword)){
        functions[0] = userTable.getBaseInforFunction();
        functions[1] = userTable.getStockFunction();
        functions[2] = userTable.getStockManageFunction();
        functions[3] = userTable.getSaleFunction();
      }else{
        functions[0] = -1;
        functions[1] = -1;
        functions[2] = -1;
        functions[3] = -1;
      }
    }catch(Exception ex){
      functions[0] = -1;
      functions[1] = -1;
      functions[2] = -1;
      functions[3] = -1;
    }
    return functions;
  }
  //创建用户
  public int createUser(User user) {
    int result = 0;
    try{
      userTable = userTableHome.create(user.getUserName(), user.getUserPassword(),
                                       user.getBaseInforFunction(),
                                       user.getStockFunction(),
                                       user.getStockManageFunction(),
                                       user.getSaleFunction());
      result = 1;
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return result;
  }
  //更新用户
  public int updateUser(User user) {
    int result = 0;
    try{
      //根据主键寻找记录
      userTable = userTableHome.findByPrimaryKey(user.getUserName());
      //更新用户密码
      userTable.setUserPassword(user.getUserPassword());
      //更新用户权限
      userTable.setBaseInforFunction(user.getBaseInforFunction());
      userTable.setStockFunction(user.getStockFunction());
      userTable.setStockManageFunction(user.getStockManageFunction());
      userTable.setSaleFunction(user.getSaleFunction());
      result = 1;
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return result;
  }
  //删除用户
  public int deleteUser(User user) {
    int result = 0;
    try{
      //根据主键寻找记录
      userTable = userTableHome.findByPrimaryKey(user.getUserName());
      //删除用户
      userTable.remove();
      result = 1;
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return result;
  }
  //根据用户名查询用户
  public String[][] getUserByUserName(String userName){
    //创建存取用户数据的数组
    String[][] detail = null;
    try{
      //取得用户的所有记录
      Collection col = userTableHome.findByUserName("%" + userName + "%");
      if(col.size() > 0){
        Iterator iterator = col.iterator();
        //重新创建数组
        detail = new String[col.size()][6];
        int i = 0;
        //填写用户数组
        while (iterator.hasNext()) {
          //取得远程接口
          userTable = (UserTable) PortableRemoteObject.narrow(
              iterator.next(), UserTable.class);
          detail[i][0] = userTable.getUserName();
          detail[i][1] = userTable.getUserPassword();
          detail[i][2] = String.valueOf(userTable.getBaseInforFunction());
          detail[i][3] = String.valueOf(userTable.getStockFunction());
          detail[i][4] = String.valueOf(userTable.getStockManageFunction());
          detail[i][5] = String.valueOf(userTable.getSaleFunction());
          i++;
        }
      }else{
        detail = new String[0][6];
      }
    }catch(Exception ex){
      detail = new String[0][6];
      ex.printStackTrace();
    }
    //返回数组
    return detail;
  }
  //创建用户日志
  public int createUserLog(String programName, String operationContent, String userName) {
    int result = 0;
    try{
      //创建日期类
      java.util.Calendar now = java.util.Calendar.getInstance();
      java.sql.Timestamp operationDate = new java.sql.Timestamp(
          now.getTime().getTime());
      Collection col = userLogHome.findAll();
      //根据集合创建Vector集合类
      Vector vector = new Vector(col);
      Integer id = null;
      if (col.size() > 0) {
        //取得最后一条记录
        UserLog userLog = (UserLog) PortableRemoteObject.narrow(
            vector.lastElement(), UserLog.class);
        //创建新序号
        int newInt = userLog.getId().intValue() + 1;
        id = new Integer(newInt);
      }
      else {
        //如果集合不返回记录，开始序号是1
        id = new Integer(1);
      }
      //添加记录
      userLogHome.create(id, programName, operationContent, userName, operationDate);
      result = 1;
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return result;
  }
  //删除用户日志记录
  public int deleteUserLog(Integer id) {
    int result = 0;
    try{
      userLog = userLogHome.findByPrimaryKey(id);
      userLog.remove();
      result = 1;
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return result;
  }
  //联接数据库缓冲池的方法
  public java.sql.Connection getConnection() {
    InitialContext initCtx = null;
   try {
     initCtx = new InitialContext();
     DataSource ds = (javax.sql.DataSource)initCtx.lookup("stockManagement");
     return ds.getConnection();
   } catch(Exception ne) {
     System.out.println("找不到数据源");
     throw new EJBException(ne);
   } finally {
     try {
       if(initCtx != null) initCtx.close();
     } catch(NamingException ne) {
       System.out.println(ne.getMessage());
       throw new EJBException(ne);
     }
   }
  }
  //关闭数据库联接的方法
  public void cleanup(Connection con) {
    //将数据库联接返回缓冲池
    try {
      if (con != null) con.close();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
  //返回数据库所有数据表名字的方法
  public String[] getTableNames() {
    String[] tableNames = new String[0];
    //创建集合类
    Vector tableNameVector = new Vector();
    //取得数据库联接
    Connection conn = getConnection();
    try{
      //取得联接信息类
      DatabaseMetaData databaseMetaData = conn.getMetaData();
      //取得数据表名字记录集
      ResultSet rs = databaseMetaData.getTables("stockmanagement", null, null,
                                                new String[] {"TABLE"});
      String tableName = new String();
      while(rs.next()){
        tableName = rs.getString(3);
        if(!tableName.equals("dtproperties")){
          tableNameVector.addElement(rs.getString(3));
        }
      }
      tableNames = new String[tableNameVector.size()];
      for(int i = 0; i < tableNames.length; i++){
        tableNames[i] = (String)tableNameVector.get(i);
      }
    }catch(Exception ex){
      ex.printStackTrace();
    }
    //清空数据库联接
    cleanup(conn);
    return tableNames;
  }
  //返回数据表数据的方法
  public String[][] getDataByTableName(String tableName) {
    String[][] data = new String[0][0];
    //取得数据库联接
    Connection conn = getConnection();
    String countSql = "select count(*) from " + tableName;
    String sql = "select * from " + tableName;
    try{
      Statement stmt = conn.createStatement();
      //取得数据表的记录数
      ResultSet rs = stmt.executeQuery(countSql);
      int rowCount = 0;
      if(rs.next()){
        rowCount = rs.getInt(1);
      }
      //取得数据表的记录
      rs = stmt.executeQuery(sql);
      //取得数据表的列对象
      ResultSetMetaData resultSetMetaData = rs.getMetaData();
      //取得列的总数
      int colCount = resultSetMetaData.getColumnCount();
      //根据数据表的行与列总数创建数组
      data = new String[rowCount][colCount];
      //将数据记录存放在数组
      int row = 0;
      while(rs.next()){
        for(int col =0; col < colCount; col++){
          data[row][col] = rs.getString(col + 1);
        }
        row++;
      }
    }catch(Exception ex){
      data = new String[0][0];
      ex.printStackTrace();
    }
    //清空数据库联接
    cleanup(conn);
    return data;
  }
  //将数组写入数据表的方法
  public int setDataByTableName(String tableName, String[][] data) {
    int result = 0;
    //取得数据库联接
    Connection conn = getConnection();
    String deleteSql = "delete from " + tableName;
    String selectSql = "select * from " + tableName;
    String insertSql = "insert into " + tableName + " values(";
    try{
      //开始事务
      conn.setAutoCommit(false);
      //创建不带参数的SQL语句执行类
      Statement stmt = conn.createStatement();
      //删除数据表的记录
      stmt.executeUpdate(deleteSql);
      //取得数据表的记录
      ResultSet rs = stmt.executeQuery(selectSql);
      //取得数据表的列对象
      ResultSetMetaData resultSetMetaData = rs.getMetaData();
      //取得列的总数
      int colCount = resultSetMetaData.getColumnCount();
      for (int col = 0; col < colCount; col++) {
        if(col == colCount -1){
          insertSql += "?" + ")";
        }else{
          insertSql += "?" + ",";
        }
      }
      //创建带参数的SQL语句执行类
      PreparedStatement pstmt = conn.prepareStatement(insertSql);
      //创建日期转换类
      java.text.DateFormat dateLongFormat = java.text.DateFormat.getDateTimeInstance();
      java.text.DateFormat dateShortFormat = java.text.DateFormat.getDateInstance();
      //声明java.sql类包的时间变量
      Timestamp timeStamp = null;
      //将数组写入数据表
      for(int row = 0; row < data.length; row++){
        for (int col = 0; col < colCount; col++) {
          //设置字符串参数
          if (resultSetMetaData.getColumnTypeName(col + 1).equals("varchar") |
              resultSetMetaData.getColumnTypeName(col + 1).equals("longvarchar")) {
            pstmt.setString(col+1, data[row][col]);
          }
          //设置bit类型参数
          else if(resultSetMetaData.getColumnTypeName(col + 1).equals("bit")){
            pstmt.setInt(col+1, Integer.parseInt(data[row][col]));
          }
          //设置int类型参数
          else if(resultSetMetaData.getColumnTypeName(col + 1).equals("int")){
            pstmt.setInt(col+1, Integer.parseInt(data[row][col]));
          }
          //设置float类型参数
          else if(resultSetMetaData.getColumnTypeName(col + 1).equals("float") |
                  resultSetMetaData.getColumnTypeName(col + 1).equals("decimal")){
            pstmt.setDouble(col+1, Double.parseDouble(data[row][col]));
          }
          //设置timestamp类型参数
          else if(resultSetMetaData.getColumnTypeName(col + 1).equals("timestamp")){
            if(data[row][col].equals("null")){
              timeStamp = null;
            }else if(data[row][col].length() > 10){
              timeStamp = new Timestamp(dateLongFormat.parse(data[row][col]).getTime());
            }else{
              timeStamp = new Timestamp(dateShortFormat.parse(data[row][col]).getTime());
            }
            pstmt.setTimestamp(col+1, timeStamp);
          }
        }
        //执行插入操作
        pstmt.execute();
      }
      //提交事条
      conn.commit();
      result = 1;
    }catch(Exception ex){
      try{
        //撤消事务
        conn.rollback();
      }catch(Exception ex1){
        ex1.printStackTrace();
      }
      data = new String[0][0];
      ex.printStackTrace();
    }
    //清空数据库联接
    cleanup(conn);
    return result;
  }
  //取得账套名字的方法
  public String[] getLedgerNames() {
    String[] ledgerNames = new String[0];
    Vector vector = new Vector();
    String[] tableNames = getTableNames();
    for(int i = 0; i < tableNames.length; i++){
      if(tableNames[i].indexOf("stockLedger") > -1){
        if(tableNames[i].length() > 11){
          //取得数据表的日期字符串
          vector.addElement(tableNames[i].substring(11, tableNames[i].length()));
        }
      }
    }
    //将vector集合的数据放入数组
    ledgerNames = new String[vector.size()];
    for(int i = 0; i < vector.size(); i++){
      ledgerNames[i] = (String)vector.get(i);
    }
    return ledgerNames;
  }
  //创建8个空账套的方法
  private void createEmptyLedger(Statement stmt, String ledgerDate) throws Exception {
    //创建SQL语句数组
    String[] createSqls = new String[8];
    createSqls[0] = "CREATE TABLE accountEntryLedger" + ledgerDate
      + " (serialId int NOT NULL PRIMARY KEY,"
      + "linkId nvarchar(20) NOT NULL ,"
      + "filler nvarchar(50) NOT NULL ,"
      + "auditUser nvarchar(50) NOT NULL ,"
      + "fillDate datetime NOT NULL ,"
      + "auditDate datetime NULL ,"
      + "onProcess int NOT NULL ,"
      + "remark ntext NOT NULL)";
    createSqls[1] = "CREATE TABLE accountEntrySubLedger" + ledgerDate
      + " (serialId int NOT NULL PRIMARY KEY,"
      + "linkSerialId int NOT NULL ,"
      + "debitCredit int NOT NULL ,"
      + "accountName nvarchar(100) NOT NULL,"
      + "amount numeric(18, 2) NOT NULL)";
    createSqls[2] = "CREATE TABLE cashLedger" + ledgerDate
      + " (serialId int NOT NULL PRIMARY KEY,"
      + "linkId nvarchar(20) NOT NULL ,"
      + "debitCredit int NOT NULL ,"
      + "filler nvarchar(50) NOT NULL ,"
      + "amount numeric(18, 2) NOT NULL ,"
      + "fillDate datetime NOT NULL)";
    createSqls[3] = "CREATE TABLE currentAccountLedger" + ledgerDate
      + " (currentAccountId nvarchar(20) NOT NULL PRIMARY KEY,"
      + "linkId nvarchar(20) NOT NULL ,"
      + "documentType int NOT NULL ,"
      + "amount numeric(18, 2) NOT NULL ,"
      + "receiverName nvarchar (50)  NOT NULL ,"
      + "documentFiller nvarchar (50)  NOT NULL ,"
      + "cashUser nvarchar (50)  NOT NULL ,"
      + "fillDate datetime NOT NULL ,"
      + "payDate datetime NULL ,"
      + "onProcess int NOT NULL,"
      + "remark ntext  NOT NULL)";
    createSqls[4] = "CREATE TABLE saleLedger" + ledgerDate
      + " (saleId nvarchar (20) NOT NULL PRIMARY KEY,"
      + "saleType int NOT NULL ,"
      + "customerName nvarchar(50) NOT NULL ,"
      + "counterUser nvarchar(50) NOT NULL ,"
      + "creditUser nvarchar(50) NOT NULL ,"
      + "cashUser nvarchar(50) NOT NULL ,"
      + "address nvarchar(100) NOT NULL ,"
      + "fillerDate datetime NOT NULL ,"
      + "deliveryDate datetime NULL ,"
      + "onProcess int NOT NULL ,"
      + "remark ntext  NOT NULL)";
    createSqls[5] = "CREATE TABLE saleSubLedger" + ledgerDate
      + " (serialId int NOT NULL PRIMARY KEY,"
      + "saleId nvarchar(20) NOT NULL ,"
      + "goodsBarCode nvarchar(20) NOT NULL ,"
      + "actualPrice numeric(18, 2) NOT NULL ,"
      + "quantity int NOT NULL)";
    createSqls[6] = "CREATE TABLE stockLedger" + ledgerDate
      + " (orderId nvarchar(20) NOT NULL PRIMARY KEY,"
      + "orderType int NOT NULL ,"
      + "supplierName nvarchar(50) NOT NULL ,"
      + "submitUser nvarchar(50) NOT NULL ,"
      + "commitUser nvarchar(50) NOT NULL ,"
      + "checkUser nvarchar(50) NOT NULL ,"
      + "cashUser nvarchar(50) NOT NULL ,"
      + "address nvarchar(100) NOT NULL ,"
      + "warehouse nvarchar(20) NOT NULL ,"
      + "orderDate datetime NULL ,"
      + "stockDate datetime NULL ,"
      + "onProcess int NOT NULL ,"
      + "remark ntext  NOT NULL)";
    createSqls[7] = "CREATE TABLE stockSubLedger" + ledgerDate
      + " (serialId int NOT NULL PRIMARY KEY,"
      + "orderId nvarchar(20) NOT NULL ,"
      + "goodsBarCode nvarchar(20) NOT NULL ,"
      + "costPrice numeric(18, 2) NOT NULL ,"
      + "quantity int NOT NULL ,"
      + "usefulLife datetime NOT NULL)";
    //创建8个账套数据表
    for(int i = 0; i < createSqls.length; i++){
      stmt.executeUpdate(createSqls[i]);
    }
  }
  //创建账套的方法
  public int createLedger(String ledgerDate) {
    int result = 0;
    //取得数据库联接
    Connection conn = getConnection();
    try{
      //取得账套数组
      String[] ledgerNames = getLedgerNames();
      //开始事条
      conn.setAutoCommit(false);
      //创建不带参数的SQL语句执行类
      Statement stmt = conn.createStatement();
      //如果数据库没有账套，直接创建8个空账套数据表便可
      if (ledgerNames.length == 0) {
        //创建8个空账套
        createEmptyLedger(stmt, ledgerDate);
        conn.commit();
        return 1;
      }
      //为字符串数据排序
      Arrays.sort(ledgerNames);
      //取得上一个时间字符串
      String lastLedgerDate = ledgerNames[ledgerNames.length - 1];
      //如果新日期不大于旧日期，不能进行创建操作
      if (ledgerDate.compareTo(lastLedgerDate) <= 0) {
        return 0;
      }
      //创建8个空账套
      createEmptyLedger(stmt, ledgerDate);
/*取得stockLedger数据表和stockSubLedger数据表的上期数据*/
      String sql = "select distinct(a.warehouse) "
              + "from stockLedger" + lastLedgerDate
              + " as a , stockSubLedger" + lastLedgerDate
              + " as b where a.orderId = b.orderId and a.onProcess = 2";
     //创建取得stockLedger数据表的仓库的SQL语句
      ResultSet rs = stmt.executeQuery(sql);
      //创建仓库集合
      Vector warehouseVector = new Vector();
      String tempWarehouse;
      while(rs.next()){
        tempWarehouse = rs.getString(1).trim();
        if(tempWarehouse.length() > 0){
          warehouseVector.addElement(tempWarehouse);
        }
      }
      //创建上期库存单据数组
      String[] orderIds = new String[warehouseVector.size()];
      for(int i = 0; i < orderIds.length; i++){
        orderIds[i] = "上" + lastLedgerDate + dataMethod.changeSerial(i + 1);
      }
      //创建插入的SQL语句
      String insertSql = "insert into stockLedger" + ledgerDate +
          " values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
      //创建带参数的插入SQL语句执行类
      PreparedStatement insertPstmt = conn.prepareStatement(insertSql);
      //为库存账套数据表加入上期数据记录
      for(int i = 0; i < orderIds.length; i++){
        insertPstmt.setString(1, orderIds[i]);
        insertPstmt.setInt(2, 8);
        insertPstmt.setString(3, "");
        insertPstmt.setString(4, "");
        insertPstmt.setString(5, "");
        insertPstmt.setString(6, "");
        insertPstmt.setString(7, "");
        insertPstmt.setString(8, "");
        insertPstmt.setString(9, (String)warehouseVector.get(i));
        insertPstmt.setTimestamp(10, null);
        insertPstmt.setTimestamp(11, null);
        insertPstmt.setInt(12, 2);
        insertPstmt.setString(13, "");
        insertPstmt.executeUpdate();
      }
      //创建取得stockLedger数据表的不同仓库的产品总数的SQL语句
      sql = "select b.goodsBarCode, b.costprice, sum(b.quantity) as quantity, "
          + " b.usefullife from stockLedger" + lastLedgerDate
          + " as a , stockSubLedger" + lastLedgerDate + " as b "
          + "where a.orderId = b.orderId and a.onProcess = 2 and warehouse = ? "
          + "group by goodsBarCode, b.costprice, b.usefulLife "
          + "order by b.goodsBarCode, b.usefullife";
      //创建插入stockSubLedger数据表的SQL语句
      insertSql = "insert into stockSubLedger" + ledgerDate + " values(?, ?, ?, ?, ?, ?)";
      //创建带参数的选择SQL语句执行类
      PreparedStatement selectPstmt = conn.prepareStatement(sql);
      insertPstmt = conn.prepareStatement(insertSql);
      //创建stockSubLedger数据表的序号
      int serialId = 0;
      for(int i = 0; i < warehouseVector.size(); i++){
        //设置SQL语句的仓库变量
        selectPstmt.setString(1, (String)warehouseVector.get(i));
        //取得仓库的产品数据
        rs = selectPstmt.executeQuery();
        while(rs.next()){
          serialId++;
          insertPstmt.setInt(1, serialId);
          insertPstmt.setString(2, orderIds[i]);
          insertPstmt.setString(3, rs.getString("goodsBarCode"));
          insertPstmt.setDouble(4, rs.getDouble("costPrice"));
          insertPstmt.setInt(5, rs.getInt("quantity"));
          insertPstmt.setTimestamp(6, rs.getTimestamp("usefulLife"));
          insertPstmt.executeUpdate();
        }
      }
      //创建取得上期stockLedger数据表未完成单据的记录
      sql = "select * from stockLedger" + lastLedgerDate + " where onProcess = 0";
      rs = stmt.executeQuery(sql);
      //创建插入的SQL语句
      insertSql = "insert into stockLedger" + ledgerDate +
          " values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
      insertPstmt = conn.prepareStatement(insertSql);
      //创建单据标识集合类
      Vector orderIdVector = new Vector();
      String tempOrderId = "";
      while(rs.next()){
        tempOrderId = rs.getString("orderId");
        orderIdVector.addElement(tempOrderId);
        insertPstmt.setString(1, tempOrderId);
        insertPstmt.setInt(2, rs.getInt("orderType"));
        insertPstmt.setString(3, rs.getString("supplierName"));
        insertPstmt.setString(4, rs.getString("submitUser"));
        insertPstmt.setString(5, rs.getString("commitUser"));
        insertPstmt.setString(6, rs.getString("checkUser"));
        insertPstmt.setString(7, rs.getString("cashUser"));
        insertPstmt.setString(8, rs.getString("address"));
        insertPstmt.setString(9, rs.getString("warehouse"));
        insertPstmt.setTimestamp(10, rs.getTimestamp("orderDate"));
        insertPstmt.setTimestamp(11, rs.getTimestamp("stockDate"));
        insertPstmt.setInt(12, rs.getInt("onProcess"));
        insertPstmt.setString(13, rs.getString("remark"));
        insertPstmt.executeUpdate();
      }
      //创建取得上期stockSubLedger数据表未完成单据的记录
      sql = "select * from stockSubLedger" + lastLedgerDate + " where orderId = ?";
      //创建插入stockSubLedger数据表的SQL语句
      insertSql = "insert into stockSubLedger" + ledgerDate + " values(?, ?, ?, ?, ?, ?)";
      selectPstmt = conn.prepareStatement(sql);
      insertPstmt = conn.prepareStatement(insertSql);
      for(int i = 0; i < orderIdVector.size(); i++){
        tempOrderId = (String)orderIdVector.get(i);
        //设置SQL语句的单据变量
        selectPstmt.setString(1, tempOrderId);
        //根据单据标识取得产品数据
        rs = selectPstmt.executeQuery();
        while(rs.next()){
          serialId++;
          insertPstmt.setInt(1, serialId);
          insertPstmt.setString(2, tempOrderId);
          insertPstmt.setString(3, rs.getString("goodsBarCode"));
          insertPstmt.setDouble(4, rs.getDouble("costPrice"));
          insertPstmt.setInt(5, rs.getInt("quantity"));
          insertPstmt.setTimestamp(6, rs.getTimestamp("usefulLife"));
          insertPstmt.executeUpdate();
        }
      }
/*取得saleLedger数据表和saleSubLedger数据表的上期数据*/
      //创建取得上期saleLedger数据表未完成单据的记录
      sql = "select * from saleLedger" + lastLedgerDate + " where onProcess = 0";
      rs = stmt.executeQuery(sql);
      //创建插入的SQL语句
      insertSql = "insert into saleLedger" + ledgerDate +
          " values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
      insertPstmt = conn.prepareStatement(insertSql);
      //创建单据标识集合类
      Vector saleIdVector = new Vector();
      String tempSaleId = "";
      while(rs.next()){
        tempSaleId = rs.getString("saleId");
        saleIdVector.addElement(tempSaleId);
        insertPstmt.setString(1, tempSaleId);
        insertPstmt.setInt(2, rs.getInt("saleType"));
        insertPstmt.setString(3, rs.getString("customerName"));
        insertPstmt.setString(4, rs.getString("counterUser"));
        insertPstmt.setString(5, rs.getString("creditUser"));
        insertPstmt.setString(6, rs.getString("cashUser"));
        insertPstmt.setString(7, rs.getString("address"));
        insertPstmt.setTimestamp(8, rs.getTimestamp("fillerDate"));
        insertPstmt.setTimestamp(9, rs.getTimestamp("deliveryDate"));
        insertPstmt.setInt(10, rs.getInt("onProcess"));
        insertPstmt.setString(11, rs.getString("remark"));
        insertPstmt.executeUpdate();
      }
      //创建取得上期saleSubLedger数据表未完成单据的记录
      sql = "select * from saleSubLedger" + lastLedgerDate + " where saleId = ?";
      //创建插入saleSubLedger数据表的SQL语句
      insertSql = "insert into saleSubLedger" + ledgerDate + " values(?, ?, ?, ?, ?)";
      selectPstmt = conn.prepareStatement(sql);
      insertPstmt = conn.prepareStatement(insertSql);
      //序列号从0开始
      serialId = 0;
      for(int i = 0; i < saleIdVector.size(); i++){
        tempSaleId = (String)saleIdVector.get(i);
        //设置SQL语句的单据变量
        selectPstmt.setString(1, tempSaleId);
        //根据单据标识取得产品数据
        rs = selectPstmt.executeQuery();
        while(rs.next()){
          serialId++;
          insertPstmt.setInt(1, serialId);
          insertPstmt.setString(2, tempSaleId);
          insertPstmt.setString(3, rs.getString("goodsBarCode"));
          insertPstmt.setDouble(4, rs.getDouble("actualPrice"));
          insertPstmt.setInt(5, rs.getInt("quantity"));
          insertPstmt.executeUpdate();
        }
      }
/*取得currentAccountLedger数据表的上期数据*/
      //创建取得上期currentAccountLedger数据表未完成单据的记录
      sql = "select * from currentAccountLedger" + lastLedgerDate + " where onProcess = 0";
      rs = stmt.executeQuery(sql);
      //创建插入的SQL语句
      insertSql = "insert into currentAccountLedger" + ledgerDate +
          " values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
      insertPstmt = conn.prepareStatement(insertSql);
      while(rs.next()){
        insertPstmt.setString(1, rs.getString("currentAccountId"));
        insertPstmt.setString(2, rs.getString("linkId"));
        insertPstmt.setInt(3, rs.getInt("documentType"));
        insertPstmt.setDouble(4, rs.getDouble("amount"));
        insertPstmt.setString(5, rs.getString("receiverName"));
        insertPstmt.setString(6, rs.getString("documentFiller"));
        insertPstmt.setString(7, rs.getString("cashUser"));
        insertPstmt.setTimestamp(8, rs.getTimestamp("fillDate"));
        insertPstmt.setTimestamp(9, rs.getTimestamp("payDate"));
        insertPstmt.setInt(10, rs.getInt("onProcess"));
        insertPstmt.setString(11, rs.getString("remark"));
        insertPstmt.executeUpdate();
      }
/*取得accountEntryLedger数据表和accountEntrySubLedger数据表的上期数据*/
      //创建插入的SQL语句
      insertSql = "insert into accountEntryLedger" + ledgerDate +
          " values(?, ?, ?, ?, ?, ?, ?, ?)";
      //创建带参数的插入SQL语句执行类
      insertPstmt = conn.prepareStatement(insertSql);
      //创建accountEntryLedger数据表的序号
      int aelSerial = 1;
      //为会计分录账套数据表加入上期数据记录
      insertPstmt.setInt(1, aelSerial);
      insertPstmt.setString(2, "上期转入");
      insertPstmt.setString(3, "");
      insertPstmt.setString(4, "");
      insertPstmt.setTimestamp(5, dataMethod.getCurrentDate());
      insertPstmt.setTimestamp(6, null);
      insertPstmt.setInt(7, 2);
      insertPstmt.setString(8, "");
      insertPstmt.executeUpdate();
      //创建取得accountEntrySubLedger数据表的会计科目余额的SQL语句
      sql = "select debitCredit, accountName, sum(amount) as amount"
            + " from accountEntryLedger" + lastLedgerDate + " as a , "
            + " accountEntrySubLedger" + lastLedgerDate + " as b "
            + " where a.serialId = b.linkSerialId and onProcess = 2 "
            + " group by debitCredit, accountName"
            + " order by debitCredit";
      //创建插入accountEntrySubLedger数据表的SQL语句
      insertSql = "insert into accountEntrySubLedger" + ledgerDate + " values(?, ?, ?, ?, ?)";
      insertPstmt = conn.prepareStatement(insertSql);
      //创建accountEntrySubLedger数据表的序号
      int aeslSerial = 0;
      //取得accountEntrySubLedger数据表的上期数据
      rs = stmt.executeQuery(sql);
      while(rs.next()){
        aeslSerial++;
        insertPstmt.setInt(1, aeslSerial);
        insertPstmt.setInt(2, aelSerial);
        insertPstmt.setInt(3, rs.getInt("debitCredit"));
        insertPstmt.setString(4, rs.getString("accountName"));
        insertPstmt.setDouble(5, rs.getDouble("amount"));
        insertPstmt.executeUpdate();
      }
      //创建取得上期accountEntryLedger数据表未完成单据的记录
      sql = "select * from accountEntryLedger" + lastLedgerDate + " where onProcess = 0";
      rs = stmt.executeQuery(sql);
      //创建插入的SQL语句
      insertSql = "insert into accountEntryLedger" + ledgerDate +
          " values(?, ?, ?, ?, ?, ?, ?, ?)";
      insertPstmt = conn.prepareStatement(insertSql);
      //创建标识集合类
      Vector serialIdVector = new Vector();
      while(rs.next()){
        aelSerial++;
        serialIdVector.addElement(new Integer(aelSerial));
        insertPstmt.setInt(1, aelSerial);
        insertPstmt.setString(2, rs.getString("linkId"));
        insertPstmt.setString(3, rs.getString("filler"));
        insertPstmt.setString(4, rs.getString("auditUser"));
        insertPstmt.setTimestamp(5, rs.getTimestamp("fillDate"));
        insertPstmt.setTimestamp(6, rs.getTimestamp("auditDate"));
        insertPstmt.setInt(7, rs.getInt("onProcess"));
        insertPstmt.setString(8, rs.getString("remark"));
        insertPstmt.executeUpdate();
      }
      //创建取得上期accountEntrySubLedger数据表未完成会计分录的记录
      sql = "select * from accountEntrySubLedger" + lastLedgerDate + " where linkSerialId = ?";
      //创建插入accountEntrySubLedger数据表的SQL语句
      insertSql = "insert into accountEntrySubLedger" + ledgerDate + " values(?, ?, ?, ?, ?)";
      selectPstmt = conn.prepareStatement(sql);
      insertPstmt = conn.prepareStatement(insertSql);
      int tempSerialId = 0;
      for(int i = 0; i < serialIdVector.size(); i++){
        tempSerialId = ((Integer)serialIdVector.get(i)).intValue();
        //设置SQL语句的变量
        selectPstmt.setInt(1, tempSerialId);
        //取得记录
        rs = selectPstmt.executeQuery();
        while(rs.next()){
          aeslSerial++;
          insertPstmt.setInt(1, aeslSerial);
          insertPstmt.setInt(2, tempSerialId);
          insertPstmt.setInt(3, rs.getInt("debitCredit"));
          insertPstmt.setString(4, rs.getString("accountName"));
          insertPstmt.setDouble(5, rs.getDouble("amount"));
          insertPstmt.executeUpdate();
        }
      }
      //提交事条
      conn.commit();
      result = 1;
    }catch(Exception ex){
      try{
        //撤消事务
        conn.rollback();
      }catch(Exception ex1){
        ex1.printStackTrace();
      }
      ex.printStackTrace();
    }
    //清空数据库联接
    cleanup(conn);
    return result;
  }
  //删除账套的方法
  public int deleteLedger(String ledgerDate) {
    int result = 0;
    String[] ledgerNames = getLedgerNames();
    //如果数据库没有账套数据，返回0
    if(ledgerNames.length == 0){
      return 0;
    }
    //为字符串数组排序
    Arrays.sort(ledgerNames);
    //如果不是最后一个账套，不能实现删除操作
    if(ledgerNames[ledgerNames.length - 1].indexOf(ledgerDate) == -1){
      return 0;
    }
    //取得数据库联接
    Connection conn = getConnection();
    //创建删除数据表数组
    String[] delTableNames = new String[] {
        "stockLedger" + ledgerDate, "stockSubLedger" + ledgerDate,
        "saleLedger" + ledgerDate, "saleSubLedger" + ledgerDate,
        "currentAccountLedger" + ledgerDate, "cashLedger" + ledgerDate,
        "accountEntryLedger" + ledgerDate, "accountEntrySubLedger" + ledgerDate
    };
    //创建删除SQL语句
    String deleteSql = "";
    try{
      //开始事务
      conn.setAutoCommit(false);
      //创建不带参数的SQL语句执行类
      Statement stmt = conn.createStatement();
      //删除数据表
      for(int i = 0; i < delTableNames.length; i++){
        deleteSql = "drop table " + delTableNames[i];
        stmt.executeUpdate(deleteSql);
      }
      //提交事务
      conn.commit();
      result = 1;
    }catch(Exception ex){
      try{
        //撤消事务
        conn.rollback();
      }catch(Exception ex1){
        ex1.printStackTrace();
      }
      ex.printStackTrace();
    }
    //清空数据库联接
    cleanup(conn);
    return result;
  }
  //创建商品类别的方法
  public int createGoodsCategory(int parentId, String categoryName, String categoryDescription) {
    int result = 0;
    try {
      Collection col = goodsCategoryHome.findAll();
      //根据集合创建Vector集合类
      Vector vector = new Vector(col);
      Integer categoryId = null;
      if (col.size() > 0) {
        //取得最后一条记录
        GoodsCategory goodsCategory = (GoodsCategory) PortableRemoteObject.narrow(
            vector.lastElement(), GoodsCategory.class);
        //创建新序号
        int newInt = goodsCategory.getCategoryId().intValue() + 1;
        categoryId = new Integer(newInt);
      }
      else {
        //如果集合不返回记录，开始序号是1
        categoryId = new Integer(1);
      }
      goodsCategoryHome.create(categoryId , parentId, categoryName,
                               categoryDescription);
      result = 1;
    }catch (Exception ex) {
      ex.printStackTrace();
    }
    return result;
  }
  //更新商品类别的方法
  public int updateGoodsCategory(int categoryId, int parentId, String categoryName, String categoryDescription) {
    int result = 0;
    try {
      goodsCategory = goodsCategoryHome.findByPrimaryKey(new Integer(categoryId));
      goodsCategory.setParentId(parentId);
      goodsCategory.setCategoryName(categoryName);
      goodsCategory.setCategoryDescription(categoryDescription);
      result = 1;
    }catch (Exception ex) {
      ex.printStackTrace();
    }
    return result;
  }
  //删除商品类别的方法
  public int deleteGoodsCategory(int categoryId) {
    int result = 0;
    try {
      Collection col = goodsHome.findByGoodsCategory(categoryId);
      //只有商品类别没有商品数量才可以删除商品类别
      if(col.size() == 0){
        goodsCategory = goodsCategoryHome.findByPrimaryKey(new Integer(categoryId));
        goodsCategory.remove();
        result = 1;
      }
    }catch (Exception ex) {
      ex.printStackTrace();
    }
    return result;
  }
  //取得所有商品类别的方法
  public String[][] getAllGoodsCategory() {
    String[][] detail = new String[0][4];
    try{
      //取得商品类别的所有记录
      Collection col = goodsCategoryHome.findAll();
      if(col.size() > 0){
        Iterator iterator = col.iterator();
        //重新创建数组
        detail = new String[col.size()][4];
        int i = 0;
        while (iterator.hasNext()) {
          //取得远程接口
          goodsCategory = (GoodsCategory) PortableRemoteObject.narrow(
              iterator.next(), GoodsCategory.class);
          detail[i][0] = String.valueOf(goodsCategory.getCategoryId());
          detail[i][1] = String.valueOf(goodsCategory.getParentId());
          detail[i][2] = goodsCategory.getCategoryName();
          detail[i][3] = goodsCategory.getCategoryDescription();
          i++;
        }
      }
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return detail;
  }
  //创建商品的方法
  public int createGoods(String goodsBarCode, int categoryId, String goodsName, String goodsNickName, String goodsAssistantName, String goodsPYName, String unit, String specification, String producer, int upperLimit, int lowerLimit, double salePrice, double discount) {
     int result = 0;
     try {
       goodsHome.create(goodsBarCode, categoryId, goodsName, goodsNickName,
                     goodsAssistantName, goodsPYName, unit,
                     specification, producer, upperLimit, lowerLimit,
                     salePrice, discount);
       result = 1;
     }catch (Exception ex) {
       ex.printStackTrace();
     }
     return result;
  }
  //更新商品的方法
  public int updateGoods(String goodsBarCode, int categoryId, String goodsName, String goodsNickName, String goodsAssistantName, String goodsPYName, String unit, String specification, String producer, int upperLimit, int lowerLimit, double salePrice, double discount) {
    int result = 0;
    try {
      goods = goodsHome.findByPrimaryKey(goodsBarCode);
      goods.setCategoryId(categoryId);
      goods.setGoodsName(goodsName);
      goods.setGoodsNickName(goodsNickName);
      goods.setGoodsAssistantName(goodsAssistantName);
      goods.setGoodsPYName(goodsPYName);
      goods.setUnit(unit);
      goods.setSpecification(specification);
      goods.setProducer(producer);
      goods.setUpperLimit(upperLimit);
      goods.setLowerLimit(lowerLimit);
      goods.setSalePrice(salePrice);
      goods.setDiscount(discount);
      result = 1;
    }catch (Exception ex) {
      ex.printStackTrace();
    }
    return result;
  }
  //删除商品的方法
  public int deleteGoods(String goodsBarCode) {
     int result = 0;
     try {
       goods = goodsHome.findByPrimaryKey(goodsBarCode);
       goods.remove();
       result = 1;
     }catch (Exception ex) {
       ex.printStackTrace();
     }
     return result;
  }
  //根据类别取得商品的方法
  public String[][] getGoodsByGoodsCategory(int goodsCategory){
    String[][] detail = new String[0][13];
    try{
      //根据类别取得商品记录
      Collection col = goodsHome.findByGoodsCategory(goodsCategory);
      if(col.size() > 0){
        Iterator iterator = col.iterator();
        //重新创建数组
        detail = new String[col.size()][13];
        int i = 0;
        while (iterator.hasNext()) {
          //取得远程接口
          goods = (Goods) PortableRemoteObject.narrow(
              iterator.next(), Goods.class);
          detail[i][0] = goods.getGoodsBarCode();
          detail[i][1] = String.valueOf(goods.getCategoryId());
          detail[i][2] = goods.getGoodsName();
          detail[i][3] = goods.getGoodsNickName();
          detail[i][4] = goods.getGoodsAssistantName();
          detail[i][5] = goods.getGoodsPYName();
          detail[i][6] = goods.getUnit();
          detail[i][7] = goods.getSpecification();
          detail[i][8] = goods.getProducer();
          detail[i][9] = String.valueOf(goods.getUpperLimit());
          detail[i][10] = String.valueOf(goods.getLowerLimit());
          detail[i][11] = String.valueOf(dataMethod.round(goods.getSalePrice()));
          detail[i][12] = String.valueOf(dataMethod.round(goods.getDiscount()));
          i++;
        }
      }
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return detail;
  }
  //根据条形码取得商品的方法
  public String[][] getGoodsByGoodsBarCode(String goodsBarCode){
    String[][] detail = new String[0][13];
    try{
      //根据条形码取得商品记录
      Collection col = goodsHome.findByGoodsBarCode("%" + goodsBarCode + "%");
      if(col.size() > 0){
        Iterator iterator = col.iterator();
        //重新创建数组
        detail = new String[col.size()][13];
        int i = 0;
        while (iterator.hasNext()) {
          //取得远程接口
          goods = (Goods) PortableRemoteObject.narrow(
              iterator.next(), Goods.class);
          detail[i][0] = goods.getGoodsBarCode();
          detail[i][1] = String.valueOf(goods.getCategoryId());
          detail[i][2] = goods.getGoodsName();
          detail[i][3] = goods.getGoodsNickName();
          detail[i][4] = goods.getGoodsAssistantName();
          detail[i][5] = goods.getGoodsPYName();
          detail[i][6] = goods.getUnit();
          detail[i][7] = goods.getSpecification();
          detail[i][8] = goods.getProducer();
          detail[i][9] = String.valueOf(goods.getUpperLimit());
          detail[i][10] = String.valueOf(goods.getLowerLimit());
          detail[i][11] = String.valueOf(dataMethod.round(goods.getSalePrice()));
          detail[i][12] = String.valueOf(dataMethod.round(goods.getDiscount()));
          i++;
        }
      }
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return detail;
  }
  //根据商品名字取得商品的方法
  public String[][] getGoodsByGoodsName(String goodsName){
    String[][] detail = new String[0][13];
    try{
      //根据商品名字取得商品记录
      Collection col = goodsHome.findByGoodsName("%" + goodsName + "%");
      if(col.size() > 0){
        Iterator iterator = col.iterator();
        //重新创建数组
        detail = new String[col.size()][13];
        int i = 0;
        while (iterator.hasNext()) {
          //取得远程接口
          goods = (Goods) PortableRemoteObject.narrow(
              iterator.next(), Goods.class);
          detail[i][0] = goods.getGoodsBarCode();
          detail[i][1] = String.valueOf(goods.getCategoryId());
          detail[i][2] = goods.getGoodsName();
          detail[i][3] = goods.getGoodsNickName();
          detail[i][4] = goods.getGoodsAssistantName();
          detail[i][5] = goods.getGoodsPYName();
          detail[i][6] = goods.getUnit();
          detail[i][7] = goods.getSpecification();
          detail[i][8] = goods.getProducer();
          detail[i][9] = String.valueOf(goods.getUpperLimit());
          detail[i][10] = String.valueOf(goods.getLowerLimit());
          detail[i][11] = String.valueOf(dataMethod.round(goods.getSalePrice()));
          detail[i][12] = String.valueOf(dataMethod.round(goods.getDiscount()));
          i++;
        }
      }
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return detail;
  }
  //根据生产厂商取得商品的方法
  public String[][] getGoodsByProducer(String producer){
    String[][] detail = new String[0][13];
    try{
      //根据生产厂商取得商品记录
      Collection col = goodsHome.findByProducer("%" + producer + "%");
      if(col.size() > 0){
        Iterator iterator = col.iterator();
        //重新创建数组
        detail = new String[col.size()][13];
        int i = 0;
        while (iterator.hasNext()) {
          //取得远程接口
          goods = (Goods) PortableRemoteObject.narrow(
              iterator.next(), Goods.class);
          detail[i][0] = goods.getGoodsBarCode();
          detail[i][1] = String.valueOf(goods.getCategoryId());
          detail[i][2] = goods.getGoodsName();
          detail[i][3] = goods.getGoodsNickName();
          detail[i][4] = goods.getGoodsAssistantName();
          detail[i][5] = goods.getGoodsPYName();
          detail[i][6] = goods.getUnit();
          detail[i][7] = goods.getSpecification();
          detail[i][8] = goods.getProducer();
          detail[i][9] = String.valueOf(goods.getUpperLimit());
          detail[i][10] = String.valueOf(goods.getLowerLimit());
          detail[i][11] = String.valueOf(dataMethod.round(goods.getSalePrice()));
          detail[i][12] = String.valueOf(dataMethod.round(goods.getDiscount()));
          i++;
        }
      }
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return detail;
  }
  //取得折扣商品的方法
  public String[][] getDiscountGoods() {
    String[][] detail = new String[0][13];
    try{
      //取得打折商品记录
      Collection col = goodsHome.findDiscountGoods();
      if(col.size() > 0){
        Iterator iterator = col.iterator();
        //重新创建数组
        detail = new String[col.size()][13];
        int i = 0;
        while (iterator.hasNext()) {
          //取得远程接口
          goods = (Goods) PortableRemoteObject.narrow(
              iterator.next(), Goods.class);
          detail[i][0] = goods.getGoodsBarCode();
          detail[i][1] = String.valueOf(goods.getCategoryId());
          detail[i][2] = goods.getGoodsName();
          detail[i][3] = goods.getGoodsNickName();
          detail[i][4] = goods.getGoodsAssistantName();
          detail[i][5] = goods.getGoodsPYName();
          detail[i][6] = goods.getUnit();
          detail[i][7] = goods.getSpecification();
          detail[i][8] = goods.getProducer();
          detail[i][9] = String.valueOf(goods.getUpperLimit());
          detail[i][10] = String.valueOf(goods.getLowerLimit());
          detail[i][11] = String.valueOf(dataMethod.round(goods.getSalePrice()));
          detail[i][12] = String.valueOf(dataMethod.round(goods.getDiscount()));
          i++;
        }
      }
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return detail;
  }
  //设置商品折扣的方法
  public int setGoodsDiscount(String goodsBarCode, double discount) {
    int result = 0;
    try {
      goods = goodsHome.findByPrimaryKey(goodsBarCode);
      goods.setDiscount(discount);
      result = 1;
    }catch (Exception ex) {
      ex.printStackTrace();
    }
    return result;
  }
  //创建供应商的方法
  public int createSupplier(String[] supplierArray) {
     int result = 0;
     if(supplierArray.length != 16){
       return result;
     }
     try {
       //创建供应商
       supplierHome.create(supplierArray[0], supplierArray[1], supplierArray[2],
                           supplierArray[3], supplierArray[4], supplierArray[5],
                           supplierArray[6], supplierArray[7], supplierArray[8],
                           supplierArray[9], supplierArray[10], supplierArray[11],
                           supplierArray[12], supplierArray[13],
                           supplierArray[14], supplierArray[15]);
       result = 1;
     }catch (Exception ex) {
       ex.printStackTrace();
     }
     return result;
  }
  //更新供应商的方法
  public int updateSupplier(String[] supplierArray) {
     int result = 0;
     if(supplierArray.length != 16){
       return result;
     }
     try {
       supplier = supplierHome.findByPrimaryKey(supplierArray[0]);
       //更新供应商
       supplier.setSupplierZone(supplierArray[1]);
       supplier.setPyCode(supplierArray[2]);
       supplier.setAbbreviation(supplierArray[3]);
       supplier.setCompanyPhone(supplierArray[4]);
       supplier.setLinkman(supplierArray[5]);
       supplier.setMobilePhone(supplierArray[6]);
       supplier.setFax(supplierArray[7]);
       supplier.setFixedPhone(supplierArray[8]);
       supplier.setAddress(supplierArray[9]);
       supplier.setZipCode(supplierArray[10]);
       supplier.setBankName(supplierArray[11]);
       supplier.setBankAccount(supplierArray[12]);
       supplier.setEmail(supplierArray[13]);
       supplier.setHomesite(supplierArray[14]);
       supplier.setRemark(supplierArray[15]);
       result = 1;
     }catch (Exception ex) {
       ex.printStackTrace();
     }
     return result;
  }
  //删除供应商的方法
  public int deleteSupplier(String supplierName) {
     int result = 0;
     try {
       supplier = supplierHome.findByPrimaryKey(supplierName);
       //删除供应商
       supplier.remove();
       result = 1;
     }catch (Exception ex) {
       ex.printStackTrace();
     }
     return result;
  }
  //根据供应商名字取得记录的方法
  public String[][] getSuppliersBySupplierName(String supplierName){
    String[][] detail = new String[0][16];
    try{
      //根据供应商名字取得记录
      Collection col = supplierHome.findBySupplierName("%" + supplierName + "%");
      if(col.size() > 0){
        Iterator iterator = col.iterator();
        //重新创建数组
        detail = new String[col.size()][16];
        int i = 0;
        while (iterator.hasNext()) {
          //取得远程接口
          supplier = (Supplier) PortableRemoteObject.narrow(
              iterator.next(), Supplier.class);
          detail[i][0] = supplier.getSupplierName();
          detail[i][1] = supplier.getSupplierZone();
          detail[i][2] = supplier.getPyCode();
          detail[i][3] = supplier.getAbbreviation();
          detail[i][4] = supplier.getCompanyPhone();
          detail[i][5] = supplier.getLinkman();
          detail[i][6] = supplier.getMobilePhone();
          detail[i][7] = supplier.getFax();
          detail[i][8] = supplier.getFixedPhone();
          detail[i][9] = supplier.getAddress();
          detail[i][10] = supplier.getZipCode();
          detail[i][11] = supplier.getBankName();
          detail[i][12] = supplier.getBankAccount();
          detail[i][13] = supplier.getEmail();
          detail[i][14] = supplier.getHomesite();
          detail[i][15] = supplier.getRemark();
          i++;
        }
      }
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return detail;
  }
  //根据地区取得供应商记录的方法
  public String[][] getSuppliersBySupplierZone(String supplierZone){
    String[][] detail = new String[0][16];
    try{
      //根据地区取得记录
      Collection col = supplierHome.findBySupplierZone("%" + supplierZone + "%");
      if(col.size() > 0){
        Iterator iterator = col.iterator();
        //重新创建数组
        detail = new String[col.size()][16];
        int i = 0;
        while (iterator.hasNext()) {
          //取得远程接口
          supplier = (Supplier) PortableRemoteObject.narrow(
              iterator.next(), Supplier.class);
          detail[i][0] = supplier.getSupplierName();
          detail[i][1] = supplier.getSupplierZone();
          detail[i][2] = supplier.getPyCode();
          detail[i][3] = supplier.getAbbreviation();
          detail[i][4] = supplier.getCompanyPhone();
          detail[i][5] = supplier.getLinkman();
          detail[i][6] = supplier.getMobilePhone();
          detail[i][7] = supplier.getFax();
          detail[i][8] = supplier.getFixedPhone();
          detail[i][9] = supplier.getAddress();
          detail[i][10] = supplier.getZipCode();
          detail[i][11] = supplier.getBankName();
          detail[i][12] = supplier.getBankAccount();
          detail[i][13] = supplier.getEmail();
          detail[i][14] = supplier.getHomesite();
          detail[i][15] = supplier.getRemark();
          i++;
        }
      }
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return detail;
  }
  //创建客户的方法
  public int createCustomer(String[] customerArray) {
     int result = 0;
     if(customerArray.length != 17){
       return result;
     }
     try {
       //创建客户
       customerHome.create(customerArray[0], customerArray[1], customerArray[2],
                           customerArray[3], customerArray[4], customerArray[5],
                           customerArray[6], customerArray[7], customerArray[8],
                           customerArray[9], customerArray[10], customerArray[11],
                           customerArray[12], customerArray[13], customerArray[14],
                           Double.parseDouble(customerArray[15]), customerArray[16]);
       result = 1;
     }catch (Exception ex) {
       ex.printStackTrace();
     }
     return result;
  }
  //更新客户的方法
  public int updateCustomer(String[] customerArray) {
     int result = 0;
     if(customerArray.length != 17){
       return result;
     }
     try {
       customer = customerHome.findByPrimaryKey(customerArray[0]);
       //更新客户
       customer.setCustomerZone(customerArray[1]);
       customer.setPyCode(customerArray[2]);
       customer.setAbbreviation(customerArray[3]);
       customer.setCompanyPhone(customerArray[4]);
       customer.setLinkman(customerArray[5]);
       customer.setMobilePhone(customerArray[6]);
       customer.setFax(customerArray[7]);
       customer.setFixedPhone(customerArray[8]);
       customer.setAddress(customerArray[9]);
       customer.setZipCode(customerArray[10]);
       customer.setBankName(customerArray[11]);
       customer.setBankAccount(customerArray[12]);
       customer.setEmail(customerArray[13]);
       customer.setHomesite(customerArray[14]);
       customer.setCreditlimit(Double.parseDouble(customerArray[15]));
       customer.setRemark(customerArray[16]);
       result = 1;
     }catch (Exception ex) {
       ex.printStackTrace();
     }
     return result;
  }
  //删除客户的方法
  public int deleteCustomer(String customerName) {
     int result = 0;
     try {
       customer = customerHome.findByPrimaryKey(customerName);
       //删除客户
       customer.remove();
       result = 1;
     }catch (Exception ex) {
       ex.printStackTrace();
     }
     return result;
  }
  //根据客户名字取得记录的方法
  public String[][] getCustomersByCustomerName(String customerName){
    String[][] detail = new String[0][17];
    try{
      //根据客户名字取得记录
      Collection col = customerHome.findByCustomerName("%" + customerName + "%");
      if(col.size() > 0){
        Iterator iterator = col.iterator();
        //重新创建数组
        detail = new String[col.size()][17];
        int i = 0;
        while (iterator.hasNext()) {
          //取得远程接口
          customer = (Customer) PortableRemoteObject.narrow(
              iterator.next(), Customer.class);
          detail[i][0] = customer.getCustomerName();
          detail[i][1] = customer.getCustomerZone();
          detail[i][2] = customer.getPyCode();
          detail[i][3] = customer.getAbbreviation();
          detail[i][4] = customer.getCompanyPhone();
          detail[i][5] = customer.getLinkman();
          detail[i][6] = customer.getMobilePhone();
          detail[i][7] = customer.getFax();
          detail[i][8] = customer.getFixedPhone();
          detail[i][9] = customer.getAddress();
          detail[i][10] = customer.getZipCode();
          detail[i][11] = customer.getBankName();
          detail[i][12] = customer.getBankAccount();
          detail[i][13] = customer.getEmail();
          detail[i][14] = customer.getHomesite();
          detail[i][15] = String.valueOf(dataMethod.round(customer.getCreditlimit()));
          detail[i][16] = customer.getRemark();
          i++;
        }
      }
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return detail;
  }
  //根据地区取得客户记录的方法
  public String[][] getCustomersByCustomerZone(String customerZone){
    String[][] detail = new String[0][17];
    try{
      //根据地区取得记录
      Collection col = customerHome.findByCustomerZone("%" + customerZone + "%");
      if(col.size() > 0){
        Iterator iterator = col.iterator();
        //重新创建数组
        detail = new String[col.size()][17];
        int i = 0;
        while (iterator.hasNext()) {
          //取得远程接口
          customer = (Customer) PortableRemoteObject.narrow(
              iterator.next(), Customer.class);
          detail[i][0] = customer.getCustomerName();
          detail[i][1] = customer.getCustomerZone();
          detail[i][2] = customer.getPyCode();
          detail[i][3] = customer.getAbbreviation();
          detail[i][4] = customer.getCompanyPhone();
          detail[i][5] = customer.getLinkman();
          detail[i][6] = customer.getMobilePhone();
          detail[i][7] = customer.getFax();
          detail[i][8] = customer.getFixedPhone();
          detail[i][9] = customer.getAddress();
          detail[i][10] = customer.getZipCode();
          detail[i][11] = customer.getBankName();
          detail[i][12] = customer.getBankAccount();
          detail[i][13] = customer.getEmail();
          detail[i][14] = customer.getHomesite();
          detail[i][15] = String.valueOf(dataMethod.round(customer.getCreditlimit()));
          detail[i][16] = customer.getRemark();
          i++;
        }
      }
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return detail;
  }
  //取得信用客户的方法
  public String[][] getCreditCustomer() {
    String[][] detail = new String[0][17];
    try{
      //取得信用客户记录
      Collection col = customerHome.findCreditCustomer();
      if(col.size() > 0){
        Iterator iterator = col.iterator();
        //重新创建数组
        detail = new String[col.size()][17];
        int i = 0;
        while (iterator.hasNext()) {
          //取得远程接口
          customer = (Customer) PortableRemoteObject.narrow(
              iterator.next(), Customer.class);
          detail[i][0] = customer.getCustomerName();
          detail[i][1] = customer.getCustomerZone();
          detail[i][2] = customer.getPyCode();
          detail[i][3] = customer.getAbbreviation();
          detail[i][4] = customer.getCompanyPhone();
          detail[i][5] = customer.getLinkman();
          detail[i][6] = customer.getMobilePhone();
          detail[i][7] = customer.getFax();
          detail[i][8] = customer.getFixedPhone();
          detail[i][9] = customer.getAddress();
          detail[i][10] = customer.getZipCode();
          detail[i][11] = customer.getBankName();
          detail[i][12] = customer.getBankAccount();
          detail[i][13] = customer.getEmail();
          detail[i][14] = customer.getHomesite();
          detail[i][15] = String.valueOf(dataMethod.round(customer.getCreditlimit()));
          detail[i][16] = customer.getRemark();
          i++;
        }
      }
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return detail;
  }
  //设置客户信用的方法
  public int setCreditCustomer(String customerName, double creditlimit) {
    int result = 0;
    try {
      customer = customerHome.findByPrimaryKey(customerName);
      //设置客户的信用
      customer.setCreditlimit(creditlimit);
      result = 1;
    }catch (Exception ex) {
      ex.printStackTrace();
    }
    return result;
  }
  //创建仓库
  public int createWarehouse(String[] warehouseArray) {
    int result = 0;
    if(warehouseArray.length != 4){
      return result;
    }
    try {
      //创建仓库
      warehouseHome.create(warehouseArray[0], warehouseArray[1], warehouseArray[2],
                          warehouseArray[3]);
      result = 1;
    }catch (Exception ex) {
      ex.printStackTrace();
    }
    return result;
  }
  //更新仓库
  public int updateWarehouse(String[] warehouseArray) {
    int result = 0;
    if(warehouseArray.length != 4){
      return result;
    }
    try {
      warehouse = warehouseHome.findByPrimaryKey(warehouseArray[0]);
      //更新仓库
      warehouse.setPyCode(warehouseArray[1]);
      warehouse.setLocation(warehouseArray[2]);
      warehouse.setDescription(warehouseArray[3]);
      result = 1;
    }catch (Exception ex) {
      ex.printStackTrace();
    }
    return result;
  }
  //删除仓库
  public int deleteWarehouse(String warehouseName) {
    int result = 0;
    try {
      warehouse = warehouseHome.findByPrimaryKey(warehouseName);
      //删除仓库
      warehouse.remove();
      result = 1;
    }catch (Exception ex) {
      ex.printStackTrace();
    }
    return result;
  }
  //取得所有仓库
  public String[][] getAllWarehouse() {
    String[][] detail = new String[0][4];
    try{
      //取得所有仓库记录
      Collection col = warehouseHome.findAll();
      if(col.size() > 0){
        Iterator iterator = col.iterator();
        //重新创建数组
        detail = new String[col.size()][4];
        int i = 0;
        while (iterator.hasNext()) {
          //取得远程接口
          warehouse = (Warehouse) PortableRemoteObject.narrow(
              iterator.next(), Warehouse.class);
          detail[i][0] = warehouse.getWarehouseName();
          detail[i][1] = warehouse.getPyCode();
          detail[i][2] = warehouse.getLocation();
          detail[i][3] = warehouse.getDescription();
          i++;
        }
      }
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return detail;
  }
  //创建会计科目
  public int createAccountName(int parentId, String accountNameStr) {
    int result = 0;
    try {
      Collection col = accountNameHome.findAll();
     //根据集合创建Vector集合类
     Vector vector = new Vector(col);
     Integer id = null;
     if (col.size() > 0) {
       //取得最后一条记录
       AccountName accountName = (AccountName) PortableRemoteObject.narrow(
           vector.lastElement(), AccountName.class);
       //创建新序号
       int newInt = accountName.getAccountId().intValue() + 1;
       id = new Integer(newInt);
     }
     else {
       //如果集合不返回记录，开始序号是1
       id = new Integer(1);
     }
      //创建会计科目
      accountNameHome.create(id, parentId, accountNameStr);
      result = 1;
    }catch (Exception ex) {
      ex.printStackTrace();
    }
    return result;
  }
  //更新会计科目
  public int updateAccountName(int accountId, int parentId, String accountNameStr) {
    int result = 0;
    try {
      accountName = accountNameHome.findByPrimaryKey(new Integer(accountId));
      //更新会计科目
      accountName.setParentId(parentId);
      accountName.setAccountName(accountNameStr);
      result = 1;
    }catch (Exception ex) {
      ex.printStackTrace();
    }
    return result;
  }
  //删除会计科目
  public int deleteAccountName(int accountId) {
    int result = 0;
    try {
      accountName = accountNameHome.findByPrimaryKey(new Integer(accountId));
      int idOriginal = accountName.getAccountId().intValue();
      Collection col = accountNameHome.findByParentId(idOriginal);
      //如果该科目没有子科目，才能删除会计科目
      if(col.size() == 0){
        //删除会计科目
        accountName.remove();
        result = 1;
      }
    }catch (Exception ex) {
      ex.printStackTrace();
    }
    return result;
  }
  //根据父标识取得会计科目
  public String[][] getAccountNameByParentid(int parentId) {
    String[][] detail = new String[0][3];
    try{
      //根据父标识取得会计科目记录
      Collection col = accountNameHome.findByParentId(parentId);
      if(col.size() > 0){
        Iterator iterator = col.iterator();
        //重新创建数组
        detail = new String[col.size()][3];
        int i = 0;
        while (iterator.hasNext()) {
          //取得远程接口
          accountName = (AccountName) PortableRemoteObject.narrow(
              iterator.next(), AccountName.class);
          detail[i][0] = accountName.getAccountId().toString();
          detail[i][1] = String.valueOf(accountName.getParentId());
          detail[i][2] = accountName.getAccountName();
          i++;
        }
      }
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return detail;
  }
  //取得所有会计科目
  public String[][] getAllAccountName() {
    String[][] detail = new String[0][3];
    try{
      //取得所有会计科目记录
      Collection col = accountNameHome.findAll();
      if(col.size() > 0){
        Iterator iterator = col.iterator();
        //重新创建数组
        detail = new String[col.size()][3];
        int i = 0;
        while (iterator.hasNext()) {
          //取得远程接口
          accountName = (AccountName) PortableRemoteObject.narrow(
              iterator.next(), AccountName.class);
          detail[i][0] = accountName.getAccountId().toString();
          detail[i][1] = String.valueOf(accountName.getParentId());
          detail[i][2] = accountName.getAccountName();
          i++;
        }
      }
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return detail;
  }
  //取得科目余额的方法
  public String[][] getAccountBalance(String ledgerDate, int onProcess) {
    String[][] data = new String[0][3];
    //取得数据库联接
    Connection conn = getConnection();
    String sql = "select accountName, debitCredit, sum(amount) as amount"
         + " from accountEntryLedger" + ledgerDate + " as a , accountEntrySubLedger" + ledgerDate + " as b"
         + " where a.serialId = b.linkSerialId and onProcess = " + onProcess
         + " group by debitCredit, accountName"
         + " order by debitCredit";
    try {
      Statement stmt = conn.createStatement();
      //取得数据表的记录
      ResultSet rs = stmt.executeQuery(sql);
      int rowCount = 0;
      while (rs.next()) {
        rowCount++;
      }
      //重新取得数据表的记录
      rs = stmt.executeQuery(sql);
      //根据数据表的行与列总数创建数组
      data = new String[rowCount][3];
      //将数据记录存放在数组
      int row = 0;
      while (rs.next()) {
        for (int col = 0; col < 3; col++) {
          data[row][col] = rs.getString(col + 1);
        }
        row++;
      }
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    //清空数据库联接
    cleanup(conn);
    return data;
  }
  //根据操作程序名字取得日志记录的方法
  public String[][] getUserLogByProgramName(String programName) {
    String[][] detail = new String[0][5];
    try{
      //根据操作程序名字取得日志记录
      Collection col = userLogHome.findByProgramName("%" + programName + "%");
      if(col.size() > 0){
        Iterator iterator = col.iterator();
        //重新创建数组
        detail = new String[col.size()][5];
        int i = 0;
        while (iterator.hasNext()) {
          //取得远程接口
          userLog = (UserLog) PortableRemoteObject.narrow(
              iterator.next(), UserLog.class);
          detail[i][0] = userLog.getId().toString();
          detail[i][1] = userLog.getProgramName();
          detail[i][2] = userLog.getOperationContent();
          detail[i][3] = userLog.getUserName();
          detail[i][4] = userLog.getOperationDate().toString();
          i++;
        }
      }
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return detail;
  }
  //根据操作内容取得日志记录的方法
  public String[][] getUserLogByOperationContent(String operationContent) {
    String[][] detail = new String[0][5];
    try{
      //根据操作内容取得日志记录
      Collection col = userLogHome.findByOperationContent("%" + operationContent + "%");
      if(col.size() > 0){
        Iterator iterator = col.iterator();
        //重新创建数组
        detail = new String[col.size()][5];
        int i = 0;
        while (iterator.hasNext()) {
          //取得远程接口
          userLog = (UserLog) PortableRemoteObject.narrow(
              iterator.next(), UserLog.class);
          detail[i][0] = userLog.getId().toString();
          detail[i][1] = userLog.getProgramName();
          detail[i][2] = userLog.getOperationContent();
          detail[i][3] = userLog.getUserName();
          detail[i][4] = userLog.getOperationDate().toString();
          i++;
        }
      }
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return detail;
  }
  //根据用户名字取得日志记录的方法
  public String[][] getUserLogByUserName(String userName) {
    String[][] detail = new String[0][5];
    try{
      //根据用户名字取得日志记录
      Collection col = userLogHome.findByUserName("%" + userName + "%");
      if(col.size() > 0){
        Iterator iterator = col.iterator();
        //重新创建数组
        detail = new String[col.size()][5];
        int i = 0;
        while (iterator.hasNext()) {
          //取得远程接口
          userLog = (UserLog) PortableRemoteObject.narrow(
              iterator.next(), UserLog.class);
          detail[i][0] = userLog.getId().toString();
          detail[i][1] = userLog.getProgramName();
          detail[i][2] = userLog.getOperationContent();
          detail[i][3] = userLog.getUserName();
          detail[i][4] = userLog.getOperationDate().toString();
          i++;
        }
      }
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return detail;
  }
  //根据操作时间取得日志记录的方法
  public String[][] getUserLogByOperationDate(java.sql.Timestamp startDate, java.sql.Timestamp endDate) {
    String[][] detail = new String[0][5];
    try{
      //根据操作时间取得日志记录
      Collection col = userLogHome.findByOperationDate(startDate, endDate);
      if(col.size() > 0){
        Iterator iterator = col.iterator();
        //重新创建数组
        detail = new String[col.size()][5];
        int i = 0;
        while (iterator.hasNext()) {
          //取得远程接口
          userLog = (UserLog) PortableRemoteObject.narrow(
              iterator.next(), UserLog.class);
          detail[i][0] = userLog.getId().toString();
          detail[i][1] = userLog.getProgramName();
          detail[i][2] = userLog.getOperationContent();
          detail[i][3] = userLog.getUserName();
          detail[i][4] = userLog.getOperationDate().toString();
          i++;
        }
      }
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return detail;
  }
  //根据单据编号或者请购员名字或者仓库名字取得库存账套数据表记录的方法
  public String[][] getStockLedgerByStringField(String ledgerDate, String fieldName, String fieldValue, int orderType) {
    String[][] data = new String[0][13];
    //取得数据库联接
    Connection conn = getConnection();
    String countSql = "select count(*) from stockLedger" + ledgerDate +
        " where orderType = " + orderType + " and " + fieldName + " like '%" + fieldValue + "%'";
    String sql = "select * from stockLedger" + ledgerDate +
        " where orderType = " + orderType + " and " + fieldName + " like '%" + fieldValue + "%'";
    try {
      Statement stmt = conn.createStatement();
      //取得数据表的记录数
      ResultSet rs = stmt.executeQuery(countSql);
      int rowCount = 0;
      if (rs.next()) {
        rowCount = rs.getInt(1);
      }
      //取得数据表的记录
      rs = stmt.executeQuery(sql);
      //根据数据表的行与列总数创建数组
      data = new String[rowCount][13];
      //将数据记录存放在数组
      int row = 0;
      while (rs.next()) {
        for (int col = 0; col < 13; col++) {
          data[row][col] = rs.getString(col + 1);
        }
        row++;
      }
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    //清空数据库联接
    cleanup(conn);
    return data;
  }
  //根据订单日期取得库存账套数据表记录的方法
  public String[][] getStockLedgerByOrderDate(String ledgerDate, java.sql.Timestamp startDate, java.sql.Timestamp endDate, int orderType) {
    String[][] data = new String[0][13];
    //取得数据库联接
    Connection conn = getConnection();
    String countSql = "select count(*) from stockLedger" + ledgerDate +
        " where orderType = " + orderType + " and orderDate >= ? and orderDate <= ?";
    String sql = "select * from stockLedger" + ledgerDate +
        " where orderType = " + orderType + " and  orderDate >= ? and orderDate <= ?";
    try {
      //创建获得记录总数的SQL语句执行类
      PreparedStatement pstmt = conn.prepareStatement(countSql);
      pstmt.setTimestamp(1, startDate);
      pstmt.setTimestamp(2, endDate);
      //取得数据表的记录数
      ResultSet rs = pstmt.executeQuery();
      int rowCount = 0;
      if (rs.next()) {
        rowCount = rs.getInt(1);
      }
      //创建获得记录的SQL语句执行类
      pstmt = conn.prepareStatement(sql);
      pstmt.setTimestamp(1, startDate);
      pstmt.setTimestamp(2, endDate);
      //取得数据表的记录
      rs = pstmt.executeQuery();
      //根据数据表的行与列总数创建数组
      data = new String[rowCount][13];
      //将数据记录存放在数组
      int row = 0;
      while (rs.next()) {
        for (int col = 0; col < 13; col++) {
          data[row][col] = rs.getString(col + 1);
        }
        row++;
      }
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    //清空数据库联接
    cleanup(conn);
    return data;
  }
  //根据单据编号取得库存账套明细数据表的记录
  public String[][] getStockSubLedgerByOrderId(String ledgerDate, String orderId) {
    String[][] data = new String[0][6];
    //取得数据库联接
    Connection conn = getConnection();
    String countSql = "select count(*) from stockSubLedger" + ledgerDate +
        " where orderId = '" + orderId + "'";
    String sql = "select * from stockSubLedger" + ledgerDate +
        " where orderId = '" + orderId + "'";
    try {
      Statement stmt = conn.createStatement();
      //取得数据表的记录数
      ResultSet rs = stmt.executeQuery(countSql);
      int rowCount = 0;
      if (rs.next()) {
        rowCount = rs.getInt(1);
      }
      //取得数据表的记录
      rs = stmt.executeQuery(sql);
      //根据数据表的行与列总数创建数组
      data = new String[rowCount][6];
      //将数据记录存放在数组
      int row = 0;
      while (rs.next()) {
        for (int col = 0; col < 6; col++) {
          data[row][col] = rs.getString(col + 1);
        }
        row++;
      }
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    //清空数据库联接
    cleanup(conn);
    return data;
  }
  //创建库存账套数据表和库存账套明细数据表记录的方法
  public int createStockLedgerAndSub(String ledgerDate, String[] stockLedger, String[][] stockSubLedger) {
    int result = 0;
    //取得帐套集合
    String[] ledgerDates = this.getLedgerNames();
    //只能对当前账套进行添加操作
    if(!ledgerDates[ledgerDates.length - 1].equals(ledgerDate)){
      return result;
    }
    //取得数据库联接
    Connection conn = getConnection();
    String selectStockLedgerSql = "select * from stockLedger" + ledgerDate
        + " where orderId not like '%上%' and orderId like '%" + ledgerDate + "%' "
        + " order by orderId desc";
    String selectStockSubLedgerSql = "select * from stockSubLedger" + ledgerDate
        +" order by serialId desc ";
    String insertStockLedgerSql = "insert into stockLedger" + ledgerDate
        + " values(?,?,?,?,?,?,?,?,?,?,?,?,?)";
    String insertStockSubLedgerSql = "insert into stockSubLedger" + ledgerDate
        + " values(?,?,?,?,?,?)";
    try{
      //开始事务
      conn.setAutoCommit(false);
      //创建不带参数的SQL语句执行类
      Statement stmt = conn.createStatement();
      /*取得库存账套数据表的新单据编号*/
      ResultSet rs = stmt.executeQuery(selectStockLedgerSql);
      String newOrderId = "";
      if(rs.next()){
        newOrderId = dataMethod.getStockLedgerNewOrder(rs.getString("orderId"));
      }else{
        newOrderId = ledgerDate + "00001";
      }
      //创建带参数的SQL语句执行类
      PreparedStatement pstmt = conn.prepareStatement(insertStockLedgerSql);
      //设置单据编号
      pstmt.setString(1, newOrderId);
      //设置其它字段值
      pstmt.setInt(2, Integer.parseInt(stockLedger[1]));
      for(int i = 2; i < 9; i++){
        pstmt.setString(i + 1, stockLedger[i]);
      }
      pstmt.setTimestamp(10, dataMethod.transferDateTime(stockLedger[9]));
      pstmt.setTimestamp(11, dataMethod.transferDateTime(stockLedger[10]));
      pstmt.setInt(12, Integer.parseInt(stockLedger[11]));
      pstmt.setString(13, stockLedger[12]);
      //执行插入操作
      pstmt.execute();
      /*取得库存账套明细数据表的新编号*/
      rs = stmt.executeQuery(selectStockSubLedgerSql);
      int newSerialId = 1;
      if(rs.next()){
        newSerialId = rs.getInt(1) + 1;
      }
      pstmt = conn.prepareStatement(insertStockSubLedgerSql);
      //创建库存账套明细数据表的新记录
      for(int i = 0; i < stockSubLedger.length; i++){
        pstmt.setInt(1, newSerialId);
        pstmt.setString(2, newOrderId);
        pstmt.setString(3, stockSubLedger[i][2]);
        pstmt.setFloat(4, Float.parseFloat(stockSubLedger[i][3]));
        pstmt.setInt(5, Integer.parseInt(stockSubLedger[i][4]));
        pstmt.setTimestamp(6, dataMethod.transferDate(stockSubLedger[i][5]));
        newSerialId++;
        //执行插入操作
        pstmt.execute();
      }
      //提交事条
      conn.commit();
      result = 1;
    }catch(Exception ex){
      try{
        //撤消事务
        conn.rollback();
      }catch(Exception ex1){
        ex1.printStackTrace();
      }
      ex.printStackTrace();
    }
    //清空数据库联接
    cleanup(conn);
    return result;
  }
  //更新库存账套数据表和库存账套明细数据表记录的方法
  public int updateStockLedgerAndSub(String ledgerDate, String[] stockLedger, String[][] stockSubLedger) {
    int result = 0;
    //取得帐套集合
    String[] ledgerDates = this.getLedgerNames();
    //只能对当前账套进行更新操作
    if(!ledgerDates[ledgerDates.length - 1].equals(ledgerDate)){
      return result;
    }
    //取得数据库联接
    Connection conn = getConnection();
    String updateStockLedgerSql = "update stockLedger" + ledgerDate + " set "
        + "supplierName = ?, submitUser = ?, commitUser = ?, "
        + "checkUser = ?, cashUser = ?, address = ?, warehouse = ?, orderDate = ?, "
        + "stockDate = ?, onProcess = ?, remark = ? where orderId = ?";
    String updateStockSubLedgerSql = "update stockSubLedger" + ledgerDate
        + " set goodsBarCode = ?, costPrice = ?, quantity = ?, usefulLife = ?"
        + " where serialId = ?";
    try{
      //开始事务
      conn.setAutoCommit(false);
      //创建带参数的SQL语句执行类
      PreparedStatement pstmt = conn.prepareStatement(updateStockLedgerSql);
      //设置库存账套数据表的SQL语句参数
      pstmt.setString(1, stockLedger[2]);
      pstmt.setString(2, stockLedger[3]);
      pstmt.setString(3, stockLedger[4]);
      pstmt.setString(4, stockLedger[5]);
      pstmt.setString(5, stockLedger[6]);
      pstmt.setString(6, stockLedger[7]);
      pstmt.setString(7, stockLedger[8]);
      pstmt.setTimestamp(8, dataMethod.transferDateTime(stockLedger[9]));
      pstmt.setTimestamp(9, dataMethod.transferDateTime(stockLedger[10]));
      pstmt.setInt(10, Integer.parseInt(stockLedger[11]));
      pstmt.setString(11, stockLedger[12]);
      pstmt.setString(12, stockLedger[0]);
      //执行库存账套数据表的更新操作
      pstmt.execute();
      pstmt = conn.prepareStatement(updateStockSubLedgerSql);
      //设置库存账套明细数据表的SQL语句参数
      for(int i = 0; i < stockSubLedger.length; i++){
        pstmt.setString(1, stockSubLedger[i][2]);
        pstmt.setFloat(2, Float.parseFloat(stockSubLedger[i][3]));
        pstmt.setInt(3, Integer.parseInt(stockSubLedger[i][4]));
        pstmt.setTimestamp(4, dataMethod.transferDate(stockSubLedger[i][5]));
        pstmt.setInt(5, Integer.parseInt(stockSubLedger[i][0]));
        //执行库存账套明细数据表的更新操作
        pstmt.execute();
      }
      //提交事条
      conn.commit();
      result = 1;
    }catch(Exception ex){
      try{
        //撤消事务
        conn.rollback();
      }catch(Exception ex1){
        ex1.printStackTrace();
      }
      ex.printStackTrace();
    }
    //清空数据库联接
    cleanup(conn);
    return result;
  }
  //撤消库存账套数据表完成状态的方法
  public int cancelStockLedgerAndSub(String ledgerDate, String orderId, String remark) {
    int result = 0;
    //取得帐套集合
    String[] ledgerDates = this.getLedgerNames();
    //只能对当前账套进行撤消操作
    if(!ledgerDates[ledgerDates.length - 1].equals(ledgerDate)){
      return result;
    }
    //取得数据库联接
    Connection conn = getConnection();
    String cancelStockLedgerSql = "update stockLedger" + ledgerDate + " set "
        + "onProcess = ?, remark = ? where orderId = ?";
    try{
      //开始事务
      conn.setAutoCommit(false);
      //创建带参数的SQL语句执行类
      PreparedStatement pstmt = conn.prepareStatement(cancelStockLedgerSql);
      //设置库存账套数据表的SQL语句参数
      pstmt.setInt(1, 1);
      pstmt.setString(2, remark);
      pstmt.setString(3, orderId);
      //执行库存账套数据表的更新操作
      pstmt.execute();
      //提交事条
      conn.commit();
      result = 1;
    }catch(Exception ex){
      try{
        //撤消事务
        conn.rollback();
      }catch(Exception ex1){
        ex1.printStackTrace();
      }
      ex.printStackTrace();
    }
    //清空数据库联接
    cleanup(conn);
    return result;
  }
  //恢复库存账套数据表完成状态的方法
  public int restoreStockLedgerAndSub(String ledgerDate, String orderId, String remark) {
    int result = 0;
    //取得帐套集合
    String[] ledgerDates = this.getLedgerNames();
    //只能对当前账套进行恢复操作
    if(!ledgerDates[ledgerDates.length - 1].equals(ledgerDate)){
      return result;
    }
    //取得数据库联接
    Connection conn = getConnection();
    String updateStockLedgerSql = "update stockLedger" + ledgerDate + " set "
        + "onProcess = ?, remark = ? where orderId = ?";
    try{
      //开始事务
      conn.setAutoCommit(false);
      //创建带参数的SQL语句执行类
      PreparedStatement pstmt = conn.prepareStatement(updateStockLedgerSql);
      //设置库存账套数据表的SQL语句参数
      pstmt.setInt(1, 0);
      pstmt.setString(2, remark);
      pstmt.setString(3, orderId);
      //执行库存账套数据表的更新操作
      pstmt.execute();
      //提交事条
      conn.commit();
      result = 1;
    }catch(Exception ex){
      try{
        //撤消事务
        conn.rollback();
      }catch(Exception ex1){
        ex1.printStackTrace();
      }
      ex.printStackTrace();
    }
    //清空数据库联接
    cleanup(conn);
    return result;
  }
  //库存账套数据表电子签名的方法
  public int signStockLedgerAndSub(String ledgerDate, String fieldName, String userName, String orderId, String remark) {
    int result = 0;
    //取得帐套集合
    String[] ledgerDates = this.getLedgerNames();
    //只能对当前账套进行操作
    if(!ledgerDates[ledgerDates.length - 1].equals(ledgerDate)){
      return result;
    }
    //取得数据库联接
    Connection conn = getConnection();
    String updateStockLedgerSql = "update stockLedger" + ledgerDate + " set "
        + fieldName + " = ?, remark = ? where orderId = ?";
    try{
      //开始事务
      conn.setAutoCommit(false);
      //创建带参数的SQL语句执行类
      PreparedStatement pstmt = conn.prepareStatement(updateStockLedgerSql);
      //设置库存账套数据表的SQL语句参数
      pstmt.setString(1, userName);
      pstmt.setString(2, remark);
      pstmt.setString(3, orderId);
      //执行库存账套数据表的更新操作
      pstmt.execute();
      //提交事条
      conn.commit();
      result = 1;
    }catch(Exception ex){
      try{
        //撤消事务
        conn.rollback();
      }catch(Exception ex1){
        ex1.printStackTrace();
      }
      ex.printStackTrace();
    }
    //清空数据库联接
    cleanup(conn);
    return result;
  }
  //根据完成状态取得库存账套数据表记录的方法
  public String[][] getStockLedgerByOnProcess(String ledgerDate, int orderType, int onProcess) {
    String[][] data = new String[0][13];
    //取得数据库联接
    Connection conn = getConnection();
    String countSql = "select count(*) from stockLedger" + ledgerDate +
        " where orderType = " + orderType + " and onProcess = " + onProcess;
    String sql = "select * from stockLedger" + ledgerDate +
        " where orderType = " + orderType + " and onProcess = " + onProcess;
    try {
      Statement stmt = conn.createStatement();
      //取得数据表的记录数
      ResultSet rs = stmt.executeQuery(countSql);
      int rowCount = 0;
      if (rs.next()) {
        rowCount = rs.getInt(1);
      }
      //取得数据表的记录
      rs = stmt.executeQuery(sql);
      //根据数据表的行与列总数创建数组
      data = new String[rowCount][13];
      //将数据记录存放在数组
      int row = 0;
      while (rs.next()) {
        for (int col = 0; col < 13; col++) {
          data[row][col] = rs.getString(col + 1);
        }
        row++;
      }
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    //清空数据库联接
    cleanup(conn);
    return data;
  }
  //创建会计分录的方法
  public int createAccountEntry(String ledgerDate, String[] accountEntryLedger, String[][] accountEntrySubLedger, boolean inTransaction, Connection connIn) {
    int result = 0;
    //取得帐套集合
    String[] ledgerDates = this.getLedgerNames();
    //只能对当前账套进行操作
    if(!ledgerDates[ledgerDates.length - 1].equals(ledgerDate)){
      return result;
    }
    //创建选择语句
    String selectAccountEntryLedgerSql = "select * from accountEntryLedger"
        + ledgerDate + " order by serialId desc";
    String selectAccountEntrySubLedgerSql = "select * from accountEntrySubLedger"
        + ledgerDate + " order by serialId desc";
    //创建插入的SQL语句
    String insertAccountEntryLedgerSql = "insert into accountEntryLedger" + ledgerDate
        + " values(?,?,?,?,?,?,?,?)";
    String insertAccountEntrySubLedgerSql = "insert into accountEntrySubLedger"
        + ledgerDate + " values(?,?,?,?,?)";
    //取得数据库联接
    Connection conn = null;
    if(inTransaction){
      //如果是事务处理，直接获得数据库联接
      conn = connIn;
    }else{
      //如果是独立事务处理，重新创建数据库联接
      conn = getConnection();
    }
    try{
      //如果是独立事务处理，重新开始事务
      if(!inTransaction){
        conn.setAutoCommit(false);
      }
      //创建不带参数的SQL语句执行类
      Statement stmt = conn.createStatement();
      /*取得accountEntryLedger数据表的新序号*/
      ResultSet rs = stmt.executeQuery(selectAccountEntryLedgerSql);
      int newSerialId = 0;
      if(rs.next()){
        newSerialId = rs.getInt("serialId") + 1;
      }else{
        newSerialId = 1;
      }
      //创建带参数的SQL语句执行类
      PreparedStatement pstmt = conn.prepareStatement(insertAccountEntryLedgerSql);
      //设置序号
      pstmt.setInt(1, newSerialId);
      //设置其它字段值
      pstmt.setString(2, accountEntryLedger[0]);
      pstmt.setString(3, accountEntryLedger[1]);
      pstmt.setString(4, accountEntryLedger[2]);
      pstmt.setTimestamp(5, dataMethod.transferDateTime(accountEntryLedger[3]));
      if(accountEntryLedger[4] == null){
        pstmt.setTimestamp(6, null);
      }else{
        pstmt.setTimestamp(6, dataMethod.transferDateTime(accountEntryLedger[4]));
      }
      pstmt.setInt(7, Integer.parseInt(accountEntryLedger[5]));
      pstmt.setString(8, accountEntryLedger[6]);
      //执行插入操作
      pstmt.execute();
      /*取得accountEntrySubLedger数据表的新编号*/
      rs = stmt.executeQuery(selectAccountEntrySubLedgerSql);
      int aeslSerialId = 1;
      if(rs.next()){
        aeslSerialId = rs.getInt(1) + 1;
      }
      pstmt = conn.prepareStatement(insertAccountEntrySubLedgerSql);
      //创建accountEntrySubLedger数据表的新记录
      for(int i = 0; i < accountEntrySubLedger.length; i++){
        pstmt.setInt(1, aeslSerialId);
        pstmt.setInt(2, newSerialId);
        pstmt.setInt(3, Integer.parseInt(accountEntrySubLedger[i][0]));
        pstmt.setString(4, accountEntrySubLedger[i][1]);
        pstmt.setDouble(5, Double.parseDouble(accountEntrySubLedger[i][2]));
        aeslSerialId++;
        //执行插入操作
        pstmt.execute();
      }
      //如果是独立事务处理，提交事条
      if(!inTransaction){
        conn.commit();
      }
      result = 1;
    }catch(Exception ex){
      //如果是独立事务处理，撤消事条
      if(!inTransaction){
        try {
          conn.rollback();
        }catch (Exception ex1) {ex1.printStackTrace(); }
      }
      ex.printStackTrace();
    }
    if(!inTransaction){
      //清空数据库联接
      cleanup(conn);
    }
    return result;
  }
  //创建往来账套数据表记录的方法
  public int createCurrentAccountLedger(String ledgerDate, String[] currentAccountLedger, boolean inTransaction, Connection connIn) {
    int result = 0;
    //取得帐套集合
    String[] ledgerDates = this.getLedgerNames();
    //只能对当前账套进行操作
    if(!ledgerDates[ledgerDates.length - 1].equals(ledgerDate)){
      return result;
    }
    //创建选择语句
    String selectCurrentAccountLedgerSql = "select * from currentAccountLedger"
        + ledgerDate + " where currentAccountId like '%" + ledgerDate + "%' "
        + " order by currentAccountId desc";
    //创建插入的SQL语句
    String insertCurrentAccountLedgerSql = "insert into currentAccountLedger"
        + ledgerDate + " values(?,?,?,?,?,?,?,?,?,?,?)";
    //取得数据库联接
    Connection conn = null;
    if(inTransaction){
      //如果是事务处理，直接获得数据库联接
      conn = connIn;
    }else{
      //如果是独立事务处理，重新创建数据库联接
      conn = getConnection();
    }
    try{
      //如果是独立事务处理，重新开始事务
      if(!inTransaction){
        conn.setAutoCommit(false);
      }
      //创建不带参数的SQL语句执行类
      Statement stmt = conn.createStatement();
      /*取得currentAccountLedger数据表的新序号*/
      ResultSet rs = stmt.executeQuery(selectCurrentAccountLedgerSql);
      String newCurrentAccountId = "";
      if(rs.next()){
        newCurrentAccountId = dataMethod.getStockLedgerNewOrder(rs.getString("currentAccountId"));
      }else{
        newCurrentAccountId = ledgerDate + "00001";
      }
      //创建带参数的SQL语句执行类
      PreparedStatement pstmt = conn.prepareStatement(insertCurrentAccountLedgerSql);
      //设置序号
      pstmt.setString(1, newCurrentAccountId);
      //设置其它字段值
      pstmt.setString(2, currentAccountLedger[0]);
      pstmt.setInt(3, Integer.parseInt(currentAccountLedger[1]));
      pstmt.setFloat(4, Float.parseFloat(currentAccountLedger[2]));
      pstmt.setString(5, currentAccountLedger[3]);
      pstmt.setString(6, currentAccountLedger[4]);
      pstmt.setString(7, currentAccountLedger[5]);
      pstmt.setTimestamp(8, dataMethod.transferDateTime(currentAccountLedger[6]));
      if(currentAccountLedger[7] == null){
        pstmt.setTimestamp(9, null);
      }else{
        pstmt.setTimestamp(9, dataMethod.transferDateTime(currentAccountLedger[7]));
      }
      pstmt.setInt(10, Integer.parseInt(currentAccountLedger[8]));
      pstmt.setString(11, currentAccountLedger[9]);
      //执行插入操作
      pstmt.execute();
      //如果是独立事务处理，提交事条
      if(!inTransaction){
        conn.commit();
      }
      result = 1;
    }catch(Exception ex){
      //如果是独立事务处理，撤消事条
      if(!inTransaction){
        try {
          conn.rollback();
        }catch (Exception ex1) {ex1.printStackTrace(); }
      }
      ex.printStackTrace();
    }
    if(!inTransaction){
      //清空数据库联接
      cleanup(conn);
    }
    return result;
  }
  //根据相关联票据标识取得往来账套数据表的记录
  public String[] getCurrentAccountLedgerBylinkId(String ledgerDate, String linkId){
    String[] data = new String[11];
    //取得数据库联接
    Connection conn = getConnection();
    String sql = "select * from currentAccountLedger" + ledgerDate +
        " where linkId = '" + linkId + "'";
    try {
      Statement stmt = conn.createStatement();
      //取得数据表的记录数
      ResultSet rs = stmt.executeQuery(sql);
      //将数据记录存放在数组
      if (rs.next()){
        for (int col = 0; col < 11; col++){
          data[col] = rs.getString(col + 1);
        }
      }
    }catch (Exception ex) {
      ex.printStackTrace();
    }
    //清空数据库联接
    cleanup(conn);
    return data;
  }
  //验收员进行库存账套数据表电子签名的方法
  public int checkUserSignStockLedgerAndSub(String ledgerDate, String userName, String supplierName, String orderId, String remark) {
    int result = 0;
    //取得帐套集合
    String[] ledgerDates = this.getLedgerNames();
    //只能对当前账套进行操作
    if(!ledgerDates[ledgerDates.length - 1].equals(ledgerDate)){
      return result;
    }
    //取得数据库联接
    Connection conn = getConnection();
    //创建更新语句
    String updateStockLedgerSql = "update stockLedger" + ledgerDate + " set "
        + " checkUser = ?, remark = ?, onProcess = 2 where orderId = ? and onProcess = 0";
    //创建选择语句
    String sql = "select goodsBarCode, costPrice * sum(quantity) as amount"
                 + " from stockSubLedger" + ledgerDate
                 + " where orderId = '" + orderId + "' "
                 + " group by goodsBarCode, costPrice order by goodsBarCode";
    try{
      //开始事务
      conn.setAutoCommit(false);
      //创建不带参数的SQL语句执行类
      Statement stmt = conn.createStatement();
      //创建带参数的SQL语句执行类
      PreparedStatement pstmt = conn.prepareStatement(updateStockLedgerSql);
      //设置库存账套数据表的SQL语句参数
      pstmt.setString(1, userName);
      pstmt.setString(2, remark);
      pstmt.setString(3, orderId);
      //执行库存账套数据表的更新操作，实现验收员的签名和将进货单的完成状态更改为2
      int subResult = pstmt.executeUpdate();
      //由于进货单已完成，不能完成更新操作
      if(subResult == 0){
        conn.rollback();
        return 0;
      }
      //创建会计分录数组
      String[] accountEntryLedger = new String[7];
      //st表示与库存账套数据表相联系
      accountEntryLedger[0] = "st" + orderId;
      accountEntryLedger[1] = userName;
      accountEntryLedger[2] = "";
      accountEntryLedger[3] = dataMethod.getCurrentDate().toString();
      accountEntryLedger[4] = null;
      accountEntryLedger[5] = "0";
      accountEntryLedger[6] = "";
      //创建会计分录明细账数组
      String[][] accountEntrySubLedger = new String[0][3];
      ResultSet rs = stmt.executeQuery(sql);
      int count = 0;
      //取得记录数
      while(rs.next()){
        count++;
      }
      //重新创建会计分录明细账数组
      accountEntrySubLedger = new String[count + 1][3];
      //重新取得库存账套明细表的数据
      rs = stmt.executeQuery(sql);
      //应付给供应商的金额
      double total = 0;
      for(int i = 0; i < count; i++){
        if(rs.next()){
          accountEntrySubLedger[i][0] = "0";
          accountEntrySubLedger[i][1] = "流动资产@@存货@@" + rs.getString("goodsBarCode");
          accountEntrySubLedger[i][2] = rs.getString("amount").trim();
          total += Double.parseDouble(accountEntrySubLedger[i][2]);
        }
      }
      //写入货方分录
      accountEntrySubLedger[count][0] = "1";
      accountEntrySubLedger[count][1] = "短期负债@@应付账款@@" + supplierName;
      accountEntrySubLedger[count][2] = String.valueOf(total);
      //向数据表写入会计分录，应用本方法的事务
      subResult = this.createAccountEntry(ledgerDate, accountEntryLedger,
                                              accountEntrySubLedger, true, conn);
      //如果不能正确添加会计分录，撤消数据库的事条
      if(subResult == 0){
        conn.rollback();
        return 0;
      }
      //创建往来账套数组
      String[] currentAccountLedger = new String[10];
      //st表示与库存账套数据表相联系
      currentAccountLedger[0] = "st" + orderId;
      currentAccountLedger[1] = "0";
      currentAccountLedger[2] = String.valueOf(total);
      currentAccountLedger[3] = supplierName;
      currentAccountLedger[4] = userName;
      currentAccountLedger[5] = "";
      currentAccountLedger[6] = dataMethod.getCurrentDate().toString();;
      currentAccountLedger[7] = null;
      currentAccountLedger[8] = "0";
      currentAccountLedger[9] = "";
      //向往来账套数据表写入记录，应用本方法的事务
      subResult = this.createCurrentAccountLedger(ledgerDate, currentAccountLedger,
                                                true,  conn);
      //如果不能正确添加往来账套记录，撤消数据库的事条
      if(subResult == 0){
        conn.rollback();
        return 0;
      }
      //提交事条
      conn.commit();
      result = 1;
    }catch(Exception ex){
      try{
        //撤消事务
        conn.rollback();
      }catch(Exception ex1){
        ex1.printStackTrace();
      }
      ex.printStackTrace();
    }
    //清空数据库联接
    cleanup(conn);
    return result;
  }
  //根据票据编号、开票据的用户名、供应商名字取得往来账套数据表记录的方法
  public String[][] getCurrentAccountLedgerByStringField(String ledgerDate, String fieldName, String fieldValue, int documentType) {
    String[][] data = new String[0][11];
    //取得数据库联接
    Connection conn = getConnection();
    String countSql = "select count(*) from currentAccountLedger" + ledgerDate +
        " where documentType = " + documentType + " and " + fieldName
        + " like '%" + fieldValue + "%'";
    String sql = "select * from currentAccountLedger" + ledgerDate +
        " where documentType = " + documentType + " and " + fieldName
        + " like '%" + fieldValue + "%'";
    try {
      Statement stmt = conn.createStatement();
      //取得数据表的记录数
      ResultSet rs = stmt.executeQuery(countSql);
      int rowCount = 0;
      if (rs.next()) {
        rowCount = rs.getInt(1);
      }
      //取得数据表的记录
      rs = stmt.executeQuery(sql);
      //根据数据表的行与列总数创建数组
      data = new String[rowCount][11];
      //将数据记录存放在数组
      int row = 0;
      while (rs.next()) {
        for (int col = 0; col < 11; col++) {
          data[row][col] = rs.getString(col + 1);
        }
        row++;
      }
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    //清空数据库联接
    cleanup(conn);
    return data;
  }
  //根据完成状态取得往来账套数据表记录的方法
  public String[][] getCurrentAccountLedgerByOnProcess(String ledgerDate, int documentType, int onProcess) {
    String[][] data = new String[0][11];
    //取得数据库联接
    Connection conn = getConnection();
    String countSql = "select count(*) from currentAccountLedger" + ledgerDate +
        " where documentType = " + documentType + " and onProcess = " + onProcess;
    String sql = "select * from currentAccountLedger" + ledgerDate +
        " where documentType = " + documentType + " and onProcess = " + onProcess;
    try {
      Statement stmt = conn.createStatement();
      //取得数据表的记录数
      ResultSet rs = stmt.executeQuery(countSql);
      int rowCount = 0;
      if (rs.next()) {
        rowCount = rs.getInt(1);
      }
      //取得数据表的记录
      rs = stmt.executeQuery(sql);
      //根据数据表的行与列总数创建数组
      data = new String[rowCount][11];
      //将数据记录存放在数组
      int row = 0;
      while (rs.next()) {
        for (int col = 0; col < 11; col++) {
          data[row][col] = rs.getString(col + 1);
        }
        row++;
      }
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    //清空数据库联接
    cleanup(conn);
    return data;
  }
  //根据开票据日期取得往来账套数据表记录的方法
  public String[][] getCurrentAccountLedgerByFillDate(String ledgerDate, java.sql.Timestamp startDate, java.sql.Timestamp endDate, int documentType) {
    String[][] data = new String[0][11];
    //取得数据库联接
    Connection conn = getConnection();
    String countSql = "select count(*) from currentAccountLedger" + ledgerDate +
        " where documentType = " + documentType + " and fillDate >= ? and fillDate <= ?";
    String sql = "select * from currentAccountLedger" + ledgerDate +
        " where documentType = " + documentType + " and fillDate >= ? and fillDate <= ?";
    try {
      //创建获得记录总数的SQL语句执行类
      PreparedStatement pstmt = conn.prepareStatement(countSql);
      pstmt.setTimestamp(1, startDate);
      pstmt.setTimestamp(2, endDate);
      //取得数据表的记录数
      ResultSet rs = pstmt.executeQuery();
      int rowCount = 0;
      if (rs.next()) {
        rowCount = rs.getInt(1);
      }
      //创建获得记录的SQL语句执行类
      pstmt = conn.prepareStatement(sql);
      pstmt.setTimestamp(1, startDate);
      pstmt.setTimestamp(2, endDate);
      //取得数据表的记录
      rs = pstmt.executeQuery();
      //根据数据表的行与列总数创建数组
      data = new String[rowCount][11];
      //将数据记录存放在数组
      int row = 0;
      while (rs.next()) {
        for (int col = 0; col < 11; col++) {
          data[row][col] = rs.getString(col + 1);
        }
        row++;
      }
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    //清空数据库联接
    cleanup(conn);
    return data;
  }
  //创建现金账套数据表记录
  public int createCashLedger(String ledgerDate, String[] cashLedger, boolean inTransaction, Connection connIn) {
    int result = 0;
    //取得帐套集合
    String[] ledgerDates = this.getLedgerNames();
    //只能对当前账套进行操作
    if(!ledgerDates[ledgerDates.length - 1].equals(ledgerDate)){
      return result;
    }
    //创建选择语句
    String selectCashLedgerSql = "select * from cashLedger"
        + ledgerDate + " order by serialId desc";
    //创建插入的SQL语句
    String insertCashLedgerSql = "insert into cashLedger"
        + ledgerDate + " values(?,?,?,?,?,?)";
    //取得数据库联接
    Connection conn = null;
    if(inTransaction){
      //如果是事务处理，直接获得数据库联接
      conn = connIn;
    }else{
      //如果是独立事务处理，重新创建数据库联接
      conn = getConnection();
    }
    try{
      //如果是独立事务处理，重新开始事务
      if(!inTransaction){
        conn.setAutoCommit(false);
      }
      //创建不带参数的SQL语句执行类
      Statement stmt = conn.createStatement();
      /*取得cashLedger数据表的新序号*/
      ResultSet rs = stmt.executeQuery(selectCashLedgerSql);
      int newSerialId = 0;
      if(rs.next()){
        newSerialId = rs.getInt("serialId") + 1;
      }else{
        newSerialId = 1;
      }
      //创建带参数的SQL语句执行类
      PreparedStatement pstmt = conn.prepareStatement(insertCashLedgerSql);
      //设置序号
      pstmt.setInt(1, newSerialId);
      //设置其它字段值
      pstmt.setString(2, cashLedger[0]);
      pstmt.setInt(3, Integer.parseInt(cashLedger[1]));
      pstmt.setString(4, cashLedger[2]);
      pstmt.setDouble(5, Double.parseDouble(cashLedger[3]));
      pstmt.setTimestamp(6, dataMethod.transferDateTime(cashLedger[4]));
      //执行插入操作
      result = pstmt.executeUpdate();
      //如果是独立事务处理，提交事条
      if(!inTransaction){
        conn.commit();
      }
    }catch(Exception ex){
      //如果是独立事务处理，撤消事条
      if(!inTransaction){
        try {
          conn.rollback();
        }catch (Exception ex1) {ex1.printStackTrace(); }
      }
      ex.printStackTrace();
    }
    if(!inTransaction){
      //清空数据库联接
      cleanup(conn);
    }
    return result;
  }
  //现金管理员进行电子签名的方法
  public int cashUserSignAccountPayable(String ledgerDate, String userName, String[] currentAccountLedger) {
    int result = 0;
    //取得帐套集合
    String[] ledgerDates = this.getLedgerNames();
    //只能对当前账套进行操作
    if(!ledgerDates[ledgerDates.length - 1].equals(ledgerDate)){
      return result;
    }
    //取得数据库联接
    Connection conn = getConnection();
    //创建更新语句
    String updateCurrentAccountLedgerSql = "update currentAccountLedger" + ledgerDate + " set "
        + " cashUser = ?, remark = ?, payDate = ?, onProcess = 2 "
        + " where currentAccountId = ? and onProcess = 0";
    try{
      //开始事务
      conn.setAutoCommit(false);
      //创建不带参数的SQL语句执行类
      Statement stmt = conn.createStatement();
      //创建带参数的SQL语句执行类
      PreparedStatement pstmt = conn.prepareStatement(updateCurrentAccountLedgerSql);
      //设置往来账套数据表的SQL语句参数
      pstmt.setString(1, userName);
      pstmt.setString(2, currentAccountLedger[10]);
      pstmt.setTimestamp(3, dataMethod.getCurrentDate());
      pstmt.setString(4, currentAccountLedger[0]);
      //对往来账套数据表进行签名
      int subResult = pstmt.executeUpdate();
      //往来账套数据表的更新操作失败
      if(subResult == 0){
        conn.rollback();
        return 0;
      }
      //创建会计分录数组
      String[] accountEntryLedger = new String[7];
      //cu表示与往来账套数据表相联系
      accountEntryLedger[0] = "cu" + currentAccountLedger[0];
      accountEntryLedger[1] = userName;
      accountEntryLedger[2] = "";
      accountEntryLedger[3] = dataMethod.getCurrentDate().toString();
      accountEntryLedger[4] = null;
      accountEntryLedger[5] = "0";
      accountEntryLedger[6] = "";
      //创建会计分录明细账数组
      String[][] accountEntrySubLedger = new String[2][3];
      //写入借方分录
      accountEntrySubLedger[0][0] = "0";
      accountEntrySubLedger[0][1] = "短期负债@@应付账款@@" + currentAccountLedger[4];
      accountEntrySubLedger[0][2] = currentAccountLedger[3];
      //写入货方分录
      accountEntrySubLedger[1][0] = "1";
      accountEntrySubLedger[1][1] = "流动资产@@现金";
      accountEntrySubLedger[1][2] =  currentAccountLedger[3];
      //向数据表写入会计分录，应用本方法的事务
      subResult = this.createAccountEntry(ledgerDate, accountEntryLedger,
                                              accountEntrySubLedger, true, conn);
      //如果不能正确添加会计分录，撤消数据库的事条
      if(subResult == 0){
        conn.rollback();
        return 0;
      }
      //创建现金账套数组
      String[] cashLedger = new String[5];
      //cu表示与往来账套数据表相联系
      cashLedger[0] = "cu" + currentAccountLedger[0];
      cashLedger[1] = "1";
      cashLedger[2] = userName;
      cashLedger[3] = currentAccountLedger[3];
      cashLedger[4] = dataMethod.getCurrentDate().toString();
      //向现金账套数据表写入记录，应用本方法的事务
      subResult = this.createCashLedger(ledgerDate, cashLedger, true,  conn);
      //如果不能正确添加现金账套记录，撤消数据库的事条
      if(subResult == 0){
        conn.rollback();
        return 0;
      }
      //提交事条
      conn.commit();
      result = 1;
    }catch(Exception ex){
      try{
        //撤消事务
        conn.rollback();
      }catch(Exception ex1){
        ex1.printStackTrace();
      }
      ex.printStackTrace();
    }
    //清空数据库联接
    cleanup(conn);
    return result;
  }
  //根据关联票据标识、记账用户取得现金账套数据表记录的方法
  public String[][] getCashLedgerByStringField(String ledgerDate, String fieldName, String fieldValue) {
    String[][] data = new String[0][6];
    //取得数据库联接
    Connection conn = getConnection();
    String countSql = "select count(*) from cashLedger" + ledgerDate +
        " where " + fieldName + " like '%" + fieldValue + "%'";
    String sql = "select * from cashLedger" + ledgerDate +
        " where " + fieldName + " like '%" + fieldValue + "%'";
    try {
      Statement stmt = conn.createStatement();
      //取得数据表的记录数
      ResultSet rs = stmt.executeQuery(countSql);
      int rowCount = 0;
      if (rs.next()) {
        rowCount = rs.getInt(1);
      }
      //取得数据表的记录
      rs = stmt.executeQuery(sql);
      //根据数据表的行与列总数创建数组
      data = new String[rowCount][6];
      //将数据记录存放在数组
      int row = 0;
      while (rs.next()) {
        for (int col = 0; col < 6; col++) {
          data[row][col] = rs.getString(col + 1);
        }
        row++;
      }
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    //清空数据库联接
    cleanup(conn);
    return data;
  }
  //根据发生日期取得现金账套数据表记录的方法
  public String[][] getCashLedgerByFillDate(String ledgerDate, java.sql.Timestamp startDate, java.sql.Timestamp endDate) {
    String[][] data = new String[0][6];
    //取得数据库联接
    Connection conn = getConnection();
    String countSql = "select count(*) from cashLedger" + ledgerDate +
        " where fillDate >= ? and fillDate <= ?";
    String sql = "select * from cashLedger" + ledgerDate +
        " where fillDate >= ? and fillDate <= ?";
    try {
      //创建获得记录总数的SQL语句执行类
      PreparedStatement pstmt = conn.prepareStatement(countSql);
      pstmt.setTimestamp(1, startDate);
      pstmt.setTimestamp(2, endDate);
      //取得数据表的记录数
      ResultSet rs = pstmt.executeQuery();
      int rowCount = 0;
      if (rs.next()) {
        rowCount = rs.getInt(1);
      }
      //创建获得记录的SQL语句执行类
      pstmt = conn.prepareStatement(sql);
      pstmt.setTimestamp(1, startDate);
      pstmt.setTimestamp(2, endDate);
      //取得数据表的记录
      rs = pstmt.executeQuery();
      //根据数据表的行与列总数创建数组
      data = new String[rowCount][6];
      //将数据记录存放在数组
      int row = 0;
      while (rs.next()) {
        for (int col = 0; col < 6; col++) {
          data[row][col] = rs.getString(col + 1);
        }
        row++;
      }
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    //清空数据库联接
    cleanup(conn);
    return data;
  }
  //现金管理员收取退款进行电子签名的方法
  public int cashUserSignStockLedgerForStockReturn(String ledgerDate, String userName, String supplierName, String orderId, String remark, boolean isPay) {
    int result = 0;
    //取得帐套集合
    String[] ledgerDates = this.getLedgerNames();
    //只能对当前账套进行操作
    if(!ledgerDates[ledgerDates.length - 1].equals(ledgerDate)){
      return result;
    }
    //取得数据库联接
    Connection conn = getConnection();
    //创建更新语句
    String updateStockLedgerSql = "update stockLedger" + ledgerDate + " set "
        + " cashUser = ?, remark = ?, onProcess = 2 where orderId = ? and onProcess = 0";
    //创建选择语句
    String sql = "select goodsBarCode, costPrice * sum(quantity) as amount"
                 + " from stockSubLedger" + ledgerDate
                 + " where orderId = '" + orderId + "' "
                 + " group by goodsBarCode, costPrice order by goodsBarCode";
    try{
      //开始事务
      conn.setAutoCommit(false);
      //创建不带参数的SQL语句执行类
      Statement stmt = conn.createStatement();
      //创建带参数的SQL语句执行类
      PreparedStatement pstmt = conn.prepareStatement(updateStockLedgerSql);
      //设置库存账套数据表的SQL语句参数
      pstmt.setString(1, userName);
      pstmt.setString(2, remark);
      pstmt.setString(3, orderId);
      //执行库存账套数据表的更新操作，实现现金管理员的签名和将退货单的完成状态更改为2
      int subResult = pstmt.executeUpdate();
      //由于退货单已完成，不能完成更新操作
      if(subResult == 0){
        conn.rollback();
        return 0;
      }
      //创建会计分录数组
      String[] accountEntryLedger = new String[7];
      //st表示与库存账套数据表相联系
      accountEntryLedger[0] = "st" + orderId;
      accountEntryLedger[1] = userName;
      accountEntryLedger[2] = "";
      accountEntryLedger[3] = dataMethod.getCurrentDate().toString();
      accountEntryLedger[4] = null;
      accountEntryLedger[5] = "0";
      accountEntryLedger[6] = "";
      //创建会计分录明细账数组
      String[][] accountEntrySubLedger = new String[0][3];
      ResultSet rs = stmt.executeQuery(sql);
      int count = 0;
      //取得记录数
      while(rs.next()){
        count++;
      }
      //重新创建会计分录明细账数组
      accountEntrySubLedger = new String[count + 1][3];
      //重新取得库存账套明细表的数据
      rs = stmt.executeQuery(sql);
      //应收供应商的退货金额
      double total = 0;
      for(int i = 0; i < count; i++){
        if(rs.next()){
          accountEntrySubLedger[i][0] = "0";
          accountEntrySubLedger[i][1] = "流动资产@@存货@@" + rs.getString("goodsBarCode");
          accountEntrySubLedger[i][2] = rs.getString("amount").trim();
          total += Double.parseDouble(accountEntrySubLedger[i][2]);
        }
      }
      //写入货方分录
      if(!isPay){
        //未付款，对冲应付账款
        accountEntrySubLedger[count][0] = "1";
        accountEntrySubLedger[count][1] = "短期负债@@应付账款@@" + supplierName;
      }else{
        //已付款，对冲现金
        accountEntrySubLedger[count][0] = "1";
        accountEntrySubLedger[count][1] = "流动资产@@现金";
      }
      accountEntrySubLedger[count][2] = String.valueOf(total);
      //向数据表写入会计分录，应用本方法的事务
      subResult = this.createAccountEntry(ledgerDate, accountEntryLedger,
                                              accountEntrySubLedger, true, conn);
      //如果不能正确添加会计分录，撤消数据库的事条
      if(subResult == 0){
        conn.rollback();
        return 0;
      }
      //已付款，将收款记录写入现金数据表
      if(isPay){
        //创建现金账套数组
        String[] cashLedger = new String[5];
        //st表示与库存账套数据表相联系
        cashLedger[0] = "st" + orderId;
        cashLedger[1] = "0";
        cashLedger[2] = userName;
        cashLedger[3] = String.valueOf(-total);
        cashLedger[4] = dataMethod.getCurrentDate().toString();
        //向现金账套数据表写入记录，应用本方法的事务
        subResult = this.createCashLedger(ledgerDate, cashLedger, true, conn);
        //如果不能正确添加现金账套记录，撤消数据库的事条
        if (subResult == 0) {
          conn.rollback();
          return 0;
        }
      }
      //提交事条
      conn.commit();
      result = 1;
    }catch(Exception ex){
      try{
        //撤消事务
        conn.rollback();
      }catch(Exception ex1){
        ex1.printStackTrace();
      }
      ex.printStackTrace();
    }
    //清空数据库联接
    cleanup(conn);
    return result;
  }
  //根据会计分录账套数据表的序号取得会计分录明细数据表的记录
  public String[][] getAccountEntrySubLedgerByLinkSerialId(String ledgerDate, int linkSerialId) {
    String[][] data = new String[0][5];
    //取得数据库联接
    Connection conn = getConnection();
    String countSql = "select count(*) from accountEntrySubLedger" + ledgerDate +
        " where linkSerialId = " + linkSerialId;
    String sql = "select * from accountEntrySubLedger" + ledgerDate +
        " where linkSerialId = " + linkSerialId;
    try {
      Statement stmt = conn.createStatement();
      //取得数据表的记录数
      ResultSet rs = stmt.executeQuery(countSql);
      int rowCount = 0;
      if (rs.next()) {
        rowCount = rs.getInt(1);
      }
      //取得数据表的记录
      rs = stmt.executeQuery(sql);
      //根据数据表的行与列总数创建数组
      data = new String[rowCount][5];
      //将数据记录存放在数组
      int row = 0;
      while (rs.next()) {
        for (int col = 0; col < 5; col++) {
          data[row][col] = rs.getString(col + 1);
        }
        row++;
      }
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    //清空数据库联接
    cleanup(conn);
    return data;
  }
  //根据会计科目、关联的票据标识、记账用户、审核用户取得会计分录账套数据表记录的方法
  public String[][] getAccountEntryLedgerByStringField(String ledgerDate, String accountName, String fieldName, String fieldValue) {
    String[][] data = new String[0][8];
    //取得数据库联接
    Connection conn = getConnection();
    String countSql = "select count(*) from accountEntryLedger" + ledgerDate
        + " where serialId in (select distinct(a.serialId) "
        + " from accountEntryLedger" + ledgerDate +" as a , "
        + " accountEntrySubLedger" + ledgerDate + " as b"
        + " where a.serialId = b.linkSerialId and accountName like '%" + accountName +"%'"
        + " and " + fieldName + " like '%" + fieldValue + "%')";
    String sql = "select * from accountEntryLedger" + ledgerDate
        + " where serialId in (select distinct(a.serialId) "
        + " from accountEntryLedger" + ledgerDate +" as a , "
        + " accountEntrySubLedger" + ledgerDate + " as b"
        + " where a.serialId = b.linkSerialId and accountName like '%" + accountName +"%'"
        + " and " + fieldName + " like '%" + fieldValue + "%')";
    try {
      Statement stmt = conn.createStatement();
      //取得数据表的记录数
      ResultSet rs = stmt.executeQuery(countSql);
      int rowCount = 0;
      if (rs.next()) {
        rowCount = rs.getInt(1);
      }
      //取得数据表的记录
      rs = stmt.executeQuery(sql);
      //根据数据表的行与列总数创建数组
      data = new String[rowCount][8];
      //将数据记录存放在数组
      int row = 0;
      while (rs.next()) {
        for (int col = 0; col < 8; col++) {
          data[row][col] = rs.getString(col + 1);
        }
        row++;
      }
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    //清空数据库联接
    cleanup(conn);
    return data;
  }
  //根据会计科目、完成状态取得会计分录账套数据表记录的方法
  public String[][] getAccountEntryLedgerByOnProcess(String ledgerDate, String accountName, int onProcess) {
    String[][] data = new String[0][8];
    //取得数据库联接
    Connection conn = getConnection();
    String countSql = "select count(*) from accountEntryLedger" + ledgerDate
        + " where serialId in (select distinct(a.serialId) "
        + " from accountEntryLedger" + ledgerDate +" as a , "
        + " accountEntrySubLedger" + ledgerDate + " as b"
        + " where a.serialId = b.linkSerialId and accountName like '%" + accountName +"%'"
        + " and onProcess = " + onProcess +")";
    String sql = "select * from accountEntryLedger" + ledgerDate
        + " where serialId in (select distinct(a.serialId) "
        + " from accountEntryLedger" + ledgerDate +" as a , "
        + " accountEntrySubLedger" + ledgerDate + " as b"
        + " where a.serialId = b.linkSerialId and accountName like '%" + accountName +"%'"
        + " and onProcess = " + onProcess +")";
    try {
      Statement stmt = conn.createStatement();
      //取得数据表的记录数
      ResultSet rs = stmt.executeQuery(countSql);
      int rowCount = 0;
      if (rs.next()) {
        rowCount = rs.getInt(1);
      }
      //取得数据表的记录
      rs = stmt.executeQuery(sql);
      //根据数据表的行与列总数创建数组
      data = new String[rowCount][8];
      //将数据记录存放在数组
      int row = 0;
      while (rs.next()) {
        for (int col = 0; col < 8; col++) {
          data[row][col] = rs.getString(col + 1);
        }
        row++;
      }
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    //清空数据库联接
    cleanup(conn);
    return data;
  }
  //根据会计科目、记账日期取得会计分录账套数据表记录的方法
  public String[][] getAccountEntryLedgerByFillDate(String ledgerDate, java.sql.Timestamp startDate, java.sql.Timestamp endDate, String accountName) {
    String[][] data = new String[0][8];
    //取得数据库联接
    Connection conn = getConnection();
    String countSql = "select count(*) from accountEntryLedger" + ledgerDate
        + " where serialId in (select distinct(a.serialId) "
        + " from accountEntryLedger" + ledgerDate +" as a , "
        + " accountEntrySubLedger" + ledgerDate + " as b"
        + " where a.serialId = b.linkSerialId and accountName like '%" + accountName +"%'"
        + " and fillDate >= ? and fillDate <= ?)";
    String sql = "select * from accountEntryLedger" + ledgerDate
        + " where serialId in (select distinct(a.serialId) "
        + " from accountEntryLedger" + ledgerDate +" as a , "
        + " accountEntrySubLedger" + ledgerDate + " as b"
        + " where a.serialId = b.linkSerialId and accountName like '%" + accountName +"%'"
        + " and fillDate >= ? and fillDate <= ?)";
    try {
      //创建获得记录总数的SQL语句执行类
      PreparedStatement pstmt = conn.prepareStatement(countSql);
      pstmt.setTimestamp(1, startDate);
      pstmt.setTimestamp(2, endDate);
      //取得数据表的记录数
      ResultSet rs = pstmt.executeQuery();
      int rowCount = 0;
      if (rs.next()) {
        rowCount = rs.getInt(1);
      }
      //创建获得记录的SQL语句执行类
      pstmt = conn.prepareStatement(sql);
      pstmt.setTimestamp(1, startDate);
      pstmt.setTimestamp(2, endDate);
      //取得数据表的记录
      rs = pstmt.executeQuery();
      //根据数据表的行与列总数创建数组
      data = new String[rowCount][8];
      //将数据记录存放在数组
      int row = 0;
      while (rs.next()) {
        for (int col = 0; col < 8; col++) {
          data[row][col] = rs.getString(col + 1);
        }
        row++;
      }
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    //清空数据库联接
    cleanup(conn);
    return data;
  }
  //撤消和恢复会计分录账套数据表完成状态的方法
  public int cancelOrRestoreAccountEntryLedger(String ledgerDate, int serialId, int onProcess, String remark) {
    int result = 0;
    //取得帐套集合
    String[] ledgerDates = this.getLedgerNames();
    //只能对当前账套进行恢复操作
    if(!ledgerDates[ledgerDates.length - 1].equals(ledgerDate)){
      return result;
    }
    //取得数据库联接
    Connection conn = getConnection();
    String updateAccountEntryLedgerSql = "update accountEntryLedger" + ledgerDate + " set "
        + "onProcess = ?, remark = ? where serialId = ?";
    try{
      //开始事务
      conn.setAutoCommit(false);
      //创建带参数的SQL语句执行类
      PreparedStatement pstmt = conn.prepareStatement(updateAccountEntryLedgerSql);
      //设置会计分录账套数据表的SQL语句参数
      pstmt.setInt(1, onProcess);
      pstmt.setString(2, remark);
      pstmt.setInt(3, serialId);
      //执行会计分录账套数据表的更新操作
      pstmt.execute();
      //提交事条
      conn.commit();
      result = 1;
    }catch(Exception ex){
      try{
        //撤消事务
        conn.rollback();
      }catch(Exception ex1){
        ex1.printStackTrace();
      }
      ex.printStackTrace();
    }
    //清空数据库联接
    cleanup(conn);
    return result;
  }
  //审核用户对会计分录进行电子签名的方法
  public int signAccountEntryLedger(String ledgerDate, String fieldName, String userName, int serialId, int onProcess, String remark) {
    int result = 0;
    //取得帐套集合
    String[] ledgerDates = this.getLedgerNames();
    //只能对当前账套进行操作
    if(!ledgerDates[ledgerDates.length - 1].equals(ledgerDate)){
      return result;
    }
    //取得数据库联接
    Connection conn = getConnection();
    String updateStockLedgerSql = "update accountEntryLedger" + ledgerDate + " set "
        + fieldName + " = ?, onProcess = ?, remark = ?, auditDate = ? where serialId = ?";
    try{
      //开始事务
      conn.setAutoCommit(false);
      //创建带参数的SQL语句执行类
      PreparedStatement pstmt = conn.prepareStatement(updateStockLedgerSql);
      //设置会计分录账套数据表的SQL语句参数
      pstmt.setString(1, userName);
      pstmt.setInt(2, onProcess);
      pstmt.setString(3, remark);
      pstmt.setTimestamp(4, dataMethod.getCurrentDate());
      pstmt.setInt(5, serialId);
      //执行会计分录账套数据表的更新操作
      pstmt.execute();
      //提交事条
      conn.commit();
      result = 1;
    }catch(Exception ex){
      try{
        //撤消事务
        conn.rollback();
      }catch(Exception ex1){
        ex1.printStackTrace();
      }
      ex.printStackTrace();
    }
    //清空数据库联接
    cleanup(conn);
    return result;
  }
  //更新会计分录数据表和会计分录明细数据表记录的方法
  public int updateAccountEntry(String ledgerDate, String[] accountEntryLedger, String[][] accountEntrySubLedger) {
    int result = 0;
    //取得帐套集合
    String[] ledgerDates = this.getLedgerNames();
    //只能对当前账套进行更新操作
    if(!ledgerDates[ledgerDates.length - 1].equals(ledgerDate)){
      return result;
    }
    //取得数据库联接
    Connection conn = getConnection();
    String updateAccountEntryLedgerSql = "update accountEntryLedger" + ledgerDate + " set "
        + "linkId = ?, filler = ?, auditUser = ?, fillDate = ?, "
        + "auditDate = ?, onProcess = ?, remark = ? where serialId = ?";
    String updateAccountEntrySubLedgerSql = "update accountEntrySubLedger" + ledgerDate
        + " set debitCredit = ?, accountName = ?, amount = ?"
        + " where serialId = ?";
    try{
      //开始事务
      conn.setAutoCommit(false);
      //创建带参数的SQL语句执行类
      PreparedStatement pstmt = conn.prepareStatement(updateAccountEntryLedgerSql);
      //设置会计分录账套数据表的SQL语句参数
      pstmt.setString(1, accountEntryLedger[1]);
      pstmt.setString(2, accountEntryLedger[2]);
      pstmt.setString(3, accountEntryLedger[3]);
      pstmt.setTimestamp(4, dataMethod.transferDateTime(accountEntryLedger[4]));
      pstmt.setTimestamp(5, null);
      pstmt.setInt(6, 0);
      pstmt.setString(7, accountEntryLedger[7]);
      pstmt.setInt(8, Integer.parseInt(accountEntryLedger[0]));
      //执行会计分录账套数据表的更新操作
      pstmt.execute();
      pstmt = conn.prepareStatement(updateAccountEntrySubLedgerSql);
      //设置会计分录账套明细数据表的SQL语句参数
      for(int i = 0; i < accountEntrySubLedger.length; i++){
        pstmt.setInt(1, Integer.parseInt(accountEntrySubLedger[i][2]));
        pstmt.setString(2, accountEntrySubLedger[i][3]);
        pstmt.setDouble(3, Double.parseDouble(accountEntrySubLedger[i][4]));
        pstmt.setInt(4, Integer.parseInt(accountEntrySubLedger[i][0]));
        //执行会计分录账套明细数据表的更新操作
        pstmt.execute();
      }
      //提交事条
      conn.commit();
      result = 1;
    }catch(Exception ex){
      try{
        //撤消事务
        conn.rollback();
      }catch(Exception ex1){
        ex1.printStackTrace();
      }
      ex.printStackTrace();
    }
    //清空数据库联接
    cleanup(conn);
    return result;
  }
  //库存账套数据表电子签名和更新完成状态的方法
  public int signStockLedgerAndSubForFinish(String ledgerDate, String fieldName, String userName, String orderId, int onProcess, String remark) {
    int result = 0;
    //取得帐套集合
    String[] ledgerDates = this.getLedgerNames();
    //只能对当前账套进行操作
    if(!ledgerDates[ledgerDates.length - 1].equals(ledgerDate)){
      return result;
    }
    //取得数据库联接
    Connection conn = getConnection();
    String updateStockLedgerSql = "update stockLedger" + ledgerDate + " set "
        + fieldName + " = ?, remark = ?, onProcess = ? where orderId = ?";
    try{
      //开始事务
      conn.setAutoCommit(false);
      //创建带参数的SQL语句执行类
      PreparedStatement pstmt = conn.prepareStatement(updateStockLedgerSql);
      //设置库存账套数据表的SQL语句参数
      pstmt.setString(1, userName);
      pstmt.setString(2, remark);
      pstmt.setInt(3, onProcess);
      pstmt.setString(4, orderId);
      //执行库存账套数据表的更新操作
      pstmt.execute();
      //提交事条
      conn.commit();
      result = 1;
    }catch(Exception ex){
      try{
        //撤消事务
        conn.rollback();
      }catch(Exception ex1){
        ex1.printStackTrace();
      }
      ex.printStackTrace();
    }
    //清空数据库联接
    cleanup(conn);
    return result;
  }
  //根据仓库名字取得盘点数据的方法
  public String[][] getStocktakeQuantityByWarehouse(String ledgerDate, String warehouse, int onProcess) {
    String[][] data = new String[0][2];
    //取得数据库联接
    Connection conn = getConnection();
    String sql = "select b.goodsBarCode, sum(b.quantity) as quantity"
                 + " from stockLedger" + ledgerDate + " as a , stockSubLedger" + ledgerDate + " as b "
                 + " where a.orderId = b.orderId and a.onProcess = " + onProcess
                 + " and warehouse like '%" + warehouse + "%'"
                 + " group by goodsBarCode"
                 + " order by goodsBarCode";
    try {
      Statement stmt = conn.createStatement();
      //取得数据表的记录
      ResultSet rs = stmt.executeQuery(sql);
      //创建集合
      Vector vector = new Vector();
      while(rs.next()){
        vector.addElement("");
      }
      //根据数据表的行与列总数创建数组
      data = new String[vector.size()][2];
      //重新取得数据表的记录
      rs = stmt.executeQuery(sql);
      //将数据记录存放在数组
      int row = 0;
      while (rs.next()) {
        for (int col = 0; col < 2; col++) {
          data[row][col] = rs.getString(col + 1);
        }
        row++;
      }
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    //清空数据库联接
    cleanup(conn);
    return data;
  }
  //根据仓库名字汇总显示商品数量和金额的方法
  public String[][] getStockByWarehouse(String ledgerDate, String warehouse, int onProcess) {
    String[][] data = new String[0][5];
    //取得数据库联接
    Connection conn = getConnection();
    String sql = "select b.goodsBarCode, costPrice, sum(b.quantity) as quantity, "
        + " sum(quantity)*costPrice as amount , usefullife from stockLedger" + ledgerDate
        + " as a , stockSubLedger" + ledgerDate + " as b where a.orderId = b.orderId"
        + " and a.onProcess = " + onProcess + " and warehouse like '%" + warehouse + "%'"
        + " group by goodsBarCode, costPrice, usefullife"
        + " order by goodsBarCode";
    try {
      Statement stmt = conn.createStatement();
      //取得数据表的记录
      ResultSet rs = stmt.executeQuery(sql);
      //创建集合
      Vector vector = new Vector();
      while(rs.next()){
        vector.addElement("");
      }
      //根据数据表的行与列总数创建数组
      data = new String[vector.size()][5];
      //重新取得数据表的记录
      rs = stmt.executeQuery(sql);
      //将数据记录存放在数组
      int row = 0;
      while (rs.next()) {
        for (int col = 0; col < 5; col++) {
          data[row][col] = rs.getString(col + 1);
        }
        row++;
      }
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    //清空数据库联接
    cleanup(conn);
    return data;
  }
  //根据商品条形码汇总显示商品在各个仓库的数量和金额的方法
  public String[][] getStockByGoodsBarcode(String ledgerDate, String goodsBarcode, int onProcess) {
    String[][] data = new String[0][5];
    //取得数据库联接
    Connection conn = getConnection();
    String sql = "select warehouse, costPrice, sum(b.quantity) as quantity, "
        + " sum(quantity)*costPrice as amount, usefullife from stockLedger" + ledgerDate
        + " as a , stockSubLedger" + ledgerDate + " as b where a.orderId = b.orderId"
        + " and a.onProcess = " + onProcess + " and goodsBarCode like '%" + goodsBarcode + "%'"
        + " group by goodsBarCode, costPrice, warehouse, usefullife"
        + " order by warehouse";
    try {
      Statement stmt = conn.createStatement();
      //取得数据表的记录
      ResultSet rs = stmt.executeQuery(sql);
      //创建集合
      Vector vector = new Vector();
      while(rs.next()){
        vector.addElement("");
      }
      //根据数据表的行与列总数创建数组
      data = new String[vector.size()][5];
      //重新取得数据表的记录
      rs = stmt.executeQuery(sql);
      //将数据记录存放在数组
      int row = 0;
      while (rs.next()) {
        for (int col = 0; col < 5; col++) {
          data[row][col] = rs.getString(col + 1);
        }
        row++;
      }
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    //清空数据库联接
    cleanup(conn);
    return data;
  }
  //查询过期商品的方法
  public String[][] getStockByUsefulLife(String ledgerDate, String usefulLife, int onProcess) {
    String[][] data = new String[0][6];
    //取得数据库联接
    Connection conn = getConnection();
    String sql = "select b.goodsBarCode, warehouse, costPrice, sum(b.quantity) as quantity, "
        + " sum(quantity)*costPrice as amount , usefullife from stockLedger" + ledgerDate
        + " as a , stockSubLedger" + ledgerDate + " as b where a.orderId = b.orderId"
        + " and a.onProcess = " + onProcess + " and usefullife <= '" + usefulLife + "'"
        + " group by goodsBarCode, costPrice, warehouse, usefullife"
        + " order by goodsBarCode";
    try {
      Statement stmt = conn.createStatement();
      //取得数据表的记录
      ResultSet rs = stmt.executeQuery(sql);
      //创建集合
      Vector vector = new Vector();
      while(rs.next()){
        vector.addElement("");
      }
      //根据数据表的行与列总数创建数组
      data = new String[vector.size()][6];
      //重新取得数据表的记录
      rs = stmt.executeQuery(sql);
      //将数据记录存放在数组
      int row = 0;
      while (rs.next()) {
        for (int col = 0; col < 6; col++) {
          data[row][col] = rs.getString(col + 1);
        }
        row++;
      }
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    //清空数据库联接
    cleanup(conn);
    return data;
  }
  //创建销售账套数据表和销售账套明细数据表记录的方法
  public int createSaleLedgerAndSub(String ledgerDate, String[] saleLedger, String[][] saleSubLedger) {
    int result = 0;
    //取得帐套集合
    String[] ledgerDates = this.getLedgerNames();
    //只能对当前账套进行添加操作
    if(!ledgerDates[ledgerDates.length - 1].equals(ledgerDate)){
      return result;
    }
    //取得数据库联接
    Connection conn = getConnection();
    String selectSaleLedgerSql = "select * from saleLedger" + ledgerDate
        + " where saleId not like '%上%' and saleId like '%" + ledgerDate + "%' "
        + " order by saleId desc";
    String selectSaleSubLedgerSql = "select * from saleSubLedger" + ledgerDate
        +" order by serialId desc ";
    String insertSaleLedgerSql = "insert into saleLedger" + ledgerDate
        + " values(?,?,?,?,?,?,?,?,?,?,?)";
    String insertSaleSubLedgerSql = "insert into saleSubLedger" + ledgerDate
        + " values(?,?,?,?,?)";
    try{
      //开始事务
      conn.setAutoCommit(false);
      //创建不带参数的SQL语句执行类
      Statement stmt = conn.createStatement();
      /*取得销售账套数据表的新单据编号*/
      ResultSet rs = stmt.executeQuery(selectSaleLedgerSql);
      String newSaleId = "";
      if(rs.next()){
        newSaleId = dataMethod.getStockLedgerNewOrder(rs.getString("saleId"));
      }else{
        newSaleId = ledgerDate + "00001";
      }
      //创建带参数的SQL语句执行类
      PreparedStatement pstmt = conn.prepareStatement(insertSaleLedgerSql);
      //设置单据编号
      pstmt.setString(1, newSaleId);
      //设置其它字段值
      pstmt.setInt(2, Integer.parseInt(saleLedger[1]));
      for(int i = 2; i < 7; i++){
        pstmt.setString(i + 1, saleLedger[i]);
      }
      pstmt.setTimestamp(8, dataMethod.transferDateTime(saleLedger[7]));
      pstmt.setTimestamp(9, dataMethod.transferDateTime(saleLedger[8]));
      pstmt.setInt(10, Integer.parseInt(saleLedger[9]));
      pstmt.setString(11, saleLedger[10]);
      //执行插入操作
      pstmt.execute();
      /*取得销售账套明细数据表的新编号*/
      rs = stmt.executeQuery(selectSaleSubLedgerSql);
      int newSerialId = 1;
      if(rs.next()){
        newSerialId = rs.getInt(1) + 1;
      }
      pstmt = conn.prepareStatement(insertSaleSubLedgerSql);
      //创建销售账套明细数据表的新记录
      for(int i = 0; i < saleSubLedger.length; i++){
        pstmt.setInt(1, newSerialId);
        pstmt.setString(2, newSaleId);
        pstmt.setString(3, saleSubLedger[i][2]);
        pstmt.setDouble(4, Double.parseDouble(saleSubLedger[i][3]));
        pstmt.setInt(5, Integer.parseInt(saleSubLedger[i][4]));
        newSerialId++;
        //执行插入操作
        pstmt.execute();
      }
      //提交事条
      conn.commit();
      result = 1;
    }catch(Exception ex){
      try{
        //撤消事务
        conn.rollback();
      }catch(Exception ex1){
        ex1.printStackTrace();
      }
      ex.printStackTrace();
    }
    //清空数据库联接
    cleanup(conn);
    return result;
  }
  //更新销售账套数据表和销售账套明细数据表记录的方法
  public int updateSaleLedgerAndSub(String ledgerDate, String[] saleLedger, String[][] saleSubLedger) {
    int result = 0;
    //取得帐套集合
    String[] ledgerDates = this.getLedgerNames();
    //只能对当前账套进行更新操作
    if(!ledgerDates[ledgerDates.length - 1].equals(ledgerDate)){
      return result;
    }
    //取得数据库联接
    Connection conn = getConnection();
    String updateSaleLedgerSql = "update saleLedger" + ledgerDate + " set "
        + "customerName = ?, counterUser = ?, creditUser = ?, "
        + "cashUser = ?, address = ?, fillerDate = ?, "
        + "deliveryDate = ?, onProcess = ?, remark = ? where saleId = ?";
    String updateSaleSubLedgerSql = "update saleSubLedger" + ledgerDate
        + " set goodsBarCode = ?, actualPrice = ?, quantity = ?"
        + " where serialId = ?";
    try{
      //开始事务
      conn.setAutoCommit(false);
      //创建带参数的SQL语句执行类
      PreparedStatement pstmt = conn.prepareStatement(updateSaleLedgerSql);
      //设置销售账套数据表的SQL语句参数
      pstmt.setString(1, saleLedger[2]);
      pstmt.setString(2, saleLedger[3]);
      pstmt.setString(3, saleLedger[4]);
      pstmt.setString(4, saleLedger[5]);
      pstmt.setString(5, saleLedger[6]);
      pstmt.setTimestamp(6, dataMethod.transferDateTime(saleLedger[7]));
      pstmt.setTimestamp(7, dataMethod.transferDateTime(saleLedger[8]));
      pstmt.setInt(8, Integer.parseInt(saleLedger[9]));
      pstmt.setString(9, saleLedger[10]);
      pstmt.setString(10, saleLedger[0]);
      //执行销售账套数据表的更新操作
      pstmt.execute();
      pstmt = conn.prepareStatement(updateSaleSubLedgerSql);
      //设置销售账套明细数据表的SQL语句参数
      for(int i = 0; i < saleSubLedger.length; i++){
        pstmt.setString(1, saleSubLedger[i][2]);
        pstmt.setDouble(2, Double.parseDouble(saleSubLedger[i][3]));
        pstmt.setInt(3, Integer.parseInt(saleSubLedger[i][4]));
        pstmt.setInt(4, Integer.parseInt(saleSubLedger[i][0]));
        //执行销售账套明细数据表的更新操作
        pstmt.execute();
      }
      //提交事条
      conn.commit();
      result = 1;
    }catch(Exception ex){
      try{
        //撤消事务
        conn.rollback();
      }catch(Exception ex1){
        ex1.printStackTrace();
      }
      ex.printStackTrace();
    }
    //清空数据库联接
    cleanup(conn);
    return result;
  }
  //销售账套数据表电子签名和更新完成状态的方法
  public int signSaleLedgerAndSub(String ledgerDate, String fieldName, String userName, String saleId, int onProcess, String remark) {
    int result = 0;
    //取得帐套集合
    String[] ledgerDates = this.getLedgerNames();
    //只能对当前账套进行操作
    if(!ledgerDates[ledgerDates.length - 1].equals(ledgerDate)){
      return result;
    }
    //取得数据库联接
    Connection conn = getConnection();
    String updateStockLedgerSql = "update saleLedger" + ledgerDate + " set "
        + fieldName + " = ?, remark = ?, onProcess = ? where saleId = ?";
    try{
      //开始事务
      conn.setAutoCommit(false);
      //创建带参数的SQL语句执行类
      PreparedStatement pstmt = conn.prepareStatement(updateStockLedgerSql);
      //设置销售账套数据表的SQL语句参数
      pstmt.setString(1, userName);
      pstmt.setString(2, remark);
      pstmt.setInt(3, onProcess);
      pstmt.setString(4, saleId);
      //执行销售账套数据表的更新操作
      pstmt.execute();
      //提交事条
      conn.commit();
      result = 1;
    }catch(Exception ex){
      try{
        //撤消事务
        conn.rollback();
      }catch(Exception ex1){
        ex1.printStackTrace();
      }
      ex.printStackTrace();
    }
    //清空数据库联接
    cleanup(conn);
    return result;
  }
  //根据单据编号取得销售账套明细数据表的记录
  public String[][] getSaleSubLedgerBySaleId(String ledgerDate, String saleId) {
    String[][] data = new String[0][5];
    //取得数据库联接
    Connection conn = getConnection();
    String countSql = "select count(*) from saleSubLedger" + ledgerDate +
        " where saleId = '" + saleId + "'";
    String sql = "select * from saleSubLedger" + ledgerDate +
        " where saleId = '" + saleId + "'";
    try {
      Statement stmt = conn.createStatement();
      //取得数据表的记录数
      ResultSet rs = stmt.executeQuery(countSql);
      int rowCount = 0;
      if (rs.next()) {
        rowCount = rs.getInt(1);
      }
      //取得数据表的记录
      rs = stmt.executeQuery(sql);
      //根据数据表的行与列总数创建数组
      data = new String[rowCount][5];
      //将数据记录存放在数组
      int row = 0;
      while (rs.next()) {
        for (int col = 0; col < 5; col++) {
          data[row][col] = rs.getString(col + 1);
        }
        row++;
      }
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    //清空数据库联接
    cleanup(conn);
    return data;
  }
  //根据字符串字段取得销售账套数据表记录的方法
  public String[][] getSaleLedgerByStringField(String ledgerDate, String fieldName, String fieldValue, int saleType) {
    String[][] data = new String[0][11];
    //取得数据库联接
    Connection conn = getConnection();
    String countSql = "select count(*) from saleLedger" + ledgerDate +
        " where saleType = " + saleType + " and " + fieldName + " like '%" + fieldValue + "%'";
    String sql = "select * from saleLedger" + ledgerDate +
        " where saleType = " + saleType + " and " + fieldName + " like '%" + fieldValue + "%'";
    try {
      Statement stmt = conn.createStatement();
      //取得数据表的记录数
      ResultSet rs = stmt.executeQuery(countSql);
      int rowCount = 0;
      if (rs.next()) {
        rowCount = rs.getInt(1);
      }
      //取得数据表的记录
      rs = stmt.executeQuery(sql);
      //根据数据表的行与列总数创建数组
      data = new String[rowCount][11];
      //将数据记录存放在数组
      int row = 0;
      while (rs.next()) {
        for (int col = 0; col < 11; col++) {
          data[row][col] = rs.getString(col + 1);
        }
        row++;
      }
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    //清空数据库联接
    cleanup(conn);
    return data;
  }
  //根据完成状态取得销售账套数据表记录的方法
  public String[][] getSaleLedgerByOnProcess(String ledgerDate, int saleType, int onProcess) {
    String[][] data = new String[0][11];
    //取得数据库联接
    Connection conn = getConnection();
    String countSql = "select count(*) from saleLedger" + ledgerDate +
        " where saleType = " + saleType + " and onProcess = " + onProcess;
    String sql = "select * from saleLedger" + ledgerDate +
        " where saleType = " + saleType + " and onProcess = " + onProcess;
    try {
      Statement stmt = conn.createStatement();
      //取得数据表的记录数
      ResultSet rs = stmt.executeQuery(countSql);
      int rowCount = 0;
      if (rs.next()) {
        rowCount = rs.getInt(1);
      }
      //取得数据表的记录
      rs = stmt.executeQuery(sql);
      //根据数据表的行与列总数创建数组
      data = new String[rowCount][11];
      //将数据记录存放在数组
      int row = 0;
      while (rs.next()) {
        for (int col = 0; col < 11; col++) {
          data[row][col] = rs.getString(col + 1);
        }
        row++;
      }
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    //清空数据库联接
    cleanup(conn);
    return data;
  }
  //根据订单日期取得销售账套数据表记录的方法
  public String[][] getSaleLedgerByOrderDate(String ledgerDate, java.sql.Timestamp startDate, java.sql.Timestamp endDate, int saleType) {
    String[][] data = new String[0][11];
    //取得数据库联接
    Connection conn = getConnection();
    String countSql = "select count(*) from saleLedger" + ledgerDate +
        " where saleType = " + saleType + " and fillerDate >= ? and fillerDate <= ?";
    String sql = "select * from saleLedger" + ledgerDate +
        " where saleType = " + saleType + " and  fillerDate >= ? and fillerDate <= ?";
    try {
      //创建获得记录总数的SQL语句执行类
      PreparedStatement pstmt = conn.prepareStatement(countSql);
      pstmt.setTimestamp(1, startDate);
      pstmt.setTimestamp(2, endDate);
      //取得数据表的记录数
      ResultSet rs = pstmt.executeQuery();
      int rowCount = 0;
      if (rs.next()) {
        rowCount = rs.getInt(1);
      }
      //创建获得记录的SQL语句执行类
      pstmt = conn.prepareStatement(sql);
      pstmt.setTimestamp(1, startDate);
      pstmt.setTimestamp(2, endDate);
      //取得数据表的记录
      rs = pstmt.executeQuery();
      //根据数据表的行与列总数创建数组
      data = new String[rowCount][11];
      //将数据记录存放在数组
      int row = 0;
      while (rs.next()) {
        for (int col = 0; col < 11; col++) {
          data[row][col] = rs.getString(col + 1);
        }
        row++;
      }
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    //清空数据库联接
    cleanup(conn);
    return data;
  }
  //取得出库单明细数组表的方法，根据商品的有效期实现先入先出
  private String[][] getStockSubLedgerForSale(String ledgerDate, String[][] goodsSold, Connection conn, String warehouse) {
    String[][] stockSubLedger = new String[0][6];
    //创建选择语句，根据商品条形码、进货价和有效期取得库存账套明细数据表的商品数量
    String totalQuantitySql = "select b.goodsBarCode,costPrice, sum(b.quantity) as "
        + " quantity, usefullife from stockLedger" + ledgerDate + " as a , "
        + " stockSubLedger" + ledgerDate + " as b where a.orderId = b.orderId "
        + " and a.onProcess = 2  and goodsBarcode=? and warehouse = '" + warehouse + "'"
        + " group by goodsBarcode, costPrice, usefullife"
        + " order by usefullife";
    try{
      //创建带参数的SQL语句执行类
      PreparedStatement pstmt = conn.prepareStatement(totalQuantitySql);
      //创建集合类
      Vector vector = new Vector();
      for(int i = 0; i < goodsSold.length; i++){
        //取得商品的卖出数量
        int saleQuantity = Integer.parseInt(goodsSold[i][2]);
        //根据条形码取得库存明细账数据表的商品数量
        pstmt.setString(1, goodsSold[i][0]);
        ResultSet rs = pstmt.executeQuery();
        double costPrice = 0;
        int stockQuantity =0;
        String usefullife = "";
        while(rs.next()){
          //根据有效期的先后顺序取得商品数据
          costPrice = rs.getDouble("costPrice");
          stockQuantity = rs.getInt("quantity");
          usefullife = rs.getString("usefullife");
          //如果库存数为负数或者0,继续下一条记录
          if(stockQuantity <= 0){
            continue;
          }
          //如果库存数大于或者等于卖出数量，离开循环
          if(stockQuantity >= saleQuantity){
            //出库单的商品数量是负数
            vector.add(goodsSold[i][0] + "@@"  + String.valueOf(costPrice) + "@@" +
                       String.valueOf(-saleQuantity) + "@@" + usefullife);
            //减少卖出的数量
            saleQuantity = saleQuantity - stockQuantity;
            break;
          }else{
            vector.add(goodsSold[i][0] + "@@"  + String.valueOf(costPrice) + "@@" +
                       String.valueOf(-stockQuantity) + "@@" + usefullife);
            //减少卖出的数量
            saleQuantity = saleQuantity - stockQuantity;
          }
        }
        //如果卖出数量大于库存数，取得最后一条记录作为卖出商品的进货价和有效期
        if(saleQuantity > 0){
          vector.add(goodsSold[i][0] + "@@"  + String.valueOf(costPrice) + "@@" +
                       String.valueOf(-saleQuantity) + "@@" + usefullife);
        }
      }
      //重新创建明细账数组
      stockSubLedger = new String[vector.size()][6];
      Object[] vectorObject = vector.toArray();
      //将集合的内容放入数据
      String tempStr = "";
      for(int i = 0; i < vectorObject.length; i++){
        tempStr = (String)vectorObject[i];
        java.util.StringTokenizer token = new java.util.StringTokenizer(tempStr, "@@");
        for(int j = 0; j < 4; j++){
          if(token.hasMoreTokens()){
            stockSubLedger[i][j + 2] = token.nextToken();
          }
        }
      }
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return stockSubLedger;
  }
  //取得销售成本数组的方法
  private String[][] getGoodsCost(String[][] goodsSold, String[][] stockSubLedger){
    String[][] goodsCost = new String[goodsSold.length][3];
    for(int i = 0; i < goodsSold.length; i++){
      goodsCost[i][0] = goodsSold[i][0];
      goodsCost[i][2] = goodsSold[i][2];
      double oneGoodsCost = 0;
      for (int j = 0; j < stockSubLedger.length; j++) {
        if (stockSubLedger[j][2].equals(goodsCost[i][0])) {
          //计算单个商品的成本
          oneGoodsCost += Double.parseDouble(stockSubLedger[j][3]) *
              (-Integer.parseInt(stockSubLedger[j][4]));
        }
      }
      goodsCost[i][1] = String.valueOf(dataMethod.round(oneGoodsCost));
    }
    return goodsCost;
  }
  //前台销售员进行销售账套数据表电子签名的方法
  public int counterUserSignSaleLedgerAndSub(String ledgerDate, String userName, String remark, String warehouse) {
    int result = 0;
    //取得帐套集合
    String[] ledgerDates = this.getLedgerNames();
    //只能对当前账套进行操作
    if(!ledgerDates[ledgerDates.length - 1].equals(ledgerDate)){
      return result;
    }
    //取得数据库联接
    Connection conn = getConnection();
    //创建更新语句
    String updateSaleLedgerSql = "update saleLedger" + ledgerDate + " set cashUser = ? , "
        + " onProcess = 2, remark = ? where saleId in( select saleId "
        + " from saleLedger" + ledgerDate
        + " where counterUser = ? and saleType = 0 and onProcess = 0)";
    //创建选择语句，取得传入用户的未完成销售单的总金额和总数量
    String goodsSoldsql = "select goodsBarcode, sum(actualPrice*quantity) as amount , "
        + "sum(quantity) as quantity from saleSubLedger" + ledgerDate + " where saleId in("
        + " select saleId from saleLedger" + ledgerDate + " where counterUser = '"
        + userName + "' and saleType = 0 and onProcess = 0)"
        + " group by goodsBarcode";
    try{
      //开始事务
      conn.setAutoCommit(false);
      //创建不带参数的SQL语句执行类
      Statement stmt = conn.createStatement();
      double saleAmount = 0;
      String[][] goodsSold = new String[0][3];
      int count = 0;
      //取得传入用户的未完成销售单的商品条形码、金额和数量
      ResultSet rs = stmt.executeQuery(goodsSoldsql);
      //取得记录数
      while(rs.next()){
        count++;
      }
      goodsSold = new String[count][3];
      //重新取得记录集
      rs = stmt.executeQuery(goodsSoldsql);
      for(int i = 0; i < count; i++){
        if(rs.next()){
          goodsSold[i][0] = rs.getString("goodsBarcode");
          //取得销售总金额
          double amount = dataMethod.round(rs.getDouble("amount"));
          saleAmount += amount;
          goodsSold[i][1] = String.valueOf(amount);
          goodsSold[i][2] = rs.getString("quantity");
        }
      }
      //创建带参数的SQL语句执行类
      PreparedStatement pstmt = conn.prepareStatement(updateSaleLedgerSql);
      //设置销售账套数据表的SQL语句参数
      pstmt.setString(1, userName);
      pstmt.setString(2, remark);
      pstmt.setString(3, userName);
      //执行销售账套数据表的更新操作，将传入用户的所创建的销售单设为完成
      int subResult = pstmt.executeUpdate();
      //如果所有销售单已完成，退出事务处理
      if(subResult == 0){
        conn.rollback();
        return 0;
      }
      //创建出库单数组
      String[] stockLedger = new String[13];
      String[][] stockSubLedger = new String[0][6];
      stockLedger[1] = "4";                    //4表示销售出库单
      //sa表示与销售账套数据表相联系，由于会计分录是根据传入用户的多张销售单创建，所以与用户关联
      stockLedger[2] = "sa" + userName;        //关联标识
      stockLedger[3] = userName;               //销售员
      stockLedger[4] = "";
      stockLedger[5] = "";
      stockLedger[6] = "";
      stockLedger[7] = "";
      stockLedger[8] = warehouse;              //仓库名
      stockLedger[9] = dataMethod.getCurrentDate().toString();   //填写日期
      stockLedger[10] = dataMethod.getCurrentDate().toString();  //系统日期
      stockLedger[11] = "2";                   //出库单一经创建便处于完成状态
      stockLedger[12] = "";
      //取得出库单的明细数据
      stockSubLedger = this.getStockSubLedgerForSale(ledgerDate, goodsSold, conn, warehouse);
      //创建会计分录数组,写入销售收入会计分录
      String[] accountEntryLedger = new String[7];
      //sa表示与销售账套数据表相联系，由于会计分录是根据传入用户的多张销售单创建，所以与用户关联
      accountEntryLedger[0] = "sa" + userName;
      accountEntryLedger[1] = userName;
      accountEntryLedger[2] = "";
      accountEntryLedger[3] = dataMethod.getCurrentDate().toString();
      accountEntryLedger[4] = null;
      accountEntryLedger[5] = "0";
      accountEntryLedger[6] = "";
      //创建会计分录明细账数组
      String[][] accountEntrySubLedger = new String[goodsSold.length + 1][3];
      //写入借方分录
      accountEntrySubLedger[0][0] = "0";
      accountEntrySubLedger[0][1] = "流动资产@@现金";
      accountEntrySubLedger[0][2] = String.valueOf(saleAmount);
      //写入贷方分录
      for(int i = 1; i < accountEntrySubLedger.length; i++){
        accountEntrySubLedger[i][0] = "1";
        accountEntrySubLedger[i][1] = "销售收入@@" + goodsSold[i - 1][0];
        accountEntrySubLedger[i][2] = String.valueOf(goodsSold[i - 1][1]);
      }
      //向数据表写入销售收入会计分录,应用本方法事务
      subResult = this.createAccountEntry(ledgerDate, accountEntryLedger,
                                              accountEntrySubLedger, true, conn);
      //如果不能正确添加会计分录，撤消数据库的事条
      if(subResult == 0){
        conn.rollback();
        return 0;
      }
      //创建会计分录数组,写入销售成本会计分录
      accountEntryLedger = new String[7];
      //sa表示与销售账套数据表相联系，由于会计分录是根据传入用户的多张销售单创建，所以与用户关联
      accountEntryLedger[0] = "sa" + userName;
      accountEntryLedger[1] = userName;
      accountEntryLedger[2] = "";
      accountEntryLedger[3] = dataMethod.getCurrentDate().toString();
      accountEntryLedger[4] = null;
      accountEntryLedger[5] = "0";
      accountEntryLedger[6] = "";
      //取得成本数组
      String[][] goodsCost = this.getGoodsCost(goodsSold, stockSubLedger);
      //创建会计分录明细账数组
      accountEntrySubLedger = new String[goodsCost.length * 2][3];
      //写入借方分录
      for(int i = 0; i < goodsCost.length; i++){
        accountEntrySubLedger[i][0] = "0";
        accountEntrySubLedger[i][1] = "销售成本@@" + goodsCost[i][0];
        accountEntrySubLedger[i][2] = String.valueOf(goodsCost[i][1]);
      }
      //写入贷方分录
      int j = 0;
      for(int i = goodsCost.length; i < accountEntrySubLedger.length; i++){
        accountEntrySubLedger[i][0] = "1";
        accountEntrySubLedger[i][1] = "流动资产@@存货@@" + goodsCost[j][0];
        accountEntrySubLedger[i][2] = String.valueOf(goodsCost[j][1]);
        j++;
      }
      //向数据表写入销售成本会计分录,应用本方法事务
      subResult = this.createAccountEntry(ledgerDate, accountEntryLedger,
                                              accountEntrySubLedger, true, conn);
      //如果不能正确添加会计分录，撤消数据库的事条
      if(subResult == 0){
        conn.rollback();
        return 0;
      }
      //创建现金账套数组
      String[] cashLedger = new String[5];
      //sa表示与销售账套数据表相联系，由于会计分录是根据传入用户的多张销售单创建，所以与用户关联
      cashLedger[0] = "sa" + userName;
      cashLedger[1] = "0";
      cashLedger[2] = userName;
      cashLedger[3] = String.valueOf(saleAmount);
      cashLedger[4] = dataMethod.getCurrentDate().toString();
      //向现金账套数据表写入记录，应用本方法的事务
      subResult = this.createCashLedger(ledgerDate, cashLedger, true, conn);
      //如果不能正确添加现金账套记录，撤消数据库的事条
      if (subResult == 0) {
        conn.rollback();
        return 0;
      }
      //由于出库单是独立事务，所以最后才创建出库单
      subResult = this.createStockLedgerAndSub(ledgerDate, stockLedger, stockSubLedger);
      //如果出库单创建失败，退出事务处理
      if(subResult == 0){
        conn.rollback();
        return 0;
      }
      //提交事条
      conn.commit();
      result = 1;
    }catch(Exception ex){
      try{
        //撤消事务
        conn.rollback();
      }catch(Exception ex1){
        ex1.printStackTrace();
      }
      ex.printStackTrace();
    }
    //清空数据库联接
    cleanup(conn);
    return result;
  }
  //信用销售用户进行销售账套数据表电子签名的方法
  public int creditUserSignSaleLedgerAndSub(String ledgerDate, String userName, String remark, String warehouse, String saleId, String customerName) {
    int result = 0;
    //取得帐套集合
    String[] ledgerDates = this.getLedgerNames();
    //只能对当前账套进行操作
    if(!ledgerDates[ledgerDates.length - 1].equals(ledgerDate)){
      return result;
    }
    //取得数据库联接
    Connection conn = getConnection();
    //创建更新语句
    String updateSaleLedgerSql = "update saleLedger" + ledgerDate + " set "
        + " onProcess = 2, remark = ?, deliveryDate = ? where saleId ='" + saleId +"' and onProcess = 0";
    //创建选择语句，取得传入销售单的总金额和总数量
    String goodsSoldsql = "select goodsBarcode, sum(actualPrice*quantity) as amount , "
        + "sum(quantity) as quantity from saleSubLedger" + ledgerDate
        + " where saleId ='" + saleId +"'"
        + " group by goodsBarcode";
    try{
      //开始事务
      conn.setAutoCommit(false);
      //创建不带参数的SQL语句执行类
      Statement stmt = conn.createStatement();
      double saleAmount = 0;
      String[][] goodsSold = new String[0][3];
      int count = 0;
      //取得传入销售单的商品条形码、金额和数量
      ResultSet rs = stmt.executeQuery(goodsSoldsql);
      //取得记录数
      while(rs.next()){
        count++;
      }
      goodsSold = new String[count][3];
      //重新取得记录集
      rs = stmt.executeQuery(goodsSoldsql);
      for(int i = 0; i < count; i++){
        if(rs.next()){
          goodsSold[i][0] = rs.getString("goodsBarcode");
          //取得销售总金额
          double amount = dataMethod.round(rs.getDouble("amount"));
          saleAmount += amount;
          goodsSold[i][1] = String.valueOf(amount);
          goodsSold[i][2] = rs.getString("quantity");
        }
      }
      //创建带参数的SQL语句执行类
      PreparedStatement pstmt = conn.prepareStatement(updateSaleLedgerSql);
      //设置销售账套数据表的SQL语句参数
      pstmt.setString(1, remark);
      pstmt.setTimestamp(2, dataMethod.getCurrentDate());
      //执行销售账套数据表的更新操作，将传入销售表设为完成
      int subResult = pstmt.executeUpdate();
      //如果销售单已完成，退出事务处理
      if(subResult == 0){
        conn.rollback();
        return 0;
      }
      //创建出库单数组
      String[] stockLedger = new String[13];
      String[][] stockSubLedger = new String[0][6];
      stockLedger[1] = "4";                    //4表示销售出库单
      stockLedger[2] = "sa" + saleId;          //关联标识
      stockLedger[3] = userName;               //销售员
      stockLedger[4] = "";
      stockLedger[5] = "";
      stockLedger[6] = "";
      stockLedger[7] = "";
      stockLedger[8] = warehouse;              //仓库名
      stockLedger[9] = dataMethod.getCurrentDate().toString();   //填写日期
      stockLedger[10] = dataMethod.getCurrentDate().toString();  //系统日期
      stockLedger[11] = "2";                   //出库单一经创建便处于完成状态
      stockLedger[12] = "";
      //取得出库单的明细数据
      stockSubLedger = this.getStockSubLedgerForSale(ledgerDate, goodsSold, conn, warehouse);
      //创建会计分录数组,写入销售收入会计分录
      String[] accountEntryLedger = new String[7];
      //sa表示与销售账套数据表相联系
      accountEntryLedger[0] = "sa" + saleId;
      accountEntryLedger[1] = userName;
      accountEntryLedger[2] = "";
      accountEntryLedger[3] = dataMethod.getCurrentDate().toString();
      accountEntryLedger[4] = null;
      accountEntryLedger[5] = "0";
      accountEntryLedger[6] = "";
      //创建会计分录明细账数组
      String[][] accountEntrySubLedger = new String[goodsSold.length + 1][3];
      //写入借方分录
      accountEntrySubLedger[0][0] = "0";
      accountEntrySubLedger[0][1] = "流动资产@@应收账款@@" +  customerName;
      accountEntrySubLedger[0][2] = String.valueOf(saleAmount);
      //写入贷方分录
      for(int i = 1; i < accountEntrySubLedger.length; i++){
        accountEntrySubLedger[i][0] = "1";
        accountEntrySubLedger[i][1] = "销售收入@@" + goodsSold[i - 1][0];
        accountEntrySubLedger[i][2] = String.valueOf(goodsSold[i - 1][1]);
      }
      //向数据表写入销售收入会计分录,应用本方法事务
      subResult = this.createAccountEntry(ledgerDate, accountEntryLedger,
                                              accountEntrySubLedger, true, conn);
      //如果不能正确添加会计分录，撤消数据库的事条
      if(subResult == 0){
        conn.rollback();
        return 0;
      }
      //创建会计分录数组,写入销售成本会计分录
      accountEntryLedger = new String[7];
      //sa表示与销售账套数据表相联系
      accountEntryLedger[0] = "sa" + saleId;
      accountEntryLedger[1] = userName;
      accountEntryLedger[2] = "";
      accountEntryLedger[3] = dataMethod.getCurrentDate().toString();
      accountEntryLedger[4] = null;
      accountEntryLedger[5] = "0";
      accountEntryLedger[6] = "";
      //取得成本数组
      String[][] goodsCost = this.getGoodsCost(goodsSold, stockSubLedger);
      //创建会计分录明细账数组
      accountEntrySubLedger = new String[goodsCost.length * 2][3];
      //写入借方分录
      for(int i = 0; i < goodsCost.length; i++){
        accountEntrySubLedger[i][0] = "0";
        accountEntrySubLedger[i][1] = "销售成本@@" + goodsCost[i][0];
        accountEntrySubLedger[i][2] = String.valueOf(goodsCost[i][1]);
      }
      //写入贷方分录
      int j = 0;
      for(int i = goodsCost.length; i < accountEntrySubLedger.length; i++){
        accountEntrySubLedger[i][0] = "1";
        accountEntrySubLedger[i][1] = "流动资产@@存货@@" + goodsCost[j][0];
        accountEntrySubLedger[i][2] = String.valueOf(goodsCost[j][1]);
        j++;
      }
      //向数据表写入销售成本会计分录,应用本方法事务
      subResult = this.createAccountEntry(ledgerDate, accountEntryLedger,
                                              accountEntrySubLedger, true, conn);
      //如果不能正确添加会计分录，撤消数据库的事条
      if(subResult == 0){
        conn.rollback();
        return 0;
      }
      //创建往来账套数组
      String[] currentAccountLedger = new String[10];
      //sa表示与销售账套数据表相联系
      currentAccountLedger[0] = "sa" + saleId;
      currentAccountLedger[1] = "1";            //1表示应收账款
      currentAccountLedger[2] = String.valueOf(saleAmount);
      currentAccountLedger[3] = customerName;
      currentAccountLedger[4] = userName;
      currentAccountLedger[5] = "";
      currentAccountLedger[6] = dataMethod.getCurrentDate().toString(); ;
      currentAccountLedger[7] = null;
      currentAccountLedger[8] = "0";
      currentAccountLedger[9] = "";
      //向往来账套数据表写入记录，应用本方法的事务
      subResult = this.createCurrentAccountLedger(ledgerDate,
                                                  currentAccountLedger,
                                                  true, conn);
      //如果不能正确添加往来账套记录，撤消数据库的事条
      if (subResult == 0) {
        conn.rollback();
        return 0;
      }
      //由于出库单是独立事务，所以最后才创建出库单
      subResult = this.createStockLedgerAndSub(ledgerDate, stockLedger, stockSubLedger);
      //如果出库单创建失败，退出事务处理
      if(subResult == 0){
        conn.rollback();
        return 0;
      }
      //提交事条
      conn.commit();
      result = 1;
    }catch(Exception ex){
      try{
        //撤消事务
        conn.rollback();
      }catch(Exception ex1){
        ex1.printStackTrace();
      }
      ex.printStackTrace();
    }
    //清空数据库联接
    cleanup(conn);
    return result;
  }
  //现金管理员对应收票据进行电子签名的方法
  public int cashUserSignAccountReceivable(String ledgerDate, String userName, String[] currentAccountLedger) {
    int result = 0;
    //取得帐套集合
    String[] ledgerDates = this.getLedgerNames();
    //只能对当前账套进行操作
    if(!ledgerDates[ledgerDates.length - 1].equals(ledgerDate)){
      return result;
    }
    //取得数据库联接
    Connection conn = getConnection();
    //创建更新语句
    String updateCurrentAccountLedgerSql = "update currentAccountLedger" + ledgerDate + " set "
        + " cashUser = ?, remark = ?, payDate = ?, onProcess = 2 "
        + " where currentAccountId = ? and onProcess = 0";
    try{
      //开始事务
      conn.setAutoCommit(false);
      //创建不带参数的SQL语句执行类
      Statement stmt = conn.createStatement();
      //创建带参数的SQL语句执行类
      PreparedStatement pstmt = conn.prepareStatement(updateCurrentAccountLedgerSql);
      //设置往来账套数据表的SQL语句参数
      pstmt.setString(1, userName);
      pstmt.setString(2, currentAccountLedger[10]);
      pstmt.setTimestamp(3, dataMethod.getCurrentDate());
      pstmt.setString(4, currentAccountLedger[0]);
      //对往来账套数据表进行签名
      int subResult = pstmt.executeUpdate();
      //往来账套数据表的更新操作失败
      if(subResult == 0){
        conn.rollback();
        return 0;
      }
      //创建会计分录数组
      String[] accountEntryLedger = new String[7];
      //cu表示与往来账套数据表相联系
      accountEntryLedger[0] = "cu" + currentAccountLedger[0];
      accountEntryLedger[1] = userName;
      accountEntryLedger[2] = "";
      accountEntryLedger[3] = dataMethod.getCurrentDate().toString();
      accountEntryLedger[4] = null;
      accountEntryLedger[5] = "0";
      accountEntryLedger[6] = "";
      //创建会计分录明细账数组
      String[][] accountEntrySubLedger = new String[2][3];
      //写入借方分录
      accountEntrySubLedger[0][0] = "0";
      accountEntrySubLedger[0][1] = "流动资产@@现金";
      accountEntrySubLedger[0][2] =  currentAccountLedger[3];
      //写入贷方分录
      accountEntrySubLedger[1][0] = "1";
      accountEntrySubLedger[1][1] = "流动资产@@应收账款@@" + currentAccountLedger[4];
      accountEntrySubLedger[1][2] = currentAccountLedger[3];
      //向数据表写入会计分录，应用本方法的事务
      subResult = this.createAccountEntry(ledgerDate, accountEntryLedger,
                                              accountEntrySubLedger, true, conn);
      //如果不能正确添加会计分录，撤消数据库的事条
      if(subResult == 0){
        conn.rollback();
        return 0;
      }
      //创建现金账套数组
      String[] cashLedger = new String[5];
      //cu表示与往来账套数据表相联系
      cashLedger[0] = "cu" + currentAccountLedger[0];
      cashLedger[1] = "0";                             //0表示现金增加
      cashLedger[2] = userName;
      cashLedger[3] = currentAccountLedger[3];
      cashLedger[4] = dataMethod.getCurrentDate().toString();
      //向现金账套数据表写入记录，应用本方法的事务
      subResult = this.createCashLedger(ledgerDate, cashLedger, true,  conn);
      //如果不能正确添加现金账套记录，撤消数据库的事条
      if(subResult == 0){
        conn.rollback();
        return 0;
      }
      //提交事条
      conn.commit();
      result = 1;
    }catch(Exception ex){
      try{
        //撤消事务
        conn.rollback();
      }catch(Exception ex1){
        ex1.printStackTrace();
      }
      ex.printStackTrace();
    }
    //清空数据库联接
    cleanup(conn);
    return result;
  }
  //根据关联标识、退货单的商品条形码取得库存账套的销售出库单明细账的数据
  public String[][] getStockSaleOutBySaleOrderLink(String ledgerDate, String saleOrderLink, String saleId){
    String[][] data = new String[0][4];
    //取得数据库联接
    Connection conn = getConnection();
    String sql = "select b.goodsBarCode, b.costPrice, sum(b.quantity) as quantity, b.usefulLife"
        + " from stockLedger" + ledgerDate + " as a , stockSubLedger" + ledgerDate +"  as b"
        + " where a.orderId = b.orderId and a.supplierName = '" + saleOrderLink + "'"
        + " and a.orderType = 4 and b.goodsBarCode in ("
        + " select d.goodsBarCode from saleLedger" + ledgerDate + " as c, saleSubLedger" + ledgerDate
        + " as d where c.saleId = d.saleId and c.saleId = '" + saleId + "')"
        + " group by b.goodsBarCode, b.costPrice, b.usefulLife"
        + " order by b.goodsBarCode, b.usefullife";
    try {
      Statement stmt = conn.createStatement();
      //取得数据表的记录
      ResultSet rs = stmt.executeQuery(sql);
      //创建集合类
      Vector vector = new Vector();
      int rowCount = 0;
      while (rs.next()) {
        vector.add("");
      }
      rowCount = vector.size();
      //重新取得记录
      rs = stmt.executeQuery(sql);
      //根据数据表的行与列总数创建数组
      data = new String[rowCount][4];
      //将数据记录存放在数组
      int row = 0;
      while (rs.next()) {
        for (int col = 0; col < 4; col++) {
          data[row][col] = rs.getString(col + 1);
        }
        row++;
      }
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    //清空数据库联接
    cleanup(conn);
    return data;
  }
  //前台销售员进行销售退货单电子签名的方法
  public int counterUserSignSaleReturn(String ledgerDate, String saleId, String userName, String remark, String warehouse, String[][] stockSubLedger) {
    int result = 0;
    //取得帐套集合
    String[] ledgerDates = this.getLedgerNames();
    //只能对当前账套进行操作
    if(!ledgerDates[ledgerDates.length - 1].equals(ledgerDate)){
      return result;
    }
    //取得数据库联接
    Connection conn = getConnection();
    //创建更新语句
    String updateSaleLedgerSql = "update saleLedger" + ledgerDate + " set cashUser = ? , "
        + " onProcess = 2, remark = ? where saleId ='" + saleId + "' and onProcess = 0";
    //创建选择语句，取得传入销售退货单的总金额和总数量
    String goodsSoldReturnsql = "select goodsBarcode, sum(actualPrice*quantity) as amount , "
        + " sum(quantity) as quantity from saleSubLedger" + ledgerDate
        + " where saleId ='" + saleId +"'"
        + " group by goodsBarcode";
    try{
      //开始事务
      conn.setAutoCommit(false);
      //创建不带参数的SQL语句执行类
      Statement stmt = conn.createStatement();
      double saleAmount = 0;
      String[][] goodsSoldReturn = new String[0][3];
      int count = 0;
      //取得传入销售退货单的商品条形码、金额和数量
      ResultSet rs = stmt.executeQuery(goodsSoldReturnsql);
      //取得记录数
      while(rs.next()){
        count++;
      }
      goodsSoldReturn = new String[count][3];
      //重新取得记录集
      rs = stmt.executeQuery(goodsSoldReturnsql);
      for(int i = 0; i < count; i++){
        if(rs.next()){
          goodsSoldReturn[i][0] = rs.getString("goodsBarcode");
          //取得销售总金额
          double amount = dataMethod.round(rs.getDouble("amount"));
          saleAmount += amount;
          goodsSoldReturn[i][1] = String.valueOf(amount);
          goodsSoldReturn[i][2] = rs.getString("quantity");
        }
      }
      //创建带参数的SQL语句执行类
      PreparedStatement pstmt = conn.prepareStatement(updateSaleLedgerSql);
      //设置销售账套数据表的SQL语句参数
      pstmt.setString(1, userName);
      pstmt.setString(2, remark);
      //执行销售账套数据表的更新操作，将传入销售退货单设为完成
      int subResult = pstmt.executeUpdate();
      //如果所有销售退货单已完成，退出事务处理
      if(subResult == 0){
        conn.rollback();
        return 0;
      }
      //创建销售退货单数组
      String[] stockLedger = new String[13];
      stockLedger[1] = "5";                    //5表示销售退货单
      //sa表示与销售账套数据表相联系
      stockLedger[2] = "sa" + saleId;          //关联标识
      stockLedger[3] = userName;               //销售员
      stockLedger[4] = "";
      stockLedger[5] = "";
      stockLedger[6] = "";
      stockLedger[7] = "";
      stockLedger[8] = warehouse;              //仓库名
      stockLedger[9] = dataMethod.getCurrentDate().toString();   //填写日期
      stockLedger[10] = dataMethod.getCurrentDate().toString();  //系统日期
      stockLedger[11] = "2";                   //销售退货单一经创建便处于完成状态
      stockLedger[12] = "";
      //创建会计分录数组,写入销售收入会计分录
      String[] accountEntryLedger = new String[7];
      //sa表示与销售账套数据表相联系
      accountEntryLedger[0] = "sa" + saleId;
      accountEntryLedger[1] = userName;
      accountEntryLedger[2] = "";
      accountEntryLedger[3] = dataMethod.getCurrentDate().toString();
      accountEntryLedger[4] = null;
      accountEntryLedger[5] = "0";
      accountEntryLedger[6] = "";
      //创建会计分录明细账数组，红字分录，借与货的金额均为负数
      String[][] accountEntrySubLedger = new String[goodsSoldReturn.length + 1][3];
      //写入借方分录
      accountEntrySubLedger[0][0] = "0";
      accountEntrySubLedger[0][1] = "流动资产@@现金";
      //由于销售退货单的数量为负数，所以saleAmount为负数
      accountEntrySubLedger[0][2] = String.valueOf(saleAmount);
      //写入贷方分录
      for(int i = 1; i < accountEntrySubLedger.length; i++){
        accountEntrySubLedger[i][0] = "1";
        accountEntrySubLedger[i][1] = "销售收入@@" + goodsSoldReturn[i - 1][0];
        accountEntrySubLedger[i][2] = String.valueOf(goodsSoldReturn[i - 1][1]);
      }
      //向数据表写入销售收入会计分录,应用本方法事务
      subResult = this.createAccountEntry(ledgerDate, accountEntryLedger,
                                              accountEntrySubLedger, true, conn);
      //如果不能正确添加会计分录，撤消数据库的事条
      if(subResult == 0){
        conn.rollback();
        return 0;
      }
      //创建会计分录数组,写入销售成本会计分录
      accountEntryLedger = new String[7];
      //sa表示与销售账套数据表相联系
      accountEntryLedger[0] = "sa" + saleId;
      accountEntryLedger[1] = userName;
      accountEntryLedger[2] = "";
      accountEntryLedger[3] = dataMethod.getCurrentDate().toString();
      accountEntryLedger[4] = null;
      accountEntryLedger[5] = "0";
      accountEntryLedger[6] = "";
      //取得成本数组
      String[][] goodsCost = this.getGoodsCost(goodsSoldReturn, stockSubLedger);
      //创建会计分录明细账数组，红字分录，借与货的金额均为负数
      accountEntrySubLedger = new String[goodsCost.length * 2][3];
      //写入借方分录
      for(int i = 0; i < goodsCost.length; i++){
        accountEntrySubLedger[i][0] = "0";
        accountEntrySubLedger[i][1] = "销售成本@@" + goodsCost[i][0];
        accountEntrySubLedger[i][2] = String.valueOf(goodsCost[i][1]);
      }
      //写入贷方分录
      int j = 0;
      for(int i = goodsCost.length; i < accountEntrySubLedger.length; i++){
        accountEntrySubLedger[i][0] = "1";
        accountEntrySubLedger[i][1] = "流动资产@@存货@@" + goodsCost[j][0];
        accountEntrySubLedger[i][2] = String.valueOf(goodsCost[j][1]);
        j++;
      }
      //向数据表写入销售成本会计分录,应用本方法事务
      subResult = this.createAccountEntry(ledgerDate, accountEntryLedger,
                                              accountEntrySubLedger, true, conn);
      //如果不能正确添加会计分录，撤消数据库的事条
      if(subResult == 0){
        conn.rollback();
        return 0;
      }
      //创建现金账套数组
      String[] cashLedger = new String[5];
      //sa表示与销售账套数据表相联系
      cashLedger[0] = "sa" + saleId;
      cashLedger[1] = "1";
      cashLedger[2] = userName;
      cashLedger[3] = String.valueOf(-saleAmount);
      cashLedger[4] = dataMethod.getCurrentDate().toString();
      //向现金账套数据表写入记录，应用本方法的事务
      subResult = this.createCashLedger(ledgerDate, cashLedger, true, conn);
      //如果不能正确添加现金账套记录，撤消数据库的事条
      if (subResult == 0) {
        conn.rollback();
        return 0;
      }
      //由于销售退货单是独立事务，所以最后才创建销售退货单
      subResult = this.createStockLedgerAndSub(ledgerDate, stockLedger, stockSubLedger);
      //如果销售退货单创建失败，退出事务处理
      if(subResult == 0){
        conn.rollback();
        return 0;
      }
      //提交事条
      conn.commit();
      result = 1;
    }catch(Exception ex){
      try{
        //撤消事务
        conn.rollback();
      }catch(Exception ex1){
        ex1.printStackTrace();
      }
      ex.printStackTrace();
    }
    //清空数据库联接
    cleanup(conn);
    return result;
  }
  //信用销售员进行信用销售退货单电子签名的方法
  public int creditUserSignSaleReturn(String ledgerDate, String saleId,
                                      String userName, String remark,
                                      String warehouse, String customerName,
                                      String[][] stockSubLedger, boolean isPay) {
    int result = 0;
    //取得帐套集合
    String[] ledgerDates = this.getLedgerNames();
    //只能对当前账套进行操作
    if(!ledgerDates[ledgerDates.length - 1].equals(ledgerDate)){
      return result;
    }
    //取得数据库联接
    Connection conn = getConnection();
    //创建更新语句
    String updateSaleLedgerSql = "update saleLedger" + ledgerDate + " set "
        + " onProcess = 2, remark = ?, deliveryDate = ? where saleId ='" + saleId + "' and onProcess = 0";
    //创建选择语句，取得传入销售退货单的总金额和总数量
    String goodsSoldReturnsql = "select goodsBarcode, sum(actualPrice*quantity) as amount , "
        + " sum(quantity) as quantity from saleSubLedger" + ledgerDate
        + " where saleId ='" + saleId +"'"
        + " group by goodsBarcode";
    try{
      //开始事务
      conn.setAutoCommit(false);
      //创建不带参数的SQL语句执行类
      Statement stmt = conn.createStatement();
      double saleAmount = 0;
      String[][] goodsSoldReturn = new String[0][3];
      int count = 0;
      //取得传入销售退货单的商品条形码、金额和数量
      ResultSet rs = stmt.executeQuery(goodsSoldReturnsql);
      //取得记录数
      while(rs.next()){
        count++;
      }
      goodsSoldReturn = new String[count][3];
      //重新取得记录集
      rs = stmt.executeQuery(goodsSoldReturnsql);
      for(int i = 0; i < count; i++){
        if(rs.next()){
          goodsSoldReturn[i][0] = rs.getString("goodsBarcode");
          //取得销售总金额
          double amount = dataMethod.round(rs.getDouble("amount"));
          saleAmount += amount;
          goodsSoldReturn[i][1] = String.valueOf(amount);
          goodsSoldReturn[i][2] = rs.getString("quantity");
        }
      }
      //创建带参数的SQL语句执行类
      PreparedStatement pstmt = conn.prepareStatement(updateSaleLedgerSql);
      //设置销售账套数据表的SQL语句参数
      pstmt.setString(1, remark);
      pstmt.setTimestamp(2, dataMethod.getCurrentDate());
      //执行销售账套数据表的更新操作，将传入销售退货单设为完成
      int subResult = pstmt.executeUpdate();
      //如果所有销售退货单已完成，退出事务处理
      if(subResult == 0){
        conn.rollback();
        return 0;
      }
      //创建销售退货单数组
      String[] stockLedger = new String[13];
      stockLedger[1] = "5";                    //5表示销售退货单
      //sa表示与销售账套数据表相联系
      stockLedger[2] = "sa" + saleId;          //关联标识
      stockLedger[3] = userName;               //销售员
      stockLedger[4] = "";
      stockLedger[5] = "";
      stockLedger[6] = "";
      stockLedger[7] = "";
      stockLedger[8] = warehouse;              //仓库名
      stockLedger[9] = dataMethod.getCurrentDate().toString();   //填写日期
      stockLedger[10] = dataMethod.getCurrentDate().toString();  //系统日期
      stockLedger[11] = "2";                   //销售退货单一经创建便处于完成状态
      stockLedger[12] = "";
      //创建会计分录数组,写入销售收入会计分录
      String[] accountEntryLedger = new String[7];
      //sa表示与销售账套数据表相联系
      accountEntryLedger[0] = "sa" + saleId;
      accountEntryLedger[1] = userName;
      accountEntryLedger[2] = "";
      accountEntryLedger[3] = dataMethod.getCurrentDate().toString();
      accountEntryLedger[4] = null;
      accountEntryLedger[5] = "0";
      accountEntryLedger[6] = "";
      //创建会计分录明细账数组，红字分录，借与货的金额均为负数
      String[][] accountEntrySubLedger = new String[goodsSoldReturn.length + 1][3];
      //写入借方分录
      accountEntrySubLedger[0][0] = "0";
      if(isPay){
        //已付款
        accountEntrySubLedger[0][1] = "短期负债@@应付账款@@" + customerName;
      }else{
        //未付款
        accountEntrySubLedger[0][1] = "流动资产@@应收账款@@" + customerName;
      }
      //由于销售退货单的数量为负数，所以saleAmount为负数
      accountEntrySubLedger[0][2] = String.valueOf(saleAmount);
      //写入贷方分录
      for(int i = 1; i < accountEntrySubLedger.length; i++){
        accountEntrySubLedger[i][0] = "1";
        accountEntrySubLedger[i][1] = "销售收入@@" + goodsSoldReturn[i - 1][0];
        accountEntrySubLedger[i][2] = String.valueOf(goodsSoldReturn[i - 1][1]);
      }
      //向数据表写入销售收入会计分录,应用本方法事务
      subResult = this.createAccountEntry(ledgerDate, accountEntryLedger,
                                              accountEntrySubLedger, true, conn);
      //如果不能正确添加会计分录，撤消数据库的事条
      if(subResult == 0){
        conn.rollback();
        return 0;
      }
      //创建会计分录数组,写入销售成本会计分录
      accountEntryLedger = new String[7];
      //sa表示与销售账套数据表相联系
      accountEntryLedger[0] = "sa" + saleId;
      accountEntryLedger[1] = userName;
      accountEntryLedger[2] = "";
      accountEntryLedger[3] = dataMethod.getCurrentDate().toString();
      accountEntryLedger[4] = null;
      accountEntryLedger[5] = "0";
      accountEntryLedger[6] = "";
      //取得成本数组
      String[][] goodsCost = this.getGoodsCost(goodsSoldReturn, stockSubLedger);
      //创建会计分录明细账数组，红字分录，借与货的金额均为负数
      accountEntrySubLedger = new String[goodsCost.length * 2][3];
      //写入借方分录
      for(int i = 0; i < goodsCost.length; i++){
        accountEntrySubLedger[i][0] = "0";
        accountEntrySubLedger[i][1] = "销售成本@@" + goodsCost[i][0];
        accountEntrySubLedger[i][2] = String.valueOf(goodsCost[i][1]);
      }
      //写入贷方分录
      int j = 0;
      for(int i = goodsCost.length; i < accountEntrySubLedger.length; i++){
        accountEntrySubLedger[i][0] = "1";
        accountEntrySubLedger[i][1] = "流动资产@@存货@@" + goodsCost[j][0];
        accountEntrySubLedger[i][2] = String.valueOf(goodsCost[j][1]);
        j++;
      }
      //向数据表写入销售成本会计分录,应用本方法事务
      subResult = this.createAccountEntry(ledgerDate, accountEntryLedger,
                                              accountEntrySubLedger, true, conn);
      //如果不能正确添加会计分录，撤消数据库的事条
      if(subResult == 0){
        conn.rollback();
        return 0;
      }
      if(isPay){
        //创建往来账套数组
        String[] currentAccountLedger = new String[10];
        //sa表示与销售账套数据表相联系
        currentAccountLedger[0] = "sa" + saleId;
        currentAccountLedger[1] = "2";    //2表示销售退货的应付账款
        currentAccountLedger[2] = String.valueOf(-saleAmount);
        currentAccountLedger[3] = customerName;
        currentAccountLedger[4] = userName;
        currentAccountLedger[5] = "";
        currentAccountLedger[6] = dataMethod.getCurrentDate().toString(); ;
        currentAccountLedger[7] = null;
        currentAccountLedger[8] = "0";
        currentAccountLedger[9] = "";
        //向往来账套数据表写入记录，应用本方法的事务
        subResult = this.createCurrentAccountLedger(ledgerDate,
            currentAccountLedger,
            true, conn);
        //如果不能正确添加往来账套记录，撤消数据库的事条
        if (subResult == 0) {
          conn.rollback();
          return 0;
        }
      }
      //由于销售退货单是独立事务，所以最后才创建销售退货单
      subResult = this.createStockLedgerAndSub(ledgerDate, stockLedger, stockSubLedger);
      //如果销售退货单创建失败，退出事务处理
      if(subResult == 0){
        conn.rollback();
        return 0;
      }
      //提交事条
      conn.commit();
      result = 1;
    }catch(Exception ex){
      try{
        //撤消事务
        conn.rollback();
      }catch(Exception ex1){
        ex1.printStackTrace();
      }
      ex.printStackTrace();
    }
    //清空数据库联接
    cleanup(conn);
    return result;
  }
}
﻿package com.shinear.sm.cactustest;

import org.apache.cactus.*;
import com.shinear.sm.stockmanagementpro.*;
import javax.naming.*;
import javax.rmi.PortableRemoteObject;
import java.rmi.RemoteException;
import com.shinear.sm.user.User;

public class TestStockManagementDataCactus1 extends ServletTestCase {
  private static final String ERROR_NULL_REMOTE = "对象未定义.";
  private static final int MAX_OUTPUT_LINE_LENGTH = 100;
  private boolean logging = false;
  private StockManagementDataHome stockManagementDataHome = null;
  private StockManagementData stockManagementData = null;

  public TestStockManagementDataCactus1(String name) {
    super(name);
  }

  //初始化EJB的方法
  public void initialize() throws Exception {
    Context context = new InitialContext();
    Object ref = context.lookup("StockManagementData");
    stockManagementDataHome = (StockManagementDataHome) PortableRemoteObject.
        narrow(ref, StockManagementDataHome.class);
    create();
  }
  public void setUp() throws Exception {
    super.setUp();
    initialize();
  }
  public void tearDown() throws Exception {
    stockManagementDataHome = null;
    stockManagementData = null;
    super.tearDown();
  }
  //创建EJB的远程接口
  public StockManagementData create() throws Exception {
    stockManagementData = stockManagementDataHome.create();
    return stockManagementData;
  }
  //测试检查用户的方法
  public void testCheckUser() throws RemoteException {
    //测试正确的用户名
    String userName = "jack";
    String userPassword = "jack";
    //检查用户的方法
    int[] functions = stockManagementData.checkUser(userName, userPassword);
    this.assertEquals("return value", 0, functions[0]);
    //测试错误的用户名
    userName = "jack1";
    userPassword = "jack";
    //检查用户的方法
    functions = stockManagementData.checkUser(userName, userPassword);
    this.assertEquals("return value", -1, functions[0]);
  }
  //测试创建用户的方法
  public void testCreateUser() throws RemoteException {
    String userName = "test";
    String userPassword = "test";
    int baseInforFunction = 0;
    int stockFunction = 0;
    int stockManageFunction = 0;
    int saleFunction = 0;
    User user = new User(userName, userPassword, baseInforFunction,
                         stockFunction, stockManageFunction, saleFunction);
    int result = stockManagementData.createUser(user);
    this.assertEquals("return value", 1, result);
  }
  //测试更新用户的方法
  public void testUpdateUser() throws RemoteException {
    String userName = "test";
    String userPassword = "test1";
    int baseInforFunction = 1;
    int stockFunction = 1;
    int stockManageFunction = 1;
    int saleFunction = 1;
    User user = new User(userName, userPassword, baseInforFunction,
                         stockFunction, stockManageFunction, saleFunction);
    int result = stockManagementData.updateUser(user);
    this.assertEquals("return value", 1, result);
  }
  //测试删除用户的方法
  public void testDeleteUser() throws RemoteException {
    String userName = "test";
    String userPassword = "test";
    int baseInforFunction = 0;
    int stockFunction = 0;
    int stockManageFunction = 0;
    int saleFunction = 0;
    User user = new User(userName, userPassword, baseInforFunction,
                         stockFunction, stockManageFunction, saleFunction);
    int result = stockManagementData.deleteUser(user);
    this.assertEquals("return value", 1, result);
  }
  //测试根据用户名字取得用户记录的方法
  public void testGetUserByUserName() throws RemoteException {
    String userName = "jack";
    String[][] result = stockManagementData.getUserByUserName(userName);
    this.assertEquals("return value", "jack", result[0][1]);
  }
  //测试日志数据表记录的创建方法
  public void testCreateUserLog() throws Exception{
    String programName = "登陆窗口";
    String operationContent = "登陆";
    String userName = "jack";
    //stockManagementData.createUserLog(programName, operationContent, userName);
  }
  //测试日志数据表记录的删除方法
  public void testDeleteUserLog() throws Exception{
    Integer id = new Integer(1);
    //stockManagementData.deleteUserLog(id);
  }
  //测试返回数据库的所有数据表名字方法
  public void testGetTableNames() throws Exception{
    String[] tableNames = stockManagementData.getTableNames();
    this.assertEquals("returnValue", "accountEntryLedger", tableNames[0]);
    //this.assertEquals("returnValue", "accountName", tableNames[1]);
  }
  //测试取得数据表数据的方法
  public void testGetDataByTableName() throws Exception{
    String[][] data = stockManagementData.getDataByTableName("userTable");
    this.assertEquals("returnValue", "ame", data[0][0]);
  }
  //测试写入数据表数据的方法
  public void testSetDataByTableName() throws Exception{
    String[][] data = new String[][] {
        {"20040428", "0", "供应商", "请购员", "订购员", "验收员", "现金管理员", "收货地址",
        "仓库", "2004-04-26", "2004-4-26 18:16:10", "1", "备注"},
        {"20040427", "0", "aa1", "aa2", "aa3", "aa4", "aa5", "aa6", "aa7",
        "2004-04-26", "2004-4-26 18:16:10", "0", "ss"}
    };
    //向数据表stockLedger写入记录
    int result = stockManagementData.setDataByTableName("stockLedger", data);
    this.assertEquals("returnValue", 1, result);
    data = new String[][] {
        {"1", "20040427", "55566", "15.23", "58", "2004-04-26"},
        {"2", "20040428", "55566", "15.23", "58", "2004-04-26 13:45:12"}
    };
    //向数据表stockSubLedger写入记录
    result = stockManagementData.setDataByTableName("stockSubLedger", data);
    this.assertEquals("returnValue", 1, result);
  }
  //测试取得帐套名字的方法
  public void testGetLedgerNames() throws Exception{
    String[] ledgerNames = stockManagementData.getLedgerNames();
    this.assertEquals("return value", 1, ledgerNames.length);
  }
  //测试创建帐套的方法
  public void testCreateLedger()  throws Exception{
    String ledgerDate = "200405";
    int result = stockManagementData.createLedger(ledgerDate);
    this.assertEquals("return value", 1, result);
    result = stockManagementData.createLedger(ledgerDate);
    this.assertEquals("return value", 0, result);
  }
  //测试删除帐套的方法
  public void testDeleteLedger()  throws Exception{
    String ledgerDate = "200403";
    int result = stockManagementData.deleteLedger(ledgerDate);
    this.assertEquals("return value", 0, result);
  }
  //测试商品类别的创建方法
  public void testCreateGoodsCategory() throws Exception{
    /*int parentId = 0;
    String categoryName = "商品类别1";
    String categoryDescription = "商品类别1的描述";
    int result = stockManagementData.createGoodsCategory(parentId,
        categoryName, categoryDescription);
    this.assertEquals("return value", 1, result);
    parentId = 0;
    categoryName = "商品类别2";
    categoryDescription = "商品类别2的描述";
    result = stockManagementData.createGoodsCategory(parentId,
        categoryName, categoryDescription);
    this.assertEquals("return value", 1, result);*/
  }
  //测试商品类别的更新方法
  public void testUpdateGoodsCategory() throws Exception{
    int categoryId = 1;
    int parentId = 0;
    String categoryName = "商品类别1(更新)";
    String categoryDescription = "商品类别1的描述";
    int result = stockManagementData.updateGoodsCategory(categoryId, parentId,
        categoryName, categoryDescription);
    this.assertEquals("return value", 1, result);
  }
  //测试商品类别的findAll方法
  public void testFindAll() throws Exception{
    String[][] detail = stockManagementData.getAllGoodsCategory();
    this.assertEquals("", 2, detail.length);
  }
  //测试商品类别的删除方法
  public void testDeleteGoodsCategory() throws Exception{
    /*int categoryId = 1;
    int result = stockManagementData.deleteGoodsCategory(categoryId);
    this.assertEquals("return value", 1, result);
    categoryId = 2;
    result = stockManagementData.deleteGoodsCategory(categoryId);
    this.assertEquals("return value", 1, result);*/
  }
  //测试商品创建方法
  public void testGoodsCreate() throws Exception {
    /*String goodsBarCode = "10000001";
    int categoryId = 1;
    String goodsName  = "类别1的商品1";
    String goodsNickName = "别名1";
    String goodsAssistantName = "助记码1";
    String goodsPYName = "LBDSP1";
    String unit = "件";
    String specification = "每箱10件";
    String producer = "生产厂商1";
    int upperLimit = 0;
    int lowerLimit = 0;
    double salePrice = 15;
    double discount = 1;
    //创建商品
    int result = stockManagementData.createGoods(goodsBarCode, categoryId,
                     goodsName, goodsNickName, goodsAssistantName, goodsPYName, unit,
                     specification, producer, upperLimit, lowerLimit, salePrice, discount);
    this.assertEquals("return value", 1, result);
    goodsBarCode = "10000002";
    categoryId = 1;
    goodsName  = "类别1的商品2";
    goodsNickName = "别名2";
    goodsAssistantName = "助记码2";
    goodsPYName = "LBDSP2";
    unit = "件";
    specification = "每箱10件";
    producer = "生产厂商2";
    upperLimit = 0;
    lowerLimit = 0;
    salePrice = 20.12;
    discount = 0.56;
    //创建商品
    result = stockManagementData.createGoods(goodsBarCode, categoryId, goodsName,
                  goodsNickName, goodsAssistantName, goodsPYName, unit,
                  specification, producer, upperLimit, lowerLimit, salePrice, discount);
    this.assertEquals("return value", 1, result);*/
  }
  //测试商品更新方法
  public void testGoodsUpdate() throws Exception {
    String goodsBarCode = "10000001";
    int categoryId = 1;
    String goodsName  = "类别1的商品1（更新）";
    String goodsNickName = "别名1";
    String goodsAssistantName = "助记码1";
    String goodsPYName = "LBDSP1";
    String unit = "件";
    String specification = "每箱10件";
    String producer = "生产厂商1";
    int upperLimit = 0;
    int lowerLimit = 0;
    double salePrice = 15;
    double discount = 1;
    int result = stockManagementData.updateGoods(goodsBarCode, categoryId, goodsName,
                  goodsNickName, goodsAssistantName, goodsPYName, unit,
                  specification, producer, upperLimit, lowerLimit, salePrice, discount);
    this.assertEquals("return value", 1, result);
  }
  //测试根据类别取得商品的方法
  public void testFindByGoodsCategory() throws Exception {
    int goodsCategory = 1;
    String[][] detail = stockManagementData.getGoodsByGoodsCategory(goodsCategory);
    this.assertEquals("", 2, detail.length);
  }
  //测试根据条形码取得商品的方法
  public void testFindByGoodsBarCode() throws Exception {
    String goodsBarCode = "1";
    String[][] detail = stockManagementData.getGoodsByGoodsBarCode(goodsBarCode);
    this.assertEquals("", 2, detail.length);
  }
  //测试根据商品名字取得商品的方法
  public void testFindByGoodsName() throws Exception {
    String goodsName = "商品";
    String[][] detail = stockManagementData.getGoodsByGoodsName(goodsName);
    this.assertEquals("", 2, detail.length);
  }
  //测试根据生产厂商取得商品的方法
  public void testFindByProducer() throws Exception {
    String goodsName = "生产厂商";
    String[][] detail = stockManagementData.getGoodsByProducer(goodsName);
    this.assertEquals("", 2, detail.length);
  }
  //测试设置商品折扣的方法
  public void testSetGoodsDiscount() throws Exception {
    String goodsBarCode = "10000001";
    double discount = 0.85;
    int result = stockManagementData.setGoodsDiscount(goodsBarCode, discount);
    this.assertEquals("return value", 1, result);
  }
  //测试取得折扣商品的方法
  public void testFindDiscountGoods() throws Exception {
    String[][] detail = stockManagementData.getDiscountGoods();
    this.assertEquals("", 2, detail.length);
  }

  //测试商品删除方法
  public void testGoodsDelete() throws Exception {
    /*String goodsBarCode = "10000001";
    int result = stockManagementData.deleteGoods(goodsBarCode);
    this.assertEquals("return value", 1, result);
    goodsBarCode = "10000002";
    result = stockManagementData.deleteGoods(goodsBarCode);
    this.assertEquals("return value", 1, result);*/
  }
  //测试供应商创建方法
  public void testSupplierCreate() throws Exception{
    //创建供应商数组
    String[] supplier = new String[]{"测试供应商1", "南部", "拼音码1", "简称1", "021-556892",
        "张凡", "1350058956", "021-896523", "021-963258", "地址1", "511896",
        "中行", "银行帐号", "jack@hotmail.com", "www.jack.com", "备注1"};
    //创建供应商
    int result = stockManagementData.createSupplier(supplier);
    this.assertEquals("", 1, result);
    supplier = new String[]{"测试供应商2", "北部", "拼音码2", "简称2", "021-556892",
        "张凡", "1350058956", "021-896523", "021-963258", "地址2", "511896",
        "中行", "银行帐号", "jack@hotmail.com", "www.jack.com", "备注2"};
    //创建供应商
    result = stockManagementData.createSupplier(supplier);
    this.assertEquals("", 1, result);
    supplier = new String[]{"测试供应商3", "南部", "拼音码3", "简称3", "021-556892",
        "张凡", "1350058956", "021-896523", "021-963258", "地址3", "511896",
        "中行", "银行帐号", "jack@hotmail.com", "www.jack.com", "备注3"};
    //创建供应商
    result = stockManagementData.createSupplier(supplier);
    this.assertEquals("", 1, result);
  }
  //测试供应商更新方法
  public void testSupplierUpdate() throws Exception{
    String[] supplier = new String[]{"测试供应商1", "北部", "拼音码1", "简称1", "021-556892",
        "张凡", "1350058956", "021-896523", "021-963258", "地址1", "511896",
        "中行", "银行帐号", "jack@hotmail.com", "www.jack.com", "备注1"};
    //更新供应商的值
    int result = stockManagementData.updateSupplier(supplier);
    this.assertEquals("", 1, result);
  }
  //测试根据供应商名字取得记录的方法
  public void testFindBySupplierName() throws Exception {
    String[][] detail = stockManagementData.getSuppliersBySupplierName("%供应商%");
    this.assertEquals("", 3, detail.length);
  }
  //测试根据地区取得记录的方法
  public void testFindBySupplierZone() throws Exception {
    String[][] detail = stockManagementData.getSuppliersBySupplierZone("%北部%");
    this.assertEquals("", 2, detail.length);
  }
  //测试供应商删除方法
  public void testSupplierDelete() throws Exception{
    String[] suppliers = new String[]{"测试供应商1", "测试供应商2", "测试供应商3"};
    //删除供应商
    int result = stockManagementData.deleteSupplier(suppliers[0]);
    this.assertEquals("", 1, result);
    //删除供应商
    result = stockManagementData.deleteSupplier(suppliers[1]);
    this.assertEquals("", 1, result);
    //删除供应商
    result = stockManagementData.deleteSupplier(suppliers[2]);
    this.assertEquals("", 1, result);
  }
  //测试客户创建方法
  public void testCustomerCreate() throws Exception {
    //创建客户数组
    String[] customer = new String[] {
        "测试客户1", "南部", "拼音码1", "简称1", "021-556892",
        "张凡", "1350058956", "021-896523", "021-963258", "地址1", "511896",
        "中行", "银行帐号", "jack@hotmail.com", "www.jack.com", "10000", "备注1"};
    //创建客户
    int result = stockManagementData.createCustomer(customer);
    this.assertEquals("", 1, result);
    customer = new String[] {
        "测试客户2", "北部", "拼音码2", "简称2", "021-556892",
        "张凡", "1350058956", "021-896523", "021-963258", "地址2", "511896",
        "中行", "银行帐号", "jack@hotmail.com", "www.jack.com", "10000", "备注2"};
    //创建客户
    result = stockManagementData.createCustomer(customer);
    this.assertEquals("", 1, result);
    customer = new String[] {
        "测试客户3", "南部", "拼音码3", "简称3", "021-556892",
        "张凡", "1350058956", "021-896523", "021-963258", "地址3", "511896",
        "中行", "银行帐号", "jack@hotmail.com", "www.jack.com", "10000", "备注3"};
    //创建客户
    result = stockManagementData.createCustomer(customer);
    this.assertEquals("", 1, result);
  }
  //测试客户更新方法
  public void testCustomerUpdate() throws Exception {
    String[] customer = new String[] {
        "测试客户1", "北部", "拼音码1", "简称1", "021-556892",
        "张凡", "1350058956", "021-896523", "021-963258", "地址1", "511896",
        "中行", "银行帐号", "jack@hotmail.com", "www.jack.com", "10000", "备注1"};
    //更新客户的值
    int result = stockManagementData.updateCustomer(customer);
    this.assertEquals("", 1, result);
  }
  //测试根据客户名字取得记录的方法
  public void testFindByCustomerName() throws Exception {
    String[][] detail = stockManagementData.getCustomersByCustomerName("%客户%");
    this.assertEquals("", 6, detail.length);
  }
  //测试根据地区取得记录的方法
  public void testFindByCustomerZone() throws Exception {
    String[][] detail = stockManagementData.getCustomersByCustomerZone("%北部%");
    this.assertEquals("", 4, detail.length);
  }
  //测试设置客户信用的方法
  public void testSetCustomerCreditLimit() throws Exception{
    String customerName = "测试客户1";
    double creditlimit = 0;
    int result = stockManagementData.setCreditCustomer(customerName, creditlimit);
    this.assertEquals("", 1, result);
  }
  //测试取得信用客户记录的方法
  public void testFindCreditCustomer() throws Exception {
    String[][] detail = stockManagementData.getCreditCustomer();
    this.assertEquals("", 5, detail.length);
  }
  //测试客户删除方法
  public void testCustomerDelete() throws Exception {
    String[] customers = new String[] {
        "测试客户1", "测试客户2", "测试客户3"};
    //删除客户
    int result = stockManagementData.deleteCustomer(customers[0]);
    this.assertEquals("", 1, result);
    //删除客户
    result = stockManagementData.deleteCustomer(customers[1]);
    this.assertEquals("", 1, result);
    //删除客户
    result = stockManagementData.deleteCustomer(customers[2]);
    this.assertEquals("", 1, result);
  }
  //测试创建仓库的方法
  public void testWarehouseCreate() throws Exception{
    String[] warehouse = new String[]{"测试仓库1", "拼单码1", "第1厂区", "描述1"};
    //创建仓库
    int result = stockManagementData.createWarehouse(warehouse);
    this.assertEquals("", 1, result);
    warehouse = new String[]{"测试仓库2", "拼单码2", "第2厂区", "描述2"};
    //创建仓库
    result = stockManagementData.createWarehouse(warehouse);
    this.assertEquals("", 1, result);
    warehouse = new String[]{"测试仓库3", "拼单码3", "第3厂区", "描述3"};
    //创建仓库
    result = stockManagementData.createWarehouse(warehouse);
    this.assertEquals("", 1, result);
  }
  //测试修改仓库的方法
  public void testWarehouseUpdate() throws Exception{
    String[] warehouseArray = new String[]{"测试仓库1", "拼单码1(u)", "第1厂区(u)", "描述1(u)"};
    //更新仓库
    int result = stockManagementData.updateWarehouse(warehouseArray);
    this.assertEquals("", 1, result);
  }
  //测试取得全部记录的方法
  public void testWarehouseFindAll() throws Exception {
    String[][] returnValue = stockManagementData.getAllWarehouse();
    this.assertEquals("", 3, returnValue.length);
  }
  //测试删除仓库的方法
  public void testWarehouseDelete() throws Exception{
    String[] warehouseArray = new String[]{"测试仓库1", "测试仓库2", "测试仓库3"};
    //删除仓库
    int result = stockManagementData.deleteWarehouse(warehouseArray[0]);
    this.assertEquals("", 1, result);
    //删除仓库
    result = stockManagementData.deleteWarehouse(warehouseArray[1]);
    this.assertEquals("", 1, result);
    //删除仓库
    result = stockManagementData.deleteWarehouse(warehouseArray[2]);
    this.assertEquals("", 1, result);
  }
  //测试创建会计科目的方法
  /*public void testAccountNameCreate() throws Exception{
    //创建会计科目
    int result = stockManagementData.createAccountName(0, "流动资产");
    this.assertEquals("", 1, result);
    //创建会计科目
    result = stockManagementData.createAccountName(0, "固定资产");
    this.assertEquals("", 1, result);
    //创建会计科目
    result = stockManagementData.createAccountName(1, "现金");
    this.assertEquals("", 1, result);
    //创建会计科目
    result = stockManagementData.createAccountName(1, "银行存款");
    this.assertEquals("", 1, result);
  }
  //测试修改会计科目的方法
  public void testAccountNameUpdate() throws Exception{
    int result = stockManagementData.updateAccountName(1, 0, "流动资产(更新)");
    this.assertEquals("", 1, result);
  }
  //测试取得全部记录的方法
  public void testAccountNameFindAll() throws Exception {
    String[][] returnValue = stockManagementData.getAllAccountName();
    this.assertEquals("", 4, returnValue.length);
  }
  //测试根据父标识取得记录的方法
  public void testAccountNameFindByParentId() throws Exception {
    String[][] returnValue = stockManagementData.getAccountNameByParentid(1);
    this.assertEquals("", 2, returnValue.length);
  }
  //测试删除会计科目的方法
  public void testAccountNameDelete() throws Exception{
    int result = stockManagementData.deleteAccountName(1);
    //由于流动资产科目有子科目，所以不能进行删除操作
    this.assertEquals("", 0, result);
    //删除会计科目
    result = stockManagementData.deleteAccountName(2);
    this.assertEquals("", 1, result);
    result = stockManagementData.deleteAccountName(3);
    this.assertEquals("", 1, result);
    result = stockManagementData.deleteAccountName(4);
    this.assertEquals("", 1, result);
    result = stockManagementData.deleteAccountName(1);
    this.assertEquals("", 1, result);
  }*/
  //测试取得科目余额的方法
  public void testGetAccountBalance() throws Exception {
    String ledgerDate = "200404";
    int onProcess = 0;
    String[][] returnValue = stockManagementData.getAccountBalance(ledgerDate, onProcess);
    this.assertEquals("", 2, returnValue.length);
  }
  //测试根据操作程序名字取得日志记录的方法
  public void testUserLogFindByProgramName() throws Exception{
    String[][] detail = stockManagementData.getUserLogByProgramName("%登陆窗口%");
    this.assertEquals("", 105, detail.length);
  }
  //测试根据操作内容取得日志记录的方法
  public void testUserLogFindByOperationContent() throws Exception{
    String[][] detail = stockManagementData.getUserLogByOperationContent("%删除%");
    this.assertEquals("", 2, detail.length);
  }
  //测试根据用户名取得日志记录的方法
  public void testUserLogFindByUserName() throws Exception{
    String[][] detail = stockManagementData.getUserLogByUserName("%ame%");
    this.assertEquals("", 23, detail.length);
  }
  //测试根据日期范围取得日志记录的方法
  public void testUserLogFindByOperationDate() throws Exception{
    //创建日期类
    java.util.Calendar date = java.util.Calendar.getInstance();
    date.set(2004, 4, 4, 0, 0, 0);
    java.sql.Timestamp startDate = new java.sql.Timestamp(date.getTime().getTime());
    date.set(2004, 4, 8, 23, 59, 59);
    java.sql.Timestamp endDate = new java.sql.Timestamp(date.getTime().getTime());
    String[][] detail = stockManagementData.getUserLogByOperationDate(startDate, endDate);
    this.assertEquals("", 69, detail.length);
  }
  //测试根据单据编号或者请购员名字或者仓库名字取得库存账套数据表记录的方法
  public void testGetStockLedgerByStringField() throws Exception{
    //根据单据编号取得记录
    String[][] detail = stockManagementData.getStockLedgerByStringField(
        "200404", "orderId", "1", 0);
    this.assertEquals("", 1, detail.length);
    //根据请购员名字取得记录
    detail = stockManagementData.getStockLedgerByStringField("200404",
        "submitUser", "请", 0);
    this.assertEquals("", 5, detail.length);
    //根据仓库名字取得记录
    detail = stockManagementData.getStockLedgerByStringField("200404", "warehouse", "仓", 0);
    this.assertEquals("", 3, detail.length);
  }
  //测试根据订单日期取得库存账套数据表记录的方法
  public void testGetStockLedgerByOrderDate() throws Exception{
    //创建日期类
    java.util.Calendar date = java.util.Calendar.getInstance();
    date.set(2004, 3, 1, 0, 0, 0);
    date.set(java.util.Calendar.MILLISECOND, 0);
    java.sql.Timestamp startDate = new java.sql.Timestamp(date.getTime().getTime());
    date.set(2004, 3, 20, 23, 59, 59);
    date.set(java.util.Calendar.MILLISECOND, 998);
    java.sql.Timestamp endDate = new java.sql.Timestamp(date.getTime().getTime());
    String[][] detail = stockManagementData.getStockLedgerByOrderDate("200404", startDate, endDate, 0);
    this.assertEquals("", 5, detail.length);
  }
  //测试根据单据编号取得库存账套明细数据表的记录
  public void testGetStockSubLedgerByOrderId() throws Exception{
    //根据单据编号取得记录
    String[][] detail = stockManagementData.getStockSubLedgerByOrderId(
        "200404", "20040400001");
    this.assertEquals("", 2, detail.length);
  }
  //测试创建库存账套数据表和库存账套明细数据表记录的方法
  public void testCreateStockLedgerAndSub() throws Exception{
    /*String ledgerDate = "200405";
    String[] stockLedger = {
        "", "0", "供应商1", "jack", "", "", "", "", "仓库1", "2004-5-5", "2004-5-15",
        "0", ""};
    String[][] stockSubLedger = {{"", "", "10000001", "10", "50", "2004-12-5"},
        {"", "", "10000002", "17", "20", "2004-11-3"}};
    int result = stockManagementData.createStockLedgerAndSub(ledgerDate, stockLedger, stockSubLedger);
    this.assertEquals("", 1, result);*/
  }
  //测试更新库存账套数据表和库存账套明细数据表记录的方法
  public void testUpdateStockLedgerAndSub() throws Exception{
   /* String ledgerDate = "200405";
    String[] stockLedger = {
        "20040500002", "0", "供应商1(u)", "jack(u)", "jack", "(u)", "(u)", "(u)",
        "仓库1(u)", "2004-5-6", "2004-5-16", "0", "(u)"};
    String[][] stockSubLedger = {{"21", "20040500002", "10000001", "8.6", "30", "2004-12-8"},
        {"22", "20040500002", "10000002", "16.5", "12", "2004-12-9"}};
    int result = stockManagementData.updateStockLedgerAndSub(ledgerDate, stockLedger, stockSubLedger);
    this.assertEquals("", 1, result);*/
  }
  //测试撤消库存账套数据表记录的方法
  public void testCancelStockLedgerAndSub() throws Exception{
    String ledgerDate = "200405";
    String orderId = "20040500002";
    String remark = "仓库1不需要该存货.";
    int result = stockManagementData.cancelStockLedgerAndSub(ledgerDate, orderId, remark);
    this.assertEquals("", 1, result);
  }
  //测试恢复库存账套数据表完成状态的方法
  public void testRestoreStockLedgerAndSub() throws Exception{
    String ledgerDate = "200405";
    String orderId = "20040500002";
    String remark = "重新进行填写操作.";
    int result = stockManagementData.restoreStockLedgerAndSub(ledgerDate, orderId, remark);
    this.assertEquals("", 1, result);
  }
  //测试库存账套数据表电子签名的方法
  public void testSignStockLedgerAndSub() throws Exception{
    String ledgerDate = "200405";
    String fieldName = "commitUser";
    String userName = "jack";
    String orderId = "20040500003";
    String remark = "已经向供应商发送了进货单.";
    int result = stockManagementData.signStockLedgerAndSub(ledgerDate, fieldName, userName, orderId, remark);
    this.assertEquals("", 1, result);
  }
  //测试根据完成状态取得库存账套数据表的记录
  public void testGetStockLedgerByOnProcess() throws Exception{
    //根据完成状态取得记录
    String[][] detail = stockManagementData.getStockLedgerByOnProcess(
        "200404", 0, 0);
    this.assertEquals("", 1, detail.length);
  }
  //测试创建会计分录的方法
  public void testCreateAccountEntry() throws Exception{
    /*String ledgerDate = "200405";
    String[] accountEntry = {"st20040500005", "jack", "", "2004-5-20", null, "0", ""};
    String[][] accountSubEntry = {{"0", "流动资产@@存货@@10000001", "20"},
        {"0", "流动资产@@存货@@10000002", "30"}, {"1", "短期负债@@应付账款@@供应商1", "50"}};
    int result = stockManagementData.createAccountEntry(ledgerDate,
        accountEntry, accountSubEntry, false, null);
    this.assertEquals("", 1, result);*/
  }
  //测试创建往来账套的方法
  public void testCreateCurrentAccountLedger() throws Exception{
    /*String ledgerDate = "200405";
    String[] currentAccountLedger = {
        "st20040500005", "0", "50.6", "供应商1", "jack", "", "2004-5-20", null,
        "0", ""};
    int result = stockManagementData.createCurrentAccountLedger(ledgerDate,
        currentAccountLedger, false, null);
    this.assertEquals("", 1, result);*/
  }
  //测试验收员进行库存账套数据表电子签名的方法
  public void testCheckUserSignStockLedgerAndSub() throws Exception{
    String ledgerDate = "200405";
    String userName = "jack";
    String orderId = "20040500005";
    String supplierName = "供应商1";
    String remark = "货物已经验收入库.";
    int result = stockManagementData.checkUserSignStockLedgerAndSub(ledgerDate,
        userName, supplierName, orderId, remark);
    this.assertEquals("", 1, result);
  }
  //测试根据相关联票据标识取得往来账套数据表的记录的方法
  public void testGetCurrentAccountLedgerBylinkId() throws Exception{
    String ledgerDate = "200405";
    String orderId = "st20040500005";
    String[] data = stockManagementData.getCurrentAccountLedgerBylinkId(
        ledgerDate, orderId);
    this.assertEquals("", "供应商1", data[4]);
  }
  //测试根据票据编号、开票据的用户名、供应商名字取得往来账套数据表记录的方法
  public void testGetCurrentAccountLedgerByStringField() throws Exception{
    //根据单据编号取得记录
    String[][] detail = stockManagementData.getCurrentAccountLedgerByStringField(
        "200404", "currentAccountId", "2", 0);
    this.assertEquals("", 1, detail.length);
  }
  //测试根据完成状态取得往来账套数据表记录的方法
  public void testGetCurrentAccountLedgerByOnProcess() throws Exception{
    //根据完成状态取得记录
    String[][] detail = stockManagementData.getCurrentAccountLedgerByOnProcess(
        "200404", 0, 0);
    this.assertEquals("", 1, detail.length);
  }
  //测试根据开票据日期取得往来账套数据表记录的方法
  public void testGetCurrentAccountLedgerByFillDate() throws Exception{
    //创建日期类
    java.util.Calendar date = java.util.Calendar.getInstance();
    date.set(2004, 3, 6, 0, 0, 0);
    date.set(java.util.Calendar.MILLISECOND, 0);
    java.sql.Timestamp startDate = new java.sql.Timestamp(date.getTime().getTime());
    date.set(2004, 3, 7, 23, 59, 59);
    date.set(java.util.Calendar.MILLISECOND, 998);
    java.sql.Timestamp endDate = new java.sql.Timestamp(date.getTime().getTime());
    String[][] detail = stockManagementData.getCurrentAccountLedgerByFillDate("200404", startDate, endDate, 0);
    this.assertEquals("", 1, detail.length);
  }
  //测试创建现金账套的方法
  public void testCreateCashLedger() throws Exception{
    /*String ledgerDate = "200405";
    String[] cashLedger = {
        "cu20040500001", "0", "jack", "50.6", "2004-5-20"};
    int result = stockManagementData.createCashLedger(ledgerDate,
        cashLedger, false, null);
    this.assertEquals("", 1, result);*/
  }
  //测试现金管理员进行往来账套数据表电子签名的方法
  public void testCashUserSignAccountPayable() throws Exception{
    String ledgerDate = "200405";
    String userName = "jack";
    String[] currentAccountLedger = {"20040500002", "st20040400004", "0", "445",
        "供应商3", "jack", "", "2004-5-25 0:05:38", null, "0", ""};
    int result = stockManagementData.cashUserSignAccountPayable(ledgerDate,
        userName, currentAccountLedger);
    this.assertEquals("", 1, result);
  }
  //测试根据关联票据标识、记账用户取得现金账套数据表记录的方法
  public void testGetCashLedgerByStringField() throws Exception{
    //根据关联票据标识取得记录
    String[][] detail = stockManagementData.getCashLedgerByStringField(
        "200405", "linkId", "cu20040500002");
    this.assertEquals("", 1, detail.length);
  }
  //测试根据发生日期取得现金账套数据表记录的方法
  public void testGetCashLedgerByFillDate() throws Exception{
    //创建日期类
    java.util.Calendar date = java.util.Calendar.getInstance();
    date.set(2004, 4, 25, 0, 0, 0);
    date.set(java.util.Calendar.MILLISECOND, 0);
    java.sql.Timestamp startDate = new java.sql.Timestamp(date.getTime().getTime());
    date.set(2004, 4, 25, 23, 59, 59);
    date.set(java.util.Calendar.MILLISECOND, 998);
    java.sql.Timestamp endDate = new java.sql.Timestamp(date.getTime().getTime());
    String[][] detail = stockManagementData.getCashLedgerByFillDate("200405",
        startDate, endDate);
    this.assertEquals("", 4, detail.length);
  }
  //测试现金管理员收取退款进行电子签名的方法
  public void testCashUserSignStockLedgerForStockReturn() throws Exception{
    //供应商已付款
    String ledgerDate = "200405";
    String userName = "jack";
    String orderId = "20040500043";
    String supplierName = "供应商1";
    String remark = "退货货物已经收款.";
    int result = stockManagementData.cashUserSignStockLedgerForStockReturn(ledgerDate,
        userName, supplierName, orderId, remark, true);
    this.assertEquals("", 1, result);
    //供应商未付款
    ledgerDate = "200405";
    userName = "jack";
    orderId = "20040500044";
    supplierName = "供应商2";
    remark = "退货货物已经收款.";
    result = stockManagementData.cashUserSignStockLedgerForStockReturn(ledgerDate,
        userName, supplierName, orderId, remark, false);
    this.assertEquals("", 1, result);
  }
  //测试根据会计分录账套数据表的序号取得会计分录明细数据表的记录的方法
  public void testGetAccountEntrySubLedgerByLinkSerialId() throws Exception{
    String ledgerDate = "200404";
    int linkSerialId = 1;
    String[][] data = stockManagementData.getAccountEntrySubLedgerByLinkSerialId(
        ledgerDate, linkSerialId);
    this.assertEquals("", 3, data.length);
  }
  //测试根据会计科目、关联的票据标识、记账用户、审核用户取得会计分录账套数据表记录的方法
  public void testGetAccountEntryLedgerByStringField() throws Exception{
    String ledgerDate = "200404";
    String accountName = "现金";
    String fieldName = "filler";
    String fieldValue = "a";
    String[][] data = stockManagementData.getAccountEntryLedgerByStringField(
        ledgerDate, accountName, fieldName, fieldValue);
    this.assertEquals("", 5, data.length);
  }
  //测试根据会计科目、完成状态取得会计分录账套数据表记录的方法
  public void testGetAccountEntryLedgerByOnProcess() throws Exception{
    String ledgerDate = "200404";
    String accountName = "现金";
    int onProcess = 0;
    String[][] data = stockManagementData.getAccountEntryLedgerByOnProcess(
        ledgerDate, accountName, onProcess);
    this.assertEquals("", 1, data.length);
  }
  //测试根据会计科目、记账日期取得会计分录账套数据表记录的方法
  public void testGetAccountEntryLedgerByFillDate() throws Exception{
    String accountName = "现金";
    //创建日期类
    java.util.Calendar date = java.util.Calendar.getInstance();
    date.set(2004, 3, 5, 0, 0, 0);
    date.set(java.util.Calendar.MILLISECOND, 0);
    java.sql.Timestamp startDate = new java.sql.Timestamp(date.getTime().getTime());
    date.set(2004, 3, 5, 23, 59, 59);
    date.set(java.util.Calendar.MILLISECOND, 998);
    java.sql.Timestamp endDate = new java.sql.Timestamp(date.getTime().getTime());
    String[][] data = stockManagementData.getAccountEntryLedgerByFillDate("200404",
        startDate, endDate, accountName);
    this.assertEquals("", 5, data.length);
  }
  //测试撤消会计分录账套数据表记录完成状态的方法
  public void testCancelAccountEntryLedger() throws Exception{
    String ledgerDate = "200405";
    int serialId = 3;
    int onProcess = 1;
    String remark = "该会计分录已撤消.";
    int result = stockManagementData.cancelOrRestoreAccountEntryLedger(
        ledgerDate, serialId, onProcess, remark);
    this.assertEquals("", 1, result);
  }
  //测试恢复会计分录账套数据表记录完成状态的方法
  public void testRestoreAccountEntryLedger() throws Exception{
    String ledgerDate = "200405";
    int serialId = 3;
    int onProcess = 0;
    String remark = "该会计分录已撤消.(恢复)";
    int result = stockManagementData.cancelOrRestoreAccountEntryLedger(
        ledgerDate, serialId, onProcess, remark);
    this.assertEquals("", 1, result);
  }
  //测试会计分录账套数据表电子签名的方法
  public void testSignAccountEntryLedger() throws Exception{
    String ledgerDate = "200405";
    int serialId = 3;
    String fieldName = "auditUser";
    int onProcess = 2;
    String userName = "jack";
    String remark = "该会计分录已撤消.(恢复)(电子签名)";
    int result = stockManagementData.signAccountEntryLedger(
        ledgerDate, fieldName, userName, serialId, onProcess, remark);
    this.assertEquals("", 1, result);
  }
  //测试会计分录账套数据表的取消电子签名的方法
  public void testUnSignAccountEntryLedger() throws Exception{
    String ledgerDate = "200405";
    int serialId = 3;
    String fieldName = "auditUser";
    int onProcess = 0;
    String userName = "";
    String remark = "该会计分录已撤消.(恢复)(电子签名)(取消电子签名)";
    int result = stockManagementData.signAccountEntryLedger(
        ledgerDate, fieldName, userName, serialId, onProcess, remark);
    this.assertEquals("", 1, result);
  }
  //测试会计分录更新的方法
  public void testUpdateAccountEntry() throws Exception{
    String ledgerDate = "200405";
    String[] accountEntry = {"5", "st20040500003", "jack", "", "2004-5-30 1:19:33",
        "2004-6-1 11:42:25", "1", "备注"};
    String[][] accountSubEntry = {{"18", "5", "0", "流动资产@@存货@@10000002", "340"},
        {"19", "5", "0", "流动资产@@存货@@10000001", "340"},
        {"20", "5", "1", "短期负债@@应付账款@@供应商2", "680"}};
    int result = stockManagementData.updateAccountEntry(ledgerDate,
        accountEntry, accountSubEntry);
    this.assertEquals("", 1, result);
  }
  //测试库存账套数据表电子签名和更新完成状态的方法
  public void testSignStockLedgerAndSubForFinish() throws Exception{
    String ledgerDate = "200405";
    String fieldName = "checkUser";
    String userName = "jack";
    String orderId = "20040500058";
    int onProcess = 2;
    String remark = "商品调出单已验收.";
    int result = stockManagementData.signStockLedgerAndSubForFinish(ledgerDate,
        fieldName, userName, orderId, onProcess, remark);
    this.assertEquals("", 1, result);
  }
  //测试根据仓库名字取得盘点数据的方法
  public void testGetStocktakeQuantityByWarehouse()  throws Exception{
    String ledgerDate = "200405";
    String warehouse = "仓库1";
    int onProcess = 2;
    String[][] data = stockManagementData.getStocktakeQuantityByWarehouse(
        ledgerDate, warehouse, onProcess);
    this.assertEquals("", 4, data.length);
  }
  //测试根据仓库名字汇总显示商品数量和金额的方法
  public void testGetStockByWarehouse()  throws Exception{
    String ledgerDate = "200405";
    String warehouse = "仓库1";
    int onProcess = 2;
    String[][] data = stockManagementData.getStockByWarehouse(
        ledgerDate, warehouse, onProcess);
    this.assertEquals("", 27, data.length);
  }
  //测试根据商品条形码汇总显示商品在各个仓库的数量和金额的方法
  public void testGetStockByGoodsBarcode()  throws Exception{
    String ledgerDate = "200405";
    String goodsBarcode = "10000005";
    int onProcess = 2;
    String[][] data = stockManagementData.getStockByGoodsBarcode(
        ledgerDate, goodsBarcode, onProcess);
    this.assertEquals("", 8, data.length);
  }
  //测试查询过期商品的方法
  public void testGetStockByUsefulLife()  throws Exception{
    String ledgerDate = "200405";
    String usefulLife = "2004-6-1";
    int onProcess = 2;
    String[][] data = stockManagementData.getStockByUsefulLife(
        ledgerDate, usefulLife, onProcess);
    this.assertEquals("", 3, data.length);
  }
  //测试创建销售账套数据表和销售账套明细数据表记录的方法
  public void testCreateSaleLedgerAndSub() throws Exception{
    /*String ledgerDate = "200405";
    String[] saleLedger = {
        "", "0", "顾客", "jack", "", "", "", "2004-5-5", "2004-5-15",
        "0", ""};
    String[][] saleSubLedger = {{"", "", "10000001", "15.2", "10"},
        {"", "", "10000002", "18.5", "17"}};
    int result = stockManagementData.createSaleLedgerAndSub(ledgerDate, saleLedger, saleSubLedger);
    this.assertEquals("", 1, result);*/
  }
  //测试更新销售账套数据表和销售账套明细数据表记录的方法
  public void testUpdateSaleLedgerAndSub() throws Exception{
    String ledgerDate = "200405";
    String[] saleLedger = {
        "20040500001", "0", "顾客", "jack", "", "", "", "2004-5-6", "2004-5-6",
        "0", ""};
    String[][] saleSubLedger = {{"6", "20040500001", "10000001", "15.2", "3"},
        {"7", "20040500001", "10000002", "18.5", "5"}};
    int result = stockManagementData.updateSaleLedgerAndSub(ledgerDate, saleLedger, saleSubLedger);
    this.assertEquals("", 1, result);
  }
  //测试销售账套数据表电子签名和更新完成状态的方法
  public void testSignSaleLedgerAndSubForFinish() throws Exception{
    String ledgerDate = "200405";
    String fieldName = "counterUser";
    String userName = "jack";
    String orderId = "20040500001";
    int onProcess = 1;
    String remark = "销售单已撤消.";
    int result = stockManagementData.signSaleLedgerAndSub(ledgerDate,
        fieldName, userName, orderId, onProcess, remark);
    this.assertEquals("", 1, result);
  }
  //测试根据单据编号取得销售账套明细数据表的记录
  public void testGetSaleSubLedgerBySaleId() throws Exception{
    //根据单据编号取得记录
    String[][] detail = stockManagementData.getSaleSubLedgerBySaleId(
        "200404", "20040400001");
    this.assertEquals("", 1, detail.length);
  }
  //测试根据字符串字段取得销售账套数据表记录的方法
  public void testGetSaleLedgerByStringField() throws Exception{
    //根据单据编号取得记录
    String[][] detail = stockManagementData.getSaleLedgerByStringField(
        "200404", "saleId", "2004", 0);
    this.assertEquals("", 1, detail.length);
  }
  //测试根据填写日期取得销售账套数据表记录的方法
  public void testGetSaleLedgerByOrderDate() throws Exception{
    //创建日期类
    java.util.Calendar date = java.util.Calendar.getInstance();
    date.set(2004, 3, 10, 0, 0, 0);
    date.set(java.util.Calendar.MILLISECOND, 0);
    java.sql.Timestamp startDate = new java.sql.Timestamp(date.getTime().getTime());
    date.set(2004, 3, 10, 23, 59, 59);
    date.set(java.util.Calendar.MILLISECOND, 998);
    java.sql.Timestamp endDate = new java.sql.Timestamp(date.getTime().getTime());
    String[][] detail = stockManagementData.getSaleLedgerByOrderDate("200404", startDate, endDate, 1);
    this.assertEquals("", 1, detail.length);
  }
  //测试根据完成状态取得销售账套数据表的记录
  public void testGetSaleLedgerByOnProcess() throws Exception{
    //根据完成状态取得记录
    String[][] detail = stockManagementData.getSaleLedgerByOnProcess(
        "200404", 1, 0);
    this.assertEquals("", 1, detail.length);
  }
  //测试前台销售员进行销售账套数据表电子签名的方法
  public void testCounterUserSignSaleLedgerAndSub() throws Exception{
    String ledgerDate = "200405";
    String userName = "jack";
    String remark = "已签名";
    String warehouse = "柜台1";
    int result = stockManagementData.counterUserSignSaleLedgerAndSub(ledgerDate,
        userName, remark, warehouse);
    this.assertEquals("", 1, result);
  }
  //测试信用销售员进行销售账套数据表电子签名的方法
  public void testCreditUserSignSaleLedgerAndSub() throws Exception{
    String ledgerDate = "200405";
    String userName = "jack";
    String remark = "已签名";
    String warehouse = "柜台1";
    String saleId = "20040500011";
    String customerName = "客户1";
    int result = stockManagementData.creditUserSignSaleLedgerAndSub(ledgerDate,
        userName, remark, warehouse, saleId, customerName);
    this.assertEquals("", 1, result);
  }
  //测试现金管理员进行应收账款电子签名的方法
  public void testCashUserSignAccountReceivable() throws Exception{
    String ledgerDate = "200405";
    String userName = "jack";
    String[] currentAccountLedger = {"20040500012", "sa20040500011", "1", "466.5",
        "客户1", "jack", "", "2004-6-11 12:19:52", null, "0", "已签名."};
    int result = stockManagementData.cashUserSignAccountReceivable(ledgerDate,
        userName, currentAccountLedger);
    this.assertEquals("", 1, result);
  }
  //测试根据关联标识、退货单的商品条形码取得库存账套的销售出库单明细账的数据
  public void testGetStockSaleOutBySaleOrderLink() throws Exception{
    String ledgerDate = "200405";
    String saleOrderLink = "sajack";
    String saleId = "20040500015";
    String[][] data = stockManagementData.getStockSaleOutBySaleOrderLink(
        ledgerDate, saleOrderLink, saleId);
    this.assertEquals("", 3, data.length);
  }
  //测试前台销售员进行销售退货单电子签名的方法
  public void testCountUserSignSaleReturn() throws Exception{
    String ledgerDate = "200405";
    String userName = "jack";
    String remark = "已签名";
    String warehouse = "柜台1";
    String saleId = "20040500015";
    //销售退货，库存数量增加
    String[][] stockSubLedger = {
        {"", "", "10000001", "15.2", "1", "2004-05-20"},
    };
    int result = stockManagementData.counterUserSignSaleReturn(ledgerDate,
        saleId, userName, remark, warehouse, stockSubLedger);
    this.assertEquals("", 1, result);
  }
  //测试信用销售员进行销售退货单电子签名的方法
  public void testCreditUserSignSaleReturn() throws Exception{
    String ledgerDate = "200405";
    String userName = "jack";
    String remark = "已签名";
    String warehouse = "柜台1";
    String customerName = "客户1";
    String saleId = "20040500020";
    //销售退货，库存数量增加
    String[][] stockSubLedger = {
        {"", "", "10000001", "3.7", "10", "2004-11-5"},
    };
    int result = stockManagementData.creditUserSignSaleReturn(ledgerDate,
        saleId, userName, remark, warehouse, customerName,stockSubLedger, true);
    this.assertEquals("", 1, result);
  }
}
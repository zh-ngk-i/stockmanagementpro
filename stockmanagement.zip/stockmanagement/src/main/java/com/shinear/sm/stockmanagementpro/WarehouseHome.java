﻿package com.shinear.sm.stockmanagementpro;

import javax.ejb.*;
import java.util.*;

public interface WarehouseHome extends javax.ejb.EJBLocalHome {
  public Warehouse create(String warehouseName, String pyCode, String location, String description) throws CreateException;
  public Collection findAll() throws FinderException;
  public Warehouse findByPrimaryKey(String warehouseName) throws FinderException;
}
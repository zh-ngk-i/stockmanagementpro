﻿package com.shinear.sm.data;

import javax.naming.*;
import com.shinear.sm.stockmanagementpro.*;
import com.shinear.sm.user.*;
import javax.rmi.*;
import java.util.*;

public class StockManagementData {
  private StockManagementDataHome stockManagementDataHome = null;
  private com.shinear.sm.stockmanagementpro.StockManagementData stockManagementData = null;

  public StockManagementData() {
    try{
      initialize();
    }catch(Exception ex){
      ex.printStackTrace();
    }
  }
  //EJB的初始化方法
  public void initialize() throws Exception {
    //创建服务器对象查找类
    Context context = getInitialContext();
    //取得EJB在服务器的对象
    Object ref = context.lookup("StockManagementData");
    //取得StockManagementData EJB的创建接口
    stockManagementDataHome = (StockManagementDataHome)PortableRemoteObject.narrow(ref,
        StockManagementDataHome.class);
    //取得StockManagementData EJB的远程接口
    create();
  }
  //服务器对象查找类的创建方法
  private Context getInitialContext() throws Exception {
    String url = "t3://bemyfriend:7001";
    String user = null;
    String password = null;
    Properties properties = null;
    //初始化联接服务器的属性
    try {
      properties = new Properties();
      properties.put(Context.INITIAL_CONTEXT_FACTORY,
                     "weblogic.jndi.WLInitialContextFactory");
      properties.put(Context.PROVIDER_URL, url);
      if (user != null) {
        properties.put(Context.SECURITY_PRINCIPAL, user);
        properties.put(Context.SECURITY_CREDENTIALS, password == null ? "" : password);
      }
      return new InitialContext(properties);
    }
    catch(Exception e) {
      System.out.println("Unable to connect to WebLogic server at " + url);
      System.out.println("Please make sure that the server is running.");
      throw e;
    }
  }
  //创建StockManagementData EJB的远程接口
  public com.shinear.sm.stockmanagementpro.StockManagementData create() throws Exception {
    stockManagementData = stockManagementDataHome.create();
    return stockManagementData;
  }
  //检查用户的方法
  public int[] checkUser(String userName, String userPassword){
    int[] functions = new int[4];
    try{
      functions = stockManagementData.checkUser(userName, userPassword);
    }catch(Exception ex){
      functions[0] = -1;
      functions[1] = -1;
      functions[2] = -1;
      functions[3] = -1;
    }
    return functions;
  }
  //创建用户
  public int createUser(User user) {
    int result = 0;
    try{
      result = stockManagementData.createUser(user);
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return result;
  }
  //更新用户
  public int updateUser(User user) {
    int result = 0;
    try{
      result = stockManagementData.updateUser(user);
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return result;
  }
  //删除用户
  public int deleteUser(User user) {
    int result = 0;
    try{
      result = stockManagementData.deleteUser(user);
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return result;
  }
  //根据用户名查询用户
  public String[][] getUserByUserName(String userName){
    //创建存取用户数据的数组
    String[][] detail = null;
    try{
      detail = stockManagementData.getUserByUserName(userName);
    }catch(Exception ex){
      detail = new String[0][6];
      ex.printStackTrace();
    }
    //返回数组
    return detail;
  }
  //日志数据表记录的创建方法
  public int createUserLog(String programName, String operationContent,
                            String userName) {
    int result = 0;
    try{
      result = stockManagementData.createUserLog(programName, operationContent, userName);
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return result;
  }
  //日志数据表记录的删除方法
  public int deleteUserLog(Integer id){
    int result = 0;
    try{
      result = stockManagementData.deleteUserLog(id);
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return result;
  }
  //返回数据库所有数据表名字的方法
  public String[] getTableNames() {
    String[] tableNames = new String[0];
    try{
      tableNames = stockManagementData.getTableNames();
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return tableNames;
  }
  //返回数据表数据的方法
  public String[][] getDataByTableName(String tableName) {
    String[][] data = new String[0][0];
    try{
      data = stockManagementData.getDataByTableName(tableName);
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return data;
  }
  //将数组写入数据表的方法
  public int setDataByTableName(String tableName, String[][] data) {
    int result = 0;
    try{
      result = stockManagementData.setDataByTableName(tableName, data);
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return result;
  }
  //取得账套名字的方法
  public String[] getLedgerNames() {
    String[] ledgerNames = new String[0];
    try{
      ledgerNames = stockManagementData.getLedgerNames();
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return ledgerNames;
  }
  //创建账套的方法
  public int createLedger(String ledgerDate) {
    int result = 0;
    try{
      result = stockManagementData.createLedger(ledgerDate);
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return result;
  }
  //删除账套的方法
  public int deleteLedger(String ledgerDate) {
    int result = 0;
    try{
      result = stockManagementData.deleteLedger(ledgerDate);
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return result;
  }
  //创建商品类别的方法
  public int createGoodsCategory(int parentId, String categoryName, String categoryDescription) {
    int result = 0;
    try {
      result = stockManagementData.createGoodsCategory(parentId,
        categoryName, categoryDescription);
    }catch (Exception ex) {
      ex.printStackTrace();
    }
    return result;
  }
  //更新商品类别的方法
  public int updateGoodsCategory(int categoryId, int parentId,
                                 String categoryName,
                                 String categoryDescription) {
    int result = 0;
    try {
      result = stockManagementData.updateGoodsCategory(categoryId, parentId,
        categoryName, categoryDescription);
    }catch (Exception ex) {
      ex.printStackTrace();
    }
    return result;
  }
  //删除商品类别的方法
  public int deleteGoodsCategory(int categoryId) {
    int result = 0;
    try {
      result = stockManagementData.deleteGoodsCategory(categoryId);
    }catch (Exception ex) {
      ex.printStackTrace();
    }
    return result;
  }
  //取得所有商品类别的方法
  public String[][] getAllGoodsCategory() {
    String[][] detail = new String[0][4];
    try{
      //取得商品类别的所有记录
      detail = stockManagementData.getAllGoodsCategory();
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return detail;
  }
  //创建商品的方法
  public int createGoods(String goodsBarCode, int categoryId, String goodsName,
                         String goodsNickName, String goodsAssistantName,
                         String goodsPYName, String unit, String specification,
                         String producer, int upperLimit, int lowerLimit,
                         double salePrice, double discount) {
     int result = 0;
     try {
       result = stockManagementData.createGoods(goodsBarCode, categoryId, goodsName,
                     goodsNickName, goodsAssistantName, goodsPYName, unit,
                     specification, producer, upperLimit, lowerLimit, salePrice, discount);
     }catch (Exception ex) {
       ex.printStackTrace();
     }
     return result;
  }
  //更新商品的方法
  public int updateGoods(String goodsBarCode, int categoryId, String goodsName,
                         String goodsNickName, String goodsAssistantName,
                         String goodsPYName, String unit, String specification,
                         String producer, int upperLimit, int lowerLimit,
                         double salePrice, double discount) {
    int result = 0;
    try {
      result = stockManagementData.updateGoods(goodsBarCode, categoryId, goodsName,
                    goodsNickName, goodsAssistantName, goodsPYName, unit,
                    specification, producer, upperLimit, lowerLimit, salePrice, discount);
    }catch (Exception ex) {
      ex.printStackTrace();
    }
    return result;
  }
  //删除商品的方法
  public int deleteGoods(String goodsBarCode) {
     int result = 0;
     try {
       result = stockManagementData.deleteGoods(goodsBarCode);
     }catch (Exception ex) {
       ex.printStackTrace();
     }
     return result;
  }
  //根据类别取得商品的方法
  public String[][] getGoodsByGoodsCategory(int goodsCategory){
    String[][] detail = new String[0][13];
    try{
      detail = stockManagementData.getGoodsByGoodsCategory(goodsCategory);
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return detail;
  }
  //根据条形码取得商品的方法
  public String[][] getGoodsByGoodsBarCode(String goodsBarCode){
    String[][] detail = new String[0][13];
    try{
      detail = stockManagementData.getGoodsByGoodsBarCode(goodsBarCode);
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return detail;
  }
  //根据商品名字取得商品的方法
  public String[][] getGoodsByGoodsName(String goodsName){
    String[][] detail = new String[0][13];
    try{
      detail = stockManagementData.getGoodsByGoodsName(goodsName);
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return detail;
  }
  //根据生产厂商取得商品的方法
  public String[][] getGoodsByProducer(String producer){
    String[][] detail = new String[0][13];
    try{
      detail = stockManagementData.getGoodsByProducer(producer);
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return detail;
  }
  //取得折扣商品的方法
  public String[][] getDiscountGoods(){
    String[][] detail = new String[0][13];
    try{
      detail = stockManagementData.getDiscountGoods();
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return detail;
  }
  //设置商品折扣的方法
  public int setGoodsDiscount(String goodsBarCode, double discount){
    int result = 0;
    try {
      result = stockManagementData.setGoodsDiscount(goodsBarCode, discount);
    }catch (Exception ex) {
      ex.printStackTrace();
    }
    return result;
  }
  //创建供应商的方法
  public int createSupplier(String[] supplierArray) {
     int result = 0;
     if(supplierArray.length != 16){
       return result;
     }
     try {
       //创建供应商
       result = stockManagementData.createSupplier(supplierArray);
     }catch (Exception ex) {
       ex.printStackTrace();
     }
     return result;
  }
  //更新供应商的方法
  public int updateSupplier(String[] supplierArray) {
     int result = 0;
     if(supplierArray.length != 16){
       return result;
     }
     try {
       //更新供应商
       result = stockManagementData.updateSupplier(supplierArray);
     }catch (Exception ex) {
       ex.printStackTrace();
     }
     return result;
  }
  //删除供应商的方法
  public int deleteSupplier(String supplierName) {
     int result = 0;
     try {
       result = stockManagementData.deleteSupplier(supplierName);
     }catch (Exception ex) {
       ex.printStackTrace();
     }
     return result;
  }
  //根据供应商名字取得记录的方法
  public String[][] getSuppliersBySupplierName(String supplierName){
    String[][] detail = new String[0][16];
    try{
      //根据供应商名字取得记录
      detail = stockManagementData.getSuppliersBySupplierName(supplierName);
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return detail;
  }
  //根据地区取得供应商记录的方法
  public String[][] getSuppliersBySupplierZone(String supplierZone){
    String[][] detail = new String[0][16];
    try{
      //根据地区取得记录
      detail = stockManagementData.getSuppliersBySupplierZone(supplierZone);
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return detail;
  }
  //创建客户的方法
  public int createCustomer(String[] customerArray) {
     int result = 0;
     if(customerArray.length != 17){
       return result;
     }
     try {
       //创建客户
       result = stockManagementData.createCustomer(customerArray);
     }catch (Exception ex) {
       ex.printStackTrace();
     }
     return result;
  }
  //更新客户的方法
  public int updateCustomer(String[] customerArray) {
     int result = 0;
     if(customerArray.length != 17){
       return result;
     }
     try {
       //更新客户
       result = stockManagementData.updateCustomer(customerArray);
     }catch (Exception ex) {
       ex.printStackTrace();
     }
     return result;
  }
  //删除客户的方法
  public int deleteCustomer(String customerName) {
     int result = 0;
     try {
       result = stockManagementData.deleteCustomer(customerName);
     }catch (Exception ex) {
       ex.printStackTrace();
     }
     return result;
  }
  //根据客户名字取得记录的方法
  public String[][] getCustomersByCustomerName(String customerName){
    String[][] detail = new String[0][17];
    try{
      //根据客户名字取得记录
      detail = stockManagementData.getCustomersByCustomerName(customerName);
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return detail;
  }
  //根据地区取得客户记录的方法
  public String[][] getCustomersByCustomerZone(String customerZone){
    String[][] detail = new String[0][17];
    try{
      //根据地区取得记录
      detail = stockManagementData.getCustomersByCustomerZone(customerZone);
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return detail;
  }
  //取得信用客户的方法
  public String[][] getCreditCustomer() {
    String[][] detail = new String[0][17];
    try{
      //取得信用客户记录
      detail = stockManagementData.getCreditCustomer();
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return detail;
  }
  //设置客户信用的方法
  public int setCreditCustomer(String customerName, double creditlimit) {
    int result = 0;
    try {
      //设置客户的信用
      result = stockManagementData.setCreditCustomer(customerName, creditlimit);
    }catch (Exception ex) {
      ex.printStackTrace();
    }
    return result;
  }
  //创建仓库
  public int createWarehouse(String[] warehouseArray) {
    int result = 0;
    if(warehouseArray.length != 4){
      return result;
    }
    try {
      //创建仓库
      result = stockManagementData.createWarehouse(warehouseArray);
    }catch (Exception ex) {
      ex.printStackTrace();
    }
    return result;
  }
  //更新仓库
  public int updateWarehouse(String[] warehouseArray) {
    int result = 0;
    if(warehouseArray.length != 4){
      return result;
    }
    try {
      //更新仓库
      result = stockManagementData.updateWarehouse(warehouseArray);
    }catch (Exception ex) {
      ex.printStackTrace();
    }
    return result;
  }
  //删除仓库
  public int deleteWarehouse(String warehouseName) {
    int result = 0;
    try {
      result = stockManagementData.deleteWarehouse(warehouseName);
    }catch (Exception ex) {
      ex.printStackTrace();
    }
    return result;
  }
  //取得所有仓库
  public String[][] getAllWarehouse() {
    String[][] detail = new String[0][4];
    try{
      //取得所有仓库记录
      detail = stockManagementData.getAllWarehouse();
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return detail;
  }
  //创建会计科目
  public int createAccountName(int parentId, String accountNameStr) {
    int result = 0;
    try {
      result = stockManagementData.createAccountName(parentId, accountNameStr);
    }catch (Exception ex) {
      ex.printStackTrace();
    }
    return result;
  }
  //更新会计科目
  public int updateAccountName(int accountId, int parentId, String accountName) {
    int result = 0;
    try {
      result = stockManagementData.updateAccountName(accountId, parentId, accountName);
    }catch (Exception ex) {
      ex.printStackTrace();
    }
    return result;
  }
  //删除会计科目
  public int deleteAccountName(int accountId) {
    int result = 0;
    try {
      result = stockManagementData.deleteAccountName(accountId);
    }catch (Exception ex) {
      ex.printStackTrace();
    }
    return result;
  }
  //根据父标识取得会计科目
  public String[][] getAccountNameByParentid(int parentId) {
    String[][] detail = new String[0][3];
    try{
      detail = stockManagementData.getAccountNameByParentid(parentId);
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return detail;
  }
  //取得所有会计科目
  public String[][] getAllAccountName() {
    String[][] detail = new String[0][3];
    try{
      detail = stockManagementData.getAllAccountName();
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return detail;
  }
  //取得科目余额的方法
  public String[][] getAccountBalance(String ledgerDate, int onProcess) {
    String[][] data = new String[0][3];
    try {
     data = stockManagementData.getAccountBalance(ledgerDate, onProcess);
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    return data;
  }
  //根据操作程序名字取得日志记录的方法
  public String[][] getUserLogByProgramName(String programName) {
    String[][] detail = new String[0][5];
    try{
      detail = stockManagementData.getUserLogByProgramName(programName);
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return detail;
  }
  //根据操作内容取得日志记录的方法
  public String[][] getUserLogByOperationContent(String operationContent) {
    String[][] detail = new String[0][5];
    try{
      detail = stockManagementData.getUserLogByOperationContent(operationContent);
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return detail;
  }
  //根据用户名字取得日志记录的方法
  public String[][] getUserLogByUserName(String userName) {
    String[][] detail = new String[0][5];
    try{
      detail = stockManagementData.getUserLogByUserName(userName);
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return detail;
  }
  //根据操作时间取得日志记录的方法
  public String[][] getUserLogByOperationDate(java.sql.Timestamp startDate,
                                              java.sql.Timestamp endDate) {
    String[][] detail = new String[0][5];
    try{
      detail = stockManagementData.getUserLogByOperationDate(startDate, endDate);
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return detail;
  }
  //根据单据编号或者请购员名字或者仓库名字取得库存账套数据表记录的方法
  public String[][] getStockLedgerByStringField(String ledgerDate,
                                                String fieldName,
                                                String fieldValue,
                                                int orderType) {
    String[][] data = new String[0][13];
    try {
      data = stockManagementData.getStockLedgerByStringField(ledgerDate,
          fieldName, fieldValue, orderType);
    }catch (Exception ex) {
      ex.printStackTrace();
    }
    return data;
  }
  //根据订单日期取得库存账套数据表记录的方法
  public String[][] getStockLedgerByOrderDate(String ledgerDate,
                                              java.sql.Timestamp startDate,
                                              java.sql.Timestamp endDate,
                                              int orderType) {
    String[][] data = new String[0][13];
    try {
      data = stockManagementData.getStockLedgerByOrderDate(ledgerDate,
          startDate, endDate, orderType);
    } catch (Exception ex) {
      ex.printStackTrace();
    }
    return data;
  }
  //根据单据编号取得库存账套明细数据表的记录
  public String[][] getStockSubLedgerByOrderId(String ledgerDate,
                                               String orderId) {
    String[][] data = new String[0][6];
    try {
      data = stockManagementData.getStockSubLedgerByOrderId(ledgerDate, orderId);
    }catch (Exception ex) {
      ex.printStackTrace();
    }
    return data;
  }
  //创建库存账套数据表和库存账套明细数据表记录的方法
  public int createStockLedgerAndSub(String ledgerDate, String[] stockLedger,
                                     String[][] stockSubLedger) {
    int result = 0;
    try{
      result = stockManagementData.createStockLedgerAndSub(ledgerDate,
          stockLedger, stockSubLedger);
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return result;
  }
  //更新库存账套数据表和库存账套明细数据表记录的方法
  public int updateStockLedgerAndSub(String ledgerDate, String[] stockLedger,
                                     String[][] stockSubLedger) {
    int result = 0;
    try{
      result = stockManagementData.updateStockLedgerAndSub(ledgerDate,
          stockLedger, stockSubLedger);
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return result;
  }
  //撤消库存账套数据表记录的方法
  public int cancelStockLedgerAndSub(String ledgerDate, String orderId,
                                     String remark) {
    int result = 0;
    try{
      result = stockManagementData.cancelStockLedgerAndSub(ledgerDate, orderId, remark);
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return result;
  }
  //检查供应商的方法
  public int checkSupplier(String supplier){
    int result = 0;
    String[][] detail = this.getSuppliersBySupplierName(supplier);
    for(int i = 0; i < detail.length; i++){
      if(detail[i][0].equals(supplier)){
        result = 1;
        break;
      }
    }
    return result;
  }
  //检查仓库的方法
  public int checkWarehouse(String warehouse){
    int result = 0;
    String[][] detail = this.getAllWarehouse();
    for(int i = 0; i < detail.length; i++){
      if(detail[i][0].equals(warehouse)){
        result = 1;
        break;
      }
    }
    return result;
  }
  //检查商品条形码的方法
  public int checkGoodsBarCode(String goodsBarCode){
    int result = 0;
    String[][] detail = this.getGoodsByGoodsBarCode(goodsBarCode);
    for(int i = 0; i < detail.length; i++){
      if(detail[i][0].equals(goodsBarCode)){
        result = 1;
        break;
      }
    }
    return result;
  }
  //检查打开账套是否最新账套的方法
  public int isCurrentLedger(String ledgerDate){
    int result = 0;
    String[] ledgerDates = this.getLedgerNames();
    if(ledgerDates.length > 0){
      if(ledgerDates[ledgerDates.length -1].equals(ledgerDate)){
        result = 1;
      }
    }
    return result;
  }
  //恢复库存账套数据表完成状态的方法
  public int restoreStockLedgerAndSub(String ledgerDate, String orderId,
                                      String remark) {
    int result = 0;
    try {
      result = stockManagementData.restoreStockLedgerAndSub(ledgerDate, orderId,
          remark);
    }catch (Exception ex) {
      ex.printStackTrace();
    }
    return result;
  }
  //库存账套数据表电子签名的方法
  public int signStockLedgerAndSub(String ledgerDate, String fieldName, String userName,
                                   String orderId, String remark) {
    int result = 0;
    try {
      result = stockManagementData.signStockLedgerAndSub(ledgerDate, fieldName,
          userName, orderId, remark);
    }catch (Exception ex) {
      ex.printStackTrace();
    }
    return result;
  }
  //根据完成状态取得库存账套数据表的记录
  public String[][] getStockLedgerByOnProcess(String ledgerDate, int orderType,
                                              int onProcess) {
    String[][] data = new String[0][13];
    try {
      data = stockManagementData.getStockLedgerByOnProcess(ledgerDate,
          orderType, onProcess);
    }catch (Exception ex) {
      ex.printStackTrace();
    }
    return data;
  }
  //验收员进行库存账套数据表电子签名的方法
  public int checkUserSignStockLedgerAndSub(String ledgerDate, String userName,
                                            String supplierName, String orderId,
                                            String remark) {
    int result = 0;
    try {
      result = stockManagementData.checkUserSignStockLedgerAndSub(ledgerDate, userName,
          supplierName, orderId, remark);
    }catch (Exception ex) {
      ex.printStackTrace();
    }
    return result;
  }
  //根据相关联票据标识取得往来账套数据表的记录
  public String[] getCurrentAccountLedgerBylinkId(String ledgerDate, String linkId){
    String[] data = new String[11];
    try {
      data = stockManagementData.getCurrentAccountLedgerBylinkId(ledgerDate, linkId);
    }catch (Exception ex) {
      ex.printStackTrace();
    }
    return data;
  }
  //根据票据编号、开票据的用户名、供应商名字取得往来账套数据表记录的方法
  public String[][] getCurrentAccountLedgerByStringField(String ledgerDate,
      String fieldName, String fieldValue, int documentType) {
    String[][] data = new String[0][11];
    try {
      data = stockManagementData.getCurrentAccountLedgerByStringField(
          ledgerDate, fieldName, fieldValue, documentType);
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    return data;
  }
  //根据完成状态取得往来账套数据表记录的方法
  public String[][] getCurrentAccountLedgerByOnProcess(String ledgerDate,
      int documentType, int onProcess) {
    String[][] data = new String[0][11];
    try {
      data = stockManagementData.getCurrentAccountLedgerByOnProcess(
          ledgerDate, documentType, onProcess);
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    return data;
  }
  //根据开票据日期取得往来账套数据表记录的方法
  public String[][] getCurrentAccountLedgerByFillDate(String ledgerDate,
      java.sql.Timestamp startDate, java.sql.Timestamp endDate,
      int documentType) {
    String[][] data = new String[0][11];
    try {
      data = stockManagementData.getCurrentAccountLedgerByFillDate(ledgerDate,
          startDate, endDate, documentType);
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    return data;
  }
  //现金管理员进行电子签名的方法
  public int cashUserSignAccountPayable(String ledgerDate, String userName, String[] currentAccountLedger) {
    int result = 0;
    try{
      result = stockManagementData.cashUserSignAccountPayable(ledgerDate,
          userName, currentAccountLedger);
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return result;
  }
  //根据关联票据标识、记账用户取得现金账套数据表记录的方法
  public String[][] getCashLedgerByStringField(String ledgerDate,
                                               String fieldName,
                                               String fieldValue) {
    String[][] data = new String[0][6];
    try {
      data = stockManagementData.getCashLedgerByStringField(ledgerDate,
          fieldName, fieldValue);
    }catch (Exception ex) {
      ex.printStackTrace();
    }
    return data;
  }
  //根据发生日期取得现金账套数据表记录的方法
  public String[][] getCashLedgerByFillDate(String ledgerDate,
                                            java.sql.Timestamp startDate,
                                            java.sql.Timestamp endDate) {
    String[][] data = new String[0][6];
    try {
      data = stockManagementData.getCashLedgerByFillDate(ledgerDate, startDate,
          endDate);
    }catch (Exception ex) {
      ex.printStackTrace();
    }
    return data;
  }
  //现金管理员收取退款进行电子签名的方法
  public int cashUserSignStockLedgerForStockReturn(String ledgerDate,
      String userName, String supplierName, String orderId, String remark,
      boolean isPay) {
    int result = 0;
    try {
      result = stockManagementData.cashUserSignStockLedgerForStockReturn(
          ledgerDate, userName, supplierName, orderId, remark, isPay);
    }catch (Exception ex) {
      ex.printStackTrace();
    }
    return result;
  }
  //根据会计分录账套数据表的序号取得会计分录明细数据表的记录
  public String[][] getAccountEntrySubLedgerByLinkSerialId(String ledgerDate, int linkSerialId) {
    String[][] data = new String[0][5];
    try {
      data = stockManagementData.getAccountEntrySubLedgerByLinkSerialId(
          ledgerDate, linkSerialId);
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    return data;
  }
  //根据会计科目、关联的票据标识、记账用户、审核用户取得会计分录账套数据表记录的方法
  public String[][] getAccountEntryLedgerByStringField(String ledgerDate,
      String accountName, String fieldName, String fieldValue) {
    String[][] data = new String[0][8];
    try {
      data = stockManagementData.getAccountEntryLedgerByStringField(ledgerDate,
          accountName, fieldName, fieldValue);
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    return data;
  }
  //根据会计科目、完成状态取得会计分录账套数据表记录的方法
  public String[][] getAccountEntryLedgerByOnProcess(String ledgerDate,
      String accountName, int onProcess) {
    String[][] data = new String[0][8];
    try {
      data = stockManagementData.getAccountEntryLedgerByOnProcess(ledgerDate,
          accountName, onProcess);
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    return data;
  }
  //根据会计科目、记账日期取得会计分录账套数据表记录的方法
  public String[][] getAccountEntryLedgerByFillDate(String ledgerDate,
      java.sql.Timestamp startDate, java.sql.Timestamp endDate,
      String accountName) {
    String[][] data = new String[0][8];
    try {
      data = stockManagementData.getAccountEntryLedgerByFillDate(ledgerDate,
          startDate, endDate, accountName);
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    return data;
  }
  //撤消和恢复会计分录账套数据表完成状态的方法
  public int cancelOrRestoreAccountEntryLedger(String ledgerDate, int serialId,
                                               int onProcess, String remark) {
    int result = 0;
    try{
      result = stockManagementData.cancelOrRestoreAccountEntryLedger(ledgerDate,
          serialId, onProcess, remark);
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return result;
  }
  //审核用户对会计分录进行电子签名的方法
  public int signAccountEntryLedger(String ledgerDate, String fieldName,
                                    String userName, int serialId,
                                    int onProcess, String remark) {
    int result = 0;
    try{
      result = stockManagementData.signAccountEntryLedger(ledgerDate, fieldName,
          userName, serialId, onProcess, remark);
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return result;
  }
  //创建会计分录的方法
  public int createAccountEntry(String ledgerDate, String[] accountEntryLedger,
                                String[][] accountEntrySubLedger) {
    int result = 0;
    try{
      result = stockManagementData.createAccountEntry(ledgerDate,
          accountEntryLedger, accountEntrySubLedger, false, null);
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return result;
  }
  //更新会计分录的方法
  public int updateAccountEntry(String ledgerDate, String[] accountEntryLedger,
                                String[][] accountEntrySubLedger) {
    int result = 0;
    try{
      result = stockManagementData.updateAccountEntry(ledgerDate,
          accountEntryLedger, accountEntrySubLedger);
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return result;
  }
  //创建商品调拔单的方法
  public int createTransferOrder(String ledgerDate, String[] stockLedger,
                                     String[][] stockSubLedger){
    int result = 0;
    try{
      //创建商品调入单数组
      String[] orderInLedger = new String[stockLedger.length];
      //创建商品调入单明细数组
      String[][] orderInSubLedger = new String[stockSubLedger.length][stockSubLedger[0].length];
      //更新商品调入单明细数组
      for(int i = 0; i < orderInSubLedger.length; i++){
        orderInSubLedger[i][0] = stockSubLedger[i][0];
        orderInSubLedger[i][1] = stockSubLedger[i][1];
        orderInSubLedger[i][2] = stockSubLedger[i][2];
        orderInSubLedger[i][3] = stockSubLedger[i][3];
        //将商品数量更改为正数
        orderInSubLedger[i][4] = String.valueOf(-Integer.parseInt(stockSubLedger[i][4]));
        orderInSubLedger[i][5] = stockSubLedger[i][5];
      }
      System.arraycopy(stockLedger, 0, orderInLedger, 0, stockLedger.length);
      //更新商品调入单数组，3表示商品调入单
      orderInLedger[1] = "3";
      orderInLedger[4] = stockLedger[8];         //调出仓库
      orderInLedger[8] = stockLedger[4];         //调入仓库
      //创建商品调入单
      stockManagementData.createStockLedgerAndSub(ledgerDate, orderInLedger, orderInSubLedger);
      //根据商品调出用户名字取得商品调入单
      String[][] orderInLedgers = stockManagementData.
          getStockLedgerByStringField(ledgerDate, "submitUser", orderInLedger[3], 3);
      //取得商品调入单标识，最后一条记录便是新创建的商品调入单
      String orderInId = orderInLedgers[orderInLedgers.length -1][0];
      //创建商品调出单数组
      String[] orderOutLedger = stockLedger;
      //将商品调入单标识放在供应商字段
      orderOutLedger[2] = orderInId;
      //创建商品调出单
      stockManagementData.createStockLedgerAndSub(ledgerDate, orderOutLedger, stockSubLedger);
      //根据商品调出用户名字取得商品调出单
      String[][] orderOutLedgers = stockManagementData.
          getStockLedgerByStringField(ledgerDate, "submitUser", orderInLedger[3], 2);
      //取得商品调出单标识，最后一条记录便是新创建的商品调出单
      String orderOutId = orderOutLedgers[orderOutLedgers.length -1][0];
      //更新商品调入单数组的标识和关联标识
      orderInLedger[0] = orderInId;
      orderInLedger[2] = orderOutId;
      //根据标识重新取得商品调入单明细数组
      orderInSubLedger = stockManagementData.getStockSubLedgerByOrderId(
          ledgerDate, orderInLedger[0]);
      //更新商品调入单,将调出单的关联标识写入调入单
      stockManagementData.updateStockLedgerAndSub(ledgerDate, orderInLedger, orderInSubLedger);
      result = 1;
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return result;
  }
  //更新商品调拔单的方法
  public int updateTransferOrder(String ledgerDate, String[] stockLedger,
                                     String[][] stockSubLedger){
    int result = 0;
    try{
      //创建商品调出单数组
      String[] orderOutLedger = stockLedger;
      //更新商品调出单
      stockManagementData.updateStockLedgerAndSub(ledgerDate, orderOutLedger, stockSubLedger);
      //创建商品调入单数组
      String[] orderInLedger = new String[stockLedger.length];
      System.arraycopy(stockLedger, 0, orderInLedger, 0, stockLedger.length);
      //更新商品调入单数组，3表示商品调入单
      orderInLedger[0] = stockLedger[2];
      orderInLedger[1] = "3";
      orderInLedger[2] = stockLedger[0];     //调出单的关联标识
      orderInLedger[4] = stockLedger[8];     //调出仓库
      //将调出单的仓库字段放入调入单
      orderInLedger[8] = stockLedger[4];     //调入仓库
      //取得商品调入单明细数组
      String[][] orderInSubLedger = stockManagementData.
          getStockSubLedgerByOrderId(ledgerDate, orderInLedger[0]);
      //更新商品调入单明细数组
      for(int i = 0; i < orderInSubLedger.length; i++){
        orderInSubLedger[i][2] = stockSubLedger[i][2];
        orderInSubLedger[i][3] = stockSubLedger[i][3];
        //将商品数量更改为正数
        orderInSubLedger[i][4] = String.valueOf(-Integer.parseInt(stockSubLedger[i][4]));
        orderInSubLedger[i][5] = stockSubLedger[i][5];
      }
      //更新商品调入单
      stockManagementData.updateStockLedgerAndSub(ledgerDate, orderInLedger, orderInSubLedger);
      result = 1;
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return result;
  }
  //撤消或者恢复商品调拔单的方法
  public int cancelOrRestoreTransferOrder(String ledgerDate, String inOrderId,
                                  String outOrderId, int onProcess, String remark){
    int result = 0;
    try{
      if(onProcess == 0){
        //恢复调入单
        stockManagementData.restoreStockLedgerAndSub(ledgerDate, inOrderId, remark);
        //恢复调出单
        stockManagementData.restoreStockLedgerAndSub(ledgerDate, outOrderId, remark);
      }else{
        //取消调入单
        stockManagementData.cancelStockLedgerAndSub(ledgerDate, inOrderId, remark);
        //取消调出单
        stockManagementData.cancelStockLedgerAndSub(ledgerDate, outOrderId, remark);
      }
      result = 1;
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return result;
  }
  //库存账套数据表电子签名和更新完成状态的方法
  public int signStockLedgerAndSubForFinish(String ledgerDate, String fieldName,
                                            String userName, String orderId,
                                            int onProcess, String remark) {
    int result = 0;
    try{
      result = stockManagementData.signStockLedgerAndSubForFinish(ledgerDate,
          fieldName, userName, orderId, onProcess, remark);
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return result;
  }
  //创建商品分拆单的方法
  public int createRearrangeOrder(String ledgerDate, String[] stockLedger,
                                  String[][] stockSubLedgerOut, String[][] stockSubLedgerIn){
    int result = 0;
    try{
      //创建商品分拆调入单数组
     String[] orderInLedger = new String[stockLedger.length];
     System.arraycopy(stockLedger, 0, orderInLedger, 0, stockLedger.length);
      //创建商品分拆调入单
      stockManagementData.createStockLedgerAndSub(ledgerDate, orderInLedger, stockSubLedgerIn);
      //根据商品组合管理用户名字取得商品分拆调入单,10表示商品分拆调入单
      String[][] orderInLedgers = stockManagementData.
          getStockLedgerByStringField(ledgerDate, "submitUser", stockLedger[3], 10);
      //取得商品分拆调入单标识，最后一条记录便是新创建的商品分拆调入单
      String orderInId = orderInLedgers[orderInLedgers.length -1][0];
      //创建商品分拆调出单数组
      String[] orderOutLedger = new String[stockLedger.length];
      System.arraycopy(stockLedger, 0, orderOutLedger, 0, stockLedger.length);
      //更新商品分拆调出单数组，将商品调入单标识放在供应商字段，9表示商品分拆调出单
      orderOutLedger[2] = orderInId;
      orderOutLedger[1] = "9";
      orderOutLedger[4] = stockLedger[8];         //调入仓库
      orderOutLedger[8] = stockLedger[4];         //调出仓库
      //创建商品分拆调出单
      stockManagementData.createStockLedgerAndSub(ledgerDate, orderOutLedger, stockSubLedgerOut);
      //根据商品组合管理用户名字取得商品分拆调出单
      String[][] orderOutLedgers = stockManagementData.
          getStockLedgerByStringField(ledgerDate, "submitUser", orderOutLedger[3], 9);
      //取得商品分拆调出单标识，最后一条记录便是新创建的商品分拆调出单
      String orderOutId = orderOutLedgers[orderOutLedgers.length -1][0];
      //更新商品分拆调入单数组的标识和关联标识
      orderInLedger[0] = orderInId;
      orderInLedger[2] = orderOutId;
      //根据标识重新取得商品分拆调入单明细数组
      String[][] orderInSubLedger = stockManagementData.getStockSubLedgerByOrderId(
          ledgerDate, orderInLedger[0]);
      //更新商品分拆调入单,将调出单的关联标识写入调入单
      stockManagementData.updateStockLedgerAndSub(ledgerDate, orderInLedger, orderInSubLedger);
      result = 1;
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return result;
  }
  //更新商品分拆单的方法
  public int updateRearrangeOrder(String ledgerDate, String[] stockLedger,
                                  String[][] stockSubLedgerOut, String[][] stockSubLedgerIn){
    int result = 0;
    try{
      //更新商品分拆调入单
      stockManagementData.updateStockLedgerAndSub(ledgerDate, stockLedger, stockSubLedgerIn);
      //创建商品分拆调出单数组
      String[] orderOutLedger = new String[stockLedger.length];
      System.arraycopy(stockLedger, 0, orderOutLedger, 0, stockLedger.length);
      //更新商品分拆调出单数组，9表示调出单
      orderOutLedger[0] = stockLedger[2];
      orderOutLedger[1] = "9";
      orderOutLedger[2] = stockLedger[0];     //调出单的关联标识
      orderOutLedger[4] = stockLedger[8];     //调入仓库
      orderOutLedger[8] = stockLedger[4];     //调出仓库
      //更新商品分拆调出单
      stockManagementData.updateStockLedgerAndSub(ledgerDate, orderOutLedger, stockSubLedgerOut);
      result = 1;
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return result;
  }
  //撤消或者恢复商品分拆或者组合单的方法
  public int cancelOrRestoreRearrangeOrder(String ledgerDate, String inOrderId,
                                           String outOrderId, String userName,
                                           int onProcess, String remark) {
    int result = 0;
    try{
      if(onProcess == 2){
        //恢复调入单
        stockManagementData.signStockLedgerAndSubForFinish(ledgerDate,
            "submitUser", userName, inOrderId, 2, remark);
        //恢复调出单
        stockManagementData.signStockLedgerAndSubForFinish(ledgerDate,
            "submitUser", userName, outOrderId, 2, remark);
      }else{
        //取消调入单
        stockManagementData.cancelStockLedgerAndSub(ledgerDate, inOrderId, remark);
        //取消调出单
        stockManagementData.cancelStockLedgerAndSub(ledgerDate, outOrderId, remark);
      }
      result = 1;
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return result;
  }
  //创建商品组合单的方法
  public int createCombineOrder(String ledgerDate, String[] stockLedger,
                                  String[][] stockSubLedgerOut, String[][] stockSubLedgerIn){
    int result = 0;
    try{
      //创建商品组合调入单数组
     String[] orderInLedger = new String[stockLedger.length];
     System.arraycopy(stockLedger, 0, orderInLedger, 0, stockLedger.length);
      //创建商品组合调入单
      stockManagementData.createStockLedgerAndSub(ledgerDate,
                                                  orderInLedger, stockSubLedgerIn);
      //根据商品组合管理用户名字取得商品组合调入单,12表示商品组合调入单
      String[][] orderInLedgers = stockManagementData.
          getStockLedgerByStringField(ledgerDate, "submitUser", stockLedger[3], 12);
      //取得商品组合调入单标识，最后一条记录便是新创建的商品组合调入单
      String orderInId = orderInLedgers[orderInLedgers.length -1][0];
      //创建商品组合调出单数组
      String[] orderOutLedger = new String[stockLedger.length];
      System.arraycopy(stockLedger, 0, orderOutLedger, 0, stockLedger.length);
      //更新商品组合调出单数组，将商品调入单标识放在供货商字段，11表示商品组合调出单
      orderOutLedger[2] = orderInId;
      orderOutLedger[1] = "11";
      orderOutLedger[4] = stockLedger[8];         //调入仓库
      orderOutLedger[8] = stockLedger[4];         //调出仓库
      //创建商品组合调出单
      stockManagementData.createStockLedgerAndSub(ledgerDate,
                                                  orderOutLedger, stockSubLedgerOut);
      //根据商品组合管理用户名字取得商品组合调出单
      String[][] orderOutLedgers = stockManagementData.
          getStockLedgerByStringField(ledgerDate, "submitUser", orderOutLedger[3], 11);
      //取得商品组合调出单标识，最后一条记录便是新创建的商品组合调出单
      String orderOutId = orderOutLedgers[orderOutLedgers.length -1][0];
      //更新商品组合调入单数组的标识和关联标识
      orderInLedger[0] = orderInId;
      orderInLedger[2] = orderOutId;
      //根据标识重新取得商品组合调入单明细数组
      String[][] orderInSubLedger = stockManagementData.getStockSubLedgerByOrderId(
          ledgerDate, orderInLedger[0]);
      //更新商品组合调入单,将调出单的关联标识写入调入单
      stockManagementData.updateStockLedgerAndSub(ledgerDate,
                                                  orderInLedger, orderInSubLedger);
      result = 1;
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return result;
  }
  //更新商品组合单的方法
  public int updateCombineOrder(String ledgerDate, String[] stockLedger,
                                  String[][] stockSubLedgerOut, String[][] stockSubLedgerIn){
    int result = 0;
    try{
      //更新商品组合调入单
      stockManagementData.updateStockLedgerAndSub(ledgerDate,
                                                  stockLedger, stockSubLedgerIn);
      //创建商品组合调出单数组
      String[] orderOutLedger = new String[stockLedger.length];
      System.arraycopy(stockLedger, 0, orderOutLedger, 0, stockLedger.length);
      //更新商品组合调出单数组，11表示调出单
      orderOutLedger[0] = stockLedger[2];
      orderOutLedger[1] = "11";
      orderOutLedger[2] = stockLedger[0];     //调出单的关联标识
      orderOutLedger[4] = stockLedger[8];     //调入仓库
      orderOutLedger[8] = stockLedger[4];     //调出仓库
      //更新商品组合调出单
      stockManagementData.updateStockLedgerAndSub(ledgerDate,
                                                  orderOutLedger, stockSubLedgerOut);
      result = 1;
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return result;
  }
  //根据仓库名字取得盘点数据的方法
  public String[][] getStocktakeQuantityByWarehouse(String ledgerDate, String warehouse, int onProcess) {
    String[][] data = new String[0][2];
    try {
      data = stockManagementData.getStocktakeQuantityByWarehouse(ledgerDate,
          warehouse, onProcess);
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    return data;
  }
  //根据仓库名字汇总显示商品数量和金额的方法
  public String[][] getStockByWarehouse(String ledgerDate, String warehouse, int onProcess) {
    String[][] data = new String[0][5];
    try {
      data = stockManagementData.getStockByWarehouse(ledgerDate, warehouse, onProcess);
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    return data;
  }
  //根据商品条形码汇总显示商品在各个仓库的数量和金额的方法
  public String[][] getStockByGoodsBarcode(String ledgerDate, String goodsBarcode, int onProcess) {
    String[][] data = new String[0][5];
    try {
      data = stockManagementData.getStockByGoodsBarcode(ledgerDate, goodsBarcode, onProcess);
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    return data;
  }
  //查询过期商品的方法
  public String[][] getStockByUsefulLife(String ledgerDate, String usefulLife, int onProcess) {
    String[][] data = new String[0][6];
    try {
      data = stockManagementData.getStockByUsefulLife(ledgerDate, usefulLife, onProcess);
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    return data;
  }
  //创建销售账套数据表和销售账套明细数据表记录的方法
  public int createSaleLedgerAndSub(String ledgerDate, String[] saleLedger,
                                    String[][] saleSubLedger) {
    int result = 0;
    try{
      result = stockManagementData.createSaleLedgerAndSub(ledgerDate,
          saleLedger, saleSubLedger);
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return result;
  }
  //更新销售账套数据表和销售账套明细数据表记录的方法
  public int updateSaleLedgerAndSub(String ledgerDate, String[] saleLedger,
                                    String[][] saleSubLedger) {
    int result = 0;
    try{
      result = stockManagementData.updateSaleLedgerAndSub(ledgerDate,
          saleLedger, saleSubLedger);
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return result;
  }
  //销售账套数据表电子签名和更新完成状态的方法
  public int signSaleLedgerAndSub(String ledgerDate, String fieldName,
                                  String userName, String saleId, int onProcess,
                                  String remark) {
    int result = 0;
    try{
      result = stockManagementData.signSaleLedgerAndSub(ledgerDate, fieldName,
          userName, saleId, onProcess, remark);
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return result;
  }
  //根据单据编号取得销售账套明细数据表的记录
  public String[][] getSaleSubLedgerBySaleId(String ledgerDate, String saleId) {
    String[][] data = new String[0][5];
    try {
      data = stockManagementData.getSaleSubLedgerBySaleId(ledgerDate, saleId);
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    return data;
  }
  //根据字符串字段取得销售账套数据表记录的方法
  public String[][] getSaleLedgerByStringField(String ledgerDate,
                                               String fieldName,
                                               String fieldValue, int saleType) {
    String[][] data = new String[0][11];
    try {
      data = stockManagementData.getSaleLedgerByStringField(ledgerDate,
          fieldName, fieldValue, saleType);
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    return data;
  }
  //根据完成状态取得销售账套数据表记录的方法
  public String[][] getSaleLedgerByOnProcess(String ledgerDate, int saleType,
                                             int onProcess) {
    String[][] data = new String[0][11];
    try {
      data = stockManagementData.getSaleLedgerByOnProcess(ledgerDate, saleType,
          onProcess);
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    return data;
  }
  //根据订单日期取得销售账套数据表记录的方法
  public String[][] getSaleLedgerByOrderDate(String ledgerDate,
                                             java.sql.Timestamp startDate,
                                             java.sql.Timestamp endDate,
                                             int saleType) {
    String[][] data = new String[0][11];
    try {
      data = stockManagementData.getSaleLedgerByOrderDate(ledgerDate, startDate,
          endDate, saleType);
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    return data;
  }
  //前台销售员进行销售账套数据表电子签名的方法
  public int counterUserSignSaleLedgerAndSub(String ledgerDate, String userName,
                                             String remark, String warehouse) {
    int result = 0;
    try{
      result = stockManagementData.counterUserSignSaleLedgerAndSub(ledgerDate,
          userName, remark, warehouse);
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return result;
  }
  //根据商品的条形码取得销售价和折扣
  public double[] getGoodsPriceAndDiscount(String goodsBarcode){
    double[] data = new double[2];
    data[0] = 0;
    data[1] = 0;
    try{
      //取得商品数据
      String[][] goods = stockManagementData.getGoodsByGoodsBarCode(
          goodsBarcode);
      if(goods.length == 1){
        data[0] = Double.parseDouble(goods[0][11]);
        data[1] = Double.parseDouble(goods[0][12]);
      }
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return data;
  }
  //根据条形码、仓库取得商品的数量，然后检查卖出商品的数量是否足够
  public int checkGoodsSaleQuantity(String ledgerDate, String goodsBarcode,
                                    int saleQuantity, String warehouse) {
    int result = 0;
    try{
      //取得商品的库存数组
      String[][] data = stockManagementData.getStocktakeQuantityByWarehouse(ledgerDate, warehouse, 2);
      int stockQuantity = 0;
      for(int i = 0; i < data.length; i++){
        if(data[i][0].equals(goodsBarcode)){
          stockQuantity = Integer.parseInt(data[i][1]);
          break;
        }
      }
      //如果库存数大于等于销售数返回1，否则返回0
      if(stockQuantity >= saleQuantity){
        result = 1;
      }
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return result;
  }
  //信用销售用户进行销售账套数据表电子签名的方法
  public int creditUserSignSaleLedgerAndSub(String ledgerDate, String userName,
                                            String remark, String warehouse,
                                            String saleId, String customerName) {
    int result = 0;
   try{
     result = stockManagementData.creditUserSignSaleLedgerAndSub(ledgerDate,
         userName, remark, warehouse, saleId, customerName);
   }catch(Exception ex){
     ex.printStackTrace();
   }
   return result;
  }
  //检查客户的方法
  public int checkCustomer(String customerName){
    int result = 0;
    String[][] detail = this.getCustomersByCustomerName(customerName);
    for(int i = 0; i < detail.length; i++){
      if(detail[i][0].equals(customerName)){
        result = 1;
        break;
      }
    }
    return result;
  }
  //检查客户信用限额的方法
  public int checkCustomerCreditLimit(String customerName, double amount){
    int result = 0;
    double creditLimit = 0;
    String[][] detail = this.getCustomersByCustomerName(customerName);
    for(int i = 0; i < detail.length; i++){
      if(detail[i][0].equals(customerName)){
        creditLimit = Double.parseDouble(detail[i][15]);
        //如果客户信用限额大于或者等于客户单次购买的金额，通过测试
        if(creditLimit >= amount){
          result = 1;
        }
        break;
      }
    }
    return result;
  }
  //现金管理员对应收票据进行电子签名的方法
  public int cashUserSignAccountReceivable(String ledgerDate, String userName,
                                           String[] currentAccountLedger) {
    int result = 0;
    try{
      result = stockManagementData.cashUserSignAccountReceivable(ledgerDate,
          userName, currentAccountLedger);
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return result;
  }
  //根据关联标识、退货单的商品条形码取得库存账套的销售出库单明细账的数据
  public String[][] getStockSaleOutBySaleOrderLink(String ledgerDate,
      String saleOrderLink, String saleId) {
    String[][] data = new String[0][4];
    try {
      data = stockManagementData.getStockSaleOutBySaleOrderLink(ledgerDate,
          saleOrderLink, saleId);
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
    return data;
  }
  //前台销售员进行销售退货单电子签名的方法
  public int counterUserSignSaleReturn(String ledgerDate, String saleId,
                                       String userName, String remark,
                                       String warehouse,
                                       String[][] stockSubLedger) {
    int result = 0;
    try{
      result = stockManagementData.counterUserSignSaleReturn(ledgerDate, saleId,
          userName, remark, warehouse, stockSubLedger);
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return result;
  }
  //信用销售员进行信用销售退货单电子签名的方法
  public int creditUserSignSaleReturn(String ledgerDate, String saleId,
                                      String userName, String remark,
                                      String warehouse, String customerName,
                                      String[][] stockSubLedger, boolean isPay) {
    int result = 0;
    try{
      result = stockManagementData.creditUserSignSaleReturn(ledgerDate, saleId,
          userName, remark, warehouse, customerName, stockSubLedger, isPay);
    }catch(Exception ex){
      ex.printStackTrace();
    }
    return result;
  }
}
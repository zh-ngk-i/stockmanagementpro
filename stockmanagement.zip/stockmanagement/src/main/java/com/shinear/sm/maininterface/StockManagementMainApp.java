﻿package com.shinear.sm.maininterface;

import javax.swing.UIManager;
import java.awt.*;

public class StockManagementMainApp {

  public StockManagementMainApp() {
    //创建窗口类
    StockManagementMainFrame frame = new StockManagementMainFrame();
    //取得屏幕大小和窗口大小
    Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
    Dimension frameSize = frame.getSize();
    //使窗口居中对齐
    if (frameSize.height > screenSize.height) {
      frameSize.height = screenSize.height;
    }
    if (frameSize.width > screenSize.width) {
      frameSize.width = screenSize.width;
    }
    frame.setLocation( (screenSize.width - frameSize.width) / 2,
                      (screenSize.height - frameSize.height) / 2);
    frame.setVisible(true);
  }
  public static void main(String[] args) {
    try {
      UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
    }
    catch(Exception e) {
      e.printStackTrace();
    }
    new StockManagementMainApp();
  }
}
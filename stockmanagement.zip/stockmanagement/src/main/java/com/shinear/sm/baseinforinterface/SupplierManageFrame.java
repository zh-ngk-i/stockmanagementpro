﻿package com.shinear.sm.baseinforinterface;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import com.shinear.sm.data.*;
import com.shinear.sm.maininterface.*;
import com.shinear.sm.user.*;

public class SupplierManageFrame extends JFrame implements ActionListener {
  JPanel contentPane;
  //创建滚动框
  JScrollPane jScrollPane1 = new JScrollPane();
  JScrollPane jScrollPane2 = new JScrollPane();
  //创建列表框数据类和列表框控件
  DefaultListModel listData1 = new DefaultListModel();
  JList jList1 = new JList(listData1);
  //创建下拉列表框控件
  JComboBox jComboBox1 = new JComboBox();
  //创建标签控件
  JLabel jLabel1 = new JLabel();
  JLabel jLabel2 = new JLabel();
  JLabel jLabel3 = new JLabel();
  JLabel jLabel4 = new JLabel();
  JLabel jLabel5 = new JLabel();
  JLabel jLabel6 = new JLabel();
  JLabel jLabel7 = new JLabel();
  JLabel jLabel8 = new JLabel();
  JLabel jLabel9 = new JLabel();
  JLabel jLabel10 = new JLabel();
  JLabel jLabel11 = new JLabel();
  JLabel jLabel12 = new JLabel();
  JLabel jLabel13 = new JLabel();
  JLabel jLabel14 = new JLabel();
  JLabel jLabel15 = new JLabel();
  JLabel jLabel16 = new JLabel();
  JLabel jLabel17 = new JLabel();
  JLabel jLabel18 = new JLabel();
  //创建编辑框控件
  JTextField jTextField1 = new JTextField();
  JTextField jTextField2 = new JTextField();
  JTextField jTextField3 = new JTextField();
  JTextField jTextField4 = new JTextField();
  JTextField jTextField5 = new JTextField();
  JTextField jTextField6 = new JTextField();
  JTextField jTextField7 = new JTextField();
  JTextField jTextField8 = new JTextField();
  JTextField jTextField9 = new JTextField();
  JTextField jTextField10 = new JTextField();
  JTextField jTextField11 = new JTextField();
  JTextField jTextField12 = new JTextField();
  JTextField jTextField13 = new JTextField();
  JTextField jTextField14 = new JTextField();
  JTextField jTextField15 = new JTextField();
  JTextField jTextField16 = new JTextField();
  //创建文本框控件
  JTextArea jTextArea1 = new JTextArea();
  //创建按钮控件
  JButton jButton1 = new JButton();
  JButton jButton2 = new JButton();
  JButton jButton3 = new JButton();
  JButton jButton4 = new JButton();
  JButton jButton5 = new JButton();
  JButton jButton6 = new JButton();
  JButton jButton7 = new JButton();
  //创建字体类
  Font dialog13 = new java.awt.Font("Dialog", 0, 13);
  //声明数据类
  StockManagementData stockManagementData = null;
  //声明用户类
  User user = null;
  //声明主窗口类
  StockManagementMainFrame stockManagementMainFrame = null;
  //创建供应商数组
  String[][] supplier = new String[0][16];
  //创建动作字符串
  String action = "";

  public SupplierManageFrame(StockManagementMainFrame stockManagementMainFrame) {
    this.stockManagementMainFrame = stockManagementMainFrame;
    //取得主窗口的数据类
    stockManagementData = stockManagementMainFrame.getStockManagementData();
    //取得主窗口的用户类
    user = stockManagementMainFrame.getUser();
    //取得基础信息模块的用户权限
    int baseInforFunction = user.getBaseInforFunction();
    //检查用户权限
    if((baseInforFunction & 32) != 32){
      JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
      System.exit(0);
    }
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception  {
    contentPane = (JPanel) this.getContentPane();
    contentPane.setLayout(null);
    this.setSize(new Dimension(624, 571));
    this.setTitle("供应商数据管理窗口");
    //设置标签控件属性
    jLabel1.setText("供应商列表：");
    jLabel1.setBounds(new Rectangle(24, 21, 78, 16));
    jLabel2.setText("供应商名字");
    jLabel2.setBounds(new Rectangle(202, 88, 70, 16));
    jLabel3.setText("地区");
    jLabel3.setBounds(new Rectangle(404, 88, 45, 16));
    jLabel4.setText("拼音码");
    jLabel4.setBounds(new Rectangle(202, 127, 70, 16));
    jLabel5.setText("简称");
    jLabel5.setBounds(new Rectangle(404, 127, 45, 16));
    jLabel6.setText("联系电话");
    jLabel6.setBounds(new Rectangle(202, 166, 70, 16));
    jLabel7.setText("联系人");
    jLabel7.setBounds(new Rectangle(404, 166, 45, 16));
    jLabel8.setText("手机");
    jLabel8.setBounds(new Rectangle(202, 205, 70, 16));
    jLabel9.setText("传真");
    jLabel9.setBounds(new Rectangle(404, 205, 45, 16));
    jLabel10.setText("固定电话");
    jLabel10.setBounds(new Rectangle(202, 243, 70, 16));
    jLabel11.setText("邮编");
    jLabel11.setBounds(new Rectangle(404, 243, 45, 16));
    jLabel12.setText("地址");
    jLabel12.setBounds(new Rectangle(202, 282, 70, 16));
    jLabel13.setText("银行账号");
    jLabel13.setBounds(new Rectangle(404, 321, 53, 16));
    jLabel14.setText("开户银行");
    jLabel14.setBounds(new Rectangle(202, 321, 70, 16));
    jLabel15.setText("电子邮件");
    jLabel15.setBounds(new Rectangle(202, 360, 70, 16));
    jLabel16.setText("网址");
    jLabel16.setBounds(new Rectangle(404, 363, 60, 16));
    jLabel17.setText("备注");
    jLabel17.setBounds(new Rectangle(202, 399, 40, 16));
    jLabel18.setText("查询条件：");
    jLabel18.setBounds(new Rectangle(202, 49, 67, 16));
    //设置编辑框控件属性
    jTextField1.setBounds(new Rectangle(272, 88, 114, 22));
    jTextField2.setBounds(new Rectangle(471, 88, 114, 22));
    jTextField3.setBounds(new Rectangle(272, 127, 114, 22));
    jTextField4.setBounds(new Rectangle(471, 127, 114, 22));
    jTextField5.setBounds(new Rectangle(272, 166, 114, 22));
    jTextField6.setBounds(new Rectangle(471, 166, 114, 22));
    jTextField7.setBounds(new Rectangle(272, 205, 114, 22));
    jTextField8.setBounds(new Rectangle(471, 205, 114, 22));
    jTextField9.setBounds(new Rectangle(272, 243, 114, 22));
    jTextField10.setBounds(new Rectangle(272, 282, 313, 22));
    jTextField11.setBounds(new Rectangle(471, 243, 114, 22));
    jTextField12.setBounds(new Rectangle(272, 319, 114, 22));
    jTextField13.setBounds(new Rectangle(471, 318, 114, 22));
    jTextField14.setBounds(new Rectangle(272, 361, 114, 22));
    jTextField15.setBounds(new Rectangle(471, 360, 114, 22));
    jTextField16.setBounds(new Rectangle(417, 49, 83, 22));
    //设置按钮控件属性
    jButton1.setText("查询");
    jButton1.setActionCommand("search");
    jButton1.setBounds(new Rectangle(517, 49, 68, 25));
    jButton2.setText("创建");
    jButton2.setActionCommand("create");
    jButton2.setBounds(new Rectangle(206, 485, 62, 25));
    jButton3.setText("修改");
    jButton3.setActionCommand("update");
    jButton3.setBounds(new Rectangle(269, 485, 62, 25));
    jButton4.setText("删除");
    jButton4.setActionCommand("delete");
    jButton4.setBounds(new Rectangle(333, 485, 62, 25));
    jButton5.setText("确定");
    jButton5.setActionCommand("ok");
    jButton5.setEnabled(false);
    jButton5.setBounds(new Rectangle(396, 485, 62, 25));
    jButton6.setText("取消");
    jButton6.setEnabled(false);
    jButton6.setActionCommand("cancel");
    jButton6.setBounds(new Rectangle(460, 485, 62, 25));
    jButton7.setText("退出");
    jButton7.setActionCommand("exit");
    jButton7.setBounds(new Rectangle(523, 485, 62, 25));
    //设置下拉列表框
    jComboBox1.setBounds(new Rectangle(272, 49, 139, 22));
    jComboBox1.addItem("按供应商名字查询");
    jComboBox1.addItem("按地区查询");
    //设置滚动框控件属性
    jScrollPane1.setBounds(new Rectangle(23, 49, 166, 461));
    jScrollPane2.setBounds(new Rectangle(272, 397, 314, 67));
    jScrollPane1.getViewport().add(jList1, null);
    jScrollPane2.getViewport().add(jTextArea1, null);
    //为列表框加入选择接收器
    jList1.addListSelectionListener(new ListSelectionListener() {
      public void valueChanged(ListSelectionEvent e) {
        jList1_valueChanged(e);
      }
    });
    //为面板加入控件
    contentPane.add(jLabel1, null);
    contentPane.add(jLabel2, null);
    contentPane.add(jLabel3, null);
    contentPane.add(jLabel4, null);
    contentPane.add(jLabel5, null);
    contentPane.add(jLabel6, null);
    contentPane.add(jLabel7, null);
    contentPane.add(jLabel8, null);
    contentPane.add(jLabel9, null);
    contentPane.add(jLabel10, null);
    contentPane.add(jLabel11, null);
    contentPane.add(jLabel12, null);
    contentPane.add(jLabel13, null);
    contentPane.add(jLabel14, null);
    contentPane.add(jLabel15, null);
    contentPane.add(jLabel16, null);
    contentPane.add(jLabel17, null);
    contentPane.add(jLabel18, null);
    contentPane.add(jTextField1, null);
    contentPane.add(jTextField2, null);
    contentPane.add(jTextField3, null);
    contentPane.add(jTextField4, null);
    contentPane.add(jTextField5, null);
    contentPane.add(jTextField6, null);
    contentPane.add(jTextField7, null);
    contentPane.add(jTextField8, null);
    contentPane.add(jTextField9, null);
    contentPane.add(jTextField10, null);
    contentPane.add(jTextField11, null);
    contentPane.add(jTextField12, null);
    contentPane.add(jTextField13, null);
    contentPane.add(jTextField14, null);
    contentPane.add(jTextField15, null);
    contentPane.add(jTextField16, null);
    contentPane.add(jScrollPane1, null);
    contentPane.add(jScrollPane2, null);
    contentPane.add(jComboBox1, null);
    contentPane.add(jButton1, null);
    contentPane.add(jButton2, null);
    contentPane.add(jButton3, null);
    contentPane.add(jButton4, null);
    contentPane.add(jButton5, null);
    contentPane.add(jButton6, null);
    contentPane.add(jButton7, null);
    //设置窗口类的字体和为按钮加入动作接收器
    setupFontAndListener();
  }
  //设置窗口类的字体和为按钮加入动作接收器的方法
  public void setupFontAndListener(){
    Component[] components = contentPane.getComponents();
    //创建临时按钮控件
    JButton tmpBtn = new JButton();
    for(int i = 0; i < components.length; i++){
      components[i].setFont(dialog13);
      if(components[i].getClass().getName().equals("javax.swing.JButton")){
        tmpBtn = (JButton)components[i];
        tmpBtn.addActionListener(this);
      }
    }
  }
  //退出方法
  public void exit(){
    //隐藏窗口
    this.setVisible(false);
    //清空数组的内容
    supplier = new String[0][16];
    //清空列表框的内容
    listData1.clear();
    //取得面板上的所有控件
    Component[] components = contentPane.getComponents();
    //创建临时文本框控件
    JTextField tmpTextField = new JTextField();
    for(int i = 0; i < components.length; i++){
      if(components[i].getClass().getName().equals("javax.swing.JTextField")){
        tmpTextField = (JTextField)components[i];
        //清空编辑框的内容
        tmpTextField.setText("");
      }
    }
  }
  //显示查询供应商的方法
  public void showSearchSupplier(){
    listData1.clear();
    //为供应商列表框加入供应商数据
    for(int i = 0; i < supplier.length; i++){
      listData1.addElement(supplier[i][0]);
    }
  }
  //显示单个供应商的方法
  public void showSupplier(){
    //取得当前选择项的位置
    int selectedIndex = jList1.getSelectedIndex();
    //当列表框不处于选择状态，不显示数据
    if(selectedIndex == -1){
       return;
    }
    //显示供应商的数据
    jTextField1.setText(supplier[selectedIndex][0]);
    jTextField2.setText(supplier[selectedIndex][1]);
    jTextField3.setText(supplier[selectedIndex][2]);
    jTextField4.setText(supplier[selectedIndex][3]);
    jTextField5.setText(supplier[selectedIndex][4]);
    jTextField6.setText(supplier[selectedIndex][5]);
    jTextField7.setText(supplier[selectedIndex][6]);
    jTextField8.setText(supplier[selectedIndex][7]);
    jTextField9.setText(supplier[selectedIndex][8]);
    jTextField10.setText(supplier[selectedIndex][9]);
    jTextField11.setText(supplier[selectedIndex][10]);
    jTextField12.setText(supplier[selectedIndex][11]);
    jTextField13.setText(supplier[selectedIndex][12]);
    jTextField14.setText(supplier[selectedIndex][13]);
    jTextField15.setText(supplier[selectedIndex][14]);
    jTextArea1.setText(supplier[selectedIndex][15]);
  }
  //清空单个供应商显示的方法
  public void clearSupplier(){
    jTextField1.setText("");
    jTextField2.setText("");
    jTextField3.setText("");
    jTextField4.setText("");
    jTextField5.setText("");
    jTextField6.setText("");
    jTextField7.setText("");
    jTextField8.setText("");
    jTextField9.setText("");
    jTextField10.setText("");
    jTextField11.setText("");
    jTextField12.setText("");
    jTextField13.setText("");
    jTextField14.setText("");
    jTextField15.setText("");
    jTextArea1.setText("");
  }
  //设置用户的方法
  public void setUser(User user) {
    this.user = user;
  }
  protected void processWindowEvent(WindowEvent e) {
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      exit();
    }
  }
  //检查按钮的状态
  public void checkBtn(boolean isManipulated){
    if(isManipulated){
      jButton2.setEnabled(false);
      jButton3.setEnabled(false);
      jButton4.setEnabled(false);
      jButton5.setEnabled(true);
      jButton6.setEnabled(true);
    }else{
      jButton2.setEnabled(true);
      jButton3.setEnabled(true);
      jButton4.setEnabled(true);
      jButton5.setEnabled(false);
      jButton6.setEnabled(false);
    }
  }
  //列表1的选择事件
  void jList1_valueChanged(ListSelectionEvent e) {
    if(listData1.size() > 0){
      this.showSupplier();
    }else{
      this.clearSupplier();
    }
  }
  //查询方法
  public void search(){
    //取得查询选项
    int selectedIndex = jComboBox1.getSelectedIndex();
    String searchValue = jTextField16.getText().trim();
    switch (selectedIndex) {
      case 0:
        //根据供应商名字取得记录
        supplier = stockManagementData.getSuppliersBySupplierName(searchValue);
        break;
      case 1:
        //根据地区取得记录
        supplier = stockManagementData.getSuppliersBySupplierZone(searchValue);
        break;
    }
    this.showSearchSupplier();
  }
  //单击事件方法
  public void actionPerformed(ActionEvent e) {
    //取得按钮的动作字符串
    String actionCommand = e.getActionCommand().trim();
    if(actionCommand.equals("update") | actionCommand.equals("delete")){
      if(jList1.isSelectionEmpty()){
        JOptionPane.showMessageDialog(null, "请选择供应商.");
        return;
      }
    }
    //单击按钮的处理代码
    if (actionCommand.equals("search")) {
      String searchValue = jTextField16.getText().trim();
      if(searchValue.length() == 0){
        JOptionPane.showMessageDialog(null, "请输入查询值");
        return;
      }
      //查询
      search();
    }else if(actionCommand.equals("create")){
      action = "create";
      this.clearSupplier();
      this.checkBtn(true);
    }else if(actionCommand.equals("update")){
      action = "update";
      this.checkBtn(true);
    }else if(actionCommand.equals("delete")){
      action = "delete";
      this.checkBtn(true);
    }else if(actionCommand.equals("ok")){
      //取得供应商的值
      String[] supplierArray = new String[16];
      supplierArray[0] = jTextField1.getText().trim();
      supplierArray[1] = jTextField2.getText().trim();
      supplierArray[2] = jTextField3.getText().trim();
      supplierArray[3] = jTextField4.getText().trim();
      supplierArray[4] = jTextField5.getText().trim();
      supplierArray[5] = jTextField6.getText().trim();
      supplierArray[6] = jTextField7.getText().trim();
      supplierArray[7] = jTextField8.getText().trim();
      supplierArray[8] = jTextField9.getText().trim();
      supplierArray[9] = jTextField10.getText().trim();
      supplierArray[10] = jTextField11.getText().trim();
      supplierArray[11] = jTextField12.getText().trim();
      supplierArray[12] = jTextField13.getText().trim();
      supplierArray[13] = jTextField14.getText().trim();
      supplierArray[14] = jTextField15.getText().trim();
      supplierArray[15] = jTextArea1.getText().trim();
      if(supplierArray[0].length() == 0){
        JOptionPane.showMessageDialog(null, "供应商名字不允许空值.");
        return;
      }
      if(action.equals("create")){
        //创建供应商
        int result = stockManagementData.createSupplier(supplierArray);
        if(result == 1){
          //为列表框加入供应商
          listData1.addElement(supplierArray[0]);
          //更新供应商数组
          String[][] tempStrs = new String[supplier.length + 1][16];
          System.arraycopy(supplier, 0, tempStrs, 0, supplier.length);
          for(int i = 0; i < 16; i++){
            tempStrs[supplier.length][i] = supplierArray[i];
          }
          supplier = tempStrs;
          jList1.setSelectedIndex(listData1.size() -1);
        }else{
          JOptionPane.showMessageDialog(null, "供应商创建失败,请检查该供应商是否存在和值是否超出字段长度.");
        }
      }else if (action.equals("update")){
        //更新供应商
        int result = stockManagementData.updateSupplier(supplierArray);
        if(result == 1){
          //更新供应商数组
          int selectedIndex = jList1.getSelectedIndex();
          for(int i = 0; i < 16; i++){
            supplier[selectedIndex][i] = supplierArray[i];
          }
        }else{
          JOptionPane.showMessageDialog(null, "供应商更新失败.");
        }
      }else if (action.equals("delete")){
        //删除供应商
        int result = stockManagementData.deleteSupplier(supplierArray[0]);
        if(result == 1){
          int selectedIndex = jList1.getSelectedIndex();
          //删除列表框的数据
          listData1.removeElementAt(selectedIndex);
          //更改数组的数据
          String[][] tempStrs = new String[supplier.length -1][16];
          int line = 0;
          for(int i = 0; i < supplier.length; i++){
            if(i == selectedIndex){
              continue;
            }else{
              for(int j = 0; j < 16; j++){
                tempStrs[line][j] = supplier[i][j];
              }
              line++;
            }
          }
          supplier = tempStrs;
          //清空编辑框的值
          this.clearSupplier();
        }else{
          JOptionPane.showMessageDialog(null, "供应商删除失败.");
        }
      }
      this.checkBtn(false);
    }else if(actionCommand.equals("cancel")){
       this.jList1_valueChanged(null);
       this.checkBtn(false);
    }else if(actionCommand.equals("exit")){
      exit();
    }
  }
}
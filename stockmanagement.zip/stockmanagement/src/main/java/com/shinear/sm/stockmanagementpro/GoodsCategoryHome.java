﻿package com.shinear.sm.stockmanagementpro;

import javax.ejb.*;
import java.util.*;

public interface GoodsCategoryHome extends javax.ejb.EJBLocalHome {
  public GoodsCategory create(Integer categoryId, int parentId, String categoryName, String categoryDescription) throws CreateException;
  public Collection findAll() throws FinderException;
  public GoodsCategory findByPrimaryKey(Integer categoryId) throws FinderException;
}
﻿package com.shinear.sm.stockmanagementpro;

import javax.ejb.*;
import java.util.*;
import java.sql.*;

public interface UserLog extends javax.ejb.EJBLocalObject {
  public Integer getId();
  public void setProgramName(String programName);
  public String getProgramName();
  public void setOperationContent(String operationContent);
  public String getOperationContent();
  public void setUserName(String userName);
  public String getUserName();
  public void setOperationDate(Timestamp operationDate);
  public Timestamp getOperationDate();
}
﻿package com.shinear.sm.baseinforinterface;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import com.shinear.sm.data.StockManagementData;
import com.shinear.sm.user.User;
import com.shinear.sm.maininterface.*;
import java.io.*;
import java.util.*;

public class DataBackupFrame extends JFrame implements ActionListener {
  JPanel contentPane;

  //创建标签控件
  JLabel jLabel1 = new JLabel();
  JLabel jLabel2 = new JLabel();
  //创建编辑框控件
  JTextField jTextField1 = new JTextField();
  //创建滚动框控件
  JScrollPane jScrollPane1 = new JScrollPane();
  JScrollPane jScrollPane2 = new JScrollPane();
  JScrollPane jScrollPane3 = new JScrollPane();
  //创建列表框数据类和列表框控件
  DefaultListModel listData1 = new DefaultListModel();
  DefaultListModel listData2 = new DefaultListModel();
  DefaultListModel listData3 = new DefaultListModel();
  JList jList1 = new JList(listData1);
  JList jList2 = new JList(listData2);
  JList jList3 = new JList(listData3);
  //创建按钮控件
  JButton jButton1 = new JButton();
  JButton jButton2 = new JButton();
  JButton jButton3 = new JButton();
  JButton jButton4 = new JButton();
  JButton jButton5 = new JButton();
  JButton jButton6 = new JButton();
  JButton jButton7 = new JButton();
  JButton jButton8 = new JButton();
  //创建字体类
  Font dialog13 = new java.awt.Font("Dialog", 0, 13);
  //声明数据类
  StockManagementData stockManagementData = null;
  //声明用户类
  User user = null;
  //声明主窗口类
  StockManagementMainFrame stockManagementMainFrame = null;

  public DataBackupFrame(StockManagementMainFrame stockManagementMainFrame) {
    this.stockManagementMainFrame = stockManagementMainFrame;
    //取得主窗口的数据类
    stockManagementData = stockManagementMainFrame.getStockManagementData();
    //取得主窗口的用户类
    user = stockManagementMainFrame.getUser();
    //取得基础信息模块的用户权限
    int baseInforFunction = user.getBaseInforFunction();
    //检查用户权限
    if((baseInforFunction & 2) != 2){
      JOptionPane.showMessageDialog(null, user.getUserName() + "用户不具有该权限.");
      System.exit(0);
    }
    try {
      jbInit();
    }
    catch(Exception e) {
      e.printStackTrace();
    }
  }
  private void jbInit() throws Exception  {
    contentPane = (JPanel) this.getContentPane();
    contentPane.setLayout(null);
    this.setSize(new Dimension(668, 601));
    //设置标签控件
    jLabel1.setText("备份文件目录：");
    jLabel1.setBounds(new Rectangle(12, 33, 101, 16));
    jLabel2.setText("信息显示框：");
    jLabel2.setBounds(new Rectangle(455, 76, 92, 16));
    //设置编辑框控件
    jTextField1.setBounds(new Rectangle(123, 29, 428, 22));
    //设置滚动框控件
    jScrollPane1.setBounds(new Rectangle(12, 117, 192, 365));
    jScrollPane2.setBounds(new Rectangle(234, 117, 192, 365));
    jScrollPane3.setBounds(new Rectangle(455, 117, 192, 365));
    jScrollPane3.getViewport().add(jList3, null);
    jScrollPane1.getViewport().add(jList1, null);
    jScrollPane2.getViewport().add(jList2, null);
    //设置列表框的属性，使可以选择列表框的多条记录
    jList1.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
    jList2.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
    //设置按钮控件
    jButton1.setText("选择");
    jButton1.setActionCommand("select");
    jButton1.setBounds(new Rectangle(574, 27, 73, 25));
    jButton2.setText("显示数据表");
    jButton2.setActionCommand("showTable");;
    jButton2.setBounds(new Rectangle(12, 73, 192, 25));
    jButton3.setText("显示备份文件");
    jButton3.setActionCommand("showBackupFile");;
    jButton3.setBounds(new Rectangle(234, 73, 192, 25));
    jButton4.setText("备份选择数据表");
    jButton4.setActionCommand("backupSelectedTables");;
    jButton4.setBounds(new Rectangle(12, 508, 130, 25));
    jButton5.setText("备份全部数据表");
    jButton5.setActionCommand("backupAllTables");;
    jButton5.setBounds(new Rectangle(149, 508, 135, 25));
    jButton6.setText("恢复选择文件");
    jButton6.setActionCommand("restoreSelectedFiles");;
    jButton6.setBounds(new Rectangle(291, 508, 135, 25));
    jButton7.setText("恢复全部文件");
    jButton7.setActionCommand("restoreAllFiles");;
    jButton7.setBounds(new Rectangle(432, 508, 135, 25));
    jButton8.setText("退出");
    jButton8.setActionCommand("exit");;
    jButton8.setBounds(new Rectangle(574, 508, 73, 25));
    contentPane.add(jLabel1, null);
    contentPane.add(jLabel2, null);
    contentPane.add(jTextField1, null);
    contentPane.add(jScrollPane1, null);
    contentPane.add(jScrollPane2, null);
    contentPane.add(jScrollPane3, null);
    contentPane.add(jButton1, null);
    contentPane.add(jButton2, null);
    contentPane.add(jButton3, null);
    contentPane.add(jButton4, null);
    contentPane.add(jButton5, null);
    contentPane.add(jButton6, null);
    contentPane.add(jButton7, null);
    contentPane.add(jButton8, null);
    //设置窗口类的字体和为按钮加入动作接收器
    setupFontAndListener();
  }
  //设置窗口类的字体和为按钮加入动作接收器的方法
  public void setupFontAndListener(){
    Component[] components = contentPane.getComponents();
    //创建临时按钮控件
    JButton tmpBtn = new JButton();
    for(int i = 0; i < components.length; i++){
      components[i].setFont(dialog13);
      if(components[i].getClass().getName().equals("javax.swing.JButton")){
        tmpBtn = (JButton)components[i];
        tmpBtn.addActionListener(this);
      }
    }
  }
  protected void processWindowEvent(WindowEvent e) {
    if (e.getID() == WindowEvent.WINDOW_CLOSING) {
      exit();
    }
  }
  //退出方法
  public void exit(){
    //隐藏窗口
    this.setVisible(false);
    //清空列表框的内容
    listData1.clear();
    listData2.clear();
    listData3.clear();
    //清空编辑框的内容
    jTextField1.setText("");
  }
  //设置用户的方法
  public void setUser(User user) {
    this.user = user;
  }
  public void actionPerformed(ActionEvent e) {
    //取得按钮的动作字符串
    String actionCommand = e.getActionCommand().trim();
    //单击按钮的处理代码
    if (actionCommand.equals("select")) {
      JFileChooser fc1 = new JFileChooser();   //创建文件选择器
      //显示文件选择框
      fc1.showDialog(this, "选择文件");
      try{
        //取得文件类
        File file = fc1.getSelectedFile();
        if(file != null){
          jTextField1.setText(file.getParent());
        }
      }catch(Exception ex){
        ex.printStackTrace();
      }
    }else if(actionCommand.equals("showTable")){
      //清空列表框的内容
      listData1.clear();
      //取得数据库的数据表名字
      String[] tableNames = stockManagementData.getTableNames();
      for(int i = 0; i < tableNames.length; i++){
        listData1.addElement(tableNames[i]);
      }
    }else if(actionCommand.equals("showBackupFile")){
      //清空列表框的内容
      listData2.clear();
      //取得文件路径
      String pathName = jTextField1.getText().trim();
      if(pathName.length() == 0){
        JOptionPane.showMessageDialog(null, "请选择备份文件目录.");
        return;
      }
      //创建文件类
      File file = new File(pathName);
      //取得pathName路径的所有文件
      String[] fileNameList = file.list();
      //显示pathName路径的所有文件
      for(int i = 0; i < fileNameList.length; i++){
        listData2.addElement(fileNameList[i]);
      }
    //单击备份选择数据表按钮的处理代码
    }else if(actionCommand.equals("backupSelectedTables")){
      int[] selectedIndexes = jList1.getSelectedIndices();
      if(selectedIndexes.length == 0){
        JOptionPane.showMessageDialog(null, "请选择数据表.");
        return;
      }
      //取得文件路径
      String pathName = jTextField1.getText().trim();
      if(pathName.length() == 0){
        JOptionPane.showMessageDialog(null, "请选择备份文件目录.");
        return;
      }
      //清空信息列表框的内容
      listData3.clear();
      String tableName = "";
      for(int i = 0; i < selectedIndexes.length; i++){
        //取得选择数据表的名字
        tableName = (String)listData1.getElementAt(selectedIndexes[i]);
        try{
          //备份数据表
          backupTable(tableName, pathName);
        }catch(Exception ex){
          ex.printStackTrace();
        }
      }
    //单击备份所有数据表按钮的处理代码
    }else if(actionCommand.equals("backupAllTables")){
      if(listData1.size() == 0){
        JOptionPane.showMessageDialog(null, "请显示数据表.");
        return;
      }
      //取得文件路径
      String pathName = jTextField1.getText().trim();
      if(pathName.length() == 0){
        JOptionPane.showMessageDialog(null, "请选择备份文件目录.");
        return;
      }
      //清空信息列表框的内容
      listData3.clear();
      String tableName = "";
      for(int i = 0; i < listData1.size(); i++){
        //取得选择数据表的名字
        tableName = (String)listData1.getElementAt(i);
        try{
          //备份数据表
          backupTable(tableName, pathName);
        }catch(Exception ex){
          ex.printStackTrace();
        }
      }
    //单击恢复选择文件按钮的处理代码
    }else if(actionCommand.equals("restoreSelectedFiles")){
      //取得文件路径
      String pathName = jTextField1.getText().trim();
      if(pathName.length() == 0){
        JOptionPane.showMessageDialog(null, "请选择备份文件目录.");
        return;
      }
      int[] selectedIndexes = jList2.getSelectedIndices();
      if(selectedIndexes.length == 0){
        JOptionPane.showMessageDialog(null, "请选择备份文件.");
        return;
      }
      if(listData1.size() == 0){
        JOptionPane.showMessageDialog(null, "请显示数据表.");
        return;
      }
      //清空信息列表框的内容
      listData3.clear();
      String fileName = "";
      for(int i = 0; i < selectedIndexes.length; i++){
        fileName = (String)listData2.getElementAt(selectedIndexes[i]);
        //根据文件名取得数据表的名字
        String tableName = fileName.substring(0, fileName.indexOf(".dat"));
        //检查数据表名字是否存在
        if(listData1.indexOf(tableName) == -1){
          JOptionPane.showMessageDialog(null, fileName + "文件的数据表在数据库不存在，"
                                        + "不可以进行恢复操作.");
          continue;
        }
        try{
          restoreTable(fileName, tableName, pathName);
        }catch(Exception ex){
          ex.printStackTrace();
        }
      }
    //单击恢复全部文件按钮的处理代码
    }else if(actionCommand.equals("restoreAllFiles")){
      //取得文件路径
      String pathName = jTextField1.getText().trim();
      if(pathName.length() == 0){
        JOptionPane.showMessageDialog(null, "请选择备份文件目录.");
        return;
      }
      if(listData2.size() == 0){
        JOptionPane.showMessageDialog(null, "请显示备份文件.");
        return;
      }
      if(listData1.size() == 0){
        JOptionPane.showMessageDialog(null, "请显示数据表.");
        return;
      }
      //清空信息列表框的内容
      listData3.clear();
      String fileName = "";
      for(int i = 0; i < listData2.size(); i++){
        fileName = (String)listData2.getElementAt(i);
        //根据文件名取得数据表的名字
        String tableName = fileName.substring(0, fileName.indexOf(".dat"));
        //检查数据表名字是否存在
        if(listData1.indexOf(tableName) == -1){
          JOptionPane.showMessageDialog(null, fileName + "文件的数据表在数据库不存在，"
                                        + "不可以进行恢复操作.");
          continue;
        }
        try{
          restoreTable(fileName, tableName, pathName);
        }catch(Exception ex){
          ex.printStackTrace();
        }
      }
    }else if(actionCommand.equals("exit")){
      exit();
    }
  }
  //将数据表数据保存在文件的方法
  public void backupTable(String tableName, String pathName) throws Exception{
    String[][] data = null;
    //创建文件类
    File file = new File(pathName + "\\" + tableName + ".dat");
    if(file.isFile()){
      //取得信息确认框的返回值
      int actionInt = JOptionPane.showConfirmDialog(null, tableName + ".dat"
          + "文件已存在，是否覆盖该文件?", "信息确认框",
          JOptionPane.YES_NO_OPTION, JOptionPane.INFORMATION_MESSAGE);
      //如果单击否按钮，不进行覆盖操作
      if(actionInt == JOptionPane.NO_OPTION){
        listData3.addElement(tableName + ".dat文件已存在，不进行覆盖操作.");
        return;
      }
    }
    //创建文件写出类
    FileWriter writer = new FileWriter(pathName + "\\" + tableName + ".dat");
    //取得数据表的数据
    data = stockManagementData.getDataByTableName(tableName);
    for (int row = 0; row < data.length; row++) {
      for (int col = 0; col < data[0].length; col++) {
        //如果字段值为空值，转换为null字符串，如果字段值的长度为度，加入一个空格
        if(data[row][col] == null){
          data[row][col] = "null";
        }else if(data[row][col].length() == 0){
          data[row][col] = " ";
        }
        if(col == data[0].length -1){
          //\n是换行符
          writer.write(data[row][col] + "\n");
        }else{
          //\t是水平制表符
          writer.write(data[row][col] + "\t");
        }
      }
    }
    //关闭文件写出类
    writer.close();
    listData3.addElement(tableName + "数据表成功备份，数据表的保存路径是" + pathName + ".");
    //将用户备份数据表信息写入日志数据表
    stockManagementData.createUserLog("数据备份窗口", tableName + "数据表备份操作",
                                      user.getUserName());

  }
  //将文件数据写入数据表的方法
  public void restoreTable(String fileName, String tableName, String pathName) throws
      Exception {
    //创建数组
    String[][] data = null;
    File inFile = new File(pathName + "\\" + fileName);
    //读入文件
    FileReader reader = new FileReader(inFile);
    //创建集合类
    Vector vector = new Vector();
    BufferedReader bufferedReader = new BufferedReader(reader);
    while (bufferedReader.ready()) {
      //读入一行内容
      vector.add(bufferedReader.readLine());
    }
    if (vector.size() > 0) {
      //取得行总数
      int rowLength = vector.size();
      String tempStr = (String) vector.get(0);
      StringTokenizer stringToken = new StringTokenizer(tempStr, "\t");
      //取得列总数
      int colLength = stringToken.countTokens();
      //根据行和列的总数创建内容数组
      data = new String[rowLength][colLength];
      for (int row = 0; row < rowLength; row++) {
        stringToken = new StringTokenizer( (String) vector.get(row), "\t");
        for (int col = 0; col < colLength; col++) {
          tempStr = stringToken.nextToken();
          //取代/n字符串
          tempStr.replace('\n', ' ');
          tempStr = tempStr.trim();
          //向数组写入内容
          data[row][col] = tempStr;
        }
      }
      //将数组数据写入数据表
      stockManagementData.setDataByTableName(tableName, data);
      listData3.addElement(fileName + "文件的数据已写入数据表" + tableName + ".");
      //将用户恢复数据表信息写入日志数据表
      stockManagementData.createUserLog("数据备份窗口", tableName + "数据表恢复操作",
                                        user.getUserName());
    }
    else {
      listData3.addElement(fileName + "文件没有数据.");
    }
  }
}
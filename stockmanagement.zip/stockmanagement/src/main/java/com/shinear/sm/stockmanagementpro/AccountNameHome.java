﻿package com.shinear.sm.stockmanagementpro;

import javax.ejb.*;
import java.util.*;

public interface AccountNameHome extends javax.ejb.EJBLocalHome {
  public AccountName create(Integer accountId, int parentId, String accountName) throws
      CreateException;
  public Collection findAll() throws FinderException;
  public Collection findByParentId(int parentId) throws FinderException;
  public AccountName findByPrimaryKey(Integer accountId) throws FinderException;
}
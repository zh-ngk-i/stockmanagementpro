﻿package com.shinear.sm.stockmanagementpro;

import javax.ejb.*;

abstract public class UserLogBean implements EntityBean {
  EntityContext entityContext;
  public java.lang.Integer ejbCreate(java.lang.Integer id, java.lang.String programName, java.lang.String operationContent, java.lang.String userName, java.sql.Timestamp operationDate) throws CreateException {
    setId(id);
    setProgramName(programName);
    setOperationContent(operationContent);
    setUserName(userName);
    setOperationDate(operationDate);
    return null;
  }

  public void ejbPostCreate(java.lang.Integer id, java.lang.String programName, java.lang.String operationContent, java.lang.String userName, java.sql.Timestamp operationDate) throws CreateException {
  }
  public void ejbRemove() throws RemoveException {
  }
  public abstract void setId(java.lang.Integer id);
  public abstract void setProgramName(java.lang.String programName);
  public abstract void setOperationContent(java.lang.String operationContent);
  public abstract void setUserName(java.lang.String userName);
  public abstract void setOperationDate(java.sql.Timestamp operationDate);
  public abstract java.lang.Integer getId();
  public abstract java.lang.String getProgramName();
  public abstract java.lang.String getOperationContent();
  public abstract java.lang.String getUserName();
  public abstract java.sql.Timestamp getOperationDate();
  public void ejbLoad() {
  }
  public void ejbStore() {
  }
  public void ejbActivate() {
  }
  public void ejbPassivate() {
  }
  public void unsetEntityContext() {
    this.entityContext = null;
  }
  public void setEntityContext(EntityContext entityContext) {
    this.entityContext = entityContext;
  }
}